scripts/generic.sh tools.ConvertTT2BinaryNioBuffer $@
