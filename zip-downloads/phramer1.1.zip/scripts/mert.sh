#!/bin/sh

java -Dfile.encoding=ISO-8859-1 -cp ../phramer/bin.jar -Xmx500m org.phramer.v1.decoder.main.MERTMain $1 $2 $3 $4 $5