scripts/generic.sh tools.ConvertLM2Binary $@
