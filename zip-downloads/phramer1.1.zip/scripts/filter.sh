#!/bin/sh

java -Dfile.encoding=ISO-8859-1 -cp ../phramer/bin.jar -Xmx500m org.phramer.tools.FilterTranslationTable $1 $2 $3 $4 $5 $6 $7 $8 $9