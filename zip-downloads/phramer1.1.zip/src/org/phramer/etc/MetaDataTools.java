/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.etc;
import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import java.util.*;

public class MetaDataTools
{
	
	public static String[] serialize(Map<String, String[]>[] metaData)
	{
		Vector<String> out = new Vector<String>();
		for (Map<String, String[]> m : metaData)
			serialize(out , m);
		return StringTools.array(out);
	}
	
	public static String[] serialize(Map<String, String[]> metaData)
	{
		Vector<String> out = new Vector<String>();
		serialize(out , metaData);
		return StringTools.array(out);
	}
	
	public static void serialize(Vector<String> out , Map<String, String[]> metaData)
	{
		out.add(String.valueOf(metaData.size()));
		Iterator<String> iter = metaData.keySet().iterator();
		while (iter.hasNext())
		{
			String key = iter.next();
			out.add(key);
			String[] value = metaData.get(key);
			out.add(String.valueOf(value.length));
			for (String v : value)
				out.add(v);
		}
	}
	
	private static String readValue(String[] input , MutableInt cursor)
	{
		return input[cursor.value++];
	}
	private static String[] readArray(String[] input , MutableInt cursor)
	{
		int len = Integer.parseInt(readValue(input, cursor));
		String[] array = new String[len];
		for (int i = 0; i < array.length; i++)
			array[i] = readValue(input, cursor);
		return array;
	}
	
	public static Map<String,String[]> deserialize(String[] input, MutableInt cursor)
	{
		int len = Integer.parseInt(readValue(input, cursor));
		if (len == 0)
			return null;
		HashMap<String,String[]> map = new HashMap<String, String[]>(len);
		for (int i = 0; i < len; i++)
		{
			String key = readValue(input, cursor);
			String value[] = readArray(input, cursor);
			map.put(key, value);
		}
		return map;
	}
	public static Map<String,String[]>[] deserialize(String[] input, int startCursor, int count)
	{
		Map<String,String[]>[] out = new Map[count];
		MutableInt cursor = new MutableInt(startCursor);
		for (int i = 0; i < out.length; i++)
			out[i] = deserialize(input, cursor);
		return out;
	}
}
