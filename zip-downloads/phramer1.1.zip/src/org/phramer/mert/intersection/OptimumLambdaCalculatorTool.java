/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.mert.intersection;
import java.util.*;
import org.phramer.*;
import org.phramer.mert.evaluation.*;
import org.phramer.mert.intersection.initialize.*;
import org.phramer.mert.item.*;
import org.phramer.mert.math.*;

public class OptimumLambdaCalculatorTool
{
	public static boolean DEBUG = false;
	public static java.io.PrintStream DEBUG_OUT = System.err;
	
	// debug: orthogonal only - check if consistent evaluation
	public static boolean DEBUG_ASSERT = false;
	public static ReferenceWithHypotheses[] __DEBUG_f;
	public static double[] __DEBUG_lbd;
	public static int __DEBUG_idxLbd;
	
	
	public static double DELTA = 0.1;
	public static double COEF = 1.5;
	public static double BASE = 0.0;
	
	
	protected static List<Point> computeIntersectionPoints(Line[] line, int refIndex)
	{
		line = line.clone();
		// NEED: t(e,f), m(e,f)
		
		// order the lines by how steep are they
		Arrays.sort(line);
		
		// first point
		// gamma = -Infinity: look for lowest steep
		Point first = new Point(Double.NEGATIVE_INFINITY, line[0] , null , refIndex , line[0].getOriginalIdx());
		
		List<Point> out = new ArrayList<Point>();
		out.add(first);
		
		int index = 0;
		Line lastLine = line[0];
		double lastLambda = first.lambda;
		// now iterate throughly
		
		// skip same steep
		while (index < line.length && NumberManager.lowerEqualM(line[index].m , lastLine.m))
			index++;
		
		// look for index for next intersection point
		if (index != line.length)
			while (true)
			{
				int bestIdx = -1;
				double lambdaBest = Double.POSITIVE_INFINITY;
				// look for intersections starting that point
				assert index > 0;
				for (int i = index; i < line.length; i++)
					if (line[i].m > line[i - 1].m)// ignore lines with same steep but lower
					{
						// compute intersection: (t2-t1) / (m1 - m2)
						//double lambda = (lastLine.t - line[i].t) / (line[i].m - lastLine.m);
						// NUMERIC ANOMALY: not solved here
						// negative div negative
						double lambda = (line[i].t - lastLine.t) / (lastLine.m - line[i].m);
						
//						double deltaM = (lastLine.m - line[i].m);// negative
//						double deltaT = line[i].t - lastLine.t; // negative
//						double lambda = deltaT / deltaM;
						
						lambda = NumberManager.adjustLambda(lambda);
						
						if (lambda > lastLambda)
							if (lambda <= lambdaBest) // take last, meaning highest steep
							{
								lambdaBest = lambda;
								bestIdx = i;
							}
					}
				
				if (bestIdx != -1)
				{
					Point newPoint = new Point(lambdaBest , line[bestIdx] , lastLine , refIndex, line[bestIdx].getOriginalIdx());
					lastLambda = lambdaBest;
					index = bestIdx;
					
					lastLine = line[bestIdx];
					
					out.add(newPoint);
					// skip same steep
					while (index < line.length && NumberManager.lowerEqualM(line[index].m , lastLine.m))
						index++;
				}
				else
					break;
			}
		
		return out;
	}
	
	public static LambdaScorePair getBestLambda(Line[][] line , Evaluator evaluator)
	throws PhramerException
	{
		List<Point> points = new ArrayList<Point>();
		for (int i = 0; i < line.length; i++)
			points.addAll(computeIntersectionPoints(line[i], i));
		
		// sort by lambda only
		Collections.sort(points , new Comparator<Point>()
			{
				public int compare(Point o1, Point o2)
				{
					if (o1.lambda < o2.lambda)
						return -1;
					if (o1.lambda > o2.lambda)
						return 1;
					return 0;
				}
			});
		
		// <DEBUG>
		int cntDistinct = 1;
		int positionBest[] = null;
		int position[] = new int[line.length];
		// </DEBUG>
		
		// now, initialize error state
		HypothesisErrorStatistics[] sErr = new HypothesisErrorStatistics[line.length];
		// initialize from all with -Infinity
		int index = 0;
		for (; index < points.size(); index++)
		{
			Point p = points.get(index);
			if (p.lambda != Double.NEGATIVE_INFINITY)
				break;
			sErr[p.refIndex] = p.onRight.hypothesis.error;
			
			if (DEBUG || DEBUG_ASSERT)
				position[p.refIndex] = p.originalPositionInNbest;
		}
		double bestLambda = index < points.size() ? getExtreme(points.get(index).lambda , -1) : BASE;
		double bestScore = evaluator.getScore(sErr);
		
		if (DEBUG)
		{
			DEBUG_OUT.println("Points (cnt=" + points.size() + ")");
			DEBUG_OUT.println(bestLambda + "\t" + bestScore);
		}
		if (DEBUG || DEBUG_ASSERT)
			positionBest = position.clone();
		
		while (index < points.size())
		{
			// add new points
			double currentLambda = points.get(index).lambda;
			double currentLambdaX = currentLambda;
			// update the errors
			for (; index < points.size(); index++)
			{
				Point p = points.get(index);
				
				// NUMERIC ISSUE:
				if (!NumberManager.equalSuccesiveLambdas(currentLambdaX , p.lambda))
					break;
				
				sErr[p.refIndex] = p.onRight.hypothesis.error;
				currentLambdaX = p.lambda;
				
				if (DEBUG || DEBUG_ASSERT)
					position[p.refIndex] = p.originalPositionInNbest;
			}
			// calculate new lambdas
			double lambda = index < points.size() ?
				(points.get(index).lambda + currentLambda) / 2
				: getExtreme(currentLambda , +1);
			double score = evaluator.getScore(sErr);
			
			if (DEBUG)
			{
				DEBUG_OUT.println(lambda + "\t" + score);
				cntDistinct++;
			}
			if (DEBUG_ASSERT)
			{
				// check if score is really consistent
				double[] newLambda = __DEBUG_lbd.clone();
				// orthogonal only:
				newLambda[__DEBUG_idxLbd] += lambda;
				double scoreX = ItemTools.evaluate(__DEBUG_f , newLambda , evaluator);
				if (score != scoreX)
				{
					Line[][] l = InitializeLines.getLinesWithoutM(__DEBUG_f , newLambda);
					int[] best = ItemTools.getBestIdx(l);
					// see where don't match:
					
					for (int i = 0; i < best.length; i++)
						if (position[i] != best[i])
						{
							DEBUG_OUT.println(index + " Missmatch at " + i + ": best hypo " + best[i] + " vs. iterative hypo " + position[i]);
							DEBUG_OUT.println(l[i][best[i]].t + l[i][best[i]].m * lambda);
							DEBUG_OUT.println(l[i][position[i]].t + l[i][position[i]].m * lambda);
						}
					DEBUG_OUT.println("lambda=" + lambda + " real=" + scoreX + " iterative=" + score);
					assert false : "Scores don't match: real=" + scoreX + " iterative=" + score;
				}
			}
			
			// better?
			if (score > bestScore)
			{
				bestScore = score;
				bestLambda = lambda;
				
				if (DEBUG || DEBUG_ASSERT)
					positionBest = position.clone()	;
			}
		}
		if (DEBUG)
		{
			DEBUG_OUT.println("Distinct points: " + cntDistinct);
			DEBUG_OUT.println("Index best: ");
			for (int i = 0; i < positionBest.length; i++)
			{
				if (i != 0)
					DEBUG_OUT.print(' ');
				DEBUG_OUT.print("p[" + i + "]=" + positionBest[i]);
			}
			DEBUG_OUT.println();
		}
		
		return new LambdaScorePair(bestLambda , bestScore);
	}
	
	private static double getExtreme(double currentLambda , int sign)
	{
		if (Math.abs(currentLambda) > 1)
			return currentLambda + sign * Math.abs(currentLambda) * COEF;
		return currentLambda + sign * DELTA;
	}
}
