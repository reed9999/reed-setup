/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.mert;

import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import java.io.*;
import java.util.*;
import org.phramer.mert.evaluation.*;
import org.phramer.mert.generation.*;
import org.phramer.mert.item.*;
import org.phramer.mert.strategy.*;
import org.phramer.mert.strategy.implementations.*;
import org.phramer.v1.decoder.mert.generation.*;
import org.phramer.*;


public class MinimumErrorRateTraining
{
	public static int DEBUG = 1;
	public static PrintStream LOGGER = System.out;
	
	public static double[] searchLambda(ReferenceLoader loader ,
										NewHypothesesGenerationManager mgr ,
										Evaluator eval ,
										SearchLambdaStrategy strategy ,
										LambdaNormalizer normalizer ,
										String fileRef ,
										String[] filesRef ,
										double[] initialLambda ,
										List<Hypothesis>[] initialPoints
										)
	throws Exception
	{
		return searchLambda(loader , mgr , eval , strategy , normalizer , fileRef , filesRef , initialLambda , initialPoints , null);
	}
	public static double[] searchLambda(ReferenceLoader loader ,
										NewHypothesesGenerationManager mgr ,
										Evaluator eval ,
										SearchLambdaStrategy strategy ,
										LambdaNormalizer normalizer ,
										String fileRef ,
										String[] filesRef ,
										double[] initialLambda ,
										List<Hypothesis>[] initialPoints ,
										double[][] forcedLambda
										)
	throws Exception
	{
		__________debug_loadingReferences();
		
		Item[][] ref = fileRef != null ? loader.readReference_R1(fileRef)
			:  loader.readReference_Rn(filesRef);
		ReferenceWithHypotheses[] refH = loader.getEmptyReferenceWithHypotheses(ref);
		
		double[] lambda = initialLambda.clone();
		double[] bestLambda = null;
		double bestScore = eval.bestIsSmall() ? Double.POSITIVE_INFINITY : Double.NEGATIVE_INFINITY;
		
		__________debug_start();
		
		Chronometer c = new Chronometer(true);
		Chronometer cSearch = new Chronometer();
		cSearch.startPaused();
		
		int iteration = 0;
		int hypoCount = 0;
		while (true)
		{
			iteration++;
			Chronometer c1 = new Chronometer(true);
			// first, normalize
			normalizer.normalize(lambda);
			
			__________debug_gettingNewHypo(iteration , initialPoints);
			
			// get new hypotheses
			// use initial points in the first step, if
			List<Hypothesis>[] newHypos;
			if (initialPoints != null && iteration == 1)
				newHypos = initialPoints;
			else
				newHypos = mgr.getHypotheses(lambda, iteration);
			
			
			
			// put error data
			putError(newHypos, eval, ref);
			
			
			
			// current score...
			double thisScore = getNewScore(refH , eval , newHypos , lambda);
			
			__________debug_newHypoGot(iteration, refH, eval , newHypos , lambda);
			
			// add the new hypotheses to the current hypo
			int newHypoCount = addNewHypothesesToCurrentSet(refH, newHypos, iteration, lambda, eval , hypoCount);
			hypoCount += newHypoCount;
			
			
			// if nothing new, break
			if (newHypoCount == 0)
				break;
			
			
			// search for new stuff
			__________debug_searchThroughCurrentSets(iteration);
			
			Chronometer c2 = new Chronometer(true);
			cSearch.resume();
			double[] lastLambda = lambda;
			// allow forced lambdas for debug purposes: ability to resume
			if (forcedLambda != null && (iteration - 1) < forcedLambda.length)
				lambda = forcedLambda[iteration - 1].clone();
			else
				lambda = strategy.getNewLambdas(iteration , eval , refH ,
												lambda ,
												lambda != bestLambda ? bestLambda : null ,
												Integer.MAX_VALUE);
			cSearch.pause();
			__________debug_printNewLambda(iteration, refH , lambda , strategy.getLastSearchInfo() , eval , c1 , c2);
			
			
			// prepare bestLambda
			if (thisScore > bestScore && !eval.bestIsSmall()
				|| thisScore < bestScore && eval.bestIsSmall())
			{
				bestScore = thisScore;
				// change 01/15/06: fix to lastLambda
				bestLambda = lastLambda;
			}
			
			
			// if last lambda equals current lambda, then stop
			if (equalsL(lastLambda , lambda))
			{
				__________debug_end();
				break;
			}
		}
		
		__________debug_printFinalScorePreNormalized(refH, lambda, eval);
		
		// final normalization
		normalizer.normalize(lambda);
		
		__________debug_printFinalScorePostNormalized(refH, lambda, eval);
		__________debug_finalPrint(c, cSearch , mgr, lambda);
		
		return lambda;
	}
	
	private static int addNewHypothesesToCurrentSet(ReferenceWithHypotheses[] refH, List<Hypothesis>[] newHypos, int iteration, double[] lambda, Evaluator eval , int hypoCount)
	{
		int[] nhc = new int[refH.length];
		int hypoAddedCount = 0 , newHypoCount = 0;
		for (int i = 0; i < refH.length; i++)
		{
			newHypoCount += newHypos[i].size();
			for (Hypothesis newHypo : newHypos[i])
				if (!refH[i].hypotheses.contains(newHypo))
				{
					// put new ones in the beginning
					refH[i].hypotheses.add(nhc[i]++ , newHypo);
					hypoAddedCount ++;
				}
		}
		__________debug_printInitialLambda(iteration, refH, lambda, eval , hypoAddedCount , newHypoCount , hypoCount + hypoAddedCount);
		return hypoAddedCount;
	}
	
	private static void putError(List<Hypothesis>[] newHypos, Evaluator eval, Item[][] ref)
	{
		for (int i = 0; i < newHypos.length; i++)
			for (Hypothesis newHypo : newHypos[i])
				newHypo.error = eval.getErrorStatistics(ref[i] , newHypo.h);
	}
	
	private static boolean equalsL(double[] lastLambda, double[] lambda)
	{
		for (int i = 0; i < lastLambda.length; i++)
			if (lastLambda[i] != lambda[i])
				return false;
		return true;
	}
	
	private static double getNewScore(ReferenceWithHypotheses[] refH, Evaluator eval , List<Hypothesis>[] newHypos , double[] lambda) throws PhramerException
	{
		// backup, put new hypos
		List<Hypothesis>[] oldHypos = new List[refH.length];
		for (int i = 0; i < oldHypos.length; i++)
		{
			oldHypos[i] = refH[i].hypotheses;
			refH[i].hypotheses = newHypos[i];
		}
		
		double currentScore = ItemTools.evaluate(refH , lambda , eval);
		
		// restore
		for (int i = 0; i < oldHypos.length; i++)
			refH[i].hypotheses = oldHypos[i];
		
		return currentScore;
	}
	
	
	
	
	private static void __________debug_searchThroughCurrentSets(int iteration)
	{
		if (DEBUG >= 1)
			LOGGER.println("(" + iteration + ") Search lambda using new sets...");
	}
	
	private static void __________debug_newHypoGot(int iteration, ReferenceWithHypotheses[] refH, Evaluator eval , List<Hypothesis>[] newHypos , double[] lambda) throws PhramerException
	{
		if (DEBUG >= 1)
		{
			LOGGER.println("(" + iteration + ") Adding the new hypotheses to the old set...");
			// TODO: redundancy with getNewScore
			// backup, put new hypos
			List<Hypothesis>[] oldHypos = new List[refH.length];
			for (int i = 0; i < oldHypos.length; i++)
			{
				oldHypos[i] = refH[i].hypotheses;
				refH[i].hypotheses = newHypos[i];
			}
			LOGGER.println("(" + iteration + ") Current score: " + ItemTools.evaluate(refH , lambda , eval));
			LOGGER.println("(" + iteration + ") Oracle score new set: " + EvaluationTools.getOracle(refH , eval));
			
			// restore
			for (int i = 0; i < oldHypos.length; i++)
				refH[i].hypotheses = oldHypos[i];
			
		}
	}
	
	private static void __________debug_gettingNewHypo(int iteration , List<Hypothesis>[] initialPoints)
	{
		if (DEBUG >= 1)
		{
			if (initialPoints != null && iteration == 1)
				LOGGER.println("(" + iteration + ") Using initial hypotheses set");
			else
				LOGGER.println("(" + iteration + ") Getting new hypotheses...");
		}
	}
	
	private static void __________debug_start()
	{
		if (DEBUG >= 1)
			LOGGER.println("Start search");
	}
	
	private static void __________debug_loadingReferences()
	{
		if (DEBUG >= 1)
			LOGGER.println("Loading reference...");
	}
	
	private static void __________debug_finalPrint(Chronometer c, Chronometer cSearch , NewHypothesesGenerationManager mgr, double[] lambda)
	{
		c.stop();
		if (DEBUG >= 1)
		{
			LOGGER.println("Search ended. Time: " + StringTools.formatDouble(c.getValue() / 1000.0 , "0.00") + " seconds");
			LOGGER.println("Time search only: " + StringTools.formatDouble(cSearch.getValue() / 1000.0 , "0.00") + " seconds");
			
			// print final lambda:
			LOGGER.println("Decoder parameters:");
			LOGGER.println(mgr.printDecoderParameters(lambda));
		}
	}
	
	private static void __________debug_printFinalScorePostNormalized(ReferenceWithHypotheses[] refH, double[] lambda, Evaluator eval) throws PhramerException
	{
		if (DEBUG >= 1)
		{
			LOGGER.println("Final score after normalization: " + ItemTools.evaluate(refH , lambda , eval));
			LOGGER.print("Final normalized lambdas: ");
			SearchLambdaStrategyOrthogonal.__DBG_printLambda(lambda , -1 , LOGGER);
		}
	}
	
	private static void __________debug_printFinalScorePreNormalized(ReferenceWithHypotheses[] refH, double[] lambda, Evaluator eval) throws PhramerException
	{
		if (DEBUG >= 1)
		{
			LOGGER.println("Final score before normalization: " + ItemTools.evaluate(refH , lambda , eval));
			LOGGER.print("Final unnormalized lambdas: ");
			SearchLambdaStrategyOrthogonal.__DBG_printLambda(lambda , -1 , LOGGER);
		}
	}
	
	private static void __________debug_printNewLambda(int iteration, ReferenceWithHypotheses[] refH, double[] lambda , Object infoSearch , Evaluator eval , Chronometer c1 , Chronometer c2) throws PhramerException
	{
		c2.stop();
		if (DEBUG >= 2)
		{
			LOGGER.print("(" + iteration + ") New lambdas: ");
			SearchLambdaStrategyOrthogonal.__DBG_printLambda(lambda , -1 , LOGGER);
		}
		if (DEBUG >= 1)
		{
			LOGGER.println("(" + iteration + ") New score: " + ItemTools.evaluate(refH , lambda , eval));
			c1.stop();
			if (infoSearch != null)
				LOGGER.println("(" + iteration + ") Info search: " + infoSearch);
			LOGGER.println("(" + iteration + ") Time iteration: " + StringTools.formatDouble(c1.getValue() / 1000.0 , "0.00") + " seconds");
			LOGGER.println("(" + iteration + ") Time search: " + StringTools.formatDouble(c2.getValue() / 1000.0 , "0.00") + " seconds");
		}
	}
	
	private static void __________debug_printInitialLambda(int iteration, ReferenceWithHypotheses[] refH, double[] lambda, Evaluator eval , int hypoAddedCount , int newHypoCount , int hypoCount)
	{
		if (DEBUG >= 1)
		{
			LOGGER.println("(" + iteration + ") Added " + hypoAddedCount + "/" + newHypoCount + " new hypotheses. Total: " + hypoCount);
			
//			if (iteration == 1)
//				LOGGER.println("(" + iteration + ") Initial score: " + ItemTools.evaluate(refH , lambda , eval));
			
			// get oracle on these ones
			if (iteration > 1)
				LOGGER.println("(" + iteration + ") Oracle score on merged: " + EvaluationTools.getOracle(refH , eval));
		}
	}
	
	private static void __________debug_end()
	{
		if (DEBUG >= 1)
			LOGGER.println("Same lambda as before. Stop.");
	}
}
