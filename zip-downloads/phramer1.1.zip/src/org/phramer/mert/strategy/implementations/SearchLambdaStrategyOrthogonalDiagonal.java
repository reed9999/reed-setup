/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.mert.strategy.implementations;
import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import org.phramer.*;
import org.phramer.mert.evaluation.*;
import org.phramer.mert.intersection.*;
import org.phramer.mert.intersection.initialize.*;
import org.phramer.mert.item.*;
import org.phramer.mert.strategy.*;

// TODO: intervals
public class SearchLambdaStrategyOrthogonalDiagonal implements SearchLambdaStrategy, SearchLambdaStep
{
	public String __DBG_prefix = "(1";
	public PrintStream d = System.err;
	public int DEBUG_LEVEL = 1;
	private final int steps;
	/* <Insertion> */
	private final int cntDiagonal;
	/* </Insertion> */
	private final double[][] intervalsRandom;
	private final double minDeltaScore;
	public SearchLambdaStrategyOrthogonalDiagonal(int steps , int countDiagonalDirectionsPerStep , double[][] intervalsRandom , double[][] intervalsLambda , double minDeltaScore)
	{
		this.steps = steps;
		this.intervalsRandom = intervalsRandom;
		this.minDeltaScore = minDeltaScore;
		/* <Insertion> */
		this.cntDiagonal = countDiagonalDirectionsPerStep;
		/* </Insertion> */
	}
	
	private int bestLambdaIndex = -1;
	public double[] getNewLambdas(final int iteration ,
								  final Evaluator e ,
								  final ReferenceWithHypotheses[] f,
								  final double[] initialLambda,
								  final double[] bestPrevLambda,
								  int maxLambdaAlter) throws PhramerException
	{
		// initialize
		if (__DBG_prefix.startsWith("("))
			__DBG_prefix = "(" + iteration;
		
		if (maxLambdaAlter > initialLambda.length)
			maxLambdaAlter = initialLambda.length;
		
		double[] bestLambdas = null;
		double bestScore = Double.NEGATIVE_INFINITY;
		int bestLambdaIndex = -1;
		for (int i = 0; i < steps; i++)
		{
			// initialize lambda
			double[] lambda;
			if (i == 0)
				lambda = initialLambda.clone();
			else
			if (i == 1 && bestPrevLambda != null)
				lambda = bestPrevLambda.clone();
			else
			{
				lambda = new double[initialLambda.length];
				// random points
				for (int k = 0; k < maxLambdaAlter; k++)
					lambda[k] = intervalsRandom[k][0] + (intervalsRandom[k][1] - intervalsRandom[k][0]) * Math.random();
				
				// copy those not to be altered
				for (int k = maxLambdaAlter ; k < initialLambda.length ; k++)
					lambda[k] = initialLambda[k];
			}
			
			double currentScore = executeStep(lambda , i + 1 , e , f , initialLambda.length , maxLambdaAlter);
			
			// we have a best, from that starting point
			if (currentScore > bestScore)
			{
				bestScore = currentScore;
				bestLambdas = lambda;
				bestLambdaIndex = i;
			}
		}
		if (DEBUG_LEVEL >= 1)
		{
			d.println(__DBG_prefix + ") End lambdas: ");
			__DBG_printLambda(bestLambdas, -1, d);
			d.println(__DBG_prefix + ") Score: " + bestScore);
		}
		this.bestLambdaIndex = bestLambdaIndex;
		return bestLambdas;
	}
	
	public double executeStep(double[] lambda , int iterNo , Evaluator e , ReferenceWithHypotheses[] f , int n , int maxLambdaAlter)
	throws PhramerException
	{
		// play with lambdas
		Line[][] lines = InitializeLines.getLinesWithoutM(f , lambda);
		// initialization: too slow?
		double currentScore = ItemTools.evaluate(lines , e);
		
		if (DEBUG_LEVEL >= 1)
		{
			d.print(__DBG_prefix + "." + iterNo + ") Start Lambda=");
			__DBG_printLambda(lambda, -1, d);
			d.println(__DBG_prefix + "." + iterNo + ") Score: " + ItemTools.evaluate(f , lambda , e));
		}
		
		int iter = 1;
		while (true)
		{
			lines = InitializeLines.getLinesWithoutM(f , lambda);
			int chosenIndex = -1;
			LambdaScorePair localBest = null;
			/** <Insertion> **/
			// get a random direction
			double[] bestDiagonalDirection = null;
			for (int j = 1 ; j <= cntDiagonal ; j++)
			{
				double[] diagonalDirection = new double[n];
				// random points
				for (int k = 0; k < maxLambdaAlter; k++)
					diagonalDirection[k] = Math.random() - 0.5;
				// put one equal to 1, at random
				diagonalDirection[(int)(Math.random() * Integer.MAX_VALUE) % maxLambdaAlter] = 1;
				
				// not alterable
				for (int k = maxLambdaAlter ; k < n ; k++)
					diagonalDirection[k] = 0;
				
				// now get score
				assert __DBG_initializeDebugDataPointSearch(f , lambda , e , -j);
				
				InitializeLines.setMGenericDirection(lines , diagonalDirection);
				
				// get best on this one
				LambdaScorePair q = OptimumLambdaCalculatorTool.getBestLambda(lines , e);
				if (DEBUG_LEVEL >= 1)
					d.println(__DBG_prefix + "." + iterNo + "." + iter + ".D" + j + ") Score by altering lambda on axis (delta=" + StringTools.formatDouble(q.lambda, "0.######") + "): " + q.score);
				
				if (localBest == null || q.score > localBest.score)
				{
					bestDiagonalDirection = diagonalDirection;
					localBest = q;
				}
				chosenIndex = -2;
			}
			/** </Insertion> **/
			
			for (int j = 0; j < maxLambdaAlter; j++)
			{
				// initialize stuff for debugging
				assert __DBG_initializeDebugDataPointSearch(f , lambda , e , j);
				
				InitializeLines.setMOrthogonalDirection(lines , j);
				// get best on this one
				LambdaScorePair q = OptimumLambdaCalculatorTool.getBestLambda(lines , e);
				if (DEBUG_LEVEL >= 1)
					d.println(__DBG_prefix + "." + iterNo + "." + iter + "." + j + ") Score by altering lambda on axis (delta=" + StringTools.formatDouble(q.lambda, "0.######") + "): " + q.score);
				if (localBest == null || q.score > localBest.score)
				{
					localBest = q;
					chosenIndex = j;
				}
			}
			if (localBest.score > currentScore + minDeltaScore)
			{
				/** <Insertion> **/
				if (chosenIndex == -2)
				// add direction * localBest.lambda
					for (int j = 0 ; j < lambda.length ;j++)
						lambda[j] += bestDiagonalDirection[j] * localBest.lambda;
				else
				/** </Insertion> **/
					lambda[chosenIndex] += localBest.lambda;
				currentScore = localBest.score;
				
				// check if score is really consistent
				assert ItemTools.evaluate(f , lambda , e) == currentScore : "different scores: real=" + ItemTools.evaluate(f , lambda , e) + "/reported=" + currentScore + " " + __DBG_printIdx(f, lambda);
				
				if (DEBUG_LEVEL >= 1)
				{
					d.print(__DBG_prefix + "." + iterNo + "." + iter + ") Updated score (idx=" + chosenIndex + ") BLEU=" + currentScore + " Lambda=");
					__DBG_printLambda(lambda, chosenIndex, d);
					if (DEBUG_LEVEL >= 2)
						__DBG_printBestChoice(f , lambda);
				}
				
				iter++;
			}
			else
			{
				if (DEBUG_LEVEL >= 1)
					d.println(__DBG_prefix + "." + iterNo + "." + iter + ") Failed to find better (" + localBest.score + ")");
				
				break;
			}
		}
		return currentScore;
	}
	
	
	private boolean __DBG_initializeDebugDataPointSearch(ReferenceWithHypotheses[] f, double[] lambda, Evaluator e, int j)
	{
		OptimumLambdaCalculatorTool.__DEBUG_f = f;
		OptimumLambdaCalculatorTool.__DEBUG_lbd = lambda.clone();
		OptimumLambdaCalculatorTool.__DEBUG_idxLbd = j;
		OptimumLambdaCalculatorTool.DEBUG_ASSERT = true;
		return true;
	}
	
	
	public String __DBG_printIdx(ReferenceWithHypotheses[] f, double[] lambda) throws PhramerException
	{
		d.println("Best choice:");
		Line[][] l = InitializeLines.getLinesWithoutM(f , lambda);
		int[] best = ItemTools.getBestIdx(l);
		for (int i = 0; i < best.length; i++)
		{
			if (i != 0)
				d.print(' ');
			d.print("p[" + i + "]=" + best[i]);
		}
		d.println();
		return "";
	}
	
	private void __DBG_printBestChoice(ReferenceWithHypotheses[] f, double[] lambda) throws PhramerException
	{
		Line[][] l = InitializeLines.getLinesWithoutM(f , lambda);
		int[] best = ItemTools.getBestIdx(l);
		d.print("Index:");
		for (int i = 0; i < best.length; i++)
			d.print(" " + best[i]);
		d.println();
	}
	
	public static void __DBG_printLambda(double[] lambda, int chgIdx , PrintStream log)
	{
		log.print("(");
		for (int j = 0; j < lambda.length; j++)
			log.print((j > 0 ?",": "") + (j == chgIdx ?"*": "") + lambda[j] + (j == chgIdx ?"*": ""));
		log.println(")");
	}
	
	public Object getLastSearchInfo()
	{
		return bestLambdaIndex;
	}
}
