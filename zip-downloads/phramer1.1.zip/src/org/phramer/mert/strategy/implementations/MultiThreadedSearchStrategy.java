/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.mert.strategy.implementations;
import info.olteanu.utils.workpool.*;
import info.olteanu.utils.workpool.impl.*;
import org.phramer.*;
import org.phramer.mert.evaluation.*;
import org.phramer.mert.item.*;
import org.phramer.mert.strategy.*;
import java.io.*;

public class MultiThreadedSearchStrategy implements SearchLambdaStrategy
{
	public String __DBG_prefix = "(1";
	public PrintStream d = System.err;
	public int DEBUG_LEVEL = 1;
	
	private final Workpool<Object,PhramerException> w;
	private final SearchLambdaStep stepProcessor;
	private final int steps;
	private final double[][] intervalsRandom;
	public MultiThreadedSearchStrategy(int noThreads , int steps , SearchLambdaStep stepProcessor , double[][] intervalsRandom)
	{
		if (DEBUG_LEVEL >= 1)
			d.println("[MultiThreadedSearchStrategy] threadCount = " + noThreads);
		this.w = new MultiThreadedWorkpoolImpl<Object,PhramerException>("SearchStrategy", new Object[noThreads], true);
		this.w.start();
		this.stepProcessor = stepProcessor;
		this.steps = steps;
		this.intervalsRandom = intervalsRandom;
	}
	private class StepTask extends Task<Object,PhramerException>
	{
		public double currentScore = -1;
		public double[] lambda;
		private int iterNo;
		private Evaluator e;
		private ReferenceWithHypotheses[] f;
		private int n;
		private int maxLambdaAlter;
		
		
		
		public StepTask(double[] lambda , int iterNo , Evaluator e , ReferenceWithHypotheses[] f , int n , int maxLambdaAlter)
		{
			this.lambda = lambda;
			this.iterNo = iterNo;
			this.e = e;
			this.f = f;
			this.n = n;
			this.maxLambdaAlter = maxLambdaAlter;
		}
		public void execute(Object resource) throws PhramerException
		{
			currentScore = stepProcessor.executeStep(lambda , iterNo , e , f , n , maxLambdaAlter);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	private int bestLambdaIndex = -1;
	public double[] getNewLambdas(final int iteration ,
								  final Evaluator e ,
								  final ReferenceWithHypotheses[] f,
								  final double[] initialLambda,
								  final double[] bestPrevLambda,
								  int maxLambdaAlter) throws PhramerException
	{
		// initialize
		if (__DBG_prefix.startsWith("("))
			__DBG_prefix = "(" + iteration;
		
		if (maxLambdaAlter > initialLambda.length)
			maxLambdaAlter = initialLambda.length;
		
		double[] bestLambdas = null;
		double bestScore = Double.NEGATIVE_INFINITY;
		StepTask[] tasks = new StepTask[steps];
		for (int i = 0; i < steps; i++)
		{
			// initialize lambda
			double[] lambda;
			if (i == 0)
				lambda = initialLambda.clone();
			else
			if (i == 1 && bestPrevLambda != null)
				lambda = bestPrevLambda.clone();
			else
			{
				lambda = new double[initialLambda.length];
				// random points
				for (int k = 0; k < maxLambdaAlter; k++)
					lambda[k] = intervalsRandom[k][0] + (intervalsRandom[k][1] - intervalsRandom[k][0]) * Math.random();
				
				// copy those not to be altered
				for (int k = maxLambdaAlter ; k < initialLambda.length ; k++)
					lambda[k] = initialLambda[k];
			}
			tasks[i] = new StepTask(lambda , i + 1 , e , f , initialLambda.length , maxLambdaAlter);
			w.add(tasks[i]);
		}
		try
		{
			w.waitForCompletion();
		}
		catch (InterruptedException exc)
		{
			throw new PhramerException(exc);
		}
		
		int bestLambdaIndex = -1;
		for (int i = 0; i < steps; i++)
		{
			double currentScore = tasks[i].currentScore;
			double[] lambda = tasks[i].lambda;
			
			// we have a best, from that starting point
			if (currentScore > bestScore)
			{
				bestScore = currentScore;
				bestLambdas = lambda;
				bestLambdaIndex = i;
			}
		}
		
		if (DEBUG_LEVEL >= 1)
		{
			d.println(__DBG_prefix + ") End lambdas: ");
			__DBG_printLambda(bestLambdas, -1, d);
			d.println(__DBG_prefix + ") Score: " + bestScore);
		}
		this.bestLambdaIndex = bestLambdaIndex;
		return bestLambdas;
	}
	public static void __DBG_printLambda(double[] lambda, int chgIdx , PrintStream log)
	{
		log.print("(");
		for (int j = 0; j < lambda.length; j++)
			log.print((j > 0 ?",": "") + (j == chgIdx ?"*": "") + lambda[j] + (j == chgIdx ?"*": ""));
		log.println(")");
	}
	
	
	public Object getLastSearchInfo()
	{
		return bestLambdaIndex;
	}
}
