/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.mert.evaluation;
import org.phramer.mert.evaluation.*;
import org.phramer.mert.item.*;

public class EvaluationTools
{
	public static int[] bestPosition = null;
	// estimates the oracle score
	// I don't really know if that's the true oracle or just a very very good approximation
	public static double getOracle(ReferenceWithHypotheses[] ref , Evaluator eval)
	{
		HypothesisErrorStatistics[] errors = new HypothesisErrorStatistics[ref.length];
		int bestPosition[] = new int[ref.length];
		// initialize by the first hypothesis
		for (int i = 0; i < errors.length; i++)
		{
			errors[i] = ref[i].hypotheses.get(0).error;
			bestPosition[i] = 0;
		}
		
		double currentScore = eval.getScore(errors);
		// now optimize the error
		for (int i = 0; i < ref.length; i++)
		{
			int n = ref[i].hypotheses.size();
			// replace one by one
			for (int j = 0; j < n; j++)
			{
				HypothesisErrorStatistics newError = ref[i].hypotheses.get(j).error;
				// replace, try
				HypothesisErrorStatistics lastError = errors[i];
				errors[i] = newError;
				double newScore = eval.getScore(errors);
				errors[i] = lastError;
				
				if (newScore < currentScore && eval.bestIsSmall()
					|| newScore > currentScore && !eval.bestIsSmall())
				{
					errors[i] = newError;
					bestPosition[i] = j;
					currentScore = newScore;
				}
			}
		}
		EvaluationTools.bestPosition = bestPosition;
		return currentScore;
	}
}
