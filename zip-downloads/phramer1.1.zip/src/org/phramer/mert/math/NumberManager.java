/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.mert.math;

public class NumberManager
{
	
	// TODO: check
	public static boolean lowerEqualM(double v1, double v2)
	{
		return (v1 - PRECISION_M <= v2);
	}
	
	public static boolean lowerT(double v1, double v2)
	{
		return (v1 + PRECISION_T < v2);
	}
	
	public static boolean lowerM(double v1, double v2)
	{
		return (v1 + PRECISION_M < v2);
	}
	
	public static double adjustT(double t)
	{
		return t;
	}
	public static double adjustM(double m)
	{
		return m;
	}
	public static double adjustP(double p)
	{
		return p;
	}
	
	public static double adjustLambda(double lambda)
	{
		return lambda;
//		if (lambda == Double.NEGATIVE_INFINITY)
//			return lambda;
//		return ((long)(lambda * 1000000)) / 1000000f;
	}
	
	
	public static boolean betterProbability(double previousP , double newP)
	{
		if (newP - previousP >= PRECISION_P)
			return true;
		return false;
	}
	
	
	public static boolean equalSuccesiveLambdas(double small , double big)
	{
		if (big - small <= PRECISION_LAMBDA)
			return true;
		return false;
	}
	public static double PRECISION_LAMBDA = 0.00001;
	public static double PRECISION_P = 0.0000001;
	public static double PRECISION_M = 0.00001;
	public static double PRECISION_T = 0.00001;
}
