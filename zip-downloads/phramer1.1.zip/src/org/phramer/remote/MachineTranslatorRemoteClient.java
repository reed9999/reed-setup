/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.remote;
import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.remoteservices.*;
import info.olteanu.utils.remoteservices.client.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.etc.*;
import org.phramer.v1.decoder.*;

public class MachineTranslatorRemoteClient implements MachineTranslator, BlockMachineTranslator
{
	private static final String VERSION_QUERY[] = {"version"};
	private static final String CONCURRENT[] = {"concurrent"};
	
	// TODO: correct?
	public boolean allowConcurrency()
	{
		try
		{
			return server.service(CONCURRENT)[0].equals("1");
		}
		catch (RemoteException e)
		{
			throw new RuntimeException(e);
		}
	}
	
	public String getVersion()
	{
		try
		{
			return server.service(VERSION_QUERY)[0];
		}
		catch (RemoteException e)
		{
			throw new RuntimeException(e);
		}
	}
	
	private final RemoteService server;
	
	
	
	public String[] translate(String[] fSentence, boolean[] chunk, boolean xml, Map<String,String[]>[] metaData) throws PhramerException
	{
		if (metaData == null)
			return translate(fSentence , chunk , xml);
		
		String[] serializedMetaData = MetaDataTools.serialize(metaData);
		
		String query[] = new String[fSentence.length + 4 + serializedMetaData.length];
		query[0] = "translate block meta";
		query[1] = xml ?"1": "0";
		
		char[] c = new char[fSentence.length];
		for (int i = 0; i < fSentence.length; i++)
			c[i] = chunk[i] ? '1': '0';
		query[2] = new String(c);
		query[3] = String.valueOf(fSentence.length);
		
//		for (int i = 0; i < fSentence.length; i++)
//			query[i + 3] = fSentence[i];
		System.arraycopy(fSentence, 0, query, 4, fSentence.length);
		
		System.arraycopy(serializedMetaData, 0, query, fSentence.length + 3, serializedMetaData.length);
		try
		{
			return server.service(query);
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
	}
	
	
	public String[] translate(String[] fSentence, boolean[] chunk, boolean xml) throws PhramerException
	{
		String query[] = new String[fSentence.length + 3];
		query[0] = "translate block";
		query[1] = xml ?"1": "0";
		
		char[] c = new char[fSentence.length];
		for (int i = 0; i < fSentence.length; i++)
			c[i] = chunk[i] ? '1': '0';
		query[2] = new String(c);
		
//		for (int i = 0; i < fSentence.length; i++)
//			query[i + 3] = fSentence[i];
		System.arraycopy(fSentence, 0, query, 3, fSentence.length);
		
		try
		{
			return server.service(query);
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
	}
	
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk, Map<String,String[]> metaData) throws PhramerException
	{
		if (metaData == null)
			return translate(fSentence , sentenceIdx , chunk , xml);
		
		String[] serializedMetaData = MetaDataTools.serialize(metaData);
		
		String query[] = new String[4 + serializedMetaData.length];
		query[0] = "translate meta";
		query[1] = xml ?"1": "0";
		query[2] = chunk ?"1": "0";
		query[3] = fSentence;
		System.arraycopy(serializedMetaData, 0, query, 4, serializedMetaData.length);
		try
		{
			return server.service(query)[0];
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
	}
	
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk) throws PhramerException
	{
		String query[] = new String[4];
		query[0] = "translate";
		query[1] = xml ?"1": "0";
		query[2] = chunk ?"1": "0";
		query[3] = fSentence;
		try
		{
			return server.service(query)[0];
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
	}
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, Map<String,String[]> metaData, int nbestListSize) throws PhramerException
	{
		if (metaData == null)
			return translateNBest(fSentence , xml, chunk, nbestListSize);
		
		String[] serializedMetaData = MetaDataTools.serialize(metaData);
		
		String query[] = new String[5 + serializedMetaData.length];
		query[0] = "nbest meta";
		query[1] = xml ?"1": "0";
		query[2] = chunk ?"1": "0";
		query[3] = String.valueOf(nbestListSize);
		query[4] = fSentence;
		System.arraycopy(serializedMetaData, 0, query, 5, serializedMetaData.length);
		try
		{
			return server.service(query);
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
	}
	
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, int nbestListSize) throws PhramerException
	{
		if (fSentence.length() == 0)
			return new String[]{fSentence};
		String query[] = new String[5];
		query[0] = "nbest";
		query[1] = xml ?"1": "0";
		query[2] = chunk ?"1": "0";
		query[3] = String.valueOf(nbestListSize);
		query[4] = fSentence;
		try
		{
			return server.service(query);
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
	}
	
	public MachineTranslatorRemoteClient(String serverURL) throws IOException
	{
		this.server = RemoteConnector.getRemoteConnector(serverURL);
	}
	
	public MachineTranslatorRemoteClient(RemoteService server)
	{
		this.server = server;
	}
	
	
	public static void main(String[] args)
	throws Exception
	{
		translatorMain(null , null , args);
	}
	public static void translatorMain(InputStream inputStream , OutputStream outputStream , String[] args) throws IOException, PhramerException
	{
		String serverUrl = CommandLineTools.getParameter("-server" , args);
		System.err.println("Connecting to " + serverUrl + " ...");
		BlockMachineTranslator p = new MachineTranslatorRemoteClient(serverUrl);
		System.err.println(p.getVersion());
		
		String inputType = CommandLineTools.getParameter("-inputtype" , args);
		boolean isTextInput = false;
		if (inputType != null && "text".equals(inputType))
			isTextInput = true;
		
		boolean xml = !isTextInput;
		boolean chunk = CommandLineTools.isParameter("-x-chunk" , args);
		
		String rEnc = CommandLineTools.getParameter("-renc" , args);
		if (rEnc == null)
			rEnc = PhramerTools.getDefaultEncodingInput();
		String wEnc = CommandLineTools.getParameter("-wenc" , args);
		if (wEnc == null)
			wEnc = PhramerTools.getDefaultEncodingOutput();
		
		if (inputStream == null)
		{
			String readFile = CommandLineTools.getParameter("-read" , args);
			if (readFile != null)
				inputStream = IOTools.getInputStream(readFile);
			else
				inputStream = System.in;
		}
		
		if (outputStream == null)
		{
			String writeFile = CommandLineTools.getParameter("-write" , args);
			if (writeFile != null)
				outputStream = IOTools.getOutputStream(writeFile);
			else
				outputStream = System.out;
		}
		
		
		BufferedReader inputFile =
			new BufferedReader(new InputStreamReader(inputStream , rEnc));
		
		PrintStream output =
			outputStream == System.out ?
			System.out
			:
			new PrintStream(outputStream , true , wEnc);
		
		// batch size for multi-threaded execution
		// when batch size == 1, execute uni-threaded
		String strBatchSize = CommandLineTools.getParameter("-batch" , args);
		// default: 1 for System.in, 100 else
		int batchSize = strBatchSize == null ? (inputStream == System.in ? 1 : 100) : Integer.parseInt(strBatchSize);
		if (batchSize < 1)
			batchSize = 1;
		
		String lineFile;
		int k = 0;
		Chronometer c = new Chronometer();
		c.start();
		if (batchSize == 1)
			while ((lineFile = inputFile.readLine()) != null)
			{
				String translation = p.translate(lineFile, k , xml , chunk);
				
				output.println(translation);
				if (inputStream == System.in)
					output.flush();
				else
					System.err.print(".");
				k++;
			}
		else
		{
			String[] batch = new String[batchSize];
			boolean[] chunks = new boolean[batchSize];
			for (int i = 0; i < chunks.length; i++)
				chunks[i] = chunk;
			int idxBatch = 0;
			while ((lineFile = inputFile.readLine()) != null)
			{
				batch[idxBatch] = lineFile;
				idxBatch++;
				k++;
				
				if (idxBatch == batch.length)
				{
					doBlockTranslation(batch, chunks, p , xml, output, inputStream);
					idxBatch = 0;
				}
			}
			
			
			if (idxBatch > 0)
			{
				String[] miniBatch = StringTools.select(batch , 0 , idxBatch-1);
				boolean[] miniChunks = new boolean[idxBatch];
				for (int i = 0; i < miniChunks.length; i++)
					miniChunks[i] = chunk;

				doBlockTranslation(miniBatch, miniChunks, p, xml, output, inputStream);
				idxBatch = 0;
			}
		}
		output.flush();
		inputFile.close();
		c.stop();
		System.err.println();
		System.err.println("Translated " + k + " sentences in " + (0.001 * c.getValue()) + "s");
		
		
		
		if (output != System.out)
			output.close();
	}
	
	private static void doBlockTranslation(String[] batch, boolean[] chunks, BlockMachineTranslator p, boolean xml, PrintStream output, InputStream inputStream) throws PhramerException, IOException
	{
		String[] translation = p.translate(batch , chunks , xml);
		for (String t : translation)
			output.println(t);
		
		if (inputStream == System.in)
			output.flush();
		else
			System.err.print("*");
		
	}
}
