/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.remote;
import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import info.olteanu.utils.remoteservices.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.etc.*;


public class ServerWrapperMachineTranslator implements RemoteService
{
	private final MachineTranslator t;
	private final BlockMachineTranslator bt;
	private int k;
	public ServerWrapperMachineTranslator(MachineTranslator t)
	{
		this.t = t;
		this.bt = null;
		k = 0;
	}
	public ServerWrapperMachineTranslator(BlockMachineTranslator bt)
	{
		this.t = bt;
		this.bt = bt;
		k = 0;
	}
	public String[] service(String[] input) throws RemoteException
	{
		if (input.length == 1 && input[0].equals("version"))
		{
			String[] output = new String[1];
			output[0] = t.getVersion();
			return output;
		}
		if (input.length == 1 && input[0].equals("concurrent"))
		{
			String[] output = new String[1];
			output[0] = t.allowConcurrency() ? "1": "0";
			return output;
		}
		try
		{
			boolean xml = input[1].equals("1");
			boolean chunk = input[2].equals("1");
			if (input[0].equals("translate"))
			{
				String[] output = new String[input.length - 3];
				for (int i = 3; i < input.length; i++)
					if (t.allowConcurrency())
						output[i - 3] = t.translate(input[i] , k++ , xml , chunk);
					else
						synchronized (t)
						{
							output[i - 3] = t.translate(input[i] , k++ , xml , chunk);
						}
				return output;
			}
			if (input[0].equals("translate meta"))
			{
				Map<String,String[]> metaData = MetaDataTools.deserialize(input, new MutableInt(4));
				if (t.allowConcurrency())
					return new String[]{t.translate(input[3] , k++ , xml , chunk , metaData)};
				else
					synchronized (t)
					{
						return new String[]{t.translate(input[3] , k++ , xml , chunk , metaData)};
					}
			}
			
			if (input[0].equals("translate block"))
			{
				if (bt == null)
					throw new PhramerException("Block translation not supported");
				
				boolean[] chunkV = new boolean[input.length - 3];
				for (int i = 0; i < chunkV.length; i++)
					chunkV[i] = input[2].charAt(i) == '1';
				
				
				if (bt.allowConcurrency())
					return bt.translate(StringTools.cutFirst(input, 3), chunkV , xml);
				else
					synchronized (bt)
					{
						return bt.translate(StringTools.cutFirst(input, 3), chunkV , xml);
					}
			}
			if (input[0].equals("translate block meta"))
			{
				if (bt == null)
					throw new PhramerException("Block translation not supported");
				
				boolean[] chunkV = new boolean[input.length - 3];
				for (int i = 0; i < chunkV.length; i++)
					chunkV[i] = input[2].charAt(i) == '1';
				
				int length = Integer.parseInt(input[3]);
				String fSentence[] = new String[length];
				System.arraycopy(input, 4, fSentence, 0, fSentence.length);
				
				Map<String,String[]>[] metaData = MetaDataTools.deserialize(input, 4 + length , length);
				
				if (bt.allowConcurrency())
					return bt.translate(fSentence, chunkV , xml , metaData);
				else
					synchronized (bt)
					{
						return bt.translate(fSentence, chunkV , xml , metaData);
					}
			}
			
			// nbest
			if (input[0].equals("nbest"))
			{
				if (input.length != 5)
					throw new PhramerException("Invalid length for query: " + input.length + "; expected 5");
				int nbestSize = Integer.parseInt(input[3]);
				if (t.allowConcurrency())
					return t.translateNBest(input[4] , xml , chunk , nbestSize);
				else
					synchronized (t)
					{
						return t.translateNBest(input[4] , xml , chunk , nbestSize);
					}
			}
			if (input[0].equals("nbest meta"))
			{
				int nbestSize = Integer.parseInt(input[3]);
				Map<String,String[]> metaData = MetaDataTools.deserialize(input, new MutableInt(5));
				if (t.allowConcurrency())
					return t.translateNBest(input[4] , xml , chunk , metaData , nbestSize);
				else
					synchronized (t)
					{
						return t.translateNBest(input[4] , xml , chunk , metaData , nbestSize);
					}
			}
			
			throw new PhramerException("Unknown command: " + input[0]);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw new RemoteException(e.getClass().getName() + " " + e.getMessage() , e);
		}
		catch (PhramerException e)
		{
			e.printStackTrace();
			throw new RemoteException(e.getClass().getName() + " " + e.getMessage() , e);
		}
	}
	
}
