/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.server;

import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.lang.*;
import info.olteanu.utils.remoteservices.*;
import info.olteanu.utils.remoteservices.server.*;
import java.nio.*;
import java.util.*;
import java.io.*;
import org.phramer.v1.decoder.table.*;

public class StartBinaryRemoteTranslationTable
{
	static class BinaryRemoteTranslationTable implements BinaryRemoteService
	{
		private final HashMap<ByteArrayHasher,MutableIntPair> hash;
		private final ByteBuffer buf;
		BinaryRemoteTranslationTable(String fileMask) throws IOException
		{
			buf = NIOTools.readDataFile(fileMask + ".data");
			hash = TranslationTableToolsExtra.readNioIndexB(fileMask + ".idx" , buf.capacity());
		}
		private static final byte[] VOID = new byte[0];
		public byte[] service(byte[] input)
		{
			MutableIntPair ip = hash.get(new ByteArrayHasher(input));
			if( ip == null )
				return VOID;
			byte[] out = new byte[ip.second - ip.first];
			
			// cut a piece
			synchronized (hash)
			{
				// seek
				buf.position(ip.first);
				buf.get(out);
			}
			return out;
		}
	}
	
	public static void main(String[] args)
	throws Exception
	{
		// args[0]: port
		// args[1]: name of the file
		System.out.println("Parameters: <port> <file name mask>");
		System.out.println("Loading translation table...");
		Chronometer c = new Chronometer(true);
		BinaryRemoteTranslationTable tTableService = new BinaryRemoteTranslationTable(args[1]);
		System.out.println("Translation table loaded in " + StringTools.formatDouble(0.001 * c.getValue() , "0.00") + " s");
		
		BinaryServer server = new BinaryServer(tTableService , Integer.parseInt(args[0]));
		server.debugLevel = 2;
		System.out.println("Providing service...");
		server.start();
	}
}
