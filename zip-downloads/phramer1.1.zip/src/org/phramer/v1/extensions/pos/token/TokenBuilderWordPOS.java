/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.extensions.pos.token;

import info.olteanu.interfaces.*;
import org.phramer.v1.decoder.token.*;
import org.phramer.v1.extensions.pos.*;

// no caching yet
public class TokenBuilderWordPOS implements TokenBuilder
{
	private boolean postInit; // is post data structure loading or pre?
	private final boolean shared = true; // shared token builder for concurrency?
	
	public FToken build(EToken f)
	{
		// TODO
		// but is it even required???
		throw new Error("Not yet implemented");
	}
	
	private boolean posOnE, posOnF;
	private String separator;
	private TokenBuilderWordOnly wordOnly;
	private POSMapper posMapper;
	public TokenBuilderWordPOS(StringFilter filter , boolean posOnF , boolean posOnE , String separator , POSMapper posMapper)
	{
		this.posOnE = posOnE;
		this.posOnF = posOnF;
		this.separator = separator;
		this.wordOnly = new TokenBuilderWordOnly(filter);
		this.posMapper = posMapper;
	}
	private TokenBuilderWordPOS(TokenBuilderWordOnly wordOnly , boolean posOnF , boolean posOnE , String separator , POSMapper posMapper)
	{
		this.posOnE = posOnE;
		this.posOnF = posOnF;
		this.separator = separator;
		this.wordOnly = wordOnly;
		this.posMapper = posMapper;
	}
	public TokenBuilder getCloneForConcurrency()
	{
		// issue: must the other one be shared?
		if (shared)
			return this;
		else
			return new TokenBuilderWordPOS((TokenBuilderWordOnly)wordOnly.getCloneForConcurrency(), posOnF, posOnE, separator, posMapper);
	}
	
	public void initializationFinished()
	{
		postInit = true;
		wordOnly.initializationFinished();
	}
	
	public EToken build(FToken f)
	{
		if (posOnE)
		{
			String newPos;
			if (posOnF)
			{
				String pos = ((TokenWordPOS)f).getPOS();
				newPos = posMapper.map(pos);
				if (pos == newPos)// based on intern()
					return (TokenWordPOS)f;
			}
			else// put default POS
				newPos = posMapper.getDefaultPosTagConversion(f.getWord());
			
			return new TokenWordPOS(f.getWord() , newPos , f.getWord() + separator + newPos , true);
		}
		assert !posOnE;
		// no POS on F
		if (posOnF)
			return wordOnly.buildEToken(f.getWord());		// drop POS
		else
			return (TokenWordOnly)f;
	}
	
	public EToken buildEToken(String raw)
	{
		if (posOnE)
		{
			if (raw.equals("<s>") || raw.equals("</s>"))
				return new TokenWordPOS(raw,
										raw,
										raw,
										true);
			
			return new TokenWordPOS(raw.substring(0 , raw.indexOf(separator)) ,
									raw.substring(raw.indexOf(separator) + separator.length()).toUpperCase() ,
									raw ,
									true);
		}
		else
			return wordOnly.buildEToken(raw);
	}
	
	public FToken buildFToken(String raw)
	{
		if (posOnF)
			return new TokenWordPOS(raw.substring(0 , raw.indexOf(separator)) ,
									raw.substring(raw.indexOf(separator) + separator.length()).toUpperCase() ,
									raw,
									true);
		else
			return wordOnly.buildFToken(raw);
	}
	
}

