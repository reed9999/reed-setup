/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.cost;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.cost.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.token.*;
// tries to provide better estimate for the LM probability
public class ExtendedPharaohFutureCostCalculator extends PharaohFutureCostCalculator
{
	public ExtendedPharaohFutureCostCalculator(PhramerConfig config, Instrument instrument)
	{
		super(config, instrument);
	}
	
	
	/** Precomputes using dynamic programming the estimated future cost of translating every f sequence.<br>
	 * Not to be changed by any other implementation that uses the standard dynamic programming approach.
	 */
	public void initializeInternalData(FToken[] fWords, Vector<PhraseTranslationVariant>[][] translationVariants, Instrument instrument)
	{
		double bestCostsNonLm[][];// start, len-1
		double bestCostsLm[][];// start, len-1
		bestCostsLm = FCTools.initializeBestCost(fWords.length);
		bestCostsNonLm = FCTools.initializeBestCost(fWords.length);
		EToken chosenWords[][][]= FCTools.initializeChosenWords(fWords.length); // start, len-1, vector
		
		// len 0 = 1 word
		for (int len = 1; len <= fWords.length; len++)
			for (int i = 0 ; (i + len - 1) < fWords.length ; i++)
			{
				// compute best, directly
				double bestCost = Double.NEGATIVE_INFINITY;
				double bestCostNonLm = 0;
				double bestCostLm = 0;
				EToken[] chosenTranslation = null;
				
				int q = -2;
				// fix: accept max-phrase-limit
				if (translationVariants[i].length >= len &&
					translationVariants[i][len - 1] != null)
					for (PhraseTranslationVariant tVar : translationVariants[i][len - 1])
					{
						double thisCostNonLm = getPhraseCostNonLm(tVar);
						double thisCostLm = getPhraseCostLm(tVar);
						double thisCost = thisCostNonLm + thisCostLm;
						
						if (thisCost > bestCost)
						{
							bestCost = thisCost;
							bestCostNonLm = thisCostNonLm;
							bestCostLm = thisCostLm;
							chosenTranslation = tVar.getTranslation();
							q = -1;
						}
					}
				
				
				// use prev. best costs in order to find out
				for (int j = i + 1; j < i + len ; j++)
				{
					// first, non-linking
					double thisCostNonLm = bestCostsNonLm[i][j - i - 1] + bestCostsNonLm[j][i + len - j - 1];
					double thisCostLm = bestCostsLm[i][j - i - 1] + bestCostsLm[j][i + len - j - 1];
					double thisCost = thisCostNonLm + thisCostLm;
					EToken merged[] =merge(chosenWords[i][j - i - 1] , chosenWords[j][i + len - j - 1]);
					
					if (thisCost > bestCost)
					{
						bestCost = thisCost;
						bestCostNonLm = thisCostNonLm;
						bestCostLm = thisCostLm;
						chosenTranslation = merged;
						
						q = j;
					}
					
					// second, merge translations: recalculate thisCostLm and thisCost
					thisCostLm = getCummulativeCostLm(merged);
					thisCost = thisCostNonLm + thisCostLm;
					
					if (thisCost > bestCost)
					{
//						System.err.print("$" + (bestCost-thisCost));
						bestCost = thisCost;
						bestCostNonLm = thisCostNonLm;
						bestCostLm = thisCostLm;
						chosenTranslation = merged;
						q = j;
					}
				}
				//bestCosts[i][len - 1] = bestCost;
				bestCostsLm[i][len - 1] = bestCostLm;
				bestCostsNonLm[i][len - 1] = bestCostNonLm;
				chosenWords[i][len - 1] = chosenTranslation;
			}
		
		// now write best costs
		
		bestCosts = FCTools.initializeBestCost(fWords.length);
		
		// len 0 = 1 word
		for (int len = 1; len <= fWords.length; len++)
			for (int i = 0 ; (i + len - 1) < fWords.length ; i++)
				bestCosts[i][len - 1] = bestCostsNonLm[i][len - 1] + bestCostsLm[i][len - 1];
		instrument.futureCostEstimation(bestCosts);
	}
	
	private EToken[] merge(EToken[] a, EToken[] b)
	{
		EToken[] k = new EToken[a.length + b.length];
		System.arraycopy(a , 0 , k , 0 , a.length);
		System.arraycopy(b, 0 , k , a.length , b.length);
		return k;
	}
	
	
	
	/** Returns the future cost of a phrase translation variant, not including LM. <br>
	 * Subject to be replaced in a derived class.
	 */
	protected double getPhraseCostNonLm(PhraseTranslationVariant tVar)
	{
		// lambdas already embedded
		double translationCost = tVar.getLogProbability();
		double wordPenalityCost = - config.weightW * tVar.getTranslation().length;
		return translationCost + wordPenalityCost;
	}
	
	/** Returns the future cost of a phrase translation variant, only LM. <br>
	 * Subject to be replaced in a derived class.
	 */
	protected double getPhraseCostLm(PhraseTranslationVariant tVar)
	{
		return config.lmProcessor.getLogProbability(tVar.getTranslation(), instrument);
	}
	
	
	/** Returns the future cost of an union of word strings, only LM. <br>
	 * Subject to be replaced in a derived class.
	 */
	protected double getCummulativeCostLm(EToken[] e)
	{
		return config.lmProcessor.getLogProbability(e, instrument);
	}
}
