/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.cost;
import info.olteanu.utils.chron.*;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.token.*;

/** Implements FutureCostCalculator like in Pharaoh 1.2.3 <br>
 * Implements:
 *  - language model
 *  - translation cost
 *  - word penality
 * Dynamic programming implementation
 */
public class PharaohFutureCostCalculator implements FutureCostEstimator
{
	public static ProfilerChronometer nanoClockInit = new ProfilerChronometer("PharaohFutureCostCalculator.initializeInternalData", Phramer.nanoClockTranslate);
	

	protected final PhramerConfig config;
	protected double bestCosts[][];// start, len-1
	protected final Instrument instrument;
	
	
	public PharaohFutureCostCalculator(PhramerConfig config, Instrument instrument)
	{
		this.config = config;
		this.instrument = instrument;
	}
	
	
	
	
	
	/** Precomputes using dynamic programming the estimated future cost of translating every f sequence.<br>
	 * Not to be changed by any other implementation that uses the standard dynamic programming approach.
	 */
	public void initializeInternalData(FToken[] fWords, PhraseTranslationVariant[][][] translationVariants, Instrument instrument)
	{
		nanoClockInit.resume();
		bestCosts = FCTools.initializeBestCost(fWords.length);
		
		// len 0 = 1 word
		for (int len = 1; len <= fWords.length; len++)
			for (int i = 0 ; (i + len - 1) < fWords.length ; i++)
			{
				// compute best, directly
				double bestCost = Double.NEGATIVE_INFINITY;
				
				int q = -2;
				// fix: accept max-phrase-limit
				if (translationVariants[i].length >= len &&
					translationVariants[i][len - 1] != null)
					for (PhraseTranslationVariant tVar : translationVariants[i][len - 1])
					{
						double thisCost = getPhraseCost(tVar);
						
						if (thisCost > bestCost)
						{
							bestCost = thisCost;
							q = -1;
						}
					}
				// use prev. best costs in order to find out
				for (int j = i + 1; j < i + len ; j++)
					if (bestCosts[i][j - i - 1] + bestCosts[j][i + len - j - 1] > bestCost)
					{
						bestCost = bestCosts[i][j - i - 1] + bestCosts[j][i + len - j - 1];
						q = j;
					}
				
				bestCosts[i][len - 1] = bestCost;
			}
		nanoClockInit.pause();
		instrument.futureCostEstimation(bestCosts);
	}
	
	/** Returns the future cost of what is not already translated. <br>
	 * This version uses the simple additive technique used in Pharaoh 1.2.3. <br>
	 * Subject to be replaced in a derived class.
	 */
	public double estimateFutureCost(boolean[] foreignCovered, final int lastForeign)
	{
		double sumCost = 0f;
		// sum of all chunks
		for (int i = 0; i < foreignCovered.length; i++)
			if (!foreignCovered[i])
			{
				int len = FCTools.getLenUncovered(foreignCovered , i);
				sumCost += bestCosts[i][len - 1];
				i += len;
			}
		return sumCost;
	}
	
	/** Returns the future cost of a phrase translation variant. <br>
	 * Subject to be replaced in a derived class.
	 */
	protected double getPhraseCost(PhraseTranslationVariant tVar)
	{
		// lambdas already embedded
		double translationCost = tVar.getLogProbability();
		double lmCost = config.lmProcessor.getLogProbability(tVar.getTranslation(), instrument);
		double wordPenalityCost = - config.weightW * tVar.getTranslation().length;
		return translationCost + lmCost + wordPenalityCost;
	}
	
}
