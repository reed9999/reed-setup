/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.search;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.search.*;
import info.olteanu.utils.chron.*;

public class SearchStack implements Iterable<HypothesisState>, SearchStackIf
{
//	public static ProfilerChronometer nanoClockAdd = new ProfilerChronometer("SearchStack.add()",Phramer.nanoClockDecodeTheStack);
//	public static ProfilerChronometer nanoClockAddX = new ProfilerChronometer("SearchStack.addX()",nanoClockAdd);
//	public static ProfilerChronometer nanoClockAddMerge = new ProfilerChronometer("SearchStack.add--merge()",nanoClockAdd);
//	public static ProfilerChronometer nanoClockRemove = new ProfilerChronometer("SearchStack.remove()",nanoClockAddMerge);
	private final int nFWordsCovered;
	public int getStackID()
	{
		return nFWordsCovered;
	}
	private PhramerConfig config;
	public SearchStack(int nFWordsCovered , PhramerConfig config)
	{
		this.nFWordsCovered = nFWordsCovered;
		this.config = config;
		this.set = new HashSet<HypothesisState>();
		this.bestHyp = null;
		this._worstHyp = null;
		this.mrgSet = new HashMap<HypothesisState.MergeSatellite, HypothesisState>();
	}
	
	private HashSet<HypothesisState> set;
	private HypothesisState bestHyp;
	private HypothesisState _worstHyp;
	private HashMap<HypothesisState.MergeSatellite,HypothesisState> mrgSet;
	
	public double minThreshold()
	{
		if (size() == 0)
			return Double.NEGATIVE_INFINITY;
		return bestHyp.getLogProbabilityTotal() + config.logBeamThreshold;
	}
	
	public int size()
	{
		return set.size();
	}
	
	
	public boolean mayEnterWith(double p)
	{
		// empty?
		if (set.isEmpty())
			return true;
		// under threshold?
		if (p < minThreshold())
			return false;
		// stack full and under last?
		if (set.size() == config.stack)
			if (p < getWorstHyp().getLogProbabilityTotal())
				return false;
		
		return true;
	}
	
	public void add(HypothesisState newH, boolean keepLatticePaths , Instrument instrument)
	{
//		nanoClockAdd.resume();
		assert set.size() <= config.stack;
		assert newH.nForeignCovered == this.nFWordsCovered : newH.nForeignCovered + " : " + nFWordsCovered;
		// if empty, just add
		if (set.isEmpty())
		{
			add(newH);
			instrument.hypothesisAdded(newH, this);
//			nanoClockAdd.pause();
			return;
		}
		
		// improve speed: threshold pruning first
		// check if eliminated by threshold pruning
		if (newH.getLogProbabilityTotal() < bestHyp.getLogProbabilityTotal() + config.logBeamThreshold)
		{
//			nanoClockAdd.pause();
			instrument.hypothesisBelowThreshold(newH , this, config.logBeamThreshold);
			if (keepLatticePaths)//else just ignore
				if (mrgSet.containsKey(newH.mergeObject))
				{
					HypothesisState h = mrgSet.get(newH.mergeObject);
					assert newH.canBeMerged(h);
					//assert newH.getLogProbabilityTotal() < h.getLogProbabilityTotal() : "h under threshold? " + h.getLogProbabilityTotal() + " vs. " + newH.getLogProbabilityTotal() + " threshold: " + bestHyp.getLogProbabilityTotal() + config.logBeamThreshold;
					// The above assert can fail, because I don't do threshold pruning till the end
					// TODO: check if h is dead already, and remove it
					// I chose the short path: just check if it's a correct merge
					if (newH.getLogProbabilityTotal() < h.getLogProbabilityTotal())
					{
						// merge newH to h and continue
						h.merge(newH , keepLatticePaths);
						instrument.hypothesisMerged(h , newH , this);
					}
				}
			return;
		}
		assert set.contains(bestHyp) : "Strange... bestHyp not in set";
		
//		nanoClockAddMerge.resume();
		// try to merge, fast version
		if (mrgSet.containsKey(newH.mergeObject))
		{
			HypothesisState h = mrgSet.get(newH.mergeObject);
			assert newH.canBeMerged(h);
			if (newH.getLogProbabilityTotal() > h.getLogProbabilityTotal())
			{
				// newH is leading hypothesis between those two
				remove(h, instrument);
				newH.merge(h , keepLatticePaths);
				
				add(newH);
				instrument.hypothesisMerged(newH , h , this);
			}
			else
			{
				// merge newH to h and continue
				h.merge(newH , keepLatticePaths);
				instrument.hypothesisMerged(h , newH , this);
			}
			// job finished
//			nanoClockAddMerge.pause();
//			nanoClockAdd.pause();
			return;
		}
//		nanoClockAddMerge.pause();
		
		// no merging was perfomed
		
		
		
		// check if full
		if (set.size() == config.stack)
		{
			// if better than worst, remove words, else ignore
			assert set.contains(getWorstHyp()) : "strange... worstHyp not in set";
			if (getWorstHyp().getLogProbabilityTotal() < newH.getLogProbabilityTotal())
			{
				instrument.hypothesisPruned(getWorstHyp() , this, config.stack);
				remove(getWorstHyp(), instrument);
			}
			// and continue
			else
			{
				// FINISHED
				instrument.hypothesisPruned(newH , this, config.stack);
//				nanoClockAdd.pause();
				return;
			}
			
		}
		assert set.size() < config.stack : set.size() + " : " + config.stack;
		// not full
		// add
		add(newH);
		instrument.hypothesisAdded(newH, this);
		// if we have a new leader, prune everything using threshold
		
//		nanoClockAdd.pause();
		assert set.size() <= config.stack;
	}
	
	// returs the worst hyp, if calculated
	public HypothesisState getWorstHyp()
	{
		boolean isAssert = false;
		assert isAssert = true;
		if (isAssert && _worstHyp != null)
		{
			HypothesisState myWorstHyp = set.iterator().next();
			for (HypothesisState h : set)
				if (myWorstHyp.isBetterThan(h))
					myWorstHyp = h;
			
			assert _worstHyp == myWorstHyp
			|| _worstHyp.getLogProbabilityTotal() == myWorstHyp.getLogProbabilityTotal()
			: "different hypotheses " + myWorstHyp.id + "(" + myWorstHyp.getLogProbabilityCurrent() + " , " + myWorstHyp.getLogProbabilityTotal() + ")"  + " expected " + _worstHyp.id + "(" + _worstHyp.getLogProbabilityCurrent() + " , " + _worstHyp.getLogProbabilityTotal() + ")" ;
		}
		
		// <ORIGINAL>
		if (_worstHyp == null)
		// calculate it
			for (HypothesisState h : set)
				if (_worstHyp == null || _worstHyp.isBetterThan(h))
					_worstHyp = h;
		return _worstHyp;
		// </ORIGINAL>
	}
	
	// adds to stack
	private void add(HypothesisState h)
	{
//		nanoClockAddX.resume();
		assert set.size() == mrgSet.size() : "invalid state: " + set.size() + " " + mrgSet.size() + " at stack " + getStackID();
		assert !set.contains(h) : "Why set contains h?";
		set.add(h);
		mrgSet.put(h.mergeObject, h);
		
		if (bestHyp == null || h.isBetterThan(bestHyp))
			bestHyp = h;
		
		if (set.size() == 1 || _worstHyp != null && _worstHyp.isBetterThan(h))
			_worstHyp = h;
		
		assert set.size() <= config.stack;
		assert set.size() == mrgSet.size() : "invalid growth: " + set.size() + " " + mrgSet.size() + " at stack " + getStackID();
//		nanoClockAddX.pause();
	}
	
	// Assumption: never remove the best hyp without adding even a better one
	// Therefore, we don't update bestByp now
	private void remove(HypothesisState h, Instrument instrument)
	{
//		nanoClockRemove.resume();
		assert set.contains(h) : "Why set doesn't contain h?";
		set.remove(h);
		mrgSet.remove(h.mergeObject);
		
		if (h == _worstHyp)
			_worstHyp = null;
		
//		nanoClockRemove.pause();
		instrument.hypothesisRemoved(h , this);
		assert set.size() == mrgSet.size() : "invalid cut: " + set.size() + " " + mrgSet.size() + " at stack " + getStackID();
	}
	
	public void prepareBeforeExpand(Instrument instrument)
	{
		if (set.isEmpty())
			return;
		prune(instrument);
	}
	
//	// NOT ANY MORE
//	private void pruneThresholdAll(Instrument instrument)
//	{
//		//prune(instrument);
//	}
	private void prune(Instrument instrument)
	{
		double minThreshold = minThreshold();
		// if all are within threshold, do nothing
		if (getWorstHyp().getLogProbabilityTotal() >= minThreshold)
			return;
		
		// TODxO: binary search, if possible. Not any more with hash
		ArrayList<HypothesisState> pruneSet = new ArrayList<HypothesisState>();
		for (HypothesisState h : set)
			if (h.getLogProbabilityTotal() < minThreshold)
			{
				// TODxO: all starting this must be pruned. Not any more with hash
				pruneSet.add(h);
				//mrgSet.remove(h.mergeObject);
				instrument.hypothesisBelowThreshold(h, this, config.logBeamThreshold);
			}
		if (pruneSet.size() > 0)
		{
			// alternative. If not alternative is used, pay attention to _worstHyp. Initialize it to 0
			for (HypothesisState p : pruneSet)
				remove(p, instrument);
			//set.removeAll(pruneSet);
		}
	}
	
	// sorted
	public Iterator<HypothesisState> iterator()
	{
		// TODO: improve
		ArrayList<HypothesisState> v = new ArrayList<HypothesisState>(set.size());
		v.addAll(set);
		Collections.sort(v , new Comparator<HypothesisState>()
			{
				public int compare(HypothesisState o1, HypothesisState o2)
				{
					// o1-o2
					if (o1.getLogProbabilityTotal() > o2.getLogProbabilityTotal())
						return -1;
					if (o1.getLogProbabilityTotal() < o2.getLogProbabilityTotal())
						return 1;
					return o1.hashCode() - o2.hashCode();
				}
			}
		);
		
		return v.iterator();
		//return set.iterator();
	}
	
	public HypothesisState getBest()
	{
		return bestHyp;
	}
	public int getSize()
	{
		return set.size();
	}
}
