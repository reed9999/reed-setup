/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.search;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.cost.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.token.*;
import info.olteanu.utils.chron.*;
/**
 * Imuable.
 * Note: if it is desired to be compareable, then make sure than compareTo will return 0
 * if and only if the objects are the same
 */
public final class HypothesisState
{
//	public static int _cnt__constructor_ = 0;
//	public static int _cnt_canBeMerged = 0;
//	public static int _cnt_canBeMergedSuccess = 0;
//	public static ProfilerChronometer nanoClock = new ProfilerChronometer("HypothesisState.<init>", Phramer.nanoClockDecodeTheStack);
//	public static ProfilerChronometer nanoClockCanBeMerged = new ProfilerChronometer("HypothesisState.canBeMerged", SearchStack.nanoClockAddMerge);
	
	
	
	private final int _cachedHashCode;
	public final int id;
	public final Object constraintData;
	private ArrayList<HypothesisState> mergedWith = null;
	private HypothesisState parentMerge = null;
	private ContextComparator ctxComparator;
	// restrict merging to the ones that generates the same number of words and covered the same ammount of foreign words
	private boolean mergeSameLengthGeneration;
	
	// reverse of mergedWith
	
	public HypothesisState(int nWords ,
						   FutureCostEstimator costEstimator ,
						   LMContext startOfSentenceContext ,
						   int id ,
						   ContextComparator ctxComparator ,
						   boolean mergeSameLengthGeneration ,
						   Object constraintData)
	{
//		_cnt__constructor_++;
		this.id = id;
		this.constraintData = constraintData;
		this.parent = null;
		this.foreignCovered = new boolean[ nWords ];
		this.nForeignCovered = 0;
		this.cost = 0f;
		this.phraseUsed = null;
		this.lastForeign = -1;
		this.futureCost = costEstimator.estimateFutureCost(this.foreignCovered , this.lastForeign);
		this.lmContext = startOfSentenceContext;
		this.ctxComparator = ctxComparator;
		this.mergeSameLengthGeneration = mergeSameLengthGeneration;
		
		_cachedHashCode = computeHashCode();
	}
	
	public HypothesisState(HypothesisState previous ,
						   PhraseTranslationVariant phrase ,
						   int start ,
						   int len ,
						   boolean[] newForeignCovered ,
						   double futureCost,
						   double addedCost ,
						   LMContext newContext ,
						   int id,
						   Object constraintData)
	{
//		_cnt__constructor_++;
//		nanoClock.resume();
		this.id = id;
		this.constraintData = constraintData;
		this.parent = previous;
		this.mergeSameLengthGeneration = previous.mergeSameLengthGeneration;
		this.ctxComparator = previous.ctxComparator;
		this.foreignCovered = newForeignCovered;
		this.nForeignCovered = previous.nForeignCovered + len;
		this.phraseUsed = phrase;
		this.lastForeign = start + len - 1;
		
		this.lmContext = newContext;// optimization
		this.cost = previous.cost + addedCost;
		this.futureCost = futureCost;
		assert nForeignCovered != foreignCovered.length || this.futureCost == 0f : "no future cost if all covered";
		_cachedHashCode = computeHashCode();
//		nanoClock.pause();
	}
	
	private int computeHashCode()
	{
		boolean[] foreignCovered = this.foreignCovered;/* avoid getfield opcode */
		// last foreign?
//		int h = lastForeign + 1;
//		// foreign words covered
//		for (int i = 0; i < foreignCovered.length; i++)
//			h = h * 2 + (foreignCovered[i] ?1: 0);
//		// now blend with lm context hash code
//		h = (h << 2 ^ lmContext.hashCode()) + 1;
		
		int h = 0;//lastForeign + 1;
		// foreign words covered
		for (int i = 0; i < foreignCovered.length; i++)
			h = h << 1 | (foreignCovered[i] ?1: 0);
		// now blend with lm context hash code
		h = (h * 3) ^ lmContext.hashCode();
		h += lastForeign;
		return h;
	}
	
	public final HypothesisState parent;
	// total cost till now, not incremental cost
	private final double cost;
	private final double futureCost;
	public final boolean foreignCovered[];
	public final int nForeignCovered;
	public final PhraseTranslationVariant phraseUsed;
	
	public final int lastForeign;
	public final LMContext lmContext;
	
	
	public HypothesisState getMergeBestNode()
	{
		if (parentMerge == null)
			return this;
		return parentMerge.getMergeBestNode();
	}
	
	public final double getLogProbabilityFuture()
	{
		return futureCost;
	}
	
	public final double getLogProbabilityCurrent()
	{
		return cost;
	}
	
	public final double getLogProbabilityAdded()
	{
		return cost - parent.cost;
	}
	
	public final double getLogProbabilityTotal()
	{
		return cost + futureCost;
	}
	
	public boolean foreignNotUsed(int idx)
	{
		return !foreignCovered[idx];
	}
	
	public boolean foreignNotUsed(int start , int len)
	{
		boolean[] foreignCovered = this.foreignCovered;/* avoid getfield opcode */
		for (int i = 0; i < len; i++)
			if (foreignCovered[start + i])
				return false;
		return true;
	}
	
	// buggy compare was before
	
	
	/** Compare using total cost: sum of cost + future cost
	 * The highest probability hypothesis will be first
	 */
	public boolean isBetterThan(HypothesisState t)
	{
		assert t.foreignCovered.length == this.foreignCovered.length;
		return t.getLogProbabilityTotal() < this.getLogProbabilityTotal();
		
//		if (t.cost + t.futureCost > this.cost + t.futureCost)
//			return true;
		// don't return 0 unless equal!!!
//		if (o == this)
//			return 0;
		// hashcode is good
//		assert o.hashCode() - this.hashCode() != 0;
//		return o.hashCode() - this.hashCode();
	}
	/** Object that allows fast retrieval of the object to be merged with.
	 * It implements equals and hashCode - methods required for fast hash access */
	class MergeSatellite
	{
		
		public int hashCode()
		{
			return _cachedHashCode;
		}
		// tweak
		private HypothesisState getThis()
		{
			return HypothesisState.this;
		}
		
		public boolean equals(Object t)
		{
			// check reflexivity
			assert canBeMerged(((MergeSatellite)t).getThis()) == ((MergeSatellite)t).getThis().canBeMerged(getThis());
			return canBeMerged(((MergeSatellite)t).getThis());
		}
	}
	final MergeSatellite mergeObject = new MergeSatellite();
	
	
	/** Can two hypothesis be merged? <br>
	 * Reflexive function.
	 */
	public boolean canBeMerged(HypothesisState t)
	{
		// probably it won't improve too much, especially if the function is not called too often
//		if( futureCost != t.futureCost )
//			return false;
		
//		_cnt_canBeMerged++;
		
//		nanoClockCanBeMerged.resume();
		assert t != this : "why would you want to merge with itself?";
		assert t.foreignCovered.length == this.foreignCovered.length;
		assert t.nForeignCovered == this.nForeignCovered; // cast it only on hyp that covered the same number of f.words
		
		boolean[] foreignCovered = this.foreignCovered;/* avoid getfield opcode */
		boolean[] tforeignCovered = t.foreignCovered;/* avoid getfield opcode */
		
		
		// check last foreign word used
		if (lastForeign != t.lastForeign)
		{
//			nanoClockCanBeMerged.pause();
			return false;
		}
		// check foreign words covered
		for (int i = 0; i < foreignCovered.length; i++)
			if (foreignCovered[i] != tforeignCovered[i])
			{
//				nanoClockCanBeMerged.pause();
				return false;
			}
		// check lm context
		if (!ctxComparator.mergeable(this.lmContext , t.lmContext))
		{
//			nanoClockCanBeMerged.pause();
			return false;
		}
		
		// TODO: test it (alignment)
		// alignment: limit merging to same number of words
		if (mergeSameLengthGeneration)
			if (this.getCntWordsGeneated() != t.getCntWordsGeneated())
			{
//				nanoClockCanBeMerged.pause();
				return false;
			}
		
		
		// the future costs must be the same
		assert t.futureCost == this.futureCost : "found mergeable nodes that have different future costs!!!";
		// the hash codes must be the same
		assert t.mergeObject.hashCode() == this.mergeObject.hashCode();
//		nanoClockCanBeMerged.pause();
//		_cnt_canBeMergedSuccess++;
		return true;
	}
	
	/** Merge the other object into this one.
	 * Assume that this one has a better cost */
	public void merge(HypothesisState t , boolean keepLatticePaths)
	{
		assert t != this : "why would you want to merge with itself?";
		assert canBeMerged(t);
		assert this.getLogProbabilityTotal() >= t.getLogProbabilityTotal();
		
		if (keepLatticePaths)
		{
			// TODO: finish it. Finish what? It kind of works
			if (this.mergedWith == null)
				this.mergedWith = new ArrayList<HypothesisState>();
			this.mergedWith.add(t);
			
			t.parentMerge = this;
		}
	}
	
	// iterate through the direct sibling
	// beware: there might be a tree of siblings
	public Iterator<HypothesisState> mergedIterator()
	{
		if (mergedWith == null)
			return null;
		return mergedWith.iterator();
	}
	
	/** Returns the start position of this phrase in the f string of words */
	public int getStartPosition()
	{
		if (parent == null)
			return -1;
		for (int i = 0; i < foreignCovered.length; i++)
			if (parent.foreignCovered[i] != foreignCovered[i])
				return i;
		throw new Error("unexpected not to end");
	}
	
	/** Returns the end position of this phrase in the f string of words */
	public int getEndPosition()
	{
		if (parent == null)
			return -1;
		for (int i = foreignCovered.length - 1; i >= 0; i--)
			if (parent.foreignCovered[i] != foreignCovered[i])
				return i;
		throw new Error("unexpected not to end");
	}
	
	
	
	// DEBUG stuff
	public String toString()
	{
		return getCoverageString() + " " + TokenTools.getString(PhramerTools.getTranslation(this));
	}
	// DEBUG stuff
	public String getCoverageString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append('[');
		for (int i = 0; i < foreignCovered.length; i++)
			if (!foreignCovered[i])
				sb.append('.');
			else if (parent != null && parent.foreignCovered[i])
				sb.append('o');
			else
				sb.append('O');
		sb.append(']');
		return sb.toString();
		
	}
	
	public boolean isFinalState()
	{
		return nForeignCovered == foreignCovered.length;
	}
	
	
	
	/** Returns how many english words were generated till now */
	public int getCntWordsGeneated()
	{
		int cntWordsGenerated = 0;
		HypothesisState h = this;
		while (h.parent != null)
		{
			cntWordsGenerated += h.phraseUsed.getTranslation().length;
			h = h.parent;
		}
		return cntWordsGenerated;
	}
	
}
