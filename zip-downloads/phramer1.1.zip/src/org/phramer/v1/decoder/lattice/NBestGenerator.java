/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.lattice;
import info.olteanu.utils.lang.*;
import java.util.*;
import org.phramer.v1.decoder.lattice.*;
import org.phramer.v1.decoder.search.*;

public class NBestGenerator
{
	/** Returns first n hypotheses. <br>
	 * Implements n-best decoding.
	 * One line contains the hypotheses for an item in the n-best list, from the end to the beginning
	 * First line = 1st-best
	 * Second line = 2nd-best
	 * etc
	 * */
	public static List<List<HypothesisState>> iterateFirstNHypotheses(SearchStackIf[] stack , int n)
	{
		TreeSet<ChoiceNode> choiceNodes = new TreeSet<ChoiceNode>();
		
		// fill with final hypotheses
		Iterator<HypothesisState> finalHypos = stack[stack.length - 1].iterator();
		while (finalHypos.hasNext())
		{
			List<HypothesisState> hypos = iterateSiblings(finalHypos.next());
			for (HypothesisState h : hypos)
				choiceNodes.add(new ChoiceNode(h));
		}
		
		List<List<HypothesisState>> output = new ArrayList<List<HypothesisState>>();
		while (n > 0)
		{
			// we might not have enough
			if (choiceNodes.isEmpty())
				return output;
			
			// get best choice
			ChoiceNode bestChoice = choiceNodes.first();
			choiceNodes.remove(bestChoice);
			
			// develop this choice
			List<HypothesisState> currentLine = new ArrayList<HypothesisState>();
			double scoreSecondPart = 0;
			
			int len = 0;
			if (bestChoice.secondPartPointer != null)
			// put that second part
				for (int i = 0; i < bestChoice.secondPartPointer.second; i++)
				{
					HypothesisState h = output.get(bestChoice.secondPartPointer.first).get(i);
					scoreSecondPart += h.getLogProbabilityAdded();
					currentLine.add(h);
					len++;
				}
			
			// now put the first part
			HypothesisState state = bestChoice.firstPartEndsInHypo;
			while (state.parent != null)
			{
				currentLine.add(state);
				state = state.parent;
			}
			
			// create new choices
			// now put the first part
			state = bestChoice.firstPartEndsInHypo.parent;
			scoreSecondPart += bestChoice.firstPartEndsInHypo.getLogProbabilityAdded();
			len++;
			while (state != null && state.parent != null)
			{
				// create choices from the current state
				List<HypothesisState> hypos = iterateSiblings(state);
				for (HypothesisState h : hypos)
					if (h != state) // skip current state, look only for siblings
						choiceNodes.add(new ChoiceNode(h, new IntPair(output.size() , len), scoreSecondPart));
				
				scoreSecondPart += state.getLogProbabilityAdded();
				len++;
				state = state.parent;
			}
			
			//output
			output.add(currentLine);
			
			// one less to compute
			n--;
		}
		
		return output;
	}
	
	
	
	// get all siblings of a particular hypothesis
	private static List<HypothesisState> iterateSiblings(HypothesisState hyp)
	{
		List<HypothesisState> hypotheses = new ArrayList<HypothesisState>();
		iterateSiblings(hyp  , hypotheses);
		return hypotheses;
	}
	private static void iterateSiblings(HypothesisState hyp, List<HypothesisState> hypotheses)
	{
		// add current
		hypotheses.add(hyp);
		
		// do siblings
		Iterator<HypothesisState> siblings = hyp.mergedIterator();
		if (siblings != null)
			while (siblings.hasNext())
				iterateSiblings(siblings.next(), hypotheses);
	}
}
