/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.lattice;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.token.*;

public class CarmelLattice
{
	
	/** Generates the lattice files */
	public static void printCarmelLattice(SearchStackIf[] stack, int sentenceIdx , int nFwords , int sinkNode , String latticeBaseFileName)
	throws PhramerException
	{
		try
		{
			String fileLattice = latticeBaseFileName + "." + arrangeDigits(Integer.toString(sentenceIdx) , 4);
			HashSet<HypothesisState> hypothesesSet = new HashSet<HypothesisState>();
			
			// get hypotheses that map to edges
			Iterator<HypothesisState> iter = stack[stack.length - 1].iterator();
			while (iter.hasNext())
				getSetOfHyp(iter.next() , hypothesesSet);
			
			// get an array out of them
			HypothesisState[] hypos = new HypothesisState[hypothesesSet.size()];
			int k=0;
			for (HypothesisState hyp : hypothesesSet)
				hypos[k++] = hyp;
			
			// sort them
			Arrays.sort(hypos , new Comparator<HypothesisState>()
				{
					public int compare(HypothesisState o1, HypothesisState o2)
					{
						return o1.id - o2.id;
					}
				}
			);
			
			PrintStream outFileLattice = new PrintStream(new FileOutputStream(fileLattice));
			outFileLattice.println(sinkNode);
			// print edges out of hypotheses
			for (HypothesisState hyp : hypos)
			{
				boolean useDestination = false;
				int destination = hyp.id;
				
				if (hyp.nForeignCovered == nFwords)
				{
					// terminal node
					useDestination = true;
					destination = sinkNode;
				}
				else if (hyp.getMergeBestNode() != hyp)
				{
					// merged
					useDestination = true;
					destination = hyp.getMergeBestNode().id;
				}
				
//				Edge e = new Edge(hyp , useDestination , destination);
//				outFileLattice.println("(" + e.node1ID + " (" + e.node2ID + " \"" + getString(e.node2) + "\" " + MathTools.logToNumber(e.node2.getLogProbabilityAdded()) + "))");
				outFileLattice.println("(" + hyp.parent.id + " (" + destination + " \"" + getString(hyp) + "\" " + MathTools.logToNumber(hyp.getLogProbabilityAdded()) + "))");
			}
			outFileLattice.close();
			
			PrintStream outFileState = new PrintStream(new FileOutputStream(fileLattice + ".state"));
			for (HypothesisState hyp : hypos)
				outFileState.println(hyp.id + " " + getCoverage(hyp));
			outFileState.close();
		}
		catch (IOException e)
		{
			throw new PhramerException("IOException" , e);
		}
		
	}
	
	private static void getSetOfHyp(HypothesisState hyp, HashSet<HypothesisState> hypotheses)
	{
		if (hyp.parent == null)
			return;
		
		// check if already processed
		if (hypotheses.contains(hyp))
			return;
		
		// add current
		hypotheses.add(hyp);
		// add parent
		getSetOfHyp(hyp.parent , hypotheses);
		
		// do siblings
		Iterator<HypothesisState> siblings = hyp.mergedIterator();
		if (siblings != null)
			while (siblings.hasNext())
				getSetOfHyp(siblings.next(), hypotheses);
	}
	
	
	private static String getCoverage(HypothesisState hyp)
	{
		StringBuilder sb = new StringBuilder(hyp.foreignCovered.length);
		for (int i = 0; i < hyp.foreignCovered.length; i++)
			sb.append(hyp.foreignCovered[i] ? '1' : '0');
		return sb.toString();
	}
	
	private static String getString(HypothesisState hyp)
	{
		EToken[] translation = hyp.phraseUsed.getTranslation();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < translation.length; i++)
		{
			if (i > 0)
				sb.append(' ');
			sb.append(translation[i].serializeFull());// TODO: revize. Maybe not serializeFull()
		}
		return escape(sb.toString());
	}
	
	private static String escape(String s)
	{
		return s.replace("\\" , "\\\\").replace("\"" , "\\\"");
	}
	
	private static String arrangeDigits(String str, int digits)
	{
		if (str.length() < digits)
			return "0" + arrangeDigits(str, digits - 1);
		return str;
	}
	
}
