/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.token.*;

public class PhramerInput
{
	// full stuff
	public PhramerInput(FToken[] fWords, boolean[] isPreTranslated , int[] phraseLength , List<PhraseTranslationVariant>[] prePhraseTranslations, Map<String,String[]> metaData)
	{
		this.fWords = fWords;
		this.isPreTranslated = isPreTranslated;
		this.phraseLength = phraseLength;
		this.prePhraseTranslations = prePhraseTranslations;
		this.metaData = metaData;
	}
	
	// no pre-annotation
	public PhramerInput(FToken[] fWords , Map<String,String[]> metaData)
	{
		this.fWords = fWords;
		this.isPreTranslated = null;
		this.phraseLength = null;
		this.prePhraseTranslations = null;
		this.metaData = metaData;
	}
	
	private final FToken[] fWords;
	// if here starts a pre-translation
	private final boolean isPreTranslated[];
	// how long is the pre-translation
	private final int phraseLength[];
	// what are the translation variants
	private final List<PhraseTranslationVariant>[] prePhraseTranslations;
	
	public boolean hasPreTranslations()
	{
		return isPreTranslated != null;
	}
	public FToken[] getFWords()
	{
		return fWords;
	}
	public boolean[] getIsPreTranslated()
	{
		return isPreTranslated;
	}
	public int[] getPreTranslatedPhraseLength()
	{
		return phraseLength;
	}
	public List<PhraseTranslationVariant>[] getPrePhraseTranslations()
	{
		return prePhraseTranslations;
	}
	
	public static PhramerInput getNonXML(String fSentence, TokenBuilder tokenBuilder, Map<String, String[]> metaData)
	{
		return new PhramerInput(tokenize(fSentence, tokenBuilder), metaData);
	}
	
	/** Perform simple tokenization of the input. Uses .intern() */
	private static FToken[] tokenize(String input, TokenBuilder tokenBuilder)
	{
		return PhramerTools.tokenizeIntoFToken(input , tokenBuilder);
	}
	
	
	public Object constraintsDescriptor = null;
	
	private final Map<String,String[]> metaData;
	
	public String[] getMetaData(String key)
	{
		if( metaData != null )
			return metaData.get(key);
		return null;
	}
	
}
