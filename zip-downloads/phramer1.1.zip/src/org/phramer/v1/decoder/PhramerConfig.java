/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder;
import info.olteanu.utils.*;
import info.olteanu.utils.io.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.instrumentation.analysis.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.lm.processor.*;
import org.phramer.v1.decoder.loader.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.token.*;
import info.olteanu.interfaces.*;
import org.phramer.v1.decoder.extensionifs.impl.*;
import org.phramer.v1.decoder.table.wordalignment.*;

/* New parameters:
 * -x-oov-probability / -x-oov (1) , default: -10 -- OOV score
 * -x-lm-lbound / -x-lb , default -10 (1) -- minimum value out of language model
 * -x-max-phrase-length (1) -- How long can be a phrase?
 *   It is designed to accelerate and reduce memory consumption.
 *   Default value (0) = infinite
 * -x-context-length (1) -- How many words are needed to compute the probability of adding a new word into the sentence.
 *   Default: If a n-gram model is used, lmContextLength = n-1.
 * -x-chunk (0) -- Translate chunks, not sentences. Don't add <s> and </s> in language model probability
 *
 * -x-score / -sc (2) -- score directory, n-best size
 * -x-score-simple / -simple-sc (0) -- write simple score/rescore files (space-separated)
 * -x-score-mask / -sc-mask (1) -- mask of the output score (simple type). May have: d, l, t, w, x. Comma separated
 *   I.e.: x,t
 *   Useful for MERT and custom probability functions.
 * -x-nbest / -nb (2) -- nbest directory+path, n-best size
 * -start-id (1) -- n-best, lattice, score files, rescore files - start identifier (default: 0000)
 *   Ignored by Phramer class, processed by PhramerMain.
 *   Useful for split decoding for MERT.
 * -x-nbest-includeprob (0) -- to include the total probability of the sentence probability in the n-best list
 * -x-prefix-tt (0) -- if <w1 .. wk-1> is not in the translation table, don't look for <w1 .. wk>
 *   Optimizes translation table lookup.
 *
 * -x-future-cost-class (1) -- the future cost calculator. Default: the Pharaoh future cost calculator.
 *   Recommended: org.phramer.v1.decoder.cost.PharaohDFutureCostCalculator which also considers the distortion
 *
 * -x-unk-words-transliterator (1) -- the class that does transliteration for unknown words
 *   Must implement info.olteanu.interfaces.StringFilter
 *   Active only if a helper wasn't already passed to the config file
 *   Only in the command line (issues with where it is required)
 *   The constructor of the extension has no parameters
 * -x-unk-phrases (1) -- the class that generates phrases for unknown words
 *   Must implement org.phramer.v1.decoder.extensionifs.OutOfTranslationTablePhraseGenerator
 * -x-unk-phrases-param (1-n) -- the string parameter passed to the class defined in -x-unk-phrases
 * -x-translation-variants-inspector (1) -- the class that inspects/alters the translation variants for the sentence
 *   Must implement org.phramer.v1.decoder.extensionifs.PhraseTranslationVariantInspector
 * -x-translation-variants-inspector-param (1-n) -- the string parameter passed to the class defined in -x-translation-variants-inspector
 * -x-pre-filter (1) -- the class that pre-filters the input sentences (when is passed as string)
 *   Must implement org.phramer.v1.decoder.extensionifs.PreFilter
 *   In case there's a StringFilter implementation available (with a (PhramerConfig , String[]) constructor),
 *  one can use org.phramer.v1.decoder.extensionifs.impl.StringFilter2PreFilter, and the first parameter
 *  is the name of the StringFilter implementation
 * -x-pre-filter-param (1) -- the string parameter passed to the class defined in -x-pre-filter
 * -x-post-filter (1) -- the class that post-filters the output sentences
 *   Must implement org.phramer.v1.decoder.extensionifs.PostFilter
 *   In case there's a StringFilter implementation available (with a (PhramerConfig , String[]) constructor),
 *  one can use org.phramer.v1.decoder.extensionifs.impl.StringFilter2PostFilter, and the first parameter
 *  is the name of the StringFilter implementation
 * -x-post-filter-param (1) -- the string parameter passed to the class defined in -x-post-filter
 *
 * -x-constraint-processor (1)
 *   Must implement org.phramer.v1.decoder.extensionifs.ConstraintProcessor
 * -x-constraint-processor-param (1-n)
 *
 * -x-custom-probability-calculator (1)
 *   Must implement org.phramer.v1.decoder.extensionifs.CustomProbability
 * -x-custom-probability-calculator-param (1-n)
 * -px / -weight-x (1-n) -- weights for the custom probability calculator
 *
 * -x-level-good-probabilities (1) --  default 0
 *   Values:
 *     0 - no assumption can be made about the probabilities
 *     1 - pLM + pT + pW + pX <= 0 (in logarithm)
 *     2 - [1] and pLM + pX <= 0 (in logarithm)
 *     3 - [2] and pLM <= 0 and pT <= 0 and pW <= 0 and pX <= 0 (in logarithm)
 *
 * -x-extra-output (n) -- defines what extra data that will be printed together with the sentence
 *   Lists either standard extra output types:
 *     * probability
 *     * phrase-alignment
 *     * word-alignment
 *   Or lists the class that implements the extra output printer
 *     (with a (PhramerConfig , String[]) constructor)
 * -x-extra-output-W-param (n) -- defines the params for instantiating the W-th (starts with 1) output generator
 * -x-extra-output-separator (1) -- default "|||"
 *    Defines the separator between the sentence generated and the extra output data
 *
 *
 * -profile (0) -- do execution profiling. Note: a lot of profiling hooks were
 *             disabled, due to wasted CPU processing. In order to use them, the
 *             sourcecode needs to be changed (uncomment the profiling hooks) and
 *             recompiled. Profiling is useful only to determine which are the
 *             methods/pieces of codes that worth to be optimized further more
 *
 * -renc (1) -- input file encoding. Default: ISO-8859-1
 * -wenc (1) -- out file encoding. Default: ISO-8859-1
 * -ttenc (1) -- translation table file encoding. Default: ISO-8859-1
 * -lmenc (1) -- lm file encoding. Default: ISO-8859-1
 *
 * -inputtype (1) - file input type. Values: text, xml (default)
 *
 * -compatibility (1) -- compatibility level - numeric value, or separated with .
 *  Example: Phramer 1.0.2 = 1.00.02.00
 *                         = 1.0.2.0
 *                         = 1.0.2
 *                         = 1000200
 * Default: highest ever possible
 *
 * -read (1) -- reads the input file instead of reading it from StdIn
 * -write (1) -- writes the input file instead of writting it to StdOut
 * -server (1) -- starts a Phramer server at the specified port.
 *            The remote decoding server can be accessed using
 *            org.phramer.remote.MachineTranslatorRemoteClient.main()
 * -cache (1) -- if there's a server, you can use a cache that prevents re-translation of
 *            recently translated sentences
 *            This parameter specifies the cache size (number of sentences)
 *
 * -threads (1) -- number of execution threads; or "auto" for automatic number of threads (attempt to determine the number of available processors/cores)
 * -batch (1) -- for multi-threaded execution, the number of sentences that are read from input (file/stdin) and sent in a single batch for translation
 *            Default: 100 (defined in PhramerMain). When batch size <= 1, then the execution takes place single-threaded
 * -concurrent (0) -- allow concurrent calls for
 * -env (0) -- print running environment information
 *
 * -meta (n*3) -- metaData that will be read from files.
 *    Each file:
 *       key
 *       separator (to split the line into String[])
 *       file_name
 *
 * -usewordalign (0) -- make use of the word alignment available in the translation table for each phrase?
 *        It affects translation table loading. It may affect various implementations of plugins (such as
 *        ConstraintChecker plugins)
 *
 *
 * All instantiated classes, with the exception of -x-unk-words-transliterator,
 * should have only one constructor, with the signiature: (PhramerConfig , String[])
 *
 *
 * Changed parameters
 * -trace / -t (0) -- the same
 * -trace / -t (1) -- sets trace level:
 *                    0 = no trace
 *                    1 = default trace (full, same as -t (0))
 *                    2 = minimal trace (only | separator)
 *                    3 = probability of the phrase
 *                    4 = f-word range
 */

public class PhramerConfig
{
	private static class ClassInstantiation
	{
		public static final String[] _NAMES =
		{
			"-x-unk-phrases" ,
			"-x-translation-variants-inspector",
			"-x-constraint-processor",
			"-x-custom-probability-calculator",
			"-x-pre-filter",
			"-x-post-filter",
		};
		
		public static final int OOTT_PHRASE_GENERATOR = 0;
		public static final int INSPECTOR = 1;
		public static final int CONSTRAINT = 2;
		public static final int CUSTOM_PROBABILITY_CALCULATOR = 3;
		public static final int PRE_FILTER = 4;
		public static final int POST_FILTER = 5;
	}
	// My objects
	private boolean isRescoring;
	public Instrument instrument;
	public TokenBuilder tokenBuilder;
	public PhramerHelperIf helper;
	public PrintStream verboseDump;
	public TranslationTable translationTable;
	public LMProcessor lmProcessor;
	public ContextComparator contextComparator;
	private boolean ttStoreDetails = false;
	public ConstraintChecker constraintChecker;
	public ConstraintCreator constraintCreator;
	public OutOfTranslationTablePhraseGenerator unkWordsPhraseVariants;
	public PhraseTranslationVariantInspector translationVariantsInspector;
	public CustomProbability customProbability;
	public PreFilter preFilter;
	public PostFilter postFilter;
	public boolean calculateLM; // calculate the value of LM score during decoding?
	// To be disabled for alignment
	
	// TODO: configure
	public FutureCostInstrument futureCostInstrument = null;
	// TODO: configure
	private final int wordAlignmentEncoding = WordAlignmentTypes.ENCODING_STANDARD;
	public WordAlignmentBuilder wordAlignmentBuilder; // this is the object that deals with word alignemnt
	
	
	// My parameters
	public String encodingLM; // lmenc
	public String encodingTT; // ttenc
	public String encodingInput; //renc
	public String encodingOutput; //wenc
	
	public int onlyNonPositiveLogProbabilitiesLevel; // x-level-good-probabilities
	
	public int compatibilityLevel; //compatibility
	
	public String futureCostCalculatorClass;// x-future-cost-class
	//"org.phramer.decoder.cost.VoidCostCalculator";//"org.phramer.decoder.cost.ExtendedPharaohDFutureCostCalculator";
	public String unkWordsTransliteratorClass;//x-unk-words-transliterator
	
	public String[] _class;// x-unk-phrases, etc.
	public String[][] _param;// x-unk-phrases-param, etc.
	
	/** How long can be a phrase?
	 * It is designed to accelerate and reduce memory consumption.
	 * It is supposed to help non-memory TTs
	 * 0 = infinite
	 * Default value (10) */
	public int maxPhraseLength; // x-max-phrase-length
	
	/** How many words are needed to compute the probability of adding a new word into the sentence. <br>
	 * If a n-gram model is used, lmContextLength = n-1.
	 */
	public int lmContextLength;// x-context-length
	/** Translate chunks, not sentences. Don't add &lt;s> and &lt;/s> in language model
	 */
	public boolean chunk; //x-chunk
	
	public Boolean simpleScoreFiles; // x-score-simple
	public String[] scoreMask; // x-score-mask
	
	public String scorePath;// x-score
	public int scoreN;// x-score
	
	public String nBestPath;// x-nbest
	public int nBestN;// x-nbest
	public boolean nBestIncludeP; // x-nbest-includeprob
	
	/** If a phrase <w1 .. wk> is in the translation table, then also <w1 .. wk-1> is in the translation table */
	public boolean prefixTT; // x-prefix-tt
	
	public double[] weightX;
	
	public String[] meta; // -meta
	
	public ExtraOutput[] extraOutput; // x-extra-output
	public String extraOutputSeparator; // x-extra-output-separator
	private Map<String,String[]> _extraOutputParam; // x-extra-output-W-param
	private String[] _extraOutput;
	
	public boolean useWordAlignment;// usewordalign
	
	
	// Standard parameters
	public int trace;// extended: default = 0, no trace
	public int verboseLevel;
	
	public String lattice;
	
	private double[] weightT;
	
	
	public double[] weightT()
	{return weightT;}
	public double[] weightL()
	{return _lmWeights;}
	public double weightD;
	public double weightW;
	
	public int tTableLimit;
	public double tTableThreshold;
	
	public int stack;
	private double beamThreshold;
	public double logBeamThreshold;
	
	public int distortionLimit;
	
	public boolean monotone;
	
	public boolean bypassMarked;
	public double weightMarked;
	
	
	/** Apply new parameters */
	// TODO: test it
	public void reparseCommandLine(String commandLine) throws PhramerException, IOException
	{
		String[] cmdLine = CommandLineTools.tokenize(commandLine);
		String configFile = CommandLineTools.getParameter("-f" , cmdLine);
		if (configFile == null)
			configFile = CommandLineTools.getParameter("-config" , cmdLine);
		
		if (configFile != null)
			throw new PhramerException("cannot re-read config file");
		
		
		// read parameters, overwrite
		HashMap<String,Object> params = CommandLineTools.getParameters(cmdLine , "-");
		Set<String> keys = params.keySet();
		for (String key : keys)
			if (params.get(key) == null)
				parameterNull(key, true , true);
			else if (params.get(key) instanceof String)
				parameterSingle(key , (String)params.get(key), true , true);
			else
				parameterMulti(key , (String[])params.get(key), true , true);
		
		// reload translation table, if it is not possible to readjust it
		if (!translationTable.readjustWeights(isRescoring ? Integer.MAX_VALUE : tTableLimit, tTableThreshold, weightT))
			translationTable = helper.loadTranslationTable(tokenBuilder ,
														   _ttFile,
														   encodingTT ,
														   wordAlignmentBuilder ,
														   isRescoring ? Integer.MAX_VALUE : tTableLimit,
														   maxPhraseLength == 0 ? Integer.MAX_VALUE : maxPhraseLength ,
														   tTableThreshold,
														   weightT,
														   useWordAlignment,
														   ttStoreDetails);
		
		
		// readjust language models
		for (int i = 0; i < _languageModelFiles.length; i++)
		{
			double logProbabilityUnk = -10;
			if (_lmUnkLogProbability != null)
				logProbabilityUnk = _lmUnkLogProbability[i];
			double minLogProbability = -10;
			if (_lmMinLogProbability != null)
				minLogProbability = _lmMinLogProbability[i];
			
			lmProcessor.reconfigure(i, _lmWeights[i] , logProbabilityUnk , minLogProbability);
		}
		
		// reload context comparator
		contextComparator = helper.getContextComparator(lmContextLength);
		
	}
	
	
	
	public PhramerConfig(String commandLine, PhramerHelperIf helper , Instrument instrument) throws IOException, PhramerException
	{
		this();
		String[] cmdLine = CommandLineTools.tokenize(commandLine);
		initialize(cmdLine, helper , instrument);
	}
	
	public PhramerConfig(String[] cmdLine, PhramerHelperIf helper , Instrument instrument)
	throws IOException, PhramerException
	{
		this();
		initialize(cmdLine, helper, instrument);
	}
	
	protected void initialize(String[] cmdLine, PhramerHelperIf helper, Instrument instrument)
	throws PhramerException, IOException
	{
		// identify what is the config file
		String configFile = CommandLineTools.getParameter("-f" , cmdLine);
		if (configFile == null)
			configFile = CommandLineTools.getParameter("-config" , cmdLine);
//		if (configFile == null)
//			throw new PhramerException("no config file");
		
		
		// read config file
		if (configFile != null)
		{
			String activeParameter = null;
			Vector<String> values = new Vector<String>();
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(IOTools.getInputStream(configFile), PhramerTools.getDefaultEncodingDataFiles()));
			String lineFile;
			while ((lineFile = inputFile.readLine()) != null)
			{
				lineFile = lineFile.trim();
				// ignore comments or empty lines
				if (lineFile.startsWith("#") || lineFile.length() == 0)
					continue;
				
				if (lineFile.startsWith("[") && lineFile.endsWith("]"))
				{
					if (activeParameter != null)
						commitParams(values, activeParameter);
					activeParameter = "-" + lineFile.substring(1 , lineFile.length() - 1);
				}
				else
					values.add(lineFile);
			}
			inputFile.close();
			if (activeParameter != null)
				commitParams(values, activeParameter);
			assert values.size() == 0;
		}
		
		// read parameters, overwrite
		HashMap<String,Object> params = CommandLineTools.getParameters(cmdLine , "-");
		if (params == null)
			throw new PhramerException("Invalid command line - all parameters should start with dash");
		Set<String> keys = params.keySet();
		for (String key : keys)
			if (params.get(key) == null)
				parameterNull(key, true , false);
			else if (params.get(key) instanceof String)
				parameterSingle(key , (String)params.get(key), true , false);
			else
				parameterMulti(key , (String[])params.get(key), true , false);
		
		// check missing params
		if (_ttFile == null)
			throw new PhramerException("no phrase translation table");
		if (_languageModelFiles == null)
			throw new PhramerException("no language model");
		if (!_weightD)
			throw new PhramerException("no weight-d");
		if (!_weightL)
			throw new PhramerException("no weight-l");
		if (!_weightT)
			throw new PhramerException("no weight-t");
		if (!_weightW)
			throw new PhramerException("no weight-w");
		
		// check consistency of params
		if (_languageModelFiles.length != _lmWeights.length)
			throw new PhramerException("no match between # of LMs and # of LM weights");
		
		
		// initialize
		this.instrument = getInstrument(instrument);
		if (helper == null)
			helper = PhramerHelperSimpleImpl.get(unkWordsTransliteratorClass);
		this.helper = helper;
		
		
		
		
		// get the token builder
		tokenBuilder = helper.getTokenBuilder();
		
		// get the word alignment builder (it needs to be early instantiated, because some plugins might use it)
		wordAlignmentBuilder = WordAlignmentBuilderFactory.getWordAlignmentBuilder(wordAlignmentEncoding);
		
		
		// check language models
		if (_languageModelFiles.length != _lmWeights.length)
			throw new PhramerException("weight-l doesn't match lmodel-file");
		if (_lmUnkLogProbability != null)
			if (_languageModelFiles.length != _lmUnkLogProbability.length)
				throw new PhramerException("x-oov-probability doesn't match lmodel-file");
		if (_lmMinLogProbability != null)
			if (_languageModelFiles.length != _lmMinLogProbability.length)
				throw new PhramerException("x-lm-lbound doesn't match lmodel-file");
		
		// get context comparator
		contextComparator = helper.getContextComparator(lmContextLength);
		
		// initialize unkWordsPhraseVariants
		if (_class[ClassInstantiation.OOTT_PHRASE_GENERATOR] != null)
			unkWordsPhraseVariants = (OutOfTranslationTablePhraseGenerator)
				PhramerTools.instantiateClass(_class[ClassInstantiation.OOTT_PHRASE_GENERATOR],
											  this,
											  _param[ClassInstantiation.OOTT_PHRASE_GENERATOR]
											  );
		
		// initialize translationVariantsInspector
		if (_class[ClassInstantiation.INSPECTOR] != null)
			translationVariantsInspector = (PhraseTranslationVariantInspector)
				PhramerTools.instantiateClass(_class[ClassInstantiation.INSPECTOR],
											  this,
											  _param[ClassInstantiation.INSPECTOR]
											  );
		
		// initialize constraintChecker, constraintCreator
		if (_class[ClassInstantiation.CONSTRAINT] != null)
		{
			ConstraintProcessor cp = (ConstraintProcessor)
				PhramerTools.instantiateClass(_class[ClassInstantiation.CONSTRAINT],
											  this,
											  _param[ClassInstantiation.CONSTRAINT]
											  );
			constraintChecker = cp;
			constraintCreator = cp;
		}
		
		// initialize customProbability
		if (_class[ClassInstantiation.CUSTOM_PROBABILITY_CALCULATOR] != null)
		{
			customProbability = (CustomProbability)
				PhramerTools.instantiateClass(_class[ClassInstantiation.CUSTOM_PROBABILITY_CALCULATOR],
											  this,
											  _param[ClassInstantiation.CUSTOM_PROBABILITY_CALCULATOR]
											  );
			ttStoreDetails |= customProbability.requiresDetailedProbabilitiesInTranslationTable();
		}
		
		// initialize pre-filter
		if (_class[ClassInstantiation.PRE_FILTER] != null)
			preFilter = (PreFilter)
				PhramerTools.instantiateClass(_class[ClassInstantiation.PRE_FILTER],
											  this,
											  _param[ClassInstantiation.PRE_FILTER]
											  );
		
		// initialize post-filter
		if (_class[ClassInstantiation.POST_FILTER] != null)
			postFilter = (PostFilter)
				PhramerTools.instantiateClass(_class[ClassInstantiation.POST_FILTER],
											  this,
											  _param[ClassInstantiation.POST_FILTER]
											  );
		
		// intialize extra output
		if (_extraOutput == null)
			extraOutput = null;
		else
		{
			extraOutput = new ExtraOutput[_extraOutput.length];
			for (int i = 0; i < extraOutput.length; i++)
				if (_extraOutput[i].equals("probability"))
					extraOutput[i] = new ExtraOutputProbability();
				else if (_extraOutput[i].equals("phrase-alignment"))
					extraOutput[i] = new ExtraOutputPhraseAlignment();
				else if (_extraOutput[i].equals("word-alignment"))
					extraOutput[i] = new ExtraOutputWordAlignment(this , _extraOutputParam.get(String.valueOf(i + 1)));
				else
					extraOutput[i] = (ExtraOutput)
						PhramerTools.instantiateClass(_extraOutput[i],
													  this,
													  _extraOutputParam.get(String.valueOf(i + 1))
													  );
			
		}
		
		
		if (weightX != null && customProbability == null
			|| weightX == null && customProbability != null)
			throw new PhramerException("-weight-x need to pair -x-custom-probability-calculator");
		if (weightX != null)
			if (weightX.length != customProbability.getNoProbabilities())
				throw new PhramerException("-weight-x doesn't match -x-custom-probability-calculator (weightX:" + weightX.length + " expected:" + customProbability.getNoProbabilities() + ")");
		
		// load translation table
		// if is rescoring, no translation table limit: compatibility with minimum-error-rate-training.perl
		translationTable = helper.loadTranslationTable(tokenBuilder ,
													   _ttFile,
													   encodingTT ,
													   wordAlignmentBuilder ,
													   isRescoring ?Integer.MAX_VALUE: tTableLimit,
													   maxPhraseLength == 0 ? Integer.MAX_VALUE : maxPhraseLength ,
													   tTableThreshold,
													   weightT,
													   useWordAlignment,
													   ttStoreDetails);
		
		
		// now load language models
		LanguageModelIf lm[] = new LanguageModelIf[ _languageModelFiles.length ];
		for (int i = 0; i < _languageModelFiles.length; i++)
			lm[i] = helper.loadLanguageModel(_languageModelFiles[i] , encodingLM , i);
		
		// choose a faster one, if it is possible
		if (lm.length == 1 && lm[0].isVocabularyBasedLM() && lm[0].allowFastCall())
			lmProcessor = new Vocabulary1LMProcessor(0);
		else
			lmProcessor = new GenericLMProcessor(_languageModelFiles.length, 0, helper.getNullContext(lmContextLength));
		
		for (int i = 0; i < _languageModelFiles.length; i++)
		{
			double logProbabilityUnk = -10;
			if (_lmUnkLogProbability != null)
				logProbabilityUnk = _lmUnkLogProbability[i];
			double minLogProbability = -10;
			if (_lmMinLogProbability != null)
				minLogProbability = _lmMinLogProbability[i];
			
			lmProcessor.registerLM(lm[i]
								   , helper.loadPreprocessor(_languageModelFiles[i] , i)
								   , _lmWeights[i] , logProbabilityUnk , minLogProbability)
				;
		}
		
		
		// inform the token builder that the intitialization took place
        tokenBuilder.initializationFinished();
        
        // report this
        this.instrument.config(this);
    }
	
	private Instrument getInstrument(Instrument instrument)
	{
		// verbose level
		
		if (instrument == null)
			instrument = VeryVoidInstrument.VVI;
		
		if (verboseLevel >= 3)
			instrument = new VerboseLevel3Instrument(instrument , verboseDump , this);
		else
		if (verboseLevel == 2)
			instrument = new VerboseLevel2Instrument(instrument , verboseDump , this);
		// else do nothing
		
		return instrument;
	}
	private void commitParams(Vector<String> values, String activeParameter) throws PhramerException
	{
		if (values.size() == 0)
			parameterNull(activeParameter, false , false);
		else if (values.size() == 1)
			parameterSingle(activeParameter, values.firstElement(), false , false);
		else
			parameterMulti(activeParameter , values.toArray(new String[values.size()]), false , false);
		values.clear();
	}
	
	
	
	protected void parameterNull(String key, boolean commandLine , boolean reapply) throws PhramerException
	{
		if (key.equals("-simple-sc") || key.equals("-x-score-simple"))
		{
			simpleScoreFiles = true;
			return;
		}
		if (key.equals("-x-chunk"))
		{
			chunk = true;
			return;
		}
		if (key.equals("-x-nbest-includeprob"))
		{
			nBestIncludeP = true;
			return;
		}
		if (key.equals("-x-prefix-tt"))
		{
			prefixTT = true;
			return;
		}
		if (key.equals("-usewordalign"))
		{
			useWordAlignment = true;
			return;
		}
		
		if (commandLine)
		{
			// ignore
			if (key.equals("-profile"))
				return;
			if (key.equals("-concurrent"))
				return;
			if (key.equals("-env"))
				return;
			
			if (key.equals("-rescore") || key.equals("-r"))
			{
				if (reapply && !ttStoreDetails)
					throw new PhramerException("Reparse command line: cannot store TT details from now on");
				ttStoreDetails = true;
				isRescoring = true;
				return;
			}
			if (key.equals("-monotone"))
			{
				monotone = true;
				return;
			}
			
			if (key.equals("-trace") || key.equals("-t"))
			{
				trace = 1;
				return;
			}
			
			if (key.equals("-bypass-marked"))
			{
				bypassMarked = true;
				return;
			}
		}
		throw new PhramerException("Invalid parameter: " + key);
	}
	
	protected void parameterSingle(String key, String value, boolean commandLine , boolean reapply) throws PhramerException
	{
		if (key.equals("-x-level-good-probabilities"))
		{
			onlyNonPositiveLogProbabilitiesLevel = Integer.parseInt(value);
			return;
		}
		
		if (key.equals("-x-score-mask") || key.equals("-sc-mask"))
		{
			scoreMask = StringTools.tokenize(value , ",");
			return;
		}
		
		if (key.equals("-compatibility"))
		{
			compatibilityLevel = PhramerTools.getCompatibilityLevel(value);
			return;
		}
		if (key.equals("-x-future-cost-class"))
		{
			futureCostCalculatorClass = value;
			return;
		}
		
		//if (!commandLine)
		if (key.equals("-ttable-file"))
		{
			_ttFile = value;
			return;
		}
		//if (!commandLine)
		if (key.equals("-lmodel-file"))
		{
			_languageModelFiles = new String[1];
			_languageModelFiles[0] = value;
			return;
		}
		
		if (key.equals("-weight-x") || key.equals("-px"))
		{
			if (reapply && (weightX.length != 1))
				throw new PhramerException("Reparse command line: different number of weight-x");
			
			weightX = new double[1];
			weightX[0] = Double.parseDouble(value);
			return;
		}
		if (key.equals("-weight-t") || key.equals("-tm"))
		{
			if (reapply && (weightT.length != 1))
				throw new PhramerException("Reparse command line: different number of weight-t");
			
			weightT = new double[1];
			weightT[0] = Double.parseDouble(value);
			_weightT = true;
			return;
		}
		if (key.equals("-weight-l") || key.equals("-lm"))
		{
			if (reapply && (_lmWeights.length != 1))
				throw new PhramerException("Reparse command line: different number of weight-l");
			
			_lmWeights = new double[1];
			_lmWeights[0] = Double.parseDouble(value);
			_weightL = true;
			return;
		}
		if (key.equals("-weight-d") || key.equals("-d"))
		{
			weightD = Double.parseDouble(value);
			_weightD = true;
			return;
		}
		if (key.equals("-weight-w") || key.equals("-w"))
		{
			weightW = Double.parseDouble(value);
			_weightW = true;
			return;
		}
		if (key.equals("-x-oov-probability") || key.equals("-x-oov"))
		{
			if (reapply && (_lmUnkLogProbability.length != 1))
				throw new PhramerException("Reparse command line: different number of x-oov-probability");
			
			_lmUnkLogProbability = new double[1];
			_lmUnkLogProbability[0] = Double.parseDouble(value);
			return;
		}
		if (key.equals("-x-lm-lbound") || key.equals("-x-lb"))
		{
			if (reapply && (_lmMinLogProbability.length != 1))
				throw new PhramerException("Reparse command line: different number of x-lm-lbound");
			
			_lmMinLogProbability = new double[1];
			_lmMinLogProbability[0] = Double.parseDouble(value);
			return;
		}
		if (key.equals("-x-context-length"))
		{
			lmContextLength = Integer.parseInt(value);
			return;
		}
		if (key.equals("-x-max-phrase-length"))
		{
			maxPhraseLength = Integer.parseInt(value);
			return;
		}
		
		if (key.equals("-ttable-limit"))
		{
			tTableLimit = Integer.parseInt(value);
			return;
		}
		if (key.equals("-ttable-threshold"))
		{
			tTableThreshold = Double.parseDouble(value);
			return;
		}
		if (key.equals("-stack") || key.equals("-s"))
		{
			stack = Integer.parseInt(value);
			return;
		}
		if (key.equals("-beam-threshold") || key.equals("-b"))
		{
			beamThreshold = Double.parseDouble(value);
			logBeamThreshold = MathTools.numberToLog(beamThreshold);
			return;
		}
		if (key.equals("-distortion-limit") || key.equals("-dl"))
		{
			distortionLimit = Integer.parseInt(value);
			return;
		}
		
		if (key.equals("-weight-marked"))
		{
			weightMarked = Double.parseDouble(value);
			return;
		}
		if (key.equals("-lmenc"))
		{
			encodingLM = value;
			return;
		}
		if (key.equals("-ttenc"))
		{
			encodingTT = value;
			return;
		}
		if (key.equals("-x-extra-separator"))
		{
			extraOutputSeparator = value;
			return;
		}
		if (key.equals("-x-extra-output"))
		{
			_extraOutput = new String[]{value};
			return;
		}
		if (key.startsWith("-x-extra-output-") && key.endsWith("-param"))
		{
			String xKey = StringTools.substringBefore(StringTools.substringAfter(key , "-x-extra-output-"), "-param");
			_extraOutputParam.put(xKey , new String[]{value});
			return;
		}
		for (int i = 0; i < _class.length; i++)
		{
			if (key.equals(ClassInstantiation._NAMES[i]))
			{
				_class[i] = value;
				return;
			}
			if (key.equals(ClassInstantiation._NAMES[i] + "-param"))
			{
				_param[i] = new String[1];
				_param[i][0] = value;
				return;
			}
		}
		if (commandLine)
		{
			// WARNING: sync with PhramerHelperSimpleImpl
			if (key.equals("-x-unk-words-transliterator"))
			{
				unkWordsTransliteratorClass = value;
				return;
			}
			
			// ignore inputtype - PhramerMain option
			if (key.equals("-inputtype"))
				return;
			
			// ignore config
			if (key.equals("-config") || key.equals("-f"))
				return;
			// ignore the server command
			if (key.equals("-server"))
				return;
			// ignore the thread count, batch size and cache info
			if (key.equals("-threads"))
				return;
			if (key.equals("-batch"))
				return;
			if (key.equals("-cache"))
				return;
			// encoding, command line only
			if (key.equals("-renc"))
			{
				encodingInput = value;
				return;
			}
			if (key.equals("-wenc"))
			{
				encodingOutput = value;
				return;
			}
			
			if (key.equals("-trace") || key.equals("-t"))
			{
				trace = Integer.parseInt(value);
				return;
			}
			
			// ignore commands
			if (key.equals("-rescore") || key.equals("-r"))
			{
				ttStoreDetails = true;
				return;
			}
			
			// verbose level
			if (key.equals("-verbose") || key.equals("-v"))
			{
				verboseLevel = Integer.parseInt(value);
				return;
			}
			
			// lattice output
			if (key.equals("-lattice") || key.equals("-l"))
			{
				lattice = value;
				return;
			}
			// ignore: read file, write file, start-id
			if (key.equals("-read") || key.equals("-write") || key.equals("-start-id"))
				return;
		}
		throw new PhramerException("Invalid parameter: " + key);
	}
	
	protected void parameterMulti(String key, String[] value, boolean commandLine , boolean reapply) throws PhramerException
	{
		if (key.equals("-meta"))
		{
			meta = value;
			return;
		}
		//if (!commandLine)
		if (key.equals("-lmodel-file"))
		{
			_languageModelFiles = value;
			return;
		}
		
		if (key.equals("-weight-t") || key.equals("-tm"))
		{
			if (reapply && (weightT.length != value.length))
				throw new PhramerException("Reparse command line: different number of weight-t");
			
			weightT = new double[value.length];
			for (int i = 0; i < value.length; i++)
				weightT[i] = Double.parseDouble(value[i]);
			_weightT = true;
			return;
		}
		if (key.equals("-weight-l") || key.equals("-lm"))
		{
			if (reapply && (_lmWeights.length != value.length))
				throw new PhramerException("Reparse command line: different number of weight-l");
			
			_lmWeights = new double[value.length];
			for (int i = 0; i < value.length; i++)
				_lmWeights[i] = Double.parseDouble(value[i]);
			_weightL = true;
			return;
		}
		if (key.equals("-weight-x") || key.equals("-px"))
		{
			if (reapply && (weightX.length != value.length))
				throw new PhramerException("Reparse command line: different number of weight-x");
			
			weightX = new double[value.length];
			for (int i = 0; i < value.length; i++)
				weightX[i] = Double.parseDouble(value[i]);
			return;
		}
		if (key.equals("-x-oov-probability") || key.equals("-x-oov"))
		{
			if (reapply && (_lmUnkLogProbability.length != value.length))
				throw new PhramerException("Reparse command line: different number of x-oov-probability");
			
			_lmUnkLogProbability = new double[value.length];
			for (int i = 0; i < value.length; i++)
				_lmUnkLogProbability[i] = Double.parseDouble(value[i]);
			return;
		}
		if (key.equals("-x-lm-lbound") || key.equals("-x-lb"))
		{
			if (reapply && (_lmMinLogProbability.length != value.length))
				throw new PhramerException("Reparse command line: different number of x-lm-lbound");
			
			_lmMinLogProbability = new double[value.length];
			for (int i = 0; i < value.length; i++)
				_lmMinLogProbability[i] = Double.parseDouble(value[i]);
			return;
		}
		if (key.equals("-x-extra-output"))
		{
			_extraOutput = value;
			return;
		}
		if (key.startsWith("-x-extra-output-") && key.endsWith("-param"))
		{
			String xKey = StringTools.substringBefore(StringTools.substringAfter(key , "-x-extra-output-"), "-param");
			_extraOutputParam.put(xKey , value);
			return;
		}
		for (int i = 0; i < _class.length; i++)
			if (key.equals(ClassInstantiation._NAMES[i] + "-param"))
			{
				_param[i] = value;
				return;
			}
		if (commandLine)
		{
			if (key.equals("-rescoredir") || key.equals("-rd"))
			{
				if (value.length != 2)
					throw new PhramerException("Expecting 2 values for " + key + ". Got " + value.length);
				if (reapply && !ttStoreDetails)
					throw new PhramerException("Reparse command line: cannot store TT details from now on");
				ttStoreDetails = true;
				isRescoring = true;
				return;
			}
			if (key.equals("-x-score") || key.equals("-sc"))
			{
				if (value.length != 2)
					throw new PhramerException("Expecting 2 values for " + key + ". Got " + value.length);
				if (reapply && !ttStoreDetails)
					throw new PhramerException("Reparse command line: cannot store TT details from now on");
				ttStoreDetails = true;
				scorePath = value[0];
				scoreN = Integer.parseInt(value[1]);
				return;
			}
			if (key.equals("-x-nbest") || key.equals("-nb"))
			{
				if (value.length != 2)
					throw new PhramerException("Expecting 2 values for " + key + ". Got " + value.length);
				if (reapply && !ttStoreDetails)
					throw new PhramerException("Reparse command line: cannot store TT details from now on");
				ttStoreDetails = true;
				nBestPath = value[0];
				nBestN = Integer.parseInt(value[1]);
				return;
			}
		}
		
		throw new PhramerException("Invalid parameter: " + key);
	}
	
	
	private String[] _languageModelFiles;
	private double[] _lmWeights;
	private double[] _lmUnkLogProbability; // -x-oov-probability
	private double[] _lmMinLogProbability; // -x-lm-lbound
	private String _ttFile;
	private boolean _weightT , _weightL , _weightD , _weightW;
	
	
	private PhramerConfig()
	{
		compatibilityLevel = Integer.MAX_VALUE;
		
		tTableLimit = 20;
		tTableThreshold = 0;
		
		stack = 100;
		beamThreshold = 0.00001;
		logBeamThreshold = MathTools.numberToLog(beamThreshold);
		
		distortionLimit = 0;
		
		monotone = false;
		
		onlyNonPositiveLogProbabilitiesLevel = 0;
		
		bypassMarked = false;
		weightMarked = 1;
		
		maxPhraseLength = 10;
		
		lmContextLength = 2;
		
		
		trace = 0;
		lattice = null;
		
		simpleScoreFiles = false;
		
		scoreMask = null;
		
		scorePath = null;
		scoreN = 0;
		
		nBestPath = null;
		nBestN = 0;
		nBestIncludeP = false;
		
		prefixTT = false;
		
		calculateLM = true;
		
		verboseLevel = 0;
		verboseDump = System.out;
		
		unkWordsTransliteratorClass = null;
		unkWordsPhraseVariants = null;
		
		translationVariantsInspector = null;
		constraintChecker = ConstraintChecker.VOID;
		constraintCreator = null;
		
		customProbability = null;
		weightX = null;
		
		futureCostCalculatorClass = null;
		
		wordAlignmentBuilder = null;
		
		preFilter = PreFilter.VOID;
		postFilter = PostFilter.VOID;
		
		encodingInput = PhramerTools.getDefaultEncodingInput();
		encodingOutput = PhramerTools.getDefaultEncodingOutput();
		encodingTT = PhramerTools.getDefaultEncodingDataFiles();
		encodingLM = PhramerTools.getDefaultEncodingDataFiles();
		
		meta = null;
		
		extraOutput = null;
		extraOutputSeparator = "|||";
		_extraOutputParam = new HashMap<String, String[]>();
		_extraOutput = null;
		
		useWordAlignment = false;
		
		
		_class = new String[ClassInstantiation._NAMES.length];
		_param = new String[ClassInstantiation._NAMES.length][];
	}
	
	public boolean latticeUse()
	{
		return lattice != null || scorePath != null || nBestPath != null;
	}
}
