/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.cost.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.lattice.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.phrase.*;
import org.phramer.v1.decoder.rescore.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.token.*;
import org.phramer.v1.decoder.xml.*;


/**
 *
 * TODO: don't add if below threshold (eventually as an option)
 * TODO:x another Stack implementation: I tried, it doesn't work
 * TODO:x word translation that can be part of a translation phrase
 * TODO: store future cost in TT
 * TODO: store LM info into TT - estimate savings: 20% of LM queries during search
 */

public class Phramer extends PhramerIfBasicImpl implements MachineTranslator
{
	public static final String VERSION = "Phramer v1.1 - July 5, 2009";
	
	
	
	
	
	// nanochronometerring - used for performance profiling
	public static ProfilerChronometer nanoClockTranslate = new ProfilerChronometer("Phramer.translate()");
	public static ProfilerChronometer nanoClockDecodeTheStack = new ProfilerChronometer("Phramer.decodeTheStack()", nanoClockTranslate);
	public static ProfilerChronometer nanoClockInitializeFromTranslationTable = new ProfilerChronometer("Phramer.initializeFromTranslationTable()" , nanoClockTranslate);
	
	public int __constraintDecodingFail = 0 , __constraintDecodingSuccess = 0;
	
	public Phramer(PhramerConfig config)
	{
		this.config = config;
	}
	// the configuration object
	private PhramerConfig config;
	
	/** Rescores files a file to be rescored. Emulates pharaoh behavior */
	public void rescore(BufferedReader input , PrintStream output)
	throws PhramerException, IOException
	{
		String lineFile;
		while ((lineFile = input.readLine()) != null)
			if (lineFile.length() > 0)
			{
				// tokenize the line
				StringTokenizer st = new StringTokenizer(lineFile);
				
				List<RescoreChunk> chunks = new ArrayList<RescoreChunk>();
				String tProbability = Rescore.parseInput(config.tokenBuilder , st, lineFile , chunks);
				
				// rescore and print
				output.println(Rescore.rescore(config , chunks , tProbability));
			}
		input.close();
		output.close();
	}
	
	
	/** Translates XML input. Outputs n-best list, as hypotheses lists. Doesn't generate
	 * any additional files: carmel lattice, n-best list, rescore output.<br>
	 * The hypotheses in the arraylist: from the end to the beginning.
	 * <br>
	 * Metadata is provided
	 */
	public List<List<HypothesisState>> translateXMLintoNbest(String fSentence , int nBestSize , Map<String,String[]> metaData)
	throws PhramerException, IOException
	{
		return _translateIntoNbest(fSentence , nBestSize , metaData).first;
	}
	private Triplet<List<List<HypothesisState>>,PhramerInput,SearchStackIf[]> _translateXMLintoNbest(String fSentence , int nBestSize , Map<String,String[]> metaData)
	throws PhramerException, IOException
	{
		return _translateIntoNbest(XmlInputTools.getXML(config.preFilter.filter(fSentence , metaData) , config.tokenBuilder , metaData), nBestSize);
	}
	
	/** Aligns a foreign sentence with an english sentence.
	 * Outputs the states for the best hypothesis, or null if the alignment fails.
	 * Input is XML for the foreign sentence.
	 * <br>
	 * Metadata is provided
	 */
	public List<HypothesisState> alignXML(String fSentence, String eSentence , int sentenceIdx , Map<String,String[]> metaData)
	throws PhramerException, IOException
	{
		return align(XmlInputTools.getXML(config.preFilter.filter(fSentence , metaData) , config.tokenBuilder , metaData) , PhramerTools.tokenizeIntoEToken(eSentence , config.tokenBuilder) , sentenceIdx);
	}
	
	
	/** Translates XML input. Outputs the english sentence. Does generate
	 * additional files, if required by configuration: carmel lattice, n-best list,
	 * rescore output
	 * <br>
	 * Metadata is provided
	 */
	public String translateXML(String fSentence, int sentenceIdx , Map<String,String[]> metaData)
	throws PhramerException, IOException
	{
		return translate(XmlInputTools.getXML(config.preFilter.filter(fSentence , metaData) , config.tokenBuilder , metaData) , sentenceIdx);
	}
	
	
	/** Translates non-XML input. Outputs n-best list, as hypotheses lists. Doesn't generate
	 * any additional files: carmel lattice, n-best list, rescore output. <br>
	 * The hypotheses in the arraylist: from the end to the beginning.
	 * <br>
	 * Metadata is provided
	 */
	public List<List<HypothesisState>> translateIntoNbest(String fSentence , int nBestSize, Map<String,String[]> metaData)
	throws PhramerException
	{
		return _translateIntoNbest(fSentence , nBestSize , metaData).first;
	}
	private Triplet<List<List<HypothesisState>>,PhramerInput,SearchStackIf[]> _translateIntoNbest(String fSentence , int nBestSize, Map<String,String[]> metaData)
	throws PhramerException
	{
		return _translateIntoNbest(PhramerInput.getNonXML(config.preFilter.filter(fSentence , metaData) , config.tokenBuilder , metaData), nBestSize);
	}
	
	/** Aligns a foreign sentence with an english sentence.
	 * Outputs the states for the best hypothesis, or null if the alignment fails.
	 * Input is non-XML for the foreign sentence.
	 * <br>
	 * Metadata is provided
	 */
	public List<HypothesisState> align(String fSentence , String eSentence , int sentenceIdx , Map<String,String[]> metaData)
	throws PhramerException
	{
		return align(PhramerInput.getNonXML(config.preFilter.filter(fSentence , metaData), config.tokenBuilder, metaData) , PhramerTools.tokenizeIntoEToken(eSentence , config.tokenBuilder) , sentenceIdx);
	}
	
	
	/** Translates non-XML input. Outputs the english sentence. Does generate
	 * additional files, if required by configuration: carmel lattice, n-best list,
	 * rescore output
	 * <br>
	 * Metadata is provided
	 */
	public String translate(String fSentence , int sentenceIdx, Map<String,String[]> metaData)
	throws PhramerException
	{
		return translate(PhramerInput.getNonXML(config.preFilter.filter(fSentence , metaData), config.tokenBuilder, metaData) , sentenceIdx);
	}
	
	
	/** Translates an input. Outputs n-best list, as hypotheses lists. Doesn't generate
	 * any additional files: carmel lattice, n-best list, rescore output
	 */
	public List<List<HypothesisState>> translateIntoNbest(PhramerInput input , int nBestSize)
	throws PhramerException
	{
		return _translateIntoNbest(input, nBestSize).first;
	}
	private Triplet<List<List<HypothesisState>>,PhramerInput,SearchStackIf[]> _translateIntoNbest(PhramerInput input , int nBestSize)
	throws PhramerException
	{
		SearchStackIf[] stack = decode(input, null , -1 , config.instrument , true , new MutableInt(0));// Warning: sentenceIdx = -1
		
		return new Triplet<List<List<HypothesisState>>,PhramerInput,SearchStackIf[]>(NBestGenerator.iterateFirstNHypotheses(stack , nBestSize), input, stack);
	}
	
	/** Aligns a foreign sentence with an english sentence.
	 * Outputs the states for the best hypothesis, or null if the alignment fails.
	 */
	public List<HypothesisState> align(PhramerInput input , EToken[] output , int sentenceIdx)
	throws PhramerException
	{
		MutableInt hypID = new MutableInt(0);
		SearchStackIf[] stack = decode(input, output , sentenceIdx , config.instrument , config.latticeUse(), hypID);
		HypothesisState bestHyp = doExternalFilesAndGetBestHypothesis(stack, sentenceIdx, input, hypID);
		
		if (bestHyp == null)
			return null;
		
		List<HypothesisState> out = new ArrayList<HypothesisState>();
		HypothesisState h = bestHyp;
		while (h.parent != null)
		{
			out.add(0, h);
			h = h.parent;
		}
		return out;
	}
	
	
	
	/** Translates an input. Outputs the english sentence. Does generate
	 * additional files, if required by configuration: carmel lattice, n-best list,
	 * rescore output
	 */
	public String translate(PhramerInput input , int sentenceIdx)
	throws PhramerException
	{
		nanoClockTranslate.resume();
		MutableInt hypID = new MutableInt(0);
		SearchStackIf[] stack = decode(input, null , sentenceIdx , config.instrument , config.latticeUse() , hypID);
		HypothesisState bestHyp = doExternalFilesAndGetBestHypothesis(stack, sentenceIdx, input, hypID);
		nanoClockTranslate.pause();
		String output;
		if (config.trace != 0)
			output = config.postFilter.filter(getTrace(bestHyp, config.trace) , input);
		else
		{
			// get best hypothesis
			// convert it to e-tokens
			EToken translation[] = PhramerTools.getTranslation(bestHyp);
			// convert to string
			output = config.postFilter.filter(TokenTools.getString(translation) , input);
		}
		
		if (config.extraOutput != null)
		{
			List<HypothesisState> decodingPath = PhramerTools.getTranslationPathReversed(bestHyp);
			StringBuilder sb = new StringBuilder(output);
			
			for (ExtraOutput x : config.extraOutput)
			{
				sb.append(' ')
					.append(config.extraOutputSeparator)
					.append(' ');
				
				sb.append(x.getExtraOutput(input , stack , decodingPath));
			}
			output = sb.toString();
		}
		return output;
	}
	
	private HypothesisState doExternalFilesAndGetBestHypothesis(SearchStackIf[] stack, int sentenceIdx, PhramerInput input, MutableInt hypID) throws PhramerException
	{
		doSpecialInstrumentation(stack);
		
		if (config.lattice != null)
			CarmelLattice.printCarmelLattice(stack , sentenceIdx, input.getFWords().length , hypID.value, config.lattice);
		
		// if we have commands involving lattices, execute them
		doLatticeCommands(input , stack, sentenceIdx);
		
		return getBestFinalState(stack, config.instrument);
	}
	
	private void doSpecialInstrumentation(SearchStackIf[] stack)
	{
		List<Pair<HypothesisState, List<HypothesisState>>> allHypothesisStates = null;
		// do special instrumentation here
		if (config.futureCostInstrument != null)
		{
			if (allHypothesisStates == null)
				allHypothesisStates = HypothesisStateIterator.iterate(stack);
			
			// now report all to the instrument
			for (Pair<HypothesisState, List<HypothesisState>> pair : allHypothesisStates)
			{
				// combine cost of all the successors
				double successorCost = 0;
				for (HypothesisState s : pair.second)
					successorCost += s.getLogProbabilityAdded();
				
				// now report
				config.futureCostInstrument.instance(pair.first , successorCost);
			}
			
		}
	}
	
	
	private void doLatticeCommands(PhramerInput input , SearchStackIf[] stack, int sentenceIdx) throws PhramerException
	{
		// current n-best
		List<List<HypothesisState>> nBest = null;
		int nBestN = -1;
		
		if (config.scorePath != null)
		{
			// reuse nBest if you generate multiple items that require nBest list
			if (nBestN != config.scoreN)
			{
				nBest = NBestGenerator.iterateFirstNHypotheses(stack , config.scoreN);
				nBestN = config.scoreN;
			}
			try
			{
				String path = config.scorePath + "." + PhramerTools.adjustN(Integer.toString(sentenceIdx) , 4) + ".rescore";
				PrintStream outFile = new PrintStream(new FileOutputStream(path) , true , config.encodingOutput);
				for (List<HypothesisState> itemInNbest : nBest)
					outFile.println(Rescore.rescoreNBestItem(input , itemInNbest , config));
				outFile.close();
			}
			catch (IOException e)
			{
				throw new PhramerException("IOException" , e);
			}
		}
		
		
		if (config.nBestPath != null)
		{
			// reuse nBest if you generate multiple items that require nBest list
			if (nBestN != config.nBestN)
			{
				nBest = NBestGenerator.iterateFirstNHypotheses(stack , config.nBestN);
				nBestN = config.nBestN;
			}
			try
			{
				String path = config.nBestPath + "." + PhramerTools.adjustN(Integer.toString(sentenceIdx) , 4) + ".nbest";
				PrintStream outFile = new PrintStream(new FileOutputStream(path), true, config.encodingOutput);
				for (List<HypothesisState> itemInNbest : nBest)
					outFile.println(toStringNBestItem(input, stack, itemInNbest));
				outFile.close();
			}
			catch (IOException e)
			{
				throw new PhramerException("IOException" , e);
			}
		}
	}
	
	/** Builds the text for an item in the nBest list. <br>
	 * Input is reversed */
	private String toStringNBestItem(PhramerInput input , SearchStackIf[] stack , List<HypothesisState> itemInNbest) throws PhramerException
	{
		StringBuilder sb = new StringBuilder();
		double p = 0;
		for (int i = itemInNbest.size() - 1; i >= 0 ; i--)
		{
			HypothesisState state = itemInNbest.get(i);
			p += state.getLogProbabilityAdded();
			sb.append(TokenTools.getString(state.phraseUsed.getTranslation()));
			sb.append(' ');
		}
		
		// TODO: trace
		
		// postFilter
		if (config.postFilter != PostFilter.VOID)
			sb = new StringBuilder(config.postFilter.filter(sb.toString() , input));
		
		if (config.nBestIncludeP)
		//sb.append(MathTools.logToNumber(p));
			sb.append(p);
		
		// extraOutput, optional
		if (config.extraOutput != null)
			for (ExtraOutput x : config.extraOutput)
			{
				sb.append(' ')
					.append(config.extraOutputSeparator)
					.append(' ');
				
				sb.append(x.getExtraOutput(input , stack , itemInNbest));
			}
		
		return sb.toString().trim();
	}
	
	
	/** Builds the trace */
	public static String getTrace(HypothesisState bestHyp , int traceType)
	{
		List<HypothesisState> v = PhramerTools.getTranslationPathReversed(bestHyp);
		StringBuilder sb = new StringBuilder();
		for (int i = v.size() - 1; i >= 0 ; i--)
		{
			HypothesisState state = v.get(i);
			
			switch (traceType)
			{
				case 2:
					sb.append(TokenTools.getString(state.phraseUsed.getTranslation()));
					sb.append(' ');
					sb.append('|');
					sb.append(' ');
					break;
				case 3:
					sb.append(TokenTools.getString(state.phraseUsed.getTranslation()));
					sb.append(' ');
					sb.append('|');
					sb.append(MathTools.logToNumber(state.getLogProbabilityAdded()));
					sb.append('|');
					sb.append(' ');
					break;
				case 4:
					sb.append(TokenTools.getString(state.phraseUsed.getTranslation()));
					sb.append(' ');
					sb.append('|');
					sb.append(PhramerTools.HypothesisStateTools.getFirstDifferent(state.foreignCovered , state.parent.foreignCovered));// Start token
					sb.append('|');
					sb.append(PhramerTools.HypothesisStateTools.getLastDifferent(state.foreignCovered , state.parent.foreignCovered));// End token
					sb.append('|');
					sb.append(' ');
					break;
				default:
					sb.append(TokenTools.getString(state.phraseUsed.getTranslation()));
					sb.append(' ');
					sb.append('|');
					sb.append(MathTools.logToNumber(state.getLogProbabilityAdded()));
					sb.append('|');
					sb.append(PhramerTools.HypothesisStateTools.getFirstDifferent(state.foreignCovered , state.parent.foreignCovered));// Start token
					sb.append('|');
					sb.append(PhramerTools.HypothesisStateTools.getLastDifferent(state.foreignCovered , state.parent.foreignCovered));// End token
					sb.append('|');
					sb.append(' ');
			}
		}
		
		return sb.toString().trim();
	}
	
	
	
	private HypothesisState getBestFinalState(SearchStackIf[] stack, Instrument instrument)
	{
		HypothesisState bestHyp = stack[stack.length - 1].getBest();
		// assert fails on alignment
//		assert bestHyp != null : "Stack " + stack[stack.length - 1].getStackID() + " size " + stack[stack.length - 1].getSize();
		if (bestHyp != null)
			instrument.bestFinalHypothesis(bestHyp);
		return bestHyp;
	}
	
	
	
	
	/** Decodes and fill the decoding stack. <br>
	 * The decoding stack can be used to extract either the best translation or to extract the decoding lattice
	 */
	private SearchStackIf[] decode(PhramerInput input , EToken[] output , int sentenceIdx , Instrument instrument , boolean allowLattice , MutableInt hypID)
	throws PhramerException
	{
		FToken[] fWords = input.getFWords();
		PhraseTranslationVariant[][][] translationVariants = getTranslationVariants(input, output);
		
		// add constraints, if required
		if (input.constraintsDescriptor == null && config.constraintCreator != null)
			input.constraintsDescriptor = config.constraintCreator.createGlobalDescriptor(input, translationVariants , sentenceIdx);

		// precompute estimated cost. Dynamic programming
		FutureCostEstimator costEstimator = config.helper.getCostCalculator(config, instrument);
		costEstimator.initializeInternalData(fWords, translationVariants, instrument);
		
		// init constraint checker
		config.constraintChecker.reportDecoding(input.constraintsDescriptor, true);
		
		// decode
		// initial state
		SearchStackIf[] stack = decodeTheStack(input ,
											   fWords.length,
											   costEstimator ,
											   translationVariants,
											   instrument ,
											   allowLattice ,
											   output ,
											   false ,
											   hypID);
		
		// close constraint checker
		config.constraintChecker.reportDecoding(input.constraintsDescriptor, false);
		
		// backoff: drop hard constraints, if they were the cause of failed decoding
		if (stack[stack.length - 1].size() == 0
			&& config.constraintChecker != ConstraintChecker.VOID)
		{
			__constraintDecodingFail++;
			stack = decodeTheStack(input ,
								   fWords.length,
								   costEstimator ,
								   translationVariants,
								   instrument ,
								   allowLattice ,
								   output ,
								   true ,
								   hypID);
			
		}
		else
			__constraintDecodingSuccess++;
		return stack;
	}
	
	private SearchStackIf[] decodeTheStack(PhramerInput input ,
										   int nfWords,
										   FutureCostEstimator costEstimator,
										   PhraseTranslationVariant[][][] translationVariants ,
										   Instrument instrument ,
										   boolean allowLattice ,
										   EToken[] output ,
										   boolean softMode ,
										   MutableInt hypID) throws PhramerException
	{
		nanoClockDecodeTheStack.resume();
		LMContext sosContext = config.helper.getNullContext(config.lmContextLength);
		
		// to calculate or not the LM feature?
		boolean calculateLM = config.calculateLM;
		// if all weights for the LM are 0, don't calculate
		double[] wL = config.weightL();
		boolean nz = false;
		for (int i = 0; i < wL.length && !nz; i++)
			if (wL[i] != 0)
				nz = true;
		if (!nz)
			calculateLM = false;
		
		// put <s> if it's not chunk translation
		if (!config.chunk)
			sosContext = sosContext.append(config.tokenBuilder.buildEToken(LMConstants.START_OF_SENTENCE));
		
		ConstraintChecker constraintChecker = config.constraintChecker;
		
		SearchStackIf[] hypothesisStack = initializeHypotesisStack(nfWords , allowLattice);
		
		HypothesisState initialHyp = new HypothesisState(nfWords ,
														 costEstimator ,
														 sosContext, hypID.value++ ,
														 config.contextComparator ,
														 output != null,
														 constraintChecker.getDescriptorForStartHypothesisState(input.constraintsDescriptor)
														 );
		instrument.hypothesisCreated(initialHyp , 0 , 0 , 0 , 0);
		hypothesisStack[0].add(initialHyp, allowLattice , instrument);
		
		// cache the buffer: good for speed
		double[] pXs = config.weightX == null ? null : new double[ config.weightX.length ];
		
		for (int i = 0; i < nfWords; i++)
		{
			hypothesisStack[i].prepareBeforeExpand(instrument);
			
			// report the stack here to the constraint checker
			constraintChecker.reportStack(input.constraintsDescriptor, hypothesisStack[i], true);
			
			Iterator<HypothesisState> iter = hypothesisStack[i].iterator();
			while (iter.hasNext())
			{
				HypothesisState hyp = iter.next();
				// generate successors and push into the coresponding stacks
				generateHypothesisSuccessors(hyp ,
											 input ,
											 output ,
											 hypothesisStack ,
											 allowLattice ,
											 nfWords ,
											 translationVariants ,
											 costEstimator,
											 instrument ,
											 pXs ,
											 constraintChecker ,
											 softMode ,
											 hypID ,
											 calculateLM);
			}
			
			// report the stack here to the constraint checker
			constraintChecker.reportStack(input.constraintsDescriptor, hypothesisStack[i], false);
			
		}
		if (config.compatibilityLevel >= 1000200)
			hypothesisStack[nfWords].prepareBeforeExpand(instrument);
		nanoClockDecodeTheStack.pause();
		instrument.stackAfterDecoding(hypothesisStack);
		return hypothesisStack;
	}
	
	
	
	
	/** Expands a hypothesis. <br>
	 * Builds the successors and adds them on the stacks */
	private void generateHypothesisSuccessors(final HypothesisState hyp ,
											  final PhramerInput input ,
											  final EToken[] output ,
											  final SearchStackIf[] hypothesisStack ,
											  boolean allowLattice ,
											  int nfWords,
											  PhraseTranslationVariant[][][] translationVariants ,
											  FutureCostEstimator costEstimator ,
											  Instrument instrument ,
											  double pXs[],
											  ConstraintChecker constraintChecker ,
											  boolean softMode ,
											  MutableInt hypID ,
											  boolean calculateLM
											  ) throws PhramerException
	{
		////System.out.println( hyp.toString() );
		// count how many words were generated till now. Used only for alignment
		int cntWordsGenerated = output != null ?hyp.getCntWordsGeneated(): 0;
		
		// does the constraint checker require detailed information to decide about constraints or not?
		boolean constraintsUseInPhraseAnalysis = constraintChecker.useInPhraseAnalysis();
		// does pX require PhraseTranslationVariant?
		boolean pXusePTV = config.weightX == null ? true : config.customProbability.usePhraseTranslationVariant();
		
		// allow early drop: if we predict that the hypothesis won't be in the stack, then drop it
		boolean earlyDrop = config.onlyNonPositiveLogProbabilitiesLevel >= 1 && !allowLattice;
		boolean earlyDrop2 = config.onlyNonPositiveLogProbabilitiesLevel >= 2 && !allowLattice;
		
		//boolean dl = !config.monotone && config.distortionLimit != 0;
		
		int minStartWord, maxStartWord;
		int firstGap = Integer.MAX_VALUE;
		if (config.monotone)
		{
			minStartWord = hyp.lastForeign + 1;
			maxStartWord = hyp.lastForeign + 1;
		}
		else if (config.distortionLimit != 0)
		{
			// check to see the previous gap
			firstGap = -1;
			for (int j = 0; j < nfWords ; j++)
				if (!hyp.foreignCovered[j])
				{
					firstGap = j;
					break;
				}
			assert firstGap != -1;
			
			// change 06/01/08:
			minStartWord = firstGap;
			
			maxStartWord = hyp.lastForeign + 1 + config.distortionLimit;
			if (maxStartWord >= nfWords)
				maxStartWord = nfWords - 1;
			
			// change 05/12/26: be more relaxed when first gap is after end of last one
			// this is a different behaviour than Pharaoh's
			// to compensate, use -x-max-phrase-length of -dl plus one
			if (firstGap > hyp.lastForeign + 1)
				maxStartWord = nfWords - 1;
			
			maxStartWord = Math.max(maxStartWord ,
									constraintChecker.
									getMaxStartWord(input.constraintsDescriptor ,
													hyp.constraintData ,
													hyp));
		}
		else
		{
			// any choice
			minStartWord = 0;
			maxStartWord = nfWords - 1;
		}
		//List<HypothesisState> list = new ArrayList<HypothesisState>();
		// now search for valid hypothesis
		nextStartWord:
		for (int i = minStartWord; i <= maxStartWord; i++)
		{
			double pD;
			// pD - penality
			pD = config.weightD * -	Math.abs(i - hyp.lastForeign - 1);
			
			nextLength:
			for (int len = 0 ; len < translationVariants[i].length ; len++)
			{
				// warning: total cost can decrease!!!
				
				// if it's not an empty slot
				if (!hyp.foreignNotUsed(i + len))
					continue nextStartWord;
				
				// check if it can be further expanded, because of distortion limit
				// TODOx: improve previous gap computation: this is too conservative. Now it tries to match pharaoh
				//if (dl)
				if (firstGap < i)
				{
					// pointer, after installing this
					// change 06/01/08: match pharaoh's probable behavior (removed "+ 1")
					// if greater than, go to next one
					if (i + len - firstGap > config.distortionLimit)
						continue nextStartWord;
				}
				
				if (translationVariants[i][len] != null)
				{
					// build foreign covered array - it will be shared across the hypos
					boolean[] newForeignCovered = new boolean[ hyp.foreignCovered.length ];
					System.arraycopy(hyp.foreignCovered , 0 , newForeignCovered , 0 , newForeignCovered.length);
					// NEVER USE previous.foreignCovered.clone()
					// pad to what is used
					for (int idx = 0 ; idx <= len; idx++)
					{
						assert !newForeignCovered[i + idx] : hyp + " " + i + " " + len + 1 + " (current ID: " + (hypID.value + 1) + ", parent ID: " + hyp.id + ")";
						newForeignCovered[i + idx] = true;
					}
					// build future cost
					double futureCost = costEstimator.estimateFutureCost(newForeignCovered , i + len);
					
					SearchStackIf targetStack = hypothesisStack[hyp.nForeignCovered + len + 1];
					double baseProb = futureCost + hyp.getLogProbabilityCurrent() + pD;
					// monotonic decreasing probability: break it here, if there's no reason to add more
					if (earlyDrop)
						if (!targetStack.mayEnterWith(baseProb))
							continue nextLength;
					
					Object constraintData = null;
					// hard constraints checking
					if (!constraintsUseInPhraseAnalysis)
					{
						constraintData = constraintChecker.checkHardConstraints(
							input.constraintsDescriptor ,
							hyp.constraintData ,
							hyp ,
							null ,
							i ,
							i + len ,
							(hyp.nForeignCovered + len + 1) == nfWords ,
							softMode);
						if (!softMode && constraintData == null)
							continue nextLength;
						
						// TODO: optimize it better: more than one hyp will have the same constraint state
					}
					double pXX = 0;
					if (!pXusePTV && config.weightX != null)
					{
						config.customProbability.getProbability(pXs , 0 , input , hyp , null , constraintData , i , len + 1);
						pXX = PhramerTools.getWeight(config.weightX , pXs);
					}
					
					nextPhrase:
					for (PhraseTranslationVariant tv : translationVariants[i][len])
					{
						// hard constraints checking
						if (constraintsUseInPhraseAnalysis)
						{
							// quite cheap to check it now
							if (earlyDrop2)
							{
								double pT , pW;
								EToken[] phraseTranslation = tv.getTranslation();
								// pT - scaled inside
								pT = tv.getLogProbability();
								
								// pW - penality
								pW = config.weightW * - phraseTranslation.length;
								
								if (!targetStack.mayEnterWith(baseProb + pT + pW))
									continue nextPhrase;
							}
							
							constraintData = constraintChecker.checkHardConstraints(
								input.constraintsDescriptor ,
								hyp.constraintData ,
								hyp ,
								tv ,
								i ,
								i + len ,
								(hyp.nForeignCovered + len + 1) == nfWords ,
								softMode);
							if (!softMode && constraintData == null)
								continue nextPhrase;
						}
						// check for alignment
						if (output != null)
						{
							EToken[] phraseTranslation = tv.getTranslation();
							
							// check not to overflow
							if (phraseTranslation.length + cntWordsGenerated > output.length)
								continue nextPhrase;
							
							// also, if it is the last phrase, check full coverage of the output
							if ((hyp.nForeignCovered + len + 1) == nfWords)
								if (phraseTranslation.length + cntWordsGenerated != output.length)
									continue nextPhrase;
							
							// check word overlap between hypo and expected output
							for (int j = 0; j < phraseTranslation.length; j++)
								if (!(phraseTranslation[j].equals(output[cntWordsGenerated + j])))
									continue nextPhrase;
						}
						
						// Cost is based of:
						//   translation - in TV
						//   LM - using context and TV
						//   word penalty
						//   distorsion
						//   constraints
						
						double pT , pLM , pW , pX;
						
						EToken[] phraseTranslation = tv.getTranslation();
						
						// pT - scaled inside
						pT = tv.getLogProbability();
						
						// pW - penality
						pW = config.weightW * - phraseTranslation.length;
						
						if (earlyDrop2)
							if (!targetStack.mayEnterWith(baseProb + pT + pW))
								continue nextPhrase;
						
						// pLM - scaled inside
						LMContext context = hyp.lmContext;
						pLM = 0;
						//waste of time to calculate LM score when aligning - for all hypotheses,
						// it is constant
						if (calculateLM)
						{
							for (int j = 0; j < phraseTranslation.length; j++)
							{
								pLM += config.lmProcessor.getLogProbability(context , phraseTranslation[j], instrument);
								context = context.append(phraseTranslation[j]);
							}
							assert context.equals(hyp.lmContext.append(phraseTranslation)) : context + " vs. " + hyp.lmContext.append(phraseTranslation);
							
							// if all f words are covered, add </s>
							if (!config.chunk)
								if ((hyp.nForeignCovered + len + 1) == nfWords)
									pLM += config.lmProcessor.getLogProbability(context , config.tokenBuilder.buildEToken(LMConstants.END_OF_SENTENCE), instrument);
						}
						
						
						// pX - extension
						if (config.weightX == null)
							pX = 0;
						else if (pXusePTV)
						{
							config.customProbability.getProbability(pXs , 0 , input , hyp , tv , constraintData , i , len + 1);
							pX = PhramerTools.getWeight(config.weightX , pXs);
						}
						else
							pX = pXX;
						
						// don't create the hypo state if it won't reach the stack
						if (!allowLattice && !targetStack.mayEnterWith(baseProb + pT + pLM + pW + pX))
							continue nextPhrase;
						
						HypothesisState newHyp = new HypothesisState(hyp ,
																	 tv ,
																	 i ,
																	 len + 1 ,
																	 newForeignCovered ,
																	 futureCost ,
																	 pT + pLM + pW + pD + pX ,
																	 context ,
																	 hypID.value++ ,
																	 constraintData);
						instrument.hypothesisCreated(newHyp, pT, pLM, pW, pD);
						
						//assert newHyp.cost < hyp.cost : "only decreasing costs are allowed";
						
						// add to the list of hypotheses that are generated
						hypothesisStack[newHyp.nForeignCovered].add(newHyp, allowLattice , instrument);
					}
				}
			}
		}
	}
	
	// determines the translation variants from all sources
	public PhraseTranslationVariant[][][]
	getTranslationVariants(PhramerInput input, EToken[] output) throws PhramerException
	{
		FToken[] fWords = input.getFWords();
		// determines all possible translations of phrases for the input, based on markup and translation table
		// 1st index: start word index
		// 2nd index: len-1 (0=1 word length)
		PhraseTranslationVariant[][][] translationVariants = initializeTranslation(fWords.length);
		// Deny a phrase selected from the translation table to contain this word
		boolean[] fBreak = new boolean[fWords.length];
		// first: markup
		initializeTranslationVariantsFromMarkup(input, fBreak, translationVariants);
		// next: translation table
		initializeTranslationVariantsFromTranslationTable(fWords, translationVariants, fBreak , output);
		// Unknown words - translate them identically
		initializeTranslationVariantsForUnknownWords(input, fWords, translationVariants);
		
		if (config.translationVariantsInspector != null)
			config.translationVariantsInspector.inspect(input , translationVariants);
		return translationVariants;
	}
	
	
	private SearchStackIf[] initializeHypotesisStack(int length , boolean allowLattice)
	{
		SearchStackIf[] a = new SearchStackIf[length + 1];
		if (allowLattice)
			for (int i = 0; i <= length; i++)
				a[i] = new SearchStack(i, config);
		else if (config.stack == 1)
			for (int i = 0; i <= length; i++)
				a[i] = new SearchStackSingleHyp(i, config);
		else
		{
			for (int i = 0; i < length; i++)
				a[i] = new SearchStack(i, config);
			a[length] = new SearchStackSingleHyp(length, config);
		}
		return a;
	}
	
	
	/**
	 *  Unknown words will be copied into the output
	 */
	private void initializeTranslationVariantsForUnknownWords(PhramerInput input, FToken[] fWords, PhraseTranslationVariant[][][] translationVariants)
	{
		boolean[] empty = new boolean[fWords.length];
		for (int i = 0; i < fWords.length; i++)
			empty[i] = hasNoTranslationVariant(i , translationVariants);
		
		if (config.unkWordsPhraseVariants != null)
		{
			int minEnd = -1;
			for (int i = 0; i < fWords.length; i++)
				if (empty[i])
				{
					int end = i + 1;
					while (end < empty.length && empty[end])
						end++;
					
					// now go back
					for (int j = end ; j > i; j--)
						if (j > minEnd)
						{
							Pair<Boolean, Pair<EToken[], Double>[]> response = config.unkWordsPhraseVariants.getPhrases(input , fWords , i , j);
							if (response != null)
							{
								// create into translationVariants
								PhraseTranslationVariant[] ptv = new PhraseTranslationVariant[ response.second.length ];
								translationVariants[i][j - i - 1] = ptv;
								
								for (int k = 0; k < response.second.length; k++)
									ptv[k] = PhraseTranslationVariant.buildWithoutTranslationTable(
										response.second[k].first , response.second[k].second);
								
								// block others
								if (response.first)
									minEnd = j;
							}
						}
					
					// backoff to transliteration if we had no rules
					if (minEnd <= i)
					{
						// add the one by transliteration
						// prepare translationVariants[i][0]
						if (translationVariants[i][0] == null)
							translationVariants[i][0] = new PhraseTranslationVariant[1];
						else
						{
							PhraseTranslationVariant[] newPTV = new PhraseTranslationVariant
								[ translationVariants[i][0].length + 1];
							System.arraycopy(translationVariants[i][0] , 0 , newPTV , 0 , translationVariants[i][0].length);
							translationVariants[i][0] = newPTV;
						}
						// build the phrase
						translationVariants[i][0]
							[translationVariants[i][0].length - 1] =  getUnkWordPhrase(fWords[i]);
					}
				}
		}
		else // word level only
			for (int i = 0; i < fWords.length; i++)
				if (empty[i])
				{
					// translate identically, asign translation probability 1
					translationVariants[i][0] = new PhraseTranslationVariant[1];
					translationVariants[i][0][0] =  getUnkWordPhrase(fWords[i]);
				}
	}
	
	private PhraseTranslationVariant getUnkWordPhrase(FToken fWord)
	{
		EToken[] x = new EToken[1];
		x[0] = config.tokenBuilder.build(fWord);
		return PhraseTranslationVariant.buildWithoutTranslationTable(x , MathTools.LOG_ONE);
	}
	private boolean hasNoTranslationVariant(int i, PhraseTranslationVariant[][][] translationVariants)
	{
		for (int j = 0; j < translationVariants[i].length; j++)
			if (translationVariants[i][j] != null)
				return false;
		return true;
	}
	
	
	// len = F sentence length
	private PhraseTranslationVariant[][][] initializeTranslation(int len)
	{
		int maxPhrase = config.maxPhraseLength;
		if (maxPhrase == 0)
			maxPhrase = len;
		PhraseTranslationVariant[][][] trans = new PhraseTranslationVariant[len][][];
		for (int i = 0; i < len; i++)
			trans[i] = new PhraseTranslationVariant[Math.min(len - i , maxPhrase)][];
		return trans;
	}
	
	/** Prepare translation variants table based on xml markup
	 */
	private void initializeTranslationVariantsFromMarkup(PhramerInput input , boolean[] fBreak, PhraseTranslationVariant[][][] translationVariants)
	{
		// is there a xml markup?
		if (input.hasPreTranslations())
		{
			FToken[] fWords = input.getFWords();
			boolean[] isPreTranslated = input.getIsPreTranslated();
			int[] phraseLength = input.getPreTranslatedPhraseLength();
			List<PhraseTranslationVariant>[] phraseTranslations = input.getPrePhraseTranslations();
			
			double logWeightMarked = MathTools.numberToLog(config.weightMarked);
			
			assert fWords.length == isPreTranslated.length;
			assert fWords.length == phraseLength.length;
			assert fWords.length == phraseTranslations.length;
			for (int i = 0; i < isPreTranslated.length; i++)
				if (isPreTranslated[i])
				{
					// Mark so that it is not used any more
					if (!config.bypassMarked)
						for (int j = 0; j < phraseLength[i]; j++)
							fBreak[i + j] = true;
					
					// now copy markup, scaled
					PhraseTranslationVariant[] alternatives = new PhraseTranslationVariant[phraseTranslations[i].size()];
					
					for (int j = 0; j < alternatives.length; j++)
						alternatives[j] = phraseTranslations[i].get(j).addLogFactor(logWeightMarked);
					
					// BUG FIX!!!
					putElementInTranslationVariants(translationVariants , i , phraseLength[i] - 1 , alternatives);
					//translationVariants[i][phraseLength[i] - 1] = alternatives;
					
					// TODO: see how the fix affects the initialization from the translation table
				}
		}
	}
	private static void putElementInTranslationVariants(PhraseTranslationVariant[][][] translationVariants, int pos , int idx, PhraseTranslationVariant[] alternatives)
	{
		if (translationVariants[pos].length <= idx)
		{
			// make space
			PhraseTranslationVariant[][] newVersion = new PhraseTranslationVariant[idx + 1][];
			System.arraycopy(translationVariants[pos], 0 , newVersion , 0 , translationVariants[pos].length);
			translationVariants[pos] = newVersion;
		}
		
		translationVariants[pos][idx] = alternatives;
	}
	
	private void initializeTranslationVariantsFromTranslationTable(FToken[] fWords, PhraseTranslationVariant translationVariants[][][], boolean[] fBreak ,  EToken[] eWords)
	throws PhramerException
	{
		nanoClockInitializeFromTranslationTable.resume();
		for (int i = 0; i < fWords.length; i++)
			for (int j = 0; j < translationVariants[i].length; j++)
				if (fBreak[i + j])
					break;
				else
				{
					Phrase p = PhraseTools.getPhrase(fWords , i , i + j , config.translationTable);
					TableLine[] translation = config.translationTable.getAllTranslations(p);
					
					
					// add to pre-existing list or create a new list
					if (translation != null)
					{
						
						// prune it by eWords, for alignment
						if (eWords != null)
						{
							
							List<TableLine> t = new ArrayList<TableLine>();
							for (TableLine tl : translation)
							{
								EToken[] tW = tl.getTranslation();
								// check if tW can cover eWords
								boolean matched = false;
								t: for (int start = 0; start <= eWords.length - tW.length; start++)
								{
									for (int delta = 0 ; delta < tW.length ; delta++)
										if (!(eWords[start + delta].equals(tW[delta])))
											continue t;
									matched = true;
									break;
								}
								if (matched)
									t.add(tl);
							}
							
							translation = t.toArray(new TableLine[t.size()]);
						}
						
						
						if (translation.length > 0)
						{
							translationVariants[i][j] = new PhraseTranslationVariant[translation.length];
							
							// now blend every TableLine into a PhraseTranslationVariant
							for (int k = 0; k < translation.length; k++)
								translationVariants[i][j][k] = PhraseTranslationVariant.buildFromTranslationTable(translation[k]);
						}
					}
					else if (config.prefixTT)
						break;
				}
		nanoClockInitializeFromTranslationTable.pause();
	}
	
	// not reentrant
	public boolean allowConcurrency()
	{
		return false;
	}
	
	/** Returns the version of the decoder */
	public String getVersion()
	{
		return VERSION;
	}
	//MachineTranslator method -- No metadata
	public String translate(String fSentence, int sentenceIdx , boolean xml , boolean chunk)
	throws PhramerException, IOException
	{
		return translate(fSentence, sentenceIdx , xml , chunk, null);
	}
	//MachineTranslator method --  full version
	public String translate(String fSentence, int sentenceIdx , boolean xml , boolean chunk , Map<String,String[]> metaData)
	throws PhramerException, IOException
	{
		// void input, void output. No external stuff (lattices, etc).
		if (fSentence.trim().length() == 0)
			return "";
		
		
		boolean oldChunk = config.chunk;
		if (chunk)
			config.chunk = true;
		
		String translate = xml ?
			translateXML(fSentence , sentenceIdx , metaData)
			:
			translate(fSentence , sentenceIdx , metaData);
		
		if (chunk)
			config.chunk = oldChunk;
		
		return translate;
	}
	// BlockMachineTranslator method -- no metadata
	public String[] translate(String[] fSentence, boolean[] chunk, boolean xml) throws PhramerException, IOException
	{
		return translate(fSentence, chunk, xml, null);
	}
	// BlockMachineTranslator method
	public String[] translate(String[] fSentence, boolean[] chunk, boolean xml , Map<String,String[]>[] metaData) throws PhramerException, IOException
	{
		String[] output = new String[fSentence.length];
		for (int i = 0; i < output.length; i++)
			output[i] = translate(fSentence[i] , i , chunk[i] , xml , metaData == null ? null : metaData[i]);
		return output;
	}
	
	public String[] translateNBest(String fSentence , boolean xml , boolean chunk , int nbestListSize)
	throws PhramerException, IOException
	{
		return translateNBest(fSentence , xml , chunk , null , nbestListSize);
	}
	public String[] translateNBest(String fSentence , boolean xml , boolean chunk , Map<String,String[]> metaData , int nbestListSize)
	throws PhramerException, IOException
	{
		if (fSentence.trim().length() == 0)
			return new String[0];
		
		boolean oldChunk = config.chunk;
		if (chunk)
			config.chunk = true;
		
		Triplet<List<List<HypothesisState>>,PhramerInput,SearchStackIf[]> v = xml ?
			_translateXMLintoNbest(fSentence , nbestListSize, metaData)
			:
			_translateIntoNbest(fSentence , nbestListSize , metaData);
		
		if (chunk)
			config.chunk = oldChunk;
		
		String[] output = new String[v.first.size()];
		for (int i = 0; i < output.length; i++)
			output[i] = toStringNBestItem(v.second , v.third , v.first.get(i));
		return output;
	}
	
}
