/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.main;
import info.olteanu.utils.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.mert.*;
import org.phramer.mert.evaluation.*;
import org.phramer.mert.evaluation.xer.*;
import org.phramer.mert.item.*;
import org.phramer.mert.strategy.*;
import org.phramer.mert.strategy.implementations.*;
import org.phramer.v1.decoder.mert.evaluation.bleu.*;
import org.phramer.v1.decoder.mert.generation.*;
import org.phramer.v1.decoder.mert.item.*;
import org.phramer.mert.intersection.*;
import info.olteanu.utils.debug.*;
import org.phramer.v1.decoder.*;

public class MERTMain
{
	public static void main(String[] args) throws Exception
	{
		DebugInitializer.initialize();
		
		Properties p = PropertiesTools.getProperties(args[0]);
		System.out.println("Config file: " + args[0]);
		
		// overwrite with the command line
		if (args.length > 1)
			PropertiesTools.addPropertiesFromCommandLine(p , StringTools.cutFirst(args , 1) , "--");
		
		
		double[] initialLambda = parseInitialLambda(p);
		int nStepsOrthogonal = parseNStepsOrthogonal(p);
		int nStepsDiagonal = parseNStepsDiagonal(p);
		double minDeltaScore = parseMinDeltaScore(p);
		
		int nSkipIterations = parseNSkipIterationsGeneration(p);
		double forcedLambda[][] = parseForcedLambda(p);
		if (forcedLambda != null || nSkipIterations >= 2)
			if (forcedLambda.length != nSkipIterations && forcedLambda.length + 1 != nSkipIterations)
				throw new IOException("forcedLambda.length and nSkipIterations don't match");
		
		ReferenceLoader loader = new ReferenceLoaderMT();
		BasicMtNHGM mgr = NewHypothesesGenerationManagerBuilder.getNHGM(p, parseFileInput(p), nSkipIterations);
		// Orthogonal
		SearchLambdaStrategy strategy = new SearchLambdaStrategyOrthogonalDiagonal(nStepsOrthogonal , nStepsDiagonal , parseRandomLambdaRanges(p) , null , minDeltaScore);
		// Multithreaded?
		String strThreadCount = p.getProperty("search.threads");
		int threadCount = strThreadCount == null ? 1 :
			strThreadCount.equals("auto") ? PhramerTools.getRecommendedThreadCount() : Integer.parseInt(strThreadCount);
		
		if (threadCount != 1 && threadCount != 0)
			strategy = new MultiThreadedSearchStrategy(threadCount , nStepsOrthogonal , (SearchLambdaStep)strategy , parseRandomLambdaRanges(p));
		
		setParams(p);
		
		String norm = p.getProperty("normalizer.type" , "max");
		String normListStr = p.getProperty("normalizer.index.list");
		int[] normList = null;
		if (normListStr != null)
		{
			String[] k = StringTools.tokenize(normListStr , " ,;");
			normList = new int[k.length];
			for (int i = 0; i < k.length; i++)
				normList[i] = Integer.parseInt(k[i]);
		}
		LambdaNormalizer normalizer =
			norm.equals("median") ? new LambdaNormalizerMedian1(normList) :
			norm.equals("sum") ?  new LambdaNormalizerSumX(normList, 1) :
			new LambdaNormalizerMax1(normList);
		String fileRef = parseFileRef(p);
		String filesRef[] = null;
		//multi-ref
		if (fileRef.indexOf(";") != -1)
		{
			filesRef = StringTools.tokenize(fileRef, ";");
			for (int i = 0; i < filesRef.length; i++)
				filesRef[i] = filesRef[i].trim();
			fileRef = null;
		}
		
		String evaluatorType = p.getProperty("evaluator.type" , "bleu").toLowerCase();
		// Evaluator
		Evaluator eval;
		if (evaluatorType.equals("bleu"))
			eval = fileRef != null ? new BleuR1N4Evaluator() : new BleuRnN4Evaluator(filesRef[0]);
		else if (evaluatorType.equals("wer"))
			eval = new WEREvaluator();
		else if (evaluatorType.equals("per"))
			eval = new PEREvaluator();
		else
			throw new PhramerException("Unknown evaluator type: " + evaluatorType);
		
		// first value: mode
		if (filesRef != null)
			filesRef = StringTools.cutFirst(filesRef , 1);
		
		double[] newLambda = MinimumErrorRateTraining.searchLambda(loader , mgr , eval ,
																   strategy , normalizer,
																   fileRef , filesRef ,
																   initialLambda,
																   mgr.getInitialPoints(p),
																   forcedLambda
																   );
		System.out.println("New lambdas: ");
		for (int i = 0; i < newLambda.length; i++)
			System.out.print(newLambda[i] + " ");
		System.out.println();
		
		System.err.println("New lambdas: ");
		for (int i = 0; i < newLambda.length; i++)
			System.err.print(newLambda[i] + " ");
		System.err.println();
		//bad line: System.out.println("Expected BLEU score: " + ItemTools.evaluate(loader.getEmptyReferenceWithHypotheses(loader.readReference_R1(fileRef)) , newLambda , eval));
	}
	
	// sets special parameters in search
	private static void setParams(Properties p)
	{
		if (p.getProperty("search.params.extreme.delta") != null)
			OptimumLambdaCalculatorTool.DELTA = Double.parseDouble(p.getProperty("search.params.extreme.delta"));
		if (p.getProperty("search.params.extreme.coef") != null)
			OptimumLambdaCalculatorTool.COEF = Double.parseDouble(p.getProperty("search.params.extreme.coef"));
	}
	
	private static double[][] parseForcedLambda(Properties p)
	{
		if (p.getProperty("debug.resume.lambda.count") == null)
			return null;
		int n = Integer.parseInt(p.getProperty("debug.resume.lambda.count"));
		double[][] forcedLambda = new double[n][];
		for (int i = 1 ; i <= n ; i++)
			forcedLambda[i - 1] = parseLambdas(p.getProperty("debug.resume.lambda." + i));
		return forcedLambda;
	}
	
	private static int parseNSkipIterationsGeneration(Properties p)
	{
		if (p.getProperty("debug.resume.generation.n-skip") == null)
			return 0;
		return Integer.parseInt(p.getProperty("debug.resume.generation.n-skip"));
	}
	
	
	private static double parseMinDeltaScore(Properties p)
	{
		return Double.parseDouble(p.getProperty("search.score.min-delta"));
	}
	
	private static int parseNStepsOrthogonal(Properties p)
	{
		return Integer.parseInt(p.getProperty("search.step-count"));
	}
	
	private static int parseNStepsDiagonal(Properties p)
	{
		if (p.getProperty("search.step-count.diagonal") == null)
			return 0;
		return Integer.parseInt(p.getProperty("search.step-count.diagonal"));
	}
	
	
	private static String parseFileInput(Properties p)
	{
		return p.getProperty("file.dev.f");
	}
	private static String parseFileRef(Properties p)
	{
		return p.getProperty("file.dev.e");
	}
	
	private static double[] parseInitialLambda(Properties p)
	{
		return parseLambdas(p.getProperty("lambda.initial-values"));
	}
	
	private static double[][] parseRandomLambdaRanges(Properties p)
	{
		String str = p.getProperty("lambda.random.ranges");
		StringTokenizer st = new StringTokenizer(str);
		double[][] lambda = new double[st.countTokens()][2];
		for (int i = 0; i < lambda.length; i++)
		{
			String token = st.nextToken();
			lambda[i][0] = Double.parseDouble(token.substring(0 , token.indexOf('-' , 1)));
			lambda[i][1] = Double.parseDouble(token.substring(token.indexOf('-' , 1) + 1));
		}
		return lambda;
	}
	
	
	
	public static double[] parseLambdas(String str) throws NumberFormatException
	{
		// ignore non-numerical tokens also: March 06, 2006
		
//		StringTokenizer st = new StringTokenizer(str, ", \t\n\r\f");
//		double[] lambda = new double[st.countTokens()];
//		for (int i = 0; i < lambda.length; i++)
//			lambda[i] = Double.parseDouble(st.nextToken());
//		return lambda;
		
		StringTokenizer st = new StringTokenizer(str, ", \t\n\r\f");
		List<String> tokens = new ArrayList<String>();
		while (st.hasMoreTokens())
		{
			String tok = st.nextToken();
			try
			{
				Double.parseDouble(tok);
				
				tokens.add(tok);
			}
			catch (NumberFormatException e)
			{}
		}
		double[] lambda = new double[tokens.size()];
		for (int i = 0; i < lambda.length; i++)
			lambda[i] = Double.parseDouble(tokens.get(i));
		return lambda;
	}
}
