/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.main;
import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.remoteservices.server.*;
import java.io.*;
import org.phramer.*;
import org.phramer.remote.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.instrumentation.performance.*;
import org.phramer.v1.decoder.loader.*;
import org.phramer.v1.decoder.loader.custom.*;
import org.phramer.v1.decoder.threading.*;
import org.phramer.v1.decoder.token.*;
import org.phramer.interfaceimpl.*;
import info.olteanu.utils.debug.*;
import org.phramer.v1.decoder.meta.*;

public class PhramerMain
{
	private static boolean CREATE_LOG = false;
	private static int RERUN = 0;
	private static int PRINT_STAR_AFTER = 100;
	private static int PRINT_TIME_AFTER = 1000;
	public static void main(String[] args)
	throws Exception
	{
		//System.err.println("Default encoding: " + System.getProperty("file.encoding"));
		
		phramerMain(null , null , args , null);
	}
	
	
	public static void phramerMain(InputStream inputStream , OutputStream outputStream , String[] args , PhramerHelperIf helper) throws IOException, PhramerException
	{
		DebugInitializer.initialize();
		
		// Print environment info?
		boolean printEnvironment = CommandLineTools.isParameter("-env" , args);
		if (printEnvironment)
			DebugTools.printEnvironmentInfo(System.err, "java");
		
		PrintStream logFile = null;
		
		if (CREATE_LOG)
			logFile = new PrintStream(new FileOutputStream("logPhramer.txt") , true , "UTF-8");
		
		// Do execution profiling? Profiling clocks must be activated in the sourcecode
		boolean doProfiling = CommandLineTools.isParameter("-profile" , args);
		if (doProfiling)
			ExecutionProfiler.initialize();
		
		// input type: xml, text
		String inputType = CommandLineTools.getParameter("-inputtype" , args);
		boolean isTextInput = false;
		if (inputType != null && "text".equals(inputType))
			isTextInput = true;
		
		// Allow concurrency (server mode)? How many threads should be active?
		boolean concurrent = CommandLineTools.isParameter("-concurrent" , args);
		String strThreadCount = CommandLineTools.getParameter("-threads" , args);
		int threadCount = strThreadCount == null ? 1 :
			strThreadCount.equals("auto") ? PhramerTools.getRecommendedThreadCount() : Integer.parseInt(strThreadCount);

		// batch size for multi-threaded execution
		// when batch size == 1, execute uni-threaded
		String strBatchSize = CommandLineTools.getParameter("-batch" , args);
		int batchSize = strBatchSize == null ? 100 : Integer.parseInt(strBatchSize);// default batch size 100
		if(batchSize < 1)
			batchSize = 1;
		
		
		Chronometer cCfg = new Chronometer(true);
		System.err.println(Phramer.VERSION);
		PhramerHelperIf[] helpers = new PhramerHelperIf[threadCount];
		if (threadCount > 1)
		{
			System.err.println("Execution threads: " + threadCount);
			if (helper == null)
			{
				AllLoader loader = new ConcurrentObjectsLoader();
				for (int i = 0; i < helpers.length; i++)
					helpers[i] = new PhramerHelperCustom(loader , new TokenBuilderWordOnly(PhramerHelperSimpleImpl.getFilter(args)) , loader , loader , loader);
			}
			else
				for (int i = 0; i < helpers.length; i++)
					helpers[i] = helper.getCloneForConcurrency();
		}
		else
			helpers[0] = helper;
		System.err.println("Config loading...");
		PhramerConfig[] config = new PhramerConfig[threadCount];
		for (int i = 0; i < config.length; i++)
			config[i] = new PhramerConfig(args, helpers[i] , null);
		System.err.println("Config loaded in " + StringTools.formatDouble(0.001 * cCfg.getValue(), "0.00") + " s");
		
//		config.futureCostInstrument = new FutureCostInstrumentRatioImpl();
		
		
		PhramerIf[] phramers = new PhramerIf[threadCount];
		for (int i = 0; i < phramers.length; i++)
			phramers[i] = new Phramer(config[i]);
		
		String serverPort = CommandLineTools.getParameter("-server" , args);
		
		PhramerIf p;
		if (phramers.length == 1)
			p = phramers[0];
		else
			p = new MultiThreadedPhramerWrapper(phramers, serverPort != null);// if it's server, it should be fair - don't starve some of the clients
		
		if (serverPort != null)
		{
			// make a translation server
			System.gc();
			BlockMachineTranslator mt = p;
			
			// cache disabled for now
			/*			String cacheSize = CommandLineTools.getParameter("-cache" , args);
			 if (cacheSize != null)
			 mt = new CachedMachineTranslator(mt , Integer.parseInt(cacheSize));*/
			
			// wrap it for concurrency
			if (concurrent && !mt.allowConcurrency())
				mt = new SynchronizedBlockMachineTranslator(mt);
			
			ServerWrapperMachineTranslator pWrapper = new ServerWrapperMachineTranslator(mt);
			Server server = new Server(pWrapper , serverPort);
			server.debugLevel = 2;
			System.err.println("Providing translation service on port " + serverPort + " ...");
			server.start();
			return;
		}
		
		// the initial sentence #
		String _startID = CommandLineTools.getParameter("-start-id" , args);
		int startID = _startID == null ? 0 : Integer.parseInt(_startID);
		
		// do rescoring of a single file?
		String rescore = CommandLineTools.getParameter("-r" , args);
		if (rescore == null)
			rescore = CommandLineTools.getParameter("-rescore" , args);
		if (rescore != null)
		{
			// rescore command
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(IOTools.getInputStream(rescore), config[0].encodingInput));
			PrintStream outFile = new PrintStream(IOTools.getOutputStream(rescore + ".rescore"), true, config[0].encodingOutput);
			phramers[0].rescore(inputFile , outFile);// only one thread
			return;
		}
		
		// do rescoring of a folder?
		String[] rescoreDir = CommandLineTools.getParameter("-rd" , args , 2);
		if (rescoreDir == null)
			rescoreDir = CommandLineTools.getParameter("-rescoredir" , args , 2);
		if (rescoreDir != null)
		{
			int count = Integer.parseInt(rescoreDir[1]);
			String rdPath = rescoreDir[0];
			
			for (int i = 0; i < count; i++)
			{
				String path = rdPath + "." + PhramerTools.adjustN(Integer.toString(i + startID) , 4);
				
				BufferedReader inputFile = new BufferedReader(new InputStreamReader(IOTools.getInputStream(path), config[0].encodingInput));
				PrintStream outFile = new PrintStream(IOTools.getOutputStream(path + ".rescore"), true , config[0].encodingOutput);
				phramers[0].rescore(inputFile , outFile);// only one thread
			}
			return;
		}
		
		// input
		if (inputStream == null)
		{
			String readFile = CommandLineTools.getParameter("-read" , args);
			if (readFile != null)
				inputStream = IOTools.getInputStream(readFile);
			else
				inputStream = System.in;
		}
		
		// output
		if (outputStream == null)
		{
			String writeFile = CommandLineTools.getParameter("-write" , args);
			if (writeFile != null)
				outputStream = IOTools.getOutputStream(writeFile);
			else
				outputStream = System.out;
		}
		
		// meta
		MetaReader metaReader = MetaReader.VOID;
		String[] meta = config[0].meta;
		if (meta != null)
			if (threadCount == 1 && RERUN == 0)
				metaReader = new IterativeMetaReader(meta);
			else
				metaReader = new IndexedMetaReader(meta);
		
		// keep file.encoding property
		BufferedReader inputFile =
			inputStream == System.in ?
			new BufferedReader(new InputStreamReader(inputStream))
			:
			new BufferedReader(new InputStreamReader(inputStream, config[0].encodingInput));
		
		PrintStream output =
			outputStream == System.out ?
			System.out
			:
			new PrintStream(outputStream , true , config[0].encodingOutput);
		
		String lineFile;
		int k = 0 , cntPrint = PRINT_STAR_AFTER;
		int cntPrintX = PRINT_TIME_AFTER;
		int wordCountX = 0 , wordCountAll = 0;
		Chronometer c = new Chronometer(true);
		Chronometer cGlobal = new Chronometer(true);
		java.util.ArrayList<String> v = new java.util.ArrayList<String>();
		if (threadCount == 1 || batchSize == 1)
		{
			Phramer phr = (Phramer)p;
			while ((lineFile = inputFile.readLine()) != null)
			{
				if (RERUN > 0)
					v.add(lineFile);
				int wordCount = new java.util.StringTokenizer(lineFile).countTokens();
				wordCountAll += wordCount;
				wordCountX += wordCount;
				String translation = isTextInput ?
					phr.translate(lineFile, k + startID, metaReader.readMeta(k + startID)):
					phr.translateXML(lineFile, k + startID, metaReader.readMeta(k + startID));
				if (logFile != null)
				{
					logFile.println(lineFile);
					logFile.println(translation);
					logFile.println();
				}
				output.println(translation);
				k++;
				cntPrint--;
				if (cntPrint == 0)
				{
					System.err.print("*");
					cntPrint = PRINT_STAR_AFTER;
				}
				cntPrintX--;
				if (cntPrintX == 0)
				{
					System.err.println("  Translated " + PRINT_TIME_AFTER + " sentences in " + StringTools.formatDouble(0.001 * c.getValue() , "0.00") + " s"
									   + "; " + wordCountX + " words; " + StringTools.formatDouble(wordCountX / (0.001 * c.getValue()), "0.0") + " wps");
					c.stop();
					c.start();
					wordCountX = 0;
					cntPrintX = PRINT_TIME_AFTER;
				}
			}
		}
		else
		{
			// multi-threading version
			// batch: PRINT_STAR_AFTER elements
			
			MultiThreadedPhramerWrapper m = (MultiThreadedPhramerWrapper)p;
			int idxInBatch = 0;
			String[] outputVector = new String[batchSize];
			
			while ((lineFile = inputFile.readLine()) != null)
			{
				int wordCount = new java.util.StringTokenizer(lineFile).countTokens();
				wordCountAll += wordCount;
				wordCountX += wordCount;
				// String translation = isTextInput ?  p.translate(lineFile, k + startID) : p.translateXML(lineFile, k + startID);
				m.enqueueTask(new MultiThreadedPhramerWrapper.TranslationTask(lineFile ,
																			  k + startID ,
																			  idxInBatch ,
																			  !isTextInput ,
																			  metaReader.readMeta(k + startID) ,
																			  outputVector));
				idxInBatch++;
				k++;
				
				if(idxInBatch == batchSize)
				{
					m.waitForCompletion();
					for (int i = 0; i < outputVector.length; i++)
						output.println(outputVector[i]);
					idxInBatch = 0;
					System.err.print("*");
				}
				
				cntPrintX--;
				if (cntPrintX == 0)
				{
					System.err.println("  Translated " + PRINT_TIME_AFTER + " sentences in " + StringTools.formatDouble(0.001 * c.getValue() , "0.00") + " s"
									   + "; " + wordCountX + " words; " + StringTools.formatDouble(wordCountX / (0.001 * c.getValue()), "0.0") + " wps");
					c.stop();
					c.start();
					wordCountX = 0;
					cntPrintX = PRINT_TIME_AFTER;
				}
			}
			
			m.waitForCompletion();
			for (int i = 0; i < idxInBatch; i++)
				output.println(outputVector[i]);
		}
		output.flush();
		if (output != System.out)
			output.close();
		inputFile.close();
		cGlobal.stop();
		System.err.println("Translated " + k + " sentences in " + StringTools.formatDouble(0.001 * cGlobal.getValue() , "0.00") + " s"
						   + "; " + wordCountAll + " words");
		System.err.println("Translation speed: " + StringTools.formatDouble(wordCountAll / (0.001 * cGlobal.getValue()), "0.0") + " wps; " +
						   StringTools.formatDouble(wordCountAll * 0.060 / (0.001 * cGlobal.getValue()), "0.00") + " kwpm");
		
		if (threadCount == 1)
			for (int i = 0 ; i < RERUN ; i++)
			{
				c = new Chronometer();
				c.start();
				cntPrint = PRINT_STAR_AFTER;
				for (String l : v)
				{
					if (isTextInput)
						p.translate(l, k + startID, metaReader.readMeta(k + startID));
					else
						p.translateXML(l, k + startID, metaReader.readMeta(k + startID));
					cntPrint--;
					if (cntPrint == 0)
					{
						System.err.print("*");
						cntPrint = PRINT_STAR_AFTER;
					}
				}
				c.stop();
				System.err.println();
				System.err.println("(Rerun) Translated " + k + " sentences in " + (0.001 * c.getValue()) + " s");
			}
		
		if (doProfiling)
			ExecutionProfiler.print(System.err);
		
		if (hasConstraintFailure(phramers))
			System.err.println("Decoding with constraints - failed " + countConstraintFailure(phramers) + " / " + (countConstraintFailure(phramers) + countConstraintSuccess(phramers)) + " sentences");
		
		
		if (logFile != null)
		{
			logFile.close();
			logFile = null;
		}
//		// TODO: DEBUG
//		System.err.println("Avg ratio future cost: " + ((FutureCostInstrumentRatioImpl)config.futureCostInstrument).getAvgRatio());
	}
	
	private static int countConstraintFailure(PhramerIf[] p)
	{
		int sum = 0;
		for (int i = 0; i < p.length; i++)
			sum += ((Phramer)p[i]).__constraintDecodingFail;
		return sum;
	}
	private static int countConstraintSuccess(PhramerIf[] p)
	{
		int sum = 0;
		for (int i = 0; i < p.length; i++)
			sum += ((Phramer)p[i]).__constraintDecodingSuccess;
		return sum;
	}
	
	private static boolean hasConstraintFailure(PhramerIf[] p)
	{
		for (int i = 0; i < p.length; i++)
			if (((Phramer)p[i]).__constraintDecodingFail > 0)
				return true;
		return false;
	}
	
}
