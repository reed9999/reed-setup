/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.phrase;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.token.*;

// from start to end
// (i to j) = length j-i+1
public class PhraseImplStartEnd implements Phrase
{
	private final FToken phrase[];
	private final int start, end;
	protected PhraseImplStartEnd(FToken[] phrase , int start, int end)
	{
		this.phrase = phrase;
		this.start = start;
		this.end = end;
		
		int x = 0;
		for (int i = start; i <= end; i++)
		{
			x <<= 1;
			x ^= phrase[i].hashCode();
		}
		hashCode = x;
	}
	public Object getKey()
	{
		// change KEY:
		if (EFProcessorIf.FAST)
			return this;
		return getPhrase();
	}
	public String getStringKey()
	{
		return getPhrase();
	}
	private String _cachePhrase = null;
	private String getPhrase()
	{
		if (_cachePhrase == null)
		{
			StringBuilder sb = new StringBuilder();
			for (int i = start; i <= end; i++)
			{
				sb.append(phrase[i].serialize());
				sb.append(' ');
			}
			_cachePhrase = sb.toString().trim().intern();
		}
		return _cachePhrase;
	}
	
	// change KEY:
	private final int hashCode;
	public int hashCode()
	{
		return hashCode;
	}
	
	public boolean equals(Object o)
	{
		//assert o instanceof PhraseImplStartEnd;
		PhraseImplStartEnd other = (PhraseImplStartEnd)o;
		
		if (other.end - other.start != this.end - this.start)
			return false;
		
		for (int i = start; i <= end; i++)
			if (!(phrase[i].equals(other.phrase[i - start + other.start])))
				return false;
		
		return true;
	}
	
	public FToken[] getContent()
	{
		// make a copy
		FToken[] out = new FToken[end + 1 - start];
		System.arraycopy( phrase , start , out , 0 , out.length );
		return out;
	}
}
