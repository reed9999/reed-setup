/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.token;
import info.olteanu.interfaces.*;
import java.util.*;


public class TokenBuilderWordOnly implements TokenBuilder
{
	private final StringFilter filter;
	private boolean postInit; // is post data structure loading or pre?
	private final boolean shared = true; // shared token builder for concurrency?
	private final boolean cache = true; // use caching
	public TokenBuilderWordOnly(StringFilter filter)
	{
		if (filter == null)
			filter = StringFilter.VOID;
		this.filter = filter;
		this.postInit = false;
		this.myMap = cache ? new HashMap<String,TokenWordOnly>() : null;
	}
	
	public EToken build(FToken f)
	{
		assert f instanceof TokenWordOnly;
		// bug fix May 23, 2006
		if (filter == StringFilter.VOID)
			return (TokenWordOnly)f;
		
		String newWord = filter.filter(f.getWord());
		// if they are the same even after filtering...
		if (newWord.equals(f.getWord()))
			return (TokenWordOnly)f;
		
		return buildEToken(newWord);
	}
	public FToken build(EToken f)
	{
		assert f instanceof TokenWordOnly;
		return (TokenWordOnly)f;
	}
	public EToken buildEToken(String word)
	{
		return buildToken(word);
	}
	
	public FToken buildFToken(String word)
	{
		return buildToken(word);
	}
	
	private final HashMap<String,TokenWordOnly> myMap;
	private TokenWordOnly buildToken(String word)
	{
		if (!cache)
			return new TokenWordOnly(word , true); // do intern if there's no cache
		
		// if loading the datastructures (which is serial) already took place, than use the cache as read-only
		// good for not filling up the memory, and for not doing concurrent update on a non-sync method
		if (postInit)
		{
			TokenWordOnly k = myMap.get(word);
			if (k == null)
				return new TokenWordOnly(word , false);
			else
				return k;
		}
		
		TokenWordOnly k = myMap.get(word);
		if (k == null)
		{
			k = new TokenWordOnly(word , false);
			myMap.put(word, k);
		}
		return k;
	}
	
	public TokenBuilder getCloneForConcurrency()
	{
		if (shared)
			return this;
		else
			return new TokenBuilderWordOnly(filter);
	}
	
	public void initializationFinished()
	{
		postInit = true;
	}
}

