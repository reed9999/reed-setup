/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.mert.generation;
import info.olteanu.utils.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.phramer.*;
import org.phramer.mert.item.*;
import org.phramer.v1.decoder.mert.reader.pharaohcarmel.*;
import org.phramer.v1.decoder.mert.reader.phramer.*;

public abstract class BasicPhramerNHGM
extends BasicMtNHGMWithReaders
{
	private final boolean deleteNbestText;
	private final boolean deleteRescore;
	
	public BasicPhramerNHGM(Properties p , String fileF , int nSkipIterations)
	throws IOException, PhramerException
	{
		super(p , fileF , nSkipIterations , new RescoreReaderPhramer() , new NBestReaderPhramer());
		
		deleteNbestText = "1".equals(p.getProperty("delete-temp.text", "0"));
		deleteRescore = "1".equals(p.getProperty("delete-temp.rescore", "0"));
	}
	
	public final List<Hypothesis>[] getHypotheses(double[] lambda, int run)
	{
		List<Hypothesis>[] output = new List[nSentence];
		for (int i = 0; i < output.length; i++)
			output[i] = new ArrayList<Hypothesis>();
		
		// parameters matching lambda
		String lambdaX = printDecoderParameters(lambda);
		
		try
		{
			if (run > nSkipIterations)
				doPhramerTranslate(run , lambdaX);
			
			// now I have rescored files
			loadFromDisk(output, run);
			
			// change March 15, 2006: allow reranker
			doReranking(output);
			return output;
		}
		catch (PhramerException e)
		{
			throw new Error(e);
		}
		catch (InstantiationException e)
		{
			throw new Error(e);
		}
		catch (IllegalAccessException e)
		{
			throw new Error(e);
		}
		catch (ClassNotFoundException e)
		{
			throw new Error(e);
		}
		catch (InterruptedException e)
		{
			throw new Error("Interrupted" , e);
		}
		catch (IOException e)
		{
			throw new Error("Execution failed" , e);
		}
	}
	
	private void loadFromDisk(List<Hypothesis>[] output, int run) throws IOException, PhramerException
	{
		for (int i = 0; i < nSentence; i++)
		{
			String baseFile = workingFolder + "/" + run + "/run" + run + ".best" + nBestSize + "." + StringTools.adjustLengthForNumber(i , 4);
			BufferedReader inputFileRescore = new BufferedReader(new InputStreamReader(new FileInputStream(baseFile + ".rescore")));
			BufferedReader inputFileNbest = new BufferedReader(new InputStreamReader(new FileInputStream(baseFile + ".nbest")));
			String lineNbest;
			while ((lineNbest = inputFileNbest.readLine()) != null)
			{
				String lineRescore = inputFileRescore.readLine();
				if (lineRescore == null)
					throw new PhramerException("Too short rescore file (" + baseFile + ")");
				
				Hypothesis e = getHypothesis(lineNbest);
				e.p = rescoreReader.readLine(lineRescore);
				output[i].add(e);
			}
			if (inputFileRescore.readLine() != null)
				throw new PhramerException("Too long rescore file (" + baseFile + ")");
			inputFileRescore.close();
			inputFileNbest.close();
			
			
			if (deleteRescore)
				new File(baseFile + ".rescore").delete();
			
			if (deleteNbestText)
				new File(baseFile + ".nbest").delete();
		}
	}
	
	
	protected abstract void doPhramerTranslate(int run, String lambdaX)
	throws IOException, InterruptedException, PhramerException,
	InstantiationException, IllegalAccessException, ClassNotFoundException;
	
	protected String getSpecificParameters(int run)
	{
		return "-sc " +
			workingFolder + "/" + run +
			"/run" + run + ".best" + nBestSize + " " + nBestSize + " " +
			"-simple-sc " +
			"-nb " +
			workingFolder + "/" + run +
			"/run" + run + ".best" + nBestSize + " " + nBestSize + " ";
	}
	
	
	public final List<Hypothesis>[] getInitialPoints(Properties p) throws IOException, PhramerException
	{
		int cnt = Integer.parseInt(p.getProperty("points.pre-load.count" , "0"));
		if (cnt == 0)
			return null;
		
		// TODO
		throw new Error("Initial points with PhramerExternalNewHypothesisGenerationManager: not yet implemented");
	}
}
