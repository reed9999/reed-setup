/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.mert.evaluation.bleu;

import org.phramer.mert.evaluation.*;
import org.phramer.mert.item.*;
import org.phramer.v1.decoder.mert.item.*;
import org.phramer.*;

public class BleuRnN4Evaluator extends BleuR1N4Evaluator
{
	
	public boolean printDebug = false;
	private final int mode;
	protected final int levelN;
	private static class Modes
	{
		public static final String[] _NAMES = {
			"min",
			"max",
			"closest",
			"closest_down",
			"closest_up",
			"avg",
			"median"};
		public static final int MIN = 0;
		public static final int MAX = 1;
		public static final int CLOSEST = 2;
		public static final int CLOSEST_LOWER = 3;
		public static final int CLOSEST_UPPER = 4;
		public static final int AVERAGE = 5;
		public static final int MEDIAN = 6;
	}
	
	public BleuRnN4Evaluator(String mode)
	throws PhramerException
	{
		this(mode, 4);
	}
	
	protected BleuRnN4Evaluator(String mode, int levelN)
	throws PhramerException
	{
		this.levelN = levelN;
		int m = -1;
		for (int i = 0; i < Modes._NAMES.length; i++)
			if (Modes._NAMES[i].equals(mode))
			{
				m = i;
				break;
			}
		if (m == -1)
			throw new PhramerException("Unknown mode");
		this.mode = m;
	}
	
	public HypothesisErrorStatistics getErrorStatistics(Item[] ref, Item test)
	{
		// multi-ref, variable N now
		
		String[] translation = ((StringVectorItem)test).value;
		String[][] reference = new String[ref.length][];
		for (int i = 0; i < reference.length; i++)
			reference[i] = ((StringVectorItem)ref[i]).value;
		
		BleuSentenceErrorStatistics e = new BleuSentenceErrorStatistics(
			computeRefLen(reference, translation), translation.length , levelN);
		boolean refUsed[][][] = new boolean[reference.length][][];
		for (int i = 0; i < refUsed.length; i++)
			refUsed[i] = new boolean [reference[i].length][levelN];
		
		for (int len = 1; len <= levelN; len++)
			for (int i = 0; i + len <= translation.length; i++)
			{
				e.countTotal[len - 1]++;
				// check if it's good
				boolean found = false;
				
				for (int refID = 0 ; refID < reference.length && !found ; refID++)
					x:
					for (int j = 0; j + len <= reference[refID].length && !found; j++)
						if (!refUsed[refID][j][len - 1])
						{
							for (int k = 0; k < len; k++)
								if (!translation[i + k].equals(reference[refID][j + k]))
									continue x;
							
							found = true;
							refUsed[refID][j][len - 1] = true;
						}
				if (found)
					e.countGood[len - 1]++;
			}
		
		return e;
	}
	
	protected int computeRefLen(String[][] reference , String[] translation)
	{
		switch (mode)
		{
			case Modes.MEDIAN:
				{
					// get median length
					int[] lens = new int[reference.length];
					for (int i = 0; i < lens.length; i++)
						lens[i] = reference[i].length;
					
					java.util.Arrays.sort(lens);
					return lens[lens.length / 2];
				}
			case Modes.MIN:
				// get min length
				{
					int minLen = reference[0].length;
					for (int i = 1; i < reference.length; i++)
						minLen = Math.min(minLen , reference[i].length);
					return minLen;
				}
			case Modes.MAX:
				{
					// get max length
					int maxLen = reference[0].length;
					for (int i = 1; i < reference.length; i++)
						maxLen = Math.max(maxLen , reference[i].length);
					return maxLen;
				}
			case Modes.AVERAGE:
				{
					// get average length
					int sumLen = 0;
					for (int i = 0; i < reference.length; i++)
						sumLen += reference[i].length;
					return sumLen / reference.length;
				}
			case Modes.CLOSEST_LOWER:
				{
					// get closest length that doesn't go higher than hyp
					int maxLen = -1;
					for (int i = 0; i < reference.length; i++)
						if (reference[i].length <= translation.length)
							maxLen = Math.max(maxLen , reference[i].length);
					if (maxLen == -1)
					{
						maxLen = reference[0].length;
						for (int i = 1; i < reference.length; i++)
							maxLen = Math.max(maxLen , reference[i].length);
					}
					return maxLen;
				}
			case Modes.CLOSEST_UPPER:
				{
					// get closest length that doesn't go lower than hyp
					int minLen = Integer.MAX_VALUE;
					for (int i = 0; i < reference.length; i++)
						if (reference[i].length >= translation.length)
							minLen = Math.min(minLen , reference[i].length);
					if (minLen == Integer.MAX_VALUE)
					{
						minLen = reference[0].length;
						for (int i = 1; i < reference.length; i++)
							minLen = Math.max(minLen , reference[i].length);
					}
					return minLen;
				}
			case Modes.CLOSEST:
				{
					// get closest length
					int bestLen = reference[0].length;
					for (int i = 0; i < reference.length; i++)
						if (Math.abs(bestLen - translation.length) > Math.abs(reference[i].length - translation.length))
							bestLen = reference[i].length;
					
					return bestLen;
				}
		}
		throw new Error("Other method to compute reference length for brevity: not implemented");
	}
}
