/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.mert.generation;
import info.olteanu.interfaces.*;
import info.olteanu.utils.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.phramer.*;
import org.phramer.mert.generation.*;
import org.phramer.mert.item.*;
import org.phramer.v1.decoder.mert.item.*;
import org.phramer.v1.decoder.mert.reader.*;
import org.phramer.v1.decoder.mert.reader.pharaohcarmel.*;
import org.phramer.v1.decoder.rerank.*;
import org.phramer.v1.decoder.token.*;


// TODO: put distinct values in the list to be rescored
//    advantage: slightly faster (16177 vs 17091)
//    disadvantage: MUST match the other list!!
//    anyway, they eliminated later

public class PharaohCarmelNHGM
extends BasicMtNHGMWithReaders
{
	public final boolean deleteLattice;// = false;
	public final boolean deleteCarmelOutput;// = false;
	public final boolean deletePreRescore;// = false;
	public final boolean deleteRescore;// = false;
	public final boolean saveCarmelOutput;// = true;
	public final boolean saveTEXT;// = false;
	
	private final String scriptPharaoh;
	private final String scriptCarmel;
	
	public PharaohCarmelNHGM(Properties p , String fileF , int nSkipIterations)
	throws IOException, PhramerException
	{
		super(p , fileF , nSkipIterations , new RescoreReaderPharaoh() , new NBestReaderCarmel() );
		scriptPharaoh = p.getProperty("external.pharaoh");
		scriptCarmel = p.getProperty("external.carmel");
		
		
		deleteLattice = "1".equals(p.getProperty("delete-temp.lattice", "0"));
		deleteCarmelOutput = "1".equals(p.getProperty("delete-temp.carmel", "0"));
		deletePreRescore = "1".equals(p.getProperty("delete-temp.pre-rescore", "0"));
		deleteRescore = "1".equals(p.getProperty("delete-temp.rescore", "0"));
		saveCarmelOutput = !("0".equals(p.getProperty("save-temp.carmel", "1")));
		saveTEXT = "1".equals(p.getProperty("save-temp.text", "0"));
	}
	
	// reads a set of temp folders in order to get initial points for the search process
	// replicates functionality from doCarmel, loadFromCarmel and putRescoreInfo
	public List<Hypothesis>[] getInitialPoints(Properties p) throws IOException, PhramerException
	{
		int cnt = Integer.parseInt(p.getProperty("points.pre-load.count" , "0"));
		if (cnt == 0)
			return null;
		
		// TODO
		if (rerankers != null)
			throw new Error("Initial points with reranking: not yet implemented");
		
		List<Hypothesis>[] out = new List[nSentence];
		for (int i = 0; i < out.length; i++)
			out[i] = new ArrayList<Hypothesis>();
		
		// read each
		for (int t = 1; t <= cnt; t++)
		{
			String fileMask = p.getProperty("points.pre-load.file." + t);
			
			// resembles
			for (int i = 0; i < nSentence; i++)
			{
				String baseFile = fileMask + StringTools.adjustLengthForNumber(i , 4);
				
				BufferedReader inputFileR = new BufferedReader(new InputStreamReader(new FileInputStream(baseFile + ".rescore")));
				BufferedReader inputFileC = new BufferedReader(new InputStreamReader(new FileInputStream(baseFile + ".carmel")));
				
				String lineFileC;
				while ((lineFileC = inputFileC.readLine()) != null)
				{
					// add a new hypothesis
					Hypothesis e = getHypothesis(lineFileC);
					if (e == null)
						break;
					
					String line = inputFileR.readLine();
					if (line == null)
						throw new PhramerException("Too short file at initial points");
					e.p = rescoreReader.readLine(line);
					
					out[i].add(e);
				}
				inputFileR.close();
				inputFileC.close();
			}
		}
		
		return out;
	}
	
	public List<Hypothesis>[] getHypotheses(double[] lambda , int run)
	{
		List<Hypothesis>[] output = new List[nSentence];
		for (int i = 0; i < output.length; i++)
			output[i] = new ArrayList<Hypothesis>();
		
		// parameters matching lambda
		String lambdaX = printDecoderParameters(lambda);
		
		try
		{
			// Load only: for debugging
			if (run <= nSkipIterations)
			{
				// load hypotheses from .carmel files
				for (int i = 0; i < nSentence; i++)
					loadFromCarmel(run, i, output);
			}
			else
			{
				doPharaohTranslate(run , lambdaX);
				
				// now carmel
				for (int i = 0; i < nSentence; i++)
					doCarmel(run, i, output);
				
				// now run pharaoh to rescore
				runRescore(run, lambdaX);
				
			}
			// now I have rescored files
			putRescoreInfo(output, run);
			
			// change March 15, 2006: allow reranker
			doReranking(output);
			return output;
		}
		catch (PhramerException e)
		{
			throw new Error(e);
		}
		catch (InterruptedException e)
		{
			throw new Error("Interrupted" , e);
		}
		catch (IOException e)
		{
			throw new Error("Execution failed" , e);
		}
		
	}
	
	
	
	private void doPharaohTranslate(int run , String lambdaX) throws IOException, InterruptedException
	{
		// prepare folder
		new File(workingFolder + "/" + run).mkdirs();
		
		// run pharaoh
		// param 1 : folder
		// param 2 : config
		// param 3 : fileIn
		// param 4.. : params pharaoh
		
		// build it
		StringBuilder cmdLinePharaoh = getBasicDecoderCmdLine(run, scriptPharaoh , lambdaX);
		cmdLinePharaoh.append("-l ").append(workingFolder).append("/").append(run)
			.append("/run").append(run).append(' ');
		
		if (DEBUG_PRINT_CMDLN)
			stdErr.println("** " + cmdLinePharaoh);
		
		if (!DONT_EXECUTE)
		{
			String trace = traceFile + ".run" + run;
			PrintStream outFileL = new PrintStream(new FileOutputStream(trace + ".lambda"));
			outFileL.println(lambdaX);
			outFileL.close();
			trace += ".txt";
			
			Process p = Runtime.getRuntime().exec(cmdLinePharaoh.toString());
			new StreamToStreamByLineThread(p.getErrorStream() , stdErr , "TR: ").start();
			
			// dump the file
			PrintStream outFile = new PrintStream(new FileOutputStream(trace));
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String lineFile;
			while ((lineFile = inputFile.readLine()) != null)
				outFile.println(lineFile);
			inputFile.close();
			outFile.close();
			p.waitFor();
		}
	}
	
	// only loads the file
	// adapted from doCarmel
	private void loadFromCarmel(int run, int sentenceID, List<Hypothesis>[] output) throws PhramerException, IOException
	{
		BufferedReader inputFile;
		String baseFileX = workingFolder + "/" + run + "/run" + run + ".best" + nBestSize + "." + StringTools.adjustLengthForNumber(sentenceID , 4);
		
		// read from disk
		inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(baseFileX + ".carmel")));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
		{
			Hypothesis e = getHypothesis(lineFile);
			if (e == null)
				break;// or continue
			
			output[sentenceID].add(e);
		}
		inputFile.close();
	}
	
	private void doCarmel(int run, int sentenceID, List<Hypothesis>[] output) throws PhramerException, IOException, InterruptedException
	{
		String baseFile = workingFolder + "/" + run + "/run" + run + "." + StringTools.adjustLengthForNumber(sentenceID , 4);
		
		StringBuffer cmdLineCarmel = new StringBuffer();
		cmdLineCarmel.append(scriptCarmel).append(' ');
		cmdLineCarmel.append("-mk ");
		cmdLineCarmel.append(nBestSize).append(' ');
		cmdLineCarmel.append(baseFile).append(' ');
		
		if (DEBUG_PRINT_CMDLN)
			stdErr.println("*** " + cmdLineCarmel);
		
		BufferedReader inputFile;
		String baseFileX = workingFolder + "/" + run + "/run" + run + ".best" + nBestSize + "." + StringTools.adjustLengthForNumber(sentenceID , 4);
		PharaohCarmelProcessor processor = new PharaohCarmelProcessor();
		
		processor.loadStateFile(baseFile + ".state");
		Process p = null;
		if (!DONT_EXECUTE)
		{
			p = Runtime.getRuntime().exec(cmdLineCarmel.toString());
			new StreamToStreamByLineThread(p.getErrorStream() , stdErr, "CM: ").start();
			inputFile = new BufferedReader(new InputStreamReader(p.getInputStream()));
		}
		else
		{
			// alternative: read from disk
			inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(baseFileX + ".carmel")));
		}
		
		PrintStream outFileCarmel = saveCarmelOutput && !DONT_EXECUTE ? new PrintStream(new FileOutputStream(baseFileX + ".carmel")) : null;
		PrintStream outFileRescorePrep = new PrintStream(new FileOutputStream(baseFileX));
		PrintStream outFileText = saveTEXT ? new PrintStream(new FileOutputStream(baseFileX + ".txt")) : null;
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
		{
			if (saveCarmelOutput && !DONT_EXECUTE) outFileCarmel.println(lineFile);
			if (saveTEXT)
			{
				String[] v = nbestReader.readLine(lineFile);
				if (v != null)
					outFileText.println(StringTools.untokenize(v));
			}
			String rescorePrep = processor.prepRescore(lineFile, fSentences[sentenceID]);
			
			if (rescorePrep != null)
			{
				outFileRescorePrep.println(rescorePrep);
				Hypothesis e = getHypothesis(lineFile);
				
				output[sentenceID].add(e);
			}
		}
		inputFile.close();
		if (saveCarmelOutput && !DONT_EXECUTE) outFileCarmel.close();
		if (saveTEXT) outFileText.close();
		
		outFileRescorePrep.close();
		if (!DONT_EXECUTE)
			p.waitFor();
		
		if (deleteLattice)
		{
			new File(baseFile).delete();
			new File(baseFile + ".state").delete();
		}
		
	}
	
	
	private void runRescore(int run, String lambdaX) throws IOException, InterruptedException
	{
		StringBuilder cmdLinePharaohR = getBasicDecoderCmdLine(run, scriptPharaoh , lambdaX);
		cmdLinePharaohR.append("-rd ").append(workingFolder).append("/").append(run)
			.append("/run").append(run).append(".best").append(nBestSize);
		cmdLinePharaohR.append(' ').append(nSentence);
		if (DEBUG_PRINT_CMDLN)
			stdErr.println("** " + cmdLinePharaohR);
		if (!DONT_EXECUTE)
		{
			Process p = Runtime.getRuntime().exec(cmdLinePharaohR.toString());
			new StreamToStreamByLineThread(p.getErrorStream() , stdErr , "RS: ").start();
			p.waitFor();
		}
	}
	
// be sure to update also getInitialPoints
	private void putRescoreInfo(List<Hypothesis>[] output, int run) throws PhramerException, IOException
	{
		for (int i = 0; i < nSentence; i++)
		{
			List<Hypothesis> v = output[i];
			String baseFile = workingFolder + "/" + run + "/run" + run + ".best" + nBestSize + "." + StringTools.adjustLengthForNumber(i , 4);
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(baseFile + ".rescore")));
			for (int j = 0; j < v.size(); j++)
			{
				String line = inputFile.readLine();
				if (line == null)
					throw new PhramerException("Too short file " + i + " " + j + " vs " + v.size());
				v.get(j).p = rescoreReader.readLine(line);
			}
			inputFile.close();
			
			
			if (deleteCarmelOutput && !saveCarmelOutput)
				new File(baseFile + ".carmel").delete();
			
			if (deletePreRescore)
				new File(baseFile).delete();
			
			if (deleteRescore)
				new File(baseFile + ".rescore").delete();
		}
	}
	
	
}
