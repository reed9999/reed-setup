/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.mert.generation;
import java.io.*;
import java.util.*;
import org.phramer.*;

public class PharaohCarmelProcessor
{
	private HashMap<String,String> states = new HashMap<String,String>();
	private String finalMask = null;
	
	public String prepRescore(String line, String[] fSentence) throws PhramerException
	{
		
		if (line == null)
			return null;
		// (0 -> 16 "the" : "the" / 0.0172841177390966) (16 -> 273 "member" : "member" / 0.000238634007769431) (273 -> 1081 "that the" : "that the" / 1.80794915286165e-05) (1081 -> 6090 "government" : "government" / 0.00124314416917779) (6090 -> 7401 "and" : "and" / 0.0029542860179385) (7401 -> 7928 "their" : "their" / 0.000497105063278089) (7928 -> 10407 "obligation" : "obligation" / 0.000217325804868481) (10407 -> 11523 "to" : "to" / 0.0747335224630998) (11523 -> 12562 "hochradioaktiven" : "hochradioaktiven" / 4.53999297624849e-05) (12562 -> 12662 "waste" : "waste" / 0.000138410423374793) (12662 -> 12856 "from france" : "from france" / 1.60415251495553e-05) (12856 -> 13572 "region ." : "region ." / 1.15106191758575e-06) e^-98.0689801938912
		
		StringBuffer sb = new StringBuffer();
		int idx = 0, idx2;
		int k = 0;
		int pos = 0;
		while (line.indexOf('"' , idx) != -1)
		{
			// get start and end state
			idx = line.indexOf('(' , idx);
			if (idx == -1) throw new PhramerException("Invalid carmel output: " + line);
			idx2 = line.indexOf(' ' , idx + 1);
			String startState = line.substring(idx + 1 , idx2).trim();
			
			line = line.substring(idx2);
			
			if (!line.startsWith(" -> ")) throw new PhramerException("Invalid carmel output: " + line);
			String endState = line.substring(4 , line.indexOf(' ' , 4)).trim();
			
			
			idx = line.indexOf('"');
			// look for second index
			idx2 = line.indexOf('"' , idx + 1);
			if (idx2 == -1) throw new PhramerException("Invalid carmel output: " + line);
			while (line.charAt(idx2 - 1) == '\\')
			{
				idx2 = line.indexOf('"' , idx2 + 1);
				if (idx2 == -1)
					throw new PhramerException("Invalid carmel output: " + line);
			}
			String phrase = line.substring(idx + 1 , idx2).replace("\\\"", "\"");
			idx = idx2 + 1;
			
			// skip a new one
			idx = line.indexOf('"' , idx);
			// look for second index
			idx2 = line.indexOf('"' , idx + 1);
			if (idx2 == -1) throw new PhramerException("Invalid carmel output: " + line);
			while (line.charAt(idx2 - 1) == '\\')
			{
				idx2 = line.indexOf('"' , idx2 + 1);
				if (idx2 == -1)
					throw new PhramerException("Invalid carmel output: " + line);
			}
			idx = idx2 + 1;
			
			// >> / 0.0172841177390966)<<
			// extract probability
			String prob = line.substring(idx + 3 , line.indexOf(')' , idx));
			
			// now I have the phrase
			pos = getStuff(phrase/*.trim()*/, startState , endState , prob , fSentence , sb , pos);
			k++;
		}
		
		
		line = line.substring(line.lastIndexOf(") ") + 2);
		
		sb.append("T ");
		sb.append(line);
		
		if (k == 0)
			return null;
		return sb.toString();
	}
	
	// generate: E the government F die bundesregierung D 0 P 8.48194e-05
	private int getStuff(String phrase, String startState, String endState , String prob , String[] fSentence , StringBuffer sb , int expectedPos)
	{
		sb.append("E ");
		sb.append(phrase);
		sb.append(" F ");
		
		// add all in the word
		String maskStart = states.get(startState);
		String maskEnd = states.get(endState);
		// debug:
//		{
//
//			if (maskStart == null)
//			{
//				finalMask = "00000";
//				maskStart = finalMask;
//			}
//		}
		if (maskEnd == null)
		{
			// assume final state
			maskEnd = finalMask;
		}
		int lastPos = -100;
		int startPos = -1;
		for (int i = 0; i < maskStart.length(); i++)
			if (maskStart.charAt(i) != maskEnd.charAt(i))
			{
				lastPos = i;
				if (startPos == -1)
					startPos = i;
				sb.append(fSentence[i]);
				sb.append(' ');
			}
		
		sb.append("D ");
		sb.append(startPos - expectedPos);
		
		sb.append(" P ");
		sb.append(prob);
		sb.append(' ');
		return lastPos + 1;
	}
	
	public void loadStateFile(String baseFile)
	throws IOException
	{
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(baseFile)));
		String lineFile;
		int len = -1;
		while ((lineFile = inputFile.readLine()) != null)
		{
			String state = lineFile.substring(0 , lineFile.indexOf(' ')).intern();
			String mask = lineFile.substring(lineFile.indexOf(' ') + 1).trim().intern();
			states.put(state, mask);
			len = mask.length();
		}
		
		// generate 0 state mask
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < len; i++)
			sb.append('0');
		
		String state = "0".intern();
		String mask = sb.toString().intern();
		states.put(state, mask);
		
		
		sb = new StringBuffer();
		for (int i = 0; i < len; i++)
			sb.append('1');
		finalMask = sb.toString().intern();
		
		inputFile.close();
	}
}
