/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.mert.reader.pharaohcarmel;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.mert.reader.*;

public class NBestReaderCarmel implements NBestReader
{
	
	public String[] readLine(String line) throws PhramerException
	{
		if (line == null)
			return null;
		// (0 -> 16 "the" : "the" / 0.0172841177390966) (16 -> 273 "member" : "member" / 0.000238634007769431) (273 -> 1081 "that the" : "that the" / 1.80794915286165e-05) (1081 -> 6090 "government" : "government" / 0.00124314416917779) (6090 -> 7401 "and" : "and" / 0.0029542860179385) (7401 -> 7928 "their" : "their" / 0.000497105063278089) (7928 -> 10407 "obligation" : "obligation" / 0.000217325804868481) (10407 -> 11523 "to" : "to" / 0.0747335224630998) (11523 -> 12562 "hochradioaktiven" : "hochradioaktiven" / 4.53999297624849e-05) (12562 -> 12662 "waste" : "waste" / 0.000138410423374793) (12662 -> 12856 "from france" : "from france" / 1.60415251495553e-05) (12856 -> 13572 "region ." : "region ." / 1.15106191758575e-06) e^-98.0689801938912
		ArrayList<String> l = new ArrayList<String>();
		int idx = 0;
		boolean t = true;
		while (line.indexOf('"' , idx) != -1)
		{
			idx = line.indexOf('"' , idx);
			// look for second index
			int idx2 = line.indexOf('"' , idx + 1);
			if (idx2 == -1)
				throw new PhramerException("Invalid carmel output: " + line);
			while (line.charAt(idx2 - 1) == '\\')
			{
				idx2 = line.indexOf('"' , idx2 + 1);
				if (idx2 == -1)
					throw new PhramerException("Invalid carmel output: " + line);
			}
			
			if (t)
			{
				String phrase = line.substring(idx + 1 , idx2).replace("\\\"", "\"");
				StringTokenizer st = new StringTokenizer(phrase);
				while (st.hasMoreTokens())
					l.add(st.nextToken().intern());
			}
			t = !t;
			
			idx = idx2 + 1;
		}
		if (l.size() == 0)
			return null;
		return l.toArray(new String[l.size()]);
	}
	
}
