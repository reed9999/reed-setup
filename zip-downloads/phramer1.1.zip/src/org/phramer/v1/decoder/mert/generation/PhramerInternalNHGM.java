/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.mert.generation;
import info.olteanu.utils.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.loader.*;
import org.phramer.v1.decoder.loader.custom.*;
import org.phramer.v1.decoder.main.*;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.token.*;
import org.phramer.v1.decoder.table.wordalignment.*;

public class PhramerInternalNHGM
extends BasicPhramerNHGM
{
	private PhramerHelperIf helper;
	public PhramerInternalNHGM(Properties p , String fileF , int nSkipIterations)
	throws IOException, PhramerException
	{
		super(p , fileF , nSkipIterations);
		
		
		AllLoader loader = new MyLoader();
		helper = new PhramerHelperCustom(loader , new TokenBuilderWordOnly(
											 PhramerHelperSimpleImpl.getFilter(StringTools.tokenize(additionalParameters))
										 ) , loader , loader , loader);
	}
	
	
	protected void doPhramerTranslate(int run, String lambdaX) throws IOException, PhramerException, InstantiationException, IllegalAccessException, ClassNotFoundException
	{
		// prepare folder
		new File(workingFolder + "/" + run).mkdirs();
		
		
		String[] params = StringTools.tokenize(
			"-f " + configFile + " "
			+ getParameters(lambdaX)
			+ " " + getSpecificParameters(run)
		);
		
		
		
		String trace = traceFile + ".run" + run;
		PrintStream outFileL = new PrintStream(new FileOutputStream(trace + ".lambda"));
		outFileL.println(lambdaX);
		outFileL.close();
		trace += ".txt";
		
		PhramerMain.phramerMain(new FileInputStream(fileF) , new FileOutputStream(trace) , params , helper);
	}
	
	// caches TT and LM
	class MyLoader
	extends LoaderSimpleImpl
	{
		// cache by URL
		private HashMap<String, LanguageModelIf> lms = new HashMap<String, LanguageModelIf>();
		private HashMap<String, HashMap<Object, TableLine[]>> tts = new HashMap<String, HashMap<Object, TableLine[]>>();
		
		public LanguageModelIf loadLanguageModel(String lmURL, String encodingTextFile, int index) throws IOException, PhramerException
		{
			if (lms.get(lmURL) != null)
				return lms.get(lmURL);
			
			LanguageModelIf lm = super.loadLanguageModel(lmURL, encodingTextFile, index);
			lms.put(lmURL , lm);
			return lm;
		}
		public TranslationTable loadTranslationTable(TokenBuilder tokenBuilder,
													 String ttURL,
													 String encodingTextFile,
													 WordAlignmentBuilder wordAlignmentBuilder ,
													 int ttLimit,
													 int maxPhraseLength ,
													 double ttThreshold,
													 double[] ttTresholdWeights,
													 boolean loadWordAlignment ,
													 boolean storeDetails) throws IOException, PhramerException
		{
			if (isMemoryTT(ttURL))
			{
				HashMap<Object, TableLine[]> hash = tts.get(ttURL);
				if (hash == null)
				{
					MutableInt type = new MutableInt(0);
					MutableInt alignmentConfig = new MutableInt(WordAlignmentTypes.TYPE_NONE);
					MutableBool nio = new MutableBool();
					String ttURLadjusted = parseMemoryTT(ttURL, loadWordAlignment , type , alignmentConfig , nio);
					if (nio.value)
						throw new PhramerException("Cannot use java.nio.Buffer translation tables for MERT");
					//System.err.println( "Type: " + type );
					hash = TranslationTableTools
						.readTranslationTable(
						type.value ,
						alignmentConfig.value ,
						wordAlignmentBuilder ,
						IOTools.getInputStream(ttURLadjusted) ,
						encodingTextFile ,
						Double.NEGATIVE_INFINITY ,
						ttTresholdWeights ,
						Integer.MAX_VALUE ,
						maxPhraseLength ,
						new EFProcessorSimple(tokenBuilder) ,
						null ,
						true ,
						false ,
						new MutableInt(0) ,
						new MutableInt(0));
					
					tts.put(ttURL , hash);
				}
				
				return new MemoryTranslationTable(hash , ttLimit , ttThreshold , ttTresholdWeights);
			}
			else
				return super.loadTranslationTable(tokenBuilder,
												  ttURL,
												  encodingTextFile ,
												  wordAlignmentBuilder ,
												  ttLimit,
												  maxPhraseLength ,
												  ttThreshold,
												  ttTresholdWeights,
												  loadWordAlignment,
												  storeDetails);
		}
	}
}
