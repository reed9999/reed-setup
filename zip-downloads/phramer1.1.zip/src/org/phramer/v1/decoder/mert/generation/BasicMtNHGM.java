/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.mert.generation;
import info.olteanu.interfaces.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.phramer.*;
import org.phramer.mert.generation.*;
import org.phramer.mert.item.*;
import org.phramer.v1.decoder.mert.item.*;
import org.phramer.v1.decoder.rerank.*;
import org.phramer.v1.decoder.token.*;

public abstract class BasicMtNHGM
implements NewHypothesesGenerationManager
{
	protected static final boolean DONT_EXECUTE = false;
	protected static final boolean DEBUG_PRINT_CMDLN = false;
	public static PrintStream stdErr = System.err;
	
	/** Source file (dev-foreign) */
	protected final String fileF;
	
	protected final String configFile;
	protected final String workingFolder;
	protected final String additionalParameters;
	protected final int beamSize,nBestSize;
	protected final String lambdaMask;
	protected final int nSentence;
	
	protected final String[][] fSentences;
	
	protected final HypothesisReranker rerankers[];
	protected final TokenBuilder tokenBuilder;
	protected final int cntProbRerankers;
	protected final FToken[][] fSentencesToken;
	
	protected final StringFilter filter;
	
	protected int nSkipIterations;
	
	
	public BasicMtNHGM(Properties p , String fileF , int nSkipIterations)
	throws IOException, PhramerException
	{
		try
		{
			this.nSkipIterations = nSkipIterations;
			this.fileF = fileF;
			configFile = p.getProperty("config.file");
			workingFolder = p.getProperty("working.folder");
			additionalParameters = p.getProperty("additional-parameters");
			beamSize = Integer.parseInt(p.getProperty("beam.size"));
			nBestSize = Integer.parseInt(p.getProperty("n-best.size"));
			lambdaMask = p.getProperty("lambda.mask");
			
			String classFilter = p.getProperty("filter.output.class");
			if (classFilter != null)
				filter = (StringFilter) Class.forName(classFilter).newInstance();
			else
				filter = StringFilter.VOID;
			
			
			
			
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(fileF)));
			String lineFile;
			// maybe use ReferenceLoaderMT.readReference_R1
			// EDIT: I don't think so. F is not reference file
			List<String[]> t = new ArrayList<String[]>();
			while ((lineFile = inputFile.readLine()) != null)
				if (lineFile.trim().length() > 0)
				{
					StringTokenizer st = new StringTokenizer(lineFile);
					String[] k = new String[st.countTokens()];
					for (int i = 0; i < k.length; i++)
						k[i] = st.nextToken();
					
					t.add(k);
				}
			nSentence = t.size();
			inputFile.close();
			fSentences = t.toArray(new String[nSentence][]);
			
			
			// change March 15, 2006: allow reranking
			int cntRerankers = p.getProperty("rerank.count") == null ? 0 : Integer.parseInt(p.getProperty("rerank.count"));
			if (cntRerankers == 0)
			{
				rerankers = null;
				cntProbRerankers = 0;
				tokenBuilder = null;
				fSentencesToken = null;
			}
			else
			{
				String nameTokenBuilder = p.getProperty("rerank.token-builder.class");
				if (nameTokenBuilder != null)
					tokenBuilder = (TokenBuilder) Class.forName(nameTokenBuilder).newInstance();
				else
					tokenBuilder = new TokenBuilderWordOnly(StringFilter.INVALID);
				
				rerankers = new HypothesisReranker[cntRerankers];
				int x = 0;
				for (int i = 0; i < rerankers.length; i++)
				{
					String rerankerClassName = p.getProperty("rerank." + (i + 1) + ".class");
					Integer cnt = new Integer(i + 1);
					Constructor<HypothesisReranker> constructor = ((Class<HypothesisReranker>)Class.forName(rerankerClassName)).getDeclaredConstructor(cnt.getClass() , p.getClass());
					rerankers[i] = constructor.newInstance(cnt , p);
					x += rerankers[i].getProbabilityCount();
				}
				cntProbRerankers = x;
				
				fSentencesToken = new FToken[ fSentences.length ][];
				for (int i = 0; i < fSentences.length; i++)
				{
					fSentencesToken[i] = new FToken[ fSentences[i].length ];
					for (int j = 0; j < fSentencesToken[i].length; j++)
						fSentencesToken[i][j] = tokenBuilder.buildFToken(fSentences[i][j]);
				}
			}
		}
		catch (ClassNotFoundException e)
		{
			throw new PhramerException(e);
		}
		catch (InstantiationException e)
		{
			throw new PhramerException(e);
		}
		catch (IllegalAccessException e)
		{
			throw new PhramerException(e);
		}
		catch (IllegalArgumentException e)
		{
			throw new PhramerException(e);
		}
		catch (InvocationTargetException e)
		{
			throw new PhramerException(e);
		}
		catch( NoSuchMethodException e )
		{
			throw new PhramerException(e);
		}
		
	}
	
	protected void doReranking(List<Hypothesis>[] output) throws PhramerException
	{
		if (rerankers != null)
			for (int q = 0 ; q < output.length ; q++)
			{
				List<Hypothesis> hypos = output[q];
				for (Hypothesis h : hypos)
				{
					int currentPos = h.p.length;
					
					double[] newP = new double[h.p.length + cntProbRerankers ];
					System.arraycopy(h.p , 0 , newP , 0 , h.p.length);
					h.p = newP;
					
					for (int i = 0; i < rerankers.length; i++)
					{
						double[] pR = rerankers[i].getProbability(fSentencesToken[q] , getETokens((ESentence)h.h));
						System.arraycopy(pR , 0 , h.p , currentPos , rerankers[i].getProbabilityCount());
						currentPos += rerankers[i].getProbabilityCount();
					}
				}
			}
	}
	// change March 15, 2006: allow reranker
	private EToken[] getETokens(ESentence h)
	{
		EToken[] out = new EToken[h.value.length];
		for (int i = 0; i < out.length; i++)
			out[i] = tokenBuilder.buildEToken(h.originalTokens[i]);
		
		return out;
	}
	
	public String printDecoderParameters(double[] lambda)
	{
		String thisLambdaMask = lambdaMask;
		for (int i = 0; i < lambda.length; i++)
		{
			int pos = thisLambdaMask.indexOf('%');
			// change March 15, 2006: allow reranker
			if (rerankers != null && pos == -1)
				break;
			thisLambdaMask = thisLambdaMask.substring(0, pos) + lambda[i] + thisLambdaMask.substring(pos + 1);
		}
		return thisLambdaMask;
	}
	
	protected StringBuilder getBasicDecoderCmdLine(int run, String scriptExternal , String lambdaX)
	{
		StringBuilder cmdLinePharaoh = new StringBuilder();
		cmdLinePharaoh.append(scriptExternal).append(' ');
		cmdLinePharaoh.append(workingFolder).append("/filtered").append(' ');
		cmdLinePharaoh.append(configFile).append(' ');
		cmdLinePharaoh.append(fileF).append(' ');
		
		cmdLinePharaoh.append(getParameters(lambdaX)).append(' ');
		return cmdLinePharaoh;
	}
	
	protected String getParameters(String lambdaX)
	{
		return lambdaX + " " + additionalParameters + " -s " + beamSize;
	}
	
	
	public abstract List<Hypothesis>[] getInitialPoints(Properties p) throws IOException, PhramerException;
}
