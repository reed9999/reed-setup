/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.extensionifs.impl;

import info.olteanu.utils.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.token.*;

public class CustomProbabilityPharaohLanguageModels
extends CustomProbability
{
	
	
	
	public CustomProbabilityPharaohLanguageModels(PhramerConfig config , String param[])
	{
		super(config, param);
		this.config = config;
		n = config.weightL().length;
	}
	private final int n;
	private final PhramerConfig config;
	public int getNoProbabilities()
	{
		return n;
	}
	public int getProbability(double[] bufferOut,
							  int offset,
							  PhramerInput input,
							  HypothesisState hyp,
							  PhraseTranslationVariant tv,
							  Object constraintObject ,
							  int pos,
							  int len)
	{
		assert len > 0;
		ArrayTools.fillZero(bufferOut , offset , n);

		EToken[] phraseTranslation = tv.getTranslation();
		LMContext context = hyp.lmContext;
		for (int j = 0; j < phraseTranslation.length; j++)
		{
			add(bufferOut, offset, config.lmProcessor.getLogProbabilityUnWeighted(context , phraseTranslation[j], config.instrument));
			context = context.append(phraseTranslation[j]);
		}
		assert context.equals(hyp.lmContext.append(phraseTranslation)) : context + " vs. " + hyp.lmContext.append(phraseTranslation);
		
		// if all f words are covered, add </s>
		if (!config.chunk)
			if ((hyp.nForeignCovered + len) == input.getFWords().length)
				add(bufferOut, offset, config.lmProcessor.getLogProbabilityUnWeighted(context , config.tokenBuilder.buildEToken(LMConstants.END_OF_SENTENCE), config.instrument));
		
		return n;
	}
	
	private void add(double[] bufferOut, int offset, double[] p)
	{
		assert p.length == n;
		for (int i = 0; i < n; i++)
			bufferOut[offset + i] += p[i];
	}
	
	// future cost: precalculation
	public int getEstimatedProbability(double[] bufferOut,
									   int offset,
									   PhraseTranslationVariant tVar)
	{
		double[] x = config.lmProcessor.getLogProbabilityUnWeighted(tVar.getTranslation(), config.instrument);
		assert x.length == n;
		System.arraycopy(x , 0 , bufferOut , offset , x.length);
		return n;
	}
	
	
}
