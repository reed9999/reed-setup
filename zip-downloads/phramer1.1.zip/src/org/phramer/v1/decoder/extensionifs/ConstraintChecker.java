/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.extensionifs;

import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.search.*;

// non-reentrant
public interface ConstraintChecker
{
	
	/** If the constraint checker uses only positional information (start and end position)
	 * about the current phrase, then the method should return false.
	 * If the constraint checker requires info from the PhraseTranslationVariant
	 * that is passed to checkHardConstraints and to getSoftConstraintsPenality, then this
	 * method should return true */
	public boolean useInPhraseAnalysis();
	
	/** If there are special constraints that don't fit the -dl,
	 * then the constraint checker can ask the decoder to temporarily allow
	 * more space for distortion. <br>
	 * If not, return 0*/
	public int getMaxStartWord(Object inputConstraintsDescriptor,
							   Object hypConstraintsDescriptor,
							   HypothesisState hyp);
	
	/** If it is futil to search with low minStartWord,
	 * then the constraint checker can ask the decoder
	 * to start using a higher value <br>
	 * The constraint checker is not required to implement this method. <br>
	 * The decoder is not required to call this method. <br>
	 * If not, return 0 */
	public int getMinStartWord(Object inputConstraintsDescriptor,
							   Object hypConstraintsDescriptor,
							   HypothesisState hyp);
	
	/** Returns null if the constraint failed.
	 *  Else, returs an object to be attached to the hypothesis.
	 *  In soft mode, it makes an effort to return an object, even if it would fail.
	 *  It is designed to prepare the data for the soft constraints
	 */
	public Object checkHardConstraints(Object inputConstraintsDescriptor,
									   Object hypParentConstraintsDescriptor,
									   HypothesisState parent ,
									   PhraseTranslationVariant line ,
									   int start ,
									   int end ,
									   boolean finished ,
									   boolean softMode
									   );
	
	/** Returs the object to be attached to the initial hyp state.
	 */
	public Object getDescriptorForStartHypothesisState(Object inputConstraintsDescriptor);
	
	/** Returns the number of features for soft constraints
	 */
	public int getSoftConstraintsTypesCount();
	
	/** Returns the soft constraints features.
	 */
	public int getSoftConstraintsPenality(double[] bufferOut,
										  int offset,
										  Object inputConstraintsDescriptor,
										  Object hypParentConstraintsDescriptor,
										  HypothesisState parent ,
										  PhraseTranslationVariant line ,
										  Object currentHypConstraintsDescriptor ,
										  int start ,
										  int end
										  );
	
	
	
	/**
	 * Reports a stack to the beginning of the stack expansion and to the end.
	 * Designed to allow various implementations of the constraint checker, using
	 * limited number of resources - the constraint checker knows when to free
	 * resources
	 */
	public void reportStack(Object inputConstraintsDescriptor ,
							SearchStackIf stack ,
							boolean start);
	/**
	 * Reports a stack to the beginning of the decoding and to the end.
	 * Designed to allow various implementations of the constraint checker, using
	 * limited number of resources - the constraint checker knows when to free
	 * resources
	 */
	public void reportDecoding(Object inputConstraintsDescriptor,
							   boolean start);
	
	
	
	// void implementation
	public static final ConstraintChecker VOID = new ConstraintChecker()
	{
		public boolean useInPhraseAnalysis()
		{
			return false;
		}
		
		public Object getDescriptorForStartHypothesisState(Object inputConstraintsDescriptor)
		{
			return this;
		}
		public int getMaxStartWord(Object inputConstraintsDescriptor,
								   Object hypConstraintsDescriptor,
								   HypothesisState hyp)
		{
			return 0;
		}
		public int getMinStartWord(Object inputConstraintsDescriptor,
								   Object hypConstraintsDescriptor,
								   HypothesisState hyp)
		{
			return Integer.MAX_VALUE;
		}
		public final int getSoftConstraintsTypesCount()
		{
			return 0;
		}
		
		public final Object checkHardConstraints(Object inputConstraintsDescriptor,
												 Object hypParentConstraintsDescriptor,
												 HypothesisState parent,
												 PhraseTranslationVariant line,
												 int start ,
												 int end ,
												 boolean finished ,
												 boolean softMode)
		{
			return this;
		}
		public final int getSoftConstraintsPenality(double[] bufferOut,
													int offset,
													Object inputConstraintsDescriptor,
													Object hypParentConstraintsDescriptor,
													HypothesisState parent ,
													PhraseTranslationVariant line ,
													Object currentHypConstraintsDescriptor ,
													int start ,
													int end
													)
		{
			return 0;
		}
		public void reportDecoding(Object inputConstraintsDescriptor, boolean isStart)
		{
		}
		public final void reportStack(Object inputConstraintsDescriptor,
									  SearchStackIf stack,
									  boolean start)
		{
		}
	};
}
