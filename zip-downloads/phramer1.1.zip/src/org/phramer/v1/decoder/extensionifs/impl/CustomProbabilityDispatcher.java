/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.extensionifs.impl;

import info.olteanu.utils.*;
import org.phramer.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.token.*;

// parameters passed through -x-custom-probability-calculator-param:
// className1;param1 className2;param2 ...
public class CustomProbabilityDispatcher
extends CustomProbability
{
	private final CustomProbability[] cps;
	private final int n;
	private final boolean usePhraseTranslationVariant;
	public CustomProbabilityDispatcher(PhramerConfig config , String param[])
	throws PhramerException
	{
		super(config, param);
		cps = new CustomProbability[param.length];
		boolean usePTV = false;
		for (int i = 0; i < param.length; i++)
		{
			String className = param[i];
			String[] parameter = null;
			if (param[i].indexOf(';') != -1)
			{
				className = StringTools.substringBefore(param[i] , ";");
				parameter = StringTools.tokenize(StringTools.substringAfter(param[i] , ";") , ";");
			}
			cps[i] = (CustomProbability) PhramerTools.instantiateClass(className , config , parameter);
			usePTV |= cps[i].usePhraseTranslationVariant();
		}
		
		int n = 0;
		for (int i = 0; i < cps.length; i++)
			n += cps[i].getNoProbabilities();
		this.n = n;
		this.usePhraseTranslationVariant = usePTV;
	}
	
	public boolean requiresDetailedProbabilitiesInTranslationTable()
	{
		for (int i = 0; i < cps.length; i++)
			if (cps[i].requiresDetailedProbabilitiesInTranslationTable())
				return true;
		
		return false;
	}
	
	public boolean usePhraseTranslationVariant()
	{
		return usePhraseTranslationVariant;
	}
	
	public int getNoProbabilities()
	{
		return n;
	}
	
	public int getProbability(double[] bufferOut,
							  int offset,
							  PhramerInput input,
							  HypothesisState hyp,
							  PhraseTranslationVariant tv,
							  Object constraintObject ,
							  int pos,
							  int len)
	throws PhramerException
	{
		int delta = 0;
		for (int i = 0; i < cps.length; i++)
			delta += cps[i].getProbability(bufferOut , offset + delta , input, hyp, tv, constraintObject , pos, len);
		return delta;
	}
	
	// future cost: at runtime
	public int getEstimatedProbability(double[] bufferOut,
									   int offset,
									   boolean[] foreignCovered,
									   final int lastForeign)
	{
		int delta = 0;
		for (int i = 0; i < cps.length; i++)
			delta += cps[i].getEstimatedProbability(bufferOut , offset + delta , foreignCovered , lastForeign);
		return delta;
	}
	// future cost: precalculation
	public int getEstimatedProbability(double[] bufferOut,
									   int offset,
									   PhraseTranslationVariant tVar)
	{
		int delta = 0;
		for (int i = 0; i < cps.length; i++)
			delta += cps[i].getEstimatedProbability(bufferOut , offset + delta , tVar);
		return delta;
	}
}
