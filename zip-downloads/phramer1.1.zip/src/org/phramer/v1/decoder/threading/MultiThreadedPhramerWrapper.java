/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.threading;

import info.olteanu.utils.workpool.*;
import info.olteanu.utils.workpool.impl.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.search.*;
import info.olteanu.utils.workpool.service.*;

public class MultiThreadedPhramerWrapper extends PhramerIfBasicImpl
implements PooledService<PhramerIf, MultiThreadedPhramerWrapper.TranslationTask , PhramerException , IOException>
{
	private final PhramerIf[] phramers;
	private final Workpool<PhramerIf,PhramerException> workpool;
	
	public MultiThreadedPhramerWrapper(PhramerIf[] phramers , boolean starvationSafe)
	{
		this.phramers = phramers;
		this.workpool = new MultiThreadedWorkpoolImpl<PhramerIf,PhramerException>("PhramerWrapper", phramers, starvationSafe);
		this.workpool.start();
	}
	
	public static class TranslationTask extends Task<PhramerIf,PhramerException>
	{
		private final int sentenceIdx;
		private final String sentence;
		private final boolean xml;
		private final int outputDelta;
		private final Map<String,String[]> metaData;
		private final String[] outputVector;
		
		public TranslationTask(String sentence , int sentenceIdx , int outputDelta , boolean xml , Map<String,String[]> metaData ,  String[] outputVector)
		{
			this.sentence = sentence;
			this.sentenceIdx = sentenceIdx;
			this.outputDelta = outputDelta;
			this.xml = xml;
			this.metaData = metaData;
			this.outputVector = outputVector;
		}
		
		public void execute(PhramerIf resource) throws PhramerException
		{
			try
			{
				outputVector[outputDelta] = xml ? resource.translateXML(sentence, sentenceIdx , metaData) : resource.translate(sentence , sentenceIdx, metaData);
			}
			catch (IOException e)
			{
				throw new PhramerException(e);
			}
		}
		public boolean putInOutput()
		{
			return false;
		}
		
	}
	
	
	public void enqueueTask(TranslationTask t)
	{
		workpool.add(t);
	}
	public void waitForCompletion() throws PhramerException, IOException
	{
		try
		{
			workpool.waitForCompletion();
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		assert workpool.getOutput(true).size() == 0;
	}
	
	public boolean allowConcurrency()
	{
		return true;
	}
	public String getVersion()
	{
		return phramers[0].getVersion();
	}
	
	private static class TranslateMtTask extends Task<PhramerIf,PhramerException>
	{
		private final String fSentence;
		private final int sentenceIdx;
		private final boolean xml;
		private final boolean chunk;
		private final Map<String,String[]> metaData;
		public String output;
		TranslateMtTask(String fSentence, int sentenceIdx, boolean xml, boolean chunk, Map<String,String[]> metaData)
		{
			this.fSentence = fSentence;
			this.sentenceIdx = sentenceIdx;
			this.xml = xml;
			this.chunk = chunk;
			this.metaData = metaData;
		}
		/**
		 * Returs true if it should be added to the output pool
		 */
		public void execute(PhramerIf resource) throws PhramerException
		{
			try
			{
				output = resource.translate(fSentence, sentenceIdx, xml, chunk , metaData);
			}
			catch (IOException e)
			{
				throw new PhramerException(e);
			}
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	
	// MachineTranslator method
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk) throws IOException, PhramerException
	{
		return translate(fSentence, sentenceIdx, xml, chunk , null);
	}
	// MachineTranslator method
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk , Map<String,String[]> metaData) throws PhramerException, IOException
	{
		TranslateMtTask t = new TranslateMtTask(fSentence , sentenceIdx , xml , chunk , metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
	}
	
	// BlockMachineTranslator method
	public String[] translate(String[] fSentence, boolean[] chunk, boolean xml) throws PhramerException, IOException
	{
		return translate(fSentence, chunk, xml, null);
	}
	// BlockMachineTranslator method
	/** Translate a block through the workpool */
	public String[] translate(String[] fSentence, boolean[] chunk, boolean xml, Map<String,String[]>[] metaData) throws PhramerException, IOException
	{
		try
		{
			TranslateMtTask[] tasks = new TranslateMtTask[fSentence.length];
			for (int i = 0; i < tasks.length; i++)
			{
				tasks[i] = new TranslateMtTask(fSentence[i] , i , xml , chunk[i], metaData == null ? null : metaData[i]);
				workpool.add(tasks[i]);
			}
			String[] output = new String[fSentence.length];
			
			for (int i = 0; i < tasks.length; i++)
			{
				workpool.waitFor(tasks[i]);
				output[i] = tasks[i].output;
			}
			return output;
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
	}
	
	
	private static class TranslateNbestMtTask extends Task<PhramerIf,PhramerException>
	{
		private final String fSentence;
		private final boolean xml;
		private final boolean chunk;
		private final Map<String,String[]> metaData;
		private final int nbestListSize;
		public String[] output;
		
		TranslateNbestMtTask(String fSentence, boolean xml, boolean chunk, int nbestListSize , Map<String,String[]> metaData)
		{
			this.fSentence = fSentence;
			this.xml = xml;
			this.chunk = chunk;
			this.nbestListSize = nbestListSize;
			this.metaData = metaData;
		}
		/**
		 * Returs true if it should be added to the output pool
		 */
		public void execute(PhramerIf resource) throws PhramerException
		{
			try
			{
				output = resource.translateNBest(fSentence, xml, chunk , metaData , nbestListSize);
			}
			catch (IOException e)
			{
				throw new PhramerException(e);
			}
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, int nbestListSize) throws PhramerException, IOException
	{
		return translateNBest(fSentence, xml, chunk, null, nbestListSize);
	}
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, Map<String,String[]> metaData, int nbestListSize) throws PhramerException, IOException
	{
		TranslateNbestMtTask t = new TranslateNbestMtTask(fSentence , xml , chunk , nbestListSize , metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
	}
	private static class AlignTask extends Task<PhramerIf,PhramerException>
	{
		private final String fSentence;
		private final String eSentence;
		private final int sentenceIdx;
		private final boolean xml;
		private final Map<String,String[]> metaData;
		public List<HypothesisState> output;
		
		AlignTask(String fSentence, String eSentence, int sentenceIdx, boolean xml, Map<String,String[]> metaData)
		{
			this.fSentence = fSentence;
			this.eSentence = eSentence;
			this.sentenceIdx = sentenceIdx;
			this.xml = xml;
			this.metaData = metaData;
		}
		/**
		 * Returs true if it should be added to the output pool
		 */
		public void execute(PhramerIf resource) throws PhramerException
		{
			try
			{
				output = xml ? resource.alignXML(fSentence , eSentence , sentenceIdx , metaData) : resource.align(fSentence , eSentence , sentenceIdx , metaData);
			}
			catch (IOException e)
			{
				throw new PhramerException(e);
			}
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public List<HypothesisState> alignXML(String fSentence, String eSentence, int sentenceIdx, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		AlignTask t = new AlignTask(fSentence , eSentence , sentenceIdx , true , metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
	}
	private static class TranslateTask extends Task<PhramerIf,PhramerException>
	{
		private final String fSentence;
		private final int sentenceIdx;
		private final boolean xml;
		private final Map<String,String[]> metaData;
		public String output;
		TranslateTask(String fSentence, int sentenceIdx, boolean xml , Map<String,String[]> metaData)
		{
			this.fSentence = fSentence;
			this.sentenceIdx = sentenceIdx;
			this.xml = xml;
			this.metaData = metaData;
		}
		/**
		 * Returs true if it should be added to the output pool
		 */
		public void execute(PhramerIf resource) throws PhramerException
		{
			try
			{
				output = xml ? resource.translateXML(fSentence , sentenceIdx, metaData) : resource.translate(fSentence, sentenceIdx, metaData);
			}
			catch (IOException e)
			{
				throw new PhramerException(e);
			}
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	private static class TranslateNbestTask extends Task<PhramerIf,PhramerException>
	{
		private final String fSentence;
		private final boolean xml;
		private final int nBestSize;
		private final Map<String,String[]> metaData;
		public List<List<HypothesisState>> output;
		
		TranslateNbestTask(String fSentence, int nBestSize , boolean xml , Map<String,String[]> metaData)
		{
			this.fSentence = fSentence;
			this.xml = xml;
			this.nBestSize = nBestSize;
			this.metaData = metaData;
		}
		/**
		 * Returs true if it should be added to the output pool
		 */
		public void execute(PhramerIf resource) throws PhramerException
		{
			try
			{
				output = xml ? resource.translateXMLintoNbest(fSentence, nBestSize , metaData) :  resource.translateIntoNbest(fSentence, nBestSize , metaData);
			}
			catch (IOException e)
			{
				throw new PhramerException(e);
			}
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public String translateXML(String fSentence, int sentenceIdx, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		TranslateTask t = new TranslateTask(fSentence , sentenceIdx , true , metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
	}
	
	public List<List<HypothesisState>> translateXMLintoNbest(String fSentence, int nBestSize, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		TranslateNbestTask t = new TranslateNbestTask(fSentence , nBestSize , true , metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
	}
	
	public List<HypothesisState> align(String fSentence, String eSentence, int sentenceIdx, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		AlignTask t = new AlignTask(fSentence , eSentence , sentenceIdx , false , metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
		
	}
	
	public String translate(String fSentence, int sentenceIdx, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		TranslateTask t = new TranslateTask(fSentence , sentenceIdx , false , metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
	}
	
	public List<List<HypothesisState>> translateIntoNbest(String fSentence, int nBestSize, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		TranslateNbestTask t = new TranslateNbestTask(fSentence , nBestSize , false, metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch(PhramerException e)
		{
			if( e.getCause() instanceof IOException )
				throw (IOException)e.getCause();
			throw e;
		}
		return t.output;
	}
	
	public void rescore(BufferedReader input, PrintStream output) throws PhramerException, IOException
	{
		throw new PhramerException("Rescoring under multi-threading not implemented");
	}
	
}
