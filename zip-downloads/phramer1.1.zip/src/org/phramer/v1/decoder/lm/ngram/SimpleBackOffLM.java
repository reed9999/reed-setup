/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.lm.ngram;
import info.olteanu.utils.chron.*;
import java.io.*;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.processor.*;
import org.phramer.v1.decoder.lm.wordsequence.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.lib.vocabulary.*;

public class SimpleBackOffLM extends BackOffLM
{
	
	// nanochronometerring
//	public static ProfilerChronometer nanoClock = new ProfilerChronometer("SimpleBackOffLM", GenericLMProcessor.nanoClock);
	
	public int getN()
	{
		return n;
	}
	
	private int n;
	private HashMap<WordSequence,Double>[] logProbability;
	private HashMap<WordSequence,Double>[] logBOW;
	private HashSet<String> vocabulary;
	
	public SimpleBackOffLM()
	{}
	
	/** Loads the model from an ARPA file
	 *
	 */
	public void loadArpa(Reader r) throws IOException
	{
		BufferedReader inputFile = new BufferedReader(r);
		String lineFile;
		// scan for \data\
		
		if (!readTill(inputFile, "\\data\\"))
			throw new EOFException("No model found");
		
		// look for ngram counts
        ArrayList<Integer> list = new ArrayList<Integer>();
        while ((lineFile = inputFile.readLine()) != null)
            if (lineFile.startsWith("ngram"))
				list.add(Integer.parseInt(lineFile.substring(lineFile.indexOf('=') + 1)));
			else if (lineFile.equals("\\1-grams:"))
                break;
		
		// prepare data structures
		logProbability = new HashMap[list.size()];
		logBOW = new HashMap[list.size() - 1];
		vocabulary = new HashSet<String>();
		
		// n from n-gram
		n = list.size();
		
		for (int i = 0; i < logProbability.length; i++)
		{
			System.err.println("Loading " + (1 + i) + "-grams");
			
			
			// skip to the next section, if not first
			if (i > 0)
				if (!readTill(inputFile , "\\" + (i + 1) + "-grams:"))
					throw new EOFException("LM file ended too soon");
			
			// create
			logProbability[i] = new HashMap<WordSequence,Double>();
			if (i < logBOW.length)
				logBOW[i] = new HashMap<WordSequence,Double>();
			
			// keep handy pointer
			HashMap<WordSequence,Double> lProbability = logProbability[i];
			HashMap<WordSequence,Double> lBOW = i < logBOW.length ? logBOW[i] : null;
			
			int ngramOrder = i + 1;
			int ngramCount = list.get(i);
			for (int j = 0; j < ngramCount; j++)
			{
				// read
				lineFile = inputFile.readLine();
				StringTokenizer st = new StringTokenizer(lineFile);
				if (st.countTokens() != ngramOrder + 1 && st.countTokens() != ngramOrder + 2)
					throw new IOException("Bad n-gram file: " + lineFile);
				
				double lP10 = Double.parseDouble(st.nextToken());
				String[] str = new String[ngramOrder];
				// reverse order
				for (int k = ngramOrder - 1; k >= 0 ; k--)
					str[k] = st.nextToken().intern();
				
				if (ngramCount == 1)
				// word in vocabulary
					vocabulary.add(str[0]);
				
				
				WordSequence wSeq = new StringWordSequence(false, str, 0, ngramOrder);
				
				if (lP10 == -99)
					lProbability.put(wSeq , Double.NEGATIVE_INFINITY);
				else
					lProbability.put(wSeq , MathTools.log10toLog(lP10));
				
				// has backoff weight?
				double lB10 = 0;
				if (st.hasMoreTokens())
				{
					lB10 = Double.parseDouble(st.nextToken());
					
					if (lB10 == -99)
						lBOW.put(wSeq , Double.NEGATIVE_INFINITY);
					else
						lBOW.put(wSeq , MathTools.log10toLog(lB10));
				}
			}
		}
		if (!readTill(inputFile , "\\end\\"))
			throw new IOException("Bad n-gram file: no end marker found");
		
		// leave file open
	}
	
	public void loadBinary(InputStream is , int type) throws IOException
	{
		DataInputStream input = new DataInputStream(new BufferedInputStream(is));
		// order
		int order = input.readInt();
		n = order;
		System.err.println("Loading binary " + order + "-gram LM...");
		logProbability = new HashMap[order];
		logBOW = new HashMap[order - 1];
		// read vocabulary first
		Vocabulary vocabulary = new Vocabulary();
		vocabulary.loadBinary(input);
		
		for (int i = 0; i < logProbability.length; i++)
		{
			int size = input.readInt();
			logProbability[i] = new HashMap<WordSequence,Double>(size);
			for (int j = 0; j < size; j++)
			{
				long key = input.readLong();
				double value = input.readDouble();
				StringWordSequence keyWS = getWordSequence(i + 1 , vocabulary, key);
				logProbability[i].put(keyWS, value);
			}
		}
		
		for (int i = 0; i < logBOW.length; i++)
		{
			int size = input.readInt();
			logBOW[i] = new HashMap<WordSequence,Double>(size);
			for (int j = 0; j < size; j++)
			{
				long key = input.readLong();
				double value = input.readDouble();
				StringWordSequence keyWS = getWordSequence(i + 1 , vocabulary, key);
				logBOW[i].put(keyWS, value);
			}
		}
	}
	
	
	// should be tested
	private static StringWordSequence getWordSequence(int order, Vocabulary vocabulary, long key)
	{
		String[] words = new String[order];
		for (int i = 0; i < words.length; i++)
		{
			long id = key;
			int q = order;
			for (int j = 1; j <= i; j++, q--)
				id = FastIdWordSequence.farSequence(id , q);
			
			for (; q > 1 ; q--)
				id = FastIdWordSequence.nearSequence(id);
			
			words[i] = vocabulary.get((int)id - SlowIdWordSequence.DELTA);
		}
		return new StringWordSequence(false, words, 0 , order);
	}
	
	public void saveBinary(OutputStream os , int type)// throws IOException
	{
		// TODO
		throw new Error("Not yet implemented");
	}
	
	public static boolean readTill(BufferedReader inputFile, String marker) throws IOException
	{
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
			if (marker.equals(lineFile))
				return true;
		return false;
	}
	
	
	/**
	 * Returns the log probability for a word in a particular context. <br>
	 ** The string is wn, wn-1, wn-2, ...
	 */
//	int cnt = 0;
	public double getLogProbabilityWord(WordSequence sequence)
	{
//		nanoClock.resume();
//		cnt++;
//		if (cnt % 1000 == 0)
//			System.err.print('*');
		
		// trim sequence if it is too long
		if (sequence.length() > n)
			sequence = sequence.trimToSize(n);
		
		try
		{
			return logProbabilityWord(sequence);
		}
		catch (OOVException e)
		{
			return 2;
		}
	}
	private final double logProbabilityWord(final WordSequence sequence)
	throws OOVException
	{
		Double prob = probGram(sequence);
		if (prob != null) // found
			return prob;
		
		// OOV?
		if (sequence.length() == 1)
			throw new OOVException();
		//	return MathTools.LOG_ZERO;
		
		// do backoff
		return logProbabilityWord(sequence.getNearSequence())
			+ backoffCoeficient(sequence.getFarSequence());
	}
	
	private final Double probGram(final WordSequence sequence)
	{
		//Double t =
		return logProbability[sequence.length() - 1].get(sequence);
//		System.out.println( "[probGram] " + sequence.serialize() + " -> " + t );
//		return t;
	}
	private final double backoffCoeficient(final WordSequence sequence)
	{
		Double coef = logBOW[sequence.length() - 1].get(sequence);
		if (coef != null)
		{
			//System.out.println( "[backoffC] " + sequence.serialize() + " -> " + coef );
			return coef;
		}
		//System.out.println( "[backoffC] " + sequence.serialize() + " -> 0" );
		return 0f;
	}
}

