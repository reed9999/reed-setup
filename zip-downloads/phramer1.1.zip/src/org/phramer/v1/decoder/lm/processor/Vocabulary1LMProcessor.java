/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.lm.processor;
import org.phramer.*;
import org.phramer.lib.vocabulary.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.lm.ngram.*;
import org.phramer.v1.decoder.lm.preprocessor.*;
import org.phramer.v1.decoder.lm.wordsequence.*;
import org.phramer.v1.decoder.token.*;

public class Vocabulary1LMProcessor implements LMProcessor
{
	
	
	
	public Vocabulary1LMProcessor(int maxNTokens)
	{
		System.err.println("[Vocabulary1LMProcessor] <init>");
		if (maxNTokens == 0)
			maxNTokens = 256;
		n = 0;
		tokens = new EToken[maxNTokens];
		inputLMv = new int[maxNTokens];
//		inputLM = new String[maxNTokens];
	}
	
	private EToken[] tokens;
	private final int[] inputLMv;
//	private final String[] inputLM;
	
	
	private Vocabulary v;
	private double minProbability;
	private double oovProbability;
	private double weight;
	private NgramLanguageModel lm;
	private LMPreprocessor preproc;
	private int n;
	public void registerLM(LanguageModelIf lm , LMPreprocessor preproc , double weight , double oovProbability , double minProbability) throws PhramerException
	{
		assert n == 0;
		n++;
		this.lm = (NgramLanguageModel)lm;
		assert this.lm.isVocabularyBasedLM();
		this.v = lm.getVocabulary();
		this.preproc = preproc;
		this.weight = weight;
		this.oovProbability = oovProbability;
		this.minProbability = minProbability;
		if (preproc.useSpecialFactorization())
			throw new PhramerException("Vocabulary1LMProcessor doesn't accept special factorization");
	}
	
	public void reconfigure(int index , double weight , double oovProbability , double minProbability)
	{
		// TODO
		throw new Error("TODO");
	}
	
	/** Returns the log probability (weighted) for a new token in the specified context */
	public double getLogProbability(LMContext context , EToken current, Instrument instrument)
	{
		LMLinearContext lContext = (LMLinearContext)context;
		int nTokens =  lContext.countTokens() + 1;
		tokens[0] = current;
		lContext.getTokens(tokens , 1);
		
		double sum = weight * getProbability(nTokens);
		instrument.lmQuery(context, current, sum);
		return sum;
	}
	
	private double getProbability(int nTokens)
	{
//		int k = preproc.process(nTokens , tokens , inputLM);
//		// if vocabulary based language model...
//		if (k != nTokens)
//			throw new Error("Vocabulary based language modeling requires the same number of words");
		assert tokens[0] instanceof TokenWordOnly;
		
		getIds(tokens , nTokens);
		
		long seqID = SlowIdWordSequence.getSequenceID(inputLMv , 0 , nTokens);
		double probability = lm.fastGetLogProbabilityWord(seqID , nTokens);
		assert __assert__match(probability, nTokens) : probability + " " + __assert__getP(nTokens);
		
		if (probability > 0)
			return oovProbability;
		
		if (probability < minProbability)
			probability = minProbability;
		return probability;
	}
	
	private String __assert__getP(int nTokens)
	{
		double p2 = lm.getLogProbabilityWord(new FastIdWordSequence(v , inputLMv , 0 , nTokens));
		return Double.toString(p2);
		
	}
	
	private boolean __assert__match(double p, int nTokens)
	{
		double p2 = lm.getLogProbabilityWord(new FastIdWordSequence(v , inputLMv , 0 , nTokens));
		return p == p2;
	}
	
	private void getIds(EToken[] tokens , int nTokens)
	{
		for (int j = 0; j < nTokens; j++)
		{
			TokenWordOnly tok = (TokenWordOnly)tokens[j];
			int id = tok.vocabularyID;
			if (id == Vocabulary.NOT_SET)
			{
				id = v.get(tok.getWord());
				((TokenWordOnly)tokens[j]).vocabularyID = id;
			}
			inputLMv[j] = id;
		}
	}
	
	/** Returns the log probability (raw) for a new token in the specified context.
	 * <br>
	 * Almost identical with getLogProbability(LMContext context , EToken current, Instrument instrument)
	 **/
	public double[] getLogProbabilityUnWeighted(LMContext context , EToken current, Instrument instrument)
	{
		LMLinearContext lContext = (LMLinearContext)context;
		int nTokens =  lContext.countTokens() + 1;
		tokens[0] = current;
		lContext.getTokens(tokens , 1);
		
		double prob[] = new double[1];
		prob[0] = getProbability(nTokens);
		instrument.lmQuery(context, current, prob[0] * weight);
		return prob;
	}
	
	/** Returns LM score for an individual phrase. A mixture based on weights */
	public double getLogProbability(EToken[] phrase, Instrument instrument)
	{
		// slow version
		instrument.lmQuery(phrase);
		
//		int k = preproc.process(phrase.length , phrase , inputLM);
//		assert k == phrase.length;
		assert phrase[0] instanceof TokenWordOnly : phrase[0];
		getIds(phrase , phrase.length);
		
		double sum = weight * LMTools.getPhraseLogProbability(null , inputLMv , 0 , phrase.length , 0 ,
															  lm ,
															  oovProbability ,
															  minProbability);
		return sum;
	}
	
	/** Returns LM score for an individual phrase. A mixture based on weights */
	public double[] getLogProbabilityUnWeighted(EToken[] phrase, Instrument instrument)
	{
		// slow version
		instrument.lmQuery(phrase);
		
//		int k = preproc.process(phrase.length , phrase , inputLM);
//		assert k == phrase.length;
		assert phrase[0] instanceof TokenWordOnly : phrase[0];
		getIds(phrase , phrase.length);
		
		double[] answer = { LMTools.getPhraseLogProbability(null , inputLMv , 0 , phrase.length , 0 ,
															lm ,
															oovProbability ,
															minProbability)
		};
		return answer;
	}
}
