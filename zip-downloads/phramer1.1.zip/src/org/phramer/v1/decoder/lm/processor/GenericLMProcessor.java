/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.lm.processor;
import info.olteanu.utils.*;
import org.phramer.lib.vocabulary.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.lm.ngram.*;
import org.phramer.v1.decoder.lm.preprocessor.*;
import org.phramer.v1.decoder.lm.wordsequence.*;
import org.phramer.v1.decoder.token.*;
import org.phramer.v1.decoder.loader.*;

/**
 *
 * Non-reentrant object, for speed.
 */
public class GenericLMProcessor implements LMProcessor
{
	// nanochronometerring
//	public static ProfilerChronometer nanoClock = new ProfilerChronometer("LMProcessor" , Phramer.nanoClockDecodeTheStack);
	
	private int n;
	private LanguageModelIf[] lms;
	private LMPreprocessor[] preprocs;
	private boolean[] specialFactorization;
	private double[] weights;
	private double[] oovProbabilities;
	private double[] minProbabilities;
	private EToken[] tokens;
	private LMContext nullContext;
	private final String[] inputLM;
	private final int[] inputLMv;
	private boolean allNGramLMs = true;
	
	public GenericLMProcessor(int maxLM , int maxNTokens , LMContext nullContext)
	{
		if (maxLM == 0)
			maxLM = 256;
		if (maxNTokens == 0)
			maxNTokens = 256;
		n = 0;
		lms = new LanguageModelIf[maxLM];
		preprocs = new LMPreprocessor[maxLM];
		specialFactorization = new boolean[maxLM];
		weights = new double[maxLM];
		oovProbabilities = new double[maxLM];
		minProbabilities = new double[maxLM];
		
		this.nullContext = nullContext;
		
		tokens = new EToken[maxNTokens];
		inputLM = new String[maxNTokens];
		inputLMv = new int[maxNTokens];
	}
	
	// TODO: test
	public void reconfigure(int index , double weight , double oovProbability , double minProbability)
	{
		weights[index] = weight;
		oovProbabilities[index] = oovProbability;
		minProbabilities[index] = minProbability;
	}
	
	public void registerLM(LanguageModelIf lm , LMPreprocessor preproc , double weight , double oovProbability , double minProbability)
	{
		lms[n] = lm;
		preprocs[n] = preproc;
		weights[n] = weight;
		oovProbabilities[n] = oovProbability;
		minProbabilities[n] = minProbability;
		if (!(lm.isNGramLM()))
			allNGramLMs = false;
		specialFactorization[n] = preproc.useSpecialFactorization();
		n++;
	}
	/** Returns the log probability (weighted) for a new token in the specified context */
	public double getLogProbability(LMContext context , EToken current, Instrument instrument)
	{
		if (context instanceof LMLinearContext)
		{
//			nanoClock.resume();
			/* Retrieve all tokens */
			LMLinearContext lContext = (LMLinearContext)context;
			int nTokens =  lContext.countTokens() + 1;
			tokens[0] = current;
			lContext.getTokens(tokens , 1);
			
			double sum = 0;
			for (int i = 0; i < n; i++)
				sum += weights[i] * getProbability(i, nTokens);
//			nanoClock.pause();
			instrument.lmQuery(context, current, sum);
			return sum;
		}
		throw new Error("Non linear language models: not supported");
		// TODO: Non linear language models, if any
	}
	
	/** Returns the log probability (raw) for a new token in the specified context.
	 * <br>
	 * Almost identical with getLogProbability(LMContext context , EToken current, Instrument instrument)
	 **/
	public double[] getLogProbabilityUnWeighted(LMContext context , EToken current, Instrument instrument)
	{
		if (context instanceof LMLinearContext)
		{
//			nanoClock.resume();
			/* Retrieve all tokens */
			LMLinearContext lContext = (LMLinearContext)context;
			int nTokens =  lContext.countTokens() + 1;
			tokens[0] = current;
			lContext.getTokens(tokens , 1);
			double probs[] = new double[n];
			double sum = 0;
			for (int i = 0; i < n; i++)
			{
				probs[i] = getProbability(i, nTokens);
				sum += weights[i] * probs[i];
			}
//			nanoClock.pause();
			instrument.lmQuery(context, current, sum);
			return probs;
		}
		throw new Error("Non linear language models: not supported");
		// TODO: Non linear language models, if any
	}
	
	private double getProbability(int i, int nTokens)
	{
		int k = preprocs[i].process(nTokens , tokens , inputLM);
		assert k == nTokens || !allNGramLMs;
		
		double probability;
		// if vocabulary based language model...
		if (lms[i].isVocabularyBasedLM())
		{
			if (k != nTokens)
				throw new Error("Vocabulary based language modeling requires the same number of words");
			assert tokens[0] instanceof TokenWordOnly;
			Vocabulary v = lms[i].getVocabulary();
			
			getIds(tokens , nTokens, v);
			
			
			probability	= lms[i].getLogProbabilityWord(
				new SlowIdWordSequence(v , false , inputLMv , 0 , k));
		}
		else
		{
			
			probability = lms[i].getLogProbabilityWord(
				new StringWordSequence(false , inputLM , 0 , k));
			
		}
		if (probability > 1)
			return oovProbabilities[i];
		if (probability < minProbabilities[i])
			probability = minProbabilities[i];
		return probability;
	}
	
	private void getIds(EToken[] tokens , int nTokens, Vocabulary v)
	{
		for (int j = 0; j < nTokens; j++)
		{
			int id = ((TokenWordOnly)tokens[j]).vocabularyID;
			if (id == Vocabulary.NOT_SET)
			{
				id = v.get(inputLM[j]);
				((TokenWordOnly)tokens[j]).vocabularyID = id;
			}
			inputLMv[j] = id;
		}
	}
	
	
	/** Returns LM score for an individual phrase. A mixture based on weights */
	public double getLogProbability(EToken[] phrase, Instrument instrument)
	{
		instrument.lmQuery(phrase);
//		nanoClock.resume();
		if (allNGramLMs)
		{
			/* Retrieve all tokens */
			double sum = 0;
			for (int i = 0; i < n; i++)
				if (specialFactorization[i])
				{
					// iterate
					LMContext context = nullContext;
					for (int j = 0; j < phrase.length; j++)
					{
						sum += getLogProbability(context , phrase[j] , instrument);
						context = context.append(phrase[j]);
					}
				}
				else
				{
					// default way: probably faster
					int k = preprocs[i].process(phrase.length , phrase , inputLM);
					assert k == phrase.length;
					
					if (lms[i].isVocabularyBasedLM())
					{
						assert phrase[0] instanceof TokenWordOnly : phrase[0];
						Vocabulary v = lms[i].getVocabulary();
						
						getIds(phrase , phrase.length, v);
					}
					
					
					sum += weights[i] * LMTools.getPhraseLogProbability(inputLM , inputLMv , 0 , k , 0 ,
																		(NgramLanguageModel)lms[i] ,
																		oovProbabilities[i] ,
																		minProbabilities[i]);
				}
//			nanoClock.pause();
			return sum;
		}
		else
			throw new Error("non-n-gram LMs not yet supported");
	}
	
	/** Returns LM score for an individual phrase. A mixture based on weights */
	public double[] getLogProbabilityUnWeighted(EToken[] phrase, Instrument instrument)
	{
		instrument.lmQuery(phrase);
//		nanoClock.resume();
		if (allNGramLMs)
		{
			/* Retrieve all tokens */
			double all[] = new double[n];
			for (int i = 0; i < n; i++)
				if (specialFactorization[i])
				{
					// iterate
					LMContext context = nullContext;
					for (int j = 0; j < phrase.length; j++)
					{
						ArrayTools.add(all ,
									   getLogProbabilityUnWeighted(context , phrase[j] , instrument));
						
						context = context.append(phrase[j]);
					}
				}
				else
				{
					int k = preprocs[i].process(phrase.length , phrase , inputLM);
					assert k == phrase.length;
					
					if (lms[i].isVocabularyBasedLM())
					{
						assert phrase[0] instanceof TokenWordOnly : phrase[0];
						Vocabulary v = lms[i].getVocabulary();
						
						getIds(phrase , phrase.length, v);
					}
					
					
					all[i] = LMTools.getPhraseLogProbability(inputLM , inputLMv , 0 , k , 0 ,
															 (NgramLanguageModel)lms[i] ,
															 oovProbabilities[i] ,
															 minProbabilities[i]);
				}
//			nanoClock.pause();
			return all;
		}
		else
			throw new Error("non-n-gram LMs not yet supported");
	}
}
