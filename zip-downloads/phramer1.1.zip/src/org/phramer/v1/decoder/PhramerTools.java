/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder;
import info.olteanu.utils.*;
import java.lang.reflect.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.token.*;

public class PhramerTools
{
	
	protected static int getCompatibilityLevel(String value)
	{
		if (value.indexOf('.') == -1)
			return Integer.parseInt(value);
		String[] parts = StringTools.tokenize(value, ".");
		StringBuilder sb = new StringBuilder(parts[0]);
		for (int i = 1; i < parts.length; i++)
			sb.append(StringTools.adjustLengthForNumber(parts[i] , 2));
		if (parts.length < 4)
			sb.append("00");
		return Integer.parseInt(sb.toString());
	}
	public static double getWeight(double[] coeficients, TableLine line)
	throws PhramerException
	{
		double p = 0f;
		int n = Math.min(coeficients.length , line.getProbabilitiesCount());
		for (int i = 0; i < n; i++)
			p += line.getLogProbability(i) * coeficients[i];
		return p;
	}
	public static double getWeight(double[] coeficients, double[] probabilities)
	{
		double p = 0;
		int n = Math.min(coeficients.length , probabilities.length);
		for (int i = 0; i < n; i++)
			p += probabilities[i] * coeficients[i];
		return p;
	}
	
	
	
	
	
	public static EToken[] tokenizeIntoEToken(String input, TokenBuilder tokenBuilder)
	{
		StringTokenizer st = new StringTokenizer(input);
		EToken[] k = new EToken[st.countTokens()];
		for (int i = 0; i < k.length; i++)
			k[i] = tokenBuilder.buildEToken(st.nextToken().intern());
		return k;
	}
	public static FToken[] tokenizeIntoFToken(String input , TokenBuilder tokenBuilder)
	{
		StringTokenizer st = new StringTokenizer(input);
		FToken[] k = new FToken[st.countTokens()];
		for (int i = 0; i < k.length; i++)
			k[i] = tokenBuilder.buildFToken(st.nextToken().intern());
		return k;
	}
	
	public static List<HypothesisState> getTranslationPathReversed(HypothesisState state)
	{
		List<HypothesisState> v = new ArrayList<HypothesisState>();
		while (state.nForeignCovered != 0)
		{
			v.add(state);
			state = state.parent;
		}
		return v;
	}
	
	public static EToken[] getTranslation(HypothesisState state)
	{
		List<EToken[]> v = new ArrayList<EToken[]>();
		int nTokens = 0;
		while (state.nForeignCovered != 0)
		{
			v.add(state.phraseUsed.getTranslation());
			nTokens += v.get(v.size() - 1).length;
			state = state.parent;
		}
		EToken[] translation = new EToken[nTokens];
		int idx = 0;
		for (int i = v.size() - 1; i >= 0 ; i--)
		{
			EToken[] q = v.get(i);
			System.arraycopy(q , 0 , translation , idx , q.length);
			idx += q.length;
		}
		
		return translation;
	}
	
	public static String adjustN(String i, int len)
	{
		if (i.length() < len)
			return adjustN("0" + i , len);
		return i;
	}
	
	public static String getDefaultEncodingInput()
	{
		return "ISO-8859-1";
	}
	public static String getDefaultEncodingOutput()
	{
		return "ISO-8859-1";
	}
	
	
	public static String getDefaultEncodingDataFiles()
	{
		return "ISO-8859-1";
	}
	
	
	// compare arrays of EToken
	public static boolean eEquals(EToken[] e1, EToken[] e2)
	{
		if (e1.length != e2.length)
			return false;
		for (int i = 0; i < e1.length; i++)
			if (!e1[i].equals(e2[i]))
				return false;
		return true;
	}
	
	
	
	public static Object instantiateClass(String className , PhramerConfig config , String[] param)
	throws PhramerException
	{
		try
		{
			Object[][] args = new Object[][]
			{
				{config , param},
				{},
			};
			Class[][] types = new Class[][]
			{
				{PhramerConfig.class , String[].class},
				{},
			};
			
			return ClassInstantiationTools.instantiateMultiOptions(className , args , types);
//  Changed to ClassInstantiationTools
//
//			Constructor[] constructors = Class.forName(className).getConstructors();
//
//			if (constructors.length != 1)
//				System.err.println("Warning: class " + className + " has more than one constructor");
//
//
//			if (constructors.length != 1)
//				System.err.println("Searching for (PhramerConfig , String[]) constructor...");
//
//			for (Constructor c : constructors)
//				if (isGoodConstructor(c , config))
//				{
//					if (constructors.length != 1)
//						System.err.println("Constructor (PhramerConfig , String[]) found");
//
//					// else try the (PhramerConfig , String[]) constructor
//					Object[] classArgs = {config,param};
//					return c.newInstance(classArgs);
//				}
//
//
//			if (constructors.length != 1)
//			{
//				System.err.println("Constructor (PhramerConfig , String[]) not found");
//				System.err.println("Searching for () constructor...");
//			}
//
//			for (Constructor c : constructors)
//			// does it have a standard constructor?
//				if (c.getParameterTypes().length == 0)
//				{
//					if (constructors.length != 1)
//						System.err.println("Constructor () found");
//
//					return c.newInstance();
//				}
//			if (constructors.length != 1)
//				System.err.println("Constructor () not found");
//
//			throw new PhramerException("Cannot find appropriate constructor for class " + className);
		}
		catch (ClassNotFoundException e)
		{
			throw new PhramerException(e);
		}
		catch (IllegalArgumentException e)
		{
			throw new PhramerException(e);
		}
		catch (SecurityException e)
		{
			throw new PhramerException(e);
		}
		catch (InvocationTargetException e)
		{
			throw new PhramerException(e);
		}
		catch (InstantiationException e)
		{
			throw new PhramerException(e);
		}
		catch (IllegalAccessException e)
		{
			throw new PhramerException(e);
		}
	}
	
	
//	private static final Class STRING_ARRAY_CLASS = new String[0].getClass();
//	private static boolean isGoodConstructor(Constructor c , PhramerConfig config)
//	{
//		Class[] params = c.getParameterTypes();
//		if (params.length != 2)
//			return false;
//
//		if (!params[0].equals(config.getClass()))
//			return false;
//
//		if (!params[1].equals(STRING_ARRAY_CLASS))
//			return false;
//
//
//		return true;
//	}
	
	
	public static class HypothesisStateTools
	{
		public static int getFirstDifferent(boolean[] a, boolean[] b)
		{
			for (int i = 0; i < a.length; i++)
				if (a[i] != b[i])
					return i;
			throw new Error("BUG");
		}
		
		public static int getLastDifferent(boolean[] a, boolean[] b)
		{
			for (int i = a.length - 1; i >= 0; i--)
				if (a[i] != b[i])
					return i;
			throw new Error("BUG");
		}
		
	}
	
	
	
	public static int getRecommendedThreadCount()
	{
		return Runtime.getRuntime().availableProcessors();
	}
}
