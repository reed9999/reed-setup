/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.instrumentation;
import java.io.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.token.*;

public class VerboseLevel2Instrument extends CascadedVoidInstrument
{
	private final PrintStream o;
	private final PhramerConfig config;
	private int hCreated,hAdded,hPruned,hThreshold,hMerged;
	public VerboseLevel2Instrument(Instrument c , PrintStream outStream , PhramerConfig config)
	{
		super(c);
		this.config = config;
		o = outStream;
		hCreated = 0;
		hAdded = 0;
		hPruned = 0;
		hThreshold = 0;
		hMerged = 0;
	}
	public void config(PhramerConfig config)
	{
		super.config(config);
		
		Tools.dumpConfig(o, config);
	}
	
	
	
	public void hypothesisAdded(HypothesisState hyp, SearchStackIf stack)
	{
		hAdded++;
		super.hypothesisAdded(hyp, stack);
	}
	
	
	public void hypothesisBelowThreshold(HypothesisState hyp, SearchStackIf stack, double logThreshold)
	{
		hThreshold++;
		super.hypothesisBelowThreshold(hyp, stack, logThreshold);
	}
	
	public void hypothesisPruned(HypothesisState hyp, SearchStackIf stack, int stackLimit)
	{
		hPruned++;
		super.hypothesisPruned(hyp, stack, stackLimit);
	}
	
	public void hypothesisMerged(HypothesisState better, HypothesisState worse, SearchStackIf stack)
	{
		hMerged++;
		super.hypothesisMerged(better, worse, stack);
	}
	
	public void hypothesisCreated(final HypothesisState hyp , final double pT , final double pLM , final double pW , final double pD)
	{
		hCreated++;
		super.hypothesisCreated(hyp, pT, pLM, pW, pD);
	}
	
	public void bestFinalHypothesis(final HypothesisState bestHyp)
	{
		super.bestFinalHypothesis(bestHyp);
		
		// HYP: 114 added, 284 discarded below threshold, 0 pruned, 58 merged.
		o.println("HYP: " + hAdded + " added, "
				  + hThreshold + " discarded below threshold, "
				  + hPruned + " pruned, "
				  + hMerged + " merged.");
		// BEST: this is a small house -28.9234
		o.println("BEST: " + TokenTools.getString(PhramerTools.getTranslation(bestHyp)) + " " + Tools.format(bestHyp.getLogProbabilityCurrent()));
	}
	
	
	
	/*
	 
	 reading config from file pharaoh_orig.ini
	 
	 parameter values:
	 align: undefined
	 beam-threshold (b): 0.00001
	 bypass-marked: undefined
	 config (f): pharaoh_orig.ini
	 distortion-limit (dl): undefined
	 dtable-file: undefined
	 lattice (l): undefined
	 lmodel-file: europarl.srilm
	 monotone (m): undefined
	 rescore (r): undefined
	 rescoredir (rd): undefined
	 stack (s): 100
	 trace (t): undefined
	 ttable-file: phrase-table
	 ttable-file-f2n: undefined
	 ttable-file-n2f: undefined
	 ttable-limit: 10
	 ttable-threshold: 0.01
	 verbose (v): 2
	 vocab-file-foreign: undefined
	 vocab-file-native: undefined
	 weight-d (d): 1
	 weight-l (lm): 1
	 weight-marked: 1
	 weight-t (tm): 1
	 weight-td (td): 0
	 weight-w (w): 0
	 read 1 sentences
	 collected 12 translation options
	 HYP: 114 added, 284 discarded below threshold, 0 pruned, 58 merged.
	 BEST: this is a small house -28.9234
	 */
	
	
	
}
