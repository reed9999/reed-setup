/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.instrumentation.performance;

import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import java.io.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.lm.ngram.*;
import org.phramer.v1.decoder.lm.processor.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.cost.*;

public class ExecutionProfiler
{
	public static void initialize()
	{
		assert false;
		ProfilerChronometer.active = true;
		System.out.println("[ExecutionProfiler] Activate profiling");
	}
	
	public static void print(PrintStream out)
	{
		if (out == null)
			out = System.err;
		
		print(out, Phramer.nanoClockTranslate , null);
		print(out, Phramer.nanoClockInitializeFromTranslationTable , Phramer.nanoClockTranslate);
		print(out, PharaohFutureCostCalculator.nanoClockInit , Phramer.nanoClockTranslate);
		print(out, Phramer.nanoClockDecodeTheStack , Phramer.nanoClockTranslate);
//		print(out, GenericLMProcessor.nanoClock , Phramer.nanoClockDecodeTheStack);
//		print(out, VocabularyBackOffLM.nanoClock, GenericLMProcessor.nanoClock);
//		print(out, SimpleBackOffLM.nanoClock, GenericLMProcessor.nanoClock);
//		print(out, SearchStack.nanoClockAdd, Phramer.nanoClockDecodeTheStack);
//		print(out, SearchStack.nanoClockAddX, SearchStack.nanoClockAdd);
//		print(out, SearchStack.nanoClockAddMerge, SearchStack.nanoClockAdd);
//		print(out, SearchStack.nanoClockRemove, SearchStack.nanoClockAddMerge);
//		print(out, HypothesisState.nanoClock, Phramer.nanoClockDecodeTheStack);
//		print(out, HypothesisState.nanoClockCanBeMerged, SearchStack.nanoClockAddMerge);
//
//		print( out, "HypothesisState.<init>" , HypothesisState._cnt__constructor_);
//		print( out, "canBeMerged()" , HypothesisState._cnt_canBeMerged );
//		print( out, "canBeMerged():true" , HypothesisState._cnt_canBeMergedSuccess );
	}
	
	private static void print(PrintStream out, String text , int value)
	{
		out.println("[ExecutionProfiler] " + text + "=" + value );
	}
	private static void print(PrintStream out , ProfilerChronometer chron , ProfilerChronometer chronParent)
	{
		if( chron.isOn() )
			throw new Error( chron.name + " is on");
		if (chron.getParent() != chronParent)
			throw new Error("Invalid linking: " + chron.name);
		out.println("[ExecutionProfiler] " + chron.name + ": " + 0.000000001 * chron.getValue() + " s");
		if (chronParent != null)
			out.println("[ExecutionProfiler] " + chron.name + ": " + StringTools.formatDouble(100.0 * chron.getValue() / chronParent.getValue(), "0.00") + "% of " + chronParent.name);
	}
}
