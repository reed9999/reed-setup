/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.instrumentation;
import java.io.*;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.instrumentation.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.token.*;

public class VerboseLevel3Instrument extends CascadedVoidInstrument
{
	private final PrintStream o;
	private final PhramerConfig config;
	private int hCreated,hAdded,hPruned,hThreshold,hMerged;
	private double minLMcost;
	public VerboseLevel3Instrument(Instrument c , PrintStream outStream , PhramerConfig config)
	{
		super(c);
		this.config = config;
		o = outStream;
		hCreated = 0;
		hAdded = 0;
		hPruned = 0;
		hThreshold = 0;
		hMerged = 0;
		minLMcost = 1;
	}
	
	public void futureCostEstimation(double[][] costs)
	{
		super.futureCostEstimation(costs);
		final int fLen = costs.length;
		for (int i = 0 ; i < fLen ; i++)
			for (int len = 1; i + len - 1 < fLen; len++)
				o.println("future costs from " + i + " to " + (i + len - 1) + " is " + Tools.format(costs[i][len - 1]));
	}
	
//	private HashMap<HypothesisState,Integer> mapHyp = new HashMap<HypothesisState,Integer>();;
//	private int nextHypID = 0;
	
	
	
	public void config(PhramerConfig config)
	{
		super.config(config);
		
		Tools.dumpConfig(o, config);
	}
	
	public void hypothesisAdded(HypothesisState hyp, SearchStackIf stack)
	{
		hAdded++;
		super.hypothesisAdded(hyp, stack);
		//int id = mapHyp.get(hyp);
		if (hyp.parent != null)
		{
			if (stack.getBest() == hyp)
			//new best estimate for this stack
				o.println("new best estimate for this stack");
			
			// merged hypothesis on stack 1, now size 3
			o.println("merged hypothesis on stack " + stack.getStackID() + ", now size " + stack.size());
		}
	}
	
	
	public void hypothesisBelowThreshold(HypothesisState hyp, SearchStackIf stack, double logThreshold)
	{
		hThreshold++;
		super.hypothesisBelowThreshold(hyp, stack, logThreshold);
		
		o.println("[" + hyp.id + "]");
		o.println("estimate below threshold, discarding");
		o.println("********* " +  (stack.getBest().getLogProbabilityTotal() + logThreshold) + " " + hyp.getLogProbabilityTotal() + " " + hyp.parent.getLogProbabilityTotal());
	}
	
	public void hypothesisPruned(HypothesisState hyp, SearchStackIf stack, int stackLimit)
	{
		hPruned++;
		super.hypothesisPruned(hyp, stack, stackLimit);
		// TODO
	}
	
	
	public void hypothesisMerged(HypothesisState better, HypothesisState worse, SearchStackIf stack)
	{
		hMerged++;
		super.hypothesisMerged(better, worse, stack);
		assert better.getLogProbabilityTotal() >= worse.getLogProbabilityTotal();
		if (worse.id > better.id)
			o.println("worse than existing path, discarding");
		else
			o.println("better path, overwriting exisiting hypothesis " + worse.id);
		o.println("hypothesis " + worse.id + " merged into " + better.id);
	}
	
	
	
	
	
	
	
	public void hypothesisCreated(final HypothesisState hyp , final double pT , final double pLM , final double pW , final double pD)
	{
		hCreated++;
		super.hypothesisCreated(hyp, pT, pLM, pW, pD);
		
		int id = hyp.id;
//		int id = nextHypID++;
//		mapHyp.put(hyp , id);
		if (id > 0)
		{
			o.println("creating hypothesis " + id + " from " + hyp.parent.id);
			o.println("\tbase score " + Tools.format(hyp.parent.getLogProbabilityCurrent()));
			o.println("\ttranslation cost " + Tools.format(pT));
			o.println("\tdistortion cost " + Tools.format(pD));
			
			EToken[] x = hyp.phraseUsed.getTranslation();
			LMContext context = hyp.parent.lmContext;
			for (int j = 0; j < x.length; j++)
			{
				double p = config.lmProcessor.getLogProbability(context , x[j], VeryVoidInstrument.VVI);
				o.println("\tlanguage model cost for '" + x[j].serialize() + "' " + Tools.format(p));
				context = context.append(x[j]);
			}
			
			// if all f words are covered, add </s>
			if (hyp.nForeignCovered == hyp.foreignCovered.length)
			{
				double p = config.lmProcessor.getLogProbability(context , config.tokenBuilder.buildEToken(LMConstants.END_OF_SENTENCE), VeryVoidInstrument.VVI);
				o.println("\tadding word </s> " + Tools.format(p));
			}
			
			o.println("\tword penalty " + Tools.format(pW));
			o.println("\tscore " + Tools.format(hyp.getLogProbabilityCurrent()) + " + future cost " + Tools.format(hyp.getLogProbabilityFuture()) + " = " + Tools.format(hyp.getLogProbabilityTotal()));
			
			o.println("\tcoverage: " + hyp.getCoverageString());
			// get partial translation
			o.println("\tpartial translation: " + TokenTools.getString(PhramerTools.getTranslation(hyp)));
		}
	}
	
	public void hypothesisRemoved(HypothesisState hyp, SearchStackIf stack)
	{
		o.println("hypothesis " + hyp.id + " removed from stack " + stack.getStackID() + " (size " + stack.size() + ")");
		o.println("  cost: " + hyp.getLogProbabilityTotal() + " vs. worst cost on stack " + (stack.getWorstHyp() == null ? "[stack empty" : "" + stack.getWorstHyp().getLogProbabilityTotal()));
	}
	
	
	public void bestFinalHypothesis(final HypothesisState bestHyp)
	{
		super.bestFinalHypothesis(bestHyp);
		
		o.println("Minimum LM cost: " + minLMcost);
		
		// HYP: 114 added, 284 discarded below threshold, 0 pruned, 58 merged.
		o.println("HYP: " + hAdded + " added, "
				  + hThreshold + " discarded below threshold, "
				  + hPruned + " pruned, "
				  + hMerged + " merged.");
		
		//  [ 442 => 343 ]
		//  [ 343 => 106 ]
		//  [ 106 => 12 ]
		//  [ 12 => 0 ]
		HypothesisState h = bestHyp;
		while (h.parent != null)
		{
			o.println(" [ " + h.id + " => " + h.parent.id + " ]");
			h = h.parent;
		}
		
		// BEST: this is a small house -28.9234
		o.println("BEST: " + TokenTools.getString(PhramerTools.getTranslation(bestHyp)) + " " + Tools.format(bestHyp.getLogProbabilityCurrent()));
	}
	
	public void stackAfterDecoding(SearchStackIf[] stack)
	{
		super.stackAfterDecoding(stack);
		
		
		o.println("Stack");
		for (int i = 0; i < stack.length; i++)
		{
			if (stack[i].size() > 0)
				o.println(" Stack #" + i + " threshold " + (
						  stack[i].getBest().getLogProbabilityTotal() +
						  config.logBeamThreshold)
						  );
			else
				o.println(" Stack #" + i + " empty");
			Iterator<HypothesisState> iter = stack[i].iterator();
			int k = 1;
			while (iter.hasNext())
			{
				HypothesisState hyp = iter.next();
				o.println("\tposition " + k++ + " id " + hyp.id + " parent " + (hyp.parent != null ? hyp.parent.id : -1));
				o.println("\t  probability: " + hyp.getLogProbabilityTotal());
				o.println("\t  coverage: " + hyp.getCoverageString());
				o.println("\t  translation: " + TokenTools.getString(PhramerTools.getTranslation(hyp)));
			}
		}
	}
	
	public void lmQuery(LMContext context, EToken current, double logProb)
	{
		super.lmQuery(context, current, logProb);
		if (minLMcost > logProb)
			minLMcost = logProb;
	}
	
	
	
	
	
	
	
}
