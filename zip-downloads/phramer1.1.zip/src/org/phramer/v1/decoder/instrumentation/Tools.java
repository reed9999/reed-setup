/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.instrumentation;
import info.olteanu.utils.*;
import java.io.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.math.*;

class Tools
{
	public static String format(double d)
	{
		return StringTools.formatDouble(d , "0.######");
	}
	public static void dumpConfig(PrintStream o , PhramerConfig config)
	{
		o.println("parameter values:");
//		align: undefined
		o.println("\tbeam-threshold (b): " + format(MathTools.logToNumber(config.logBeamThreshold)));
		o.println("\tbypass-marked: " + config.bypassMarked);
//			config (f): pharaoh_orig.ini
		o.println("\tdistortion-limit (dl): " + (config.distortionLimit == 0 ? "no limit" : format(config.distortionLimit)));
//			dtable-file: undefined
//			lattice (l): undefined
//			lmodel-file: europarl.srilm
		o.println("\tmonotone (m): " + config.monotone);
//			rescore (r): undefined
//			rescoredir (rd): undefined
		o.println("\tstack (s): " + config.stack);
		o.println("\ttrace (t): " + config.trace);
//			ttable-file: phrase-table
//			ttable-file-f2n: undefined
//			ttable-file-n2f: undefined
		o.println("\tttable-limit: " + config.tTableLimit);
		o.println("\tttable-threshold: " + format(config.tTableThreshold));
		o.println("\tverbose (v): " + config.verboseLevel);
//			vocab-file-foreign: undefined
//			vocab-file-native: undefined
		o.println("\tweight-d (d): " + format(config.weightD));
		o.print("\tweight-l (lm): ");
		multiPrint(o , config.weightL());
		o.println();
//	weight-marked: 1
		o.print("\tweight-t (tm): ");
		multiPrint(o , config.weightT());
		o.println();
//	weight-td (td): 0
		o.println("\tweight-w (w): " + format(config.weightW));
	}
	
	private static void multiPrint(PrintStream o, double[] k)
	{
		for (int i = 0; i < k.length; i++)
		{
			o.print(format(k[i]));
			o.print(' ');
		}
	}
}
