/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.xml;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.token.*;

public class XmlInputTools
{
	public static PhramerInput getXML(String fSentence , TokenBuilder tokenBuilder, Map<String,String[]> metaData)
	throws IOException, PhramerException
	{
		ArrayList<FToken> v = new ArrayList<FToken>();
		ArrayList<Integer> preTranslationStart = new ArrayList<Integer>();
		ArrayList<Integer> preTranslationLen = new ArrayList<Integer>();
		ArrayList<List<PhraseTranslationVariant>> preTranslationVariants = new ArrayList<List<PhraseTranslationVariant>>();
		
		String in = fSentence.trim();
		while (in.length() > 0)
		{
			int idxTag = in.indexOf('<');
			if (idxTag == -1)
			{
				// what's left is not a XML
				FToken[] k = tokenizeF(XmlTools.xmlUnescape(in) , tokenBuilder);
				for (FToken tok : k)
					v.add(tok);
				break;
			}
			else if (idxTag >= 1)
			{
				String nonXML = XmlTools.xmlUnescape(in.substring(0 , idxTag));
				FToken[] k = tokenizeF(nonXML, tokenBuilder);
				for (FToken tok : k)
					v.add(tok);
				
				in = in.substring(idxTag);
			}
			
			assert in.charAt(0) == '<';
			DecodedTag tag = XmlTools.decodeTag(in.toString() , 0);
			if (!tag.isStart || tag.isEnd)
				throw new IOException("Expected XML start tag");
			
			in = in.substring(tag.tagLength);
			
			// now do non-xml stuff again
			idxTag = in.indexOf('<');
			if (idxTag == -1)
				throw new IOException("XML element not closed: " + tag.tagName);
			if (idxTag == 0)
				throw new IOException("XML element expected to have content");
			
			// decode what's inside the tag...
			int idxStart = v.size();
			
			String nonXML = XmlTools.xmlUnescape(in.substring(0 , idxTag));
			FToken[] k = tokenizeF(nonXML, tokenBuilder);
			for (FToken tok : k)
				v.add(tok);
			
			int idxEnd = v.size();
			in = in.substring(idxTag);
			assert in.charAt(0) == '<';
			
			DecodedTag tag2 = XmlTools.decodeTag(in.toString() , 0);
			if (tag2.isStart || !tag2.isEnd)
				throw new IOException("Expected XML end tag");
			if (!tag.tagName.equals(tag2.tagName))
				throw new IOException("Unmatched tags: <" + tag.tagName + "> and </" + tag2.tagName + ">");
			
			in = in.substring(tag2.tagLength);
			
			
			// put metadata in place
			preTranslationStart.add(idxStart);
			preTranslationLen.add(idxEnd - idxStart);
			
			// Add info in preTranslationVariants
			processXMLtag(tag, preTranslationVariants , tokenBuilder);
		}
		// now build what's required
		boolean[] isPreTranslated = new boolean[v.size()];
		int[] phraseLength = new int[v.size()];
		List<PhraseTranslationVariant>[] prePhraseTranslations = new List[v.size()];
		for (int i = 0; i < preTranslationStart.size(); i++)
		{
			int start = preTranslationStart.get(i);
			int len = preTranslationLen.get(i);
			isPreTranslated[start] = true;
			phraseLength[start] = len;
			prePhraseTranslations[start] = preTranslationVariants.get(i);
		}
		return new PhramerInput(v.toArray(new FToken[v.size()]) , isPreTranslated , phraseLength , prePhraseTranslations, metaData);
	}
	
	private static void processXMLtag(DecodedTag tag, ArrayList<List<PhraseTranslationVariant>> preTranslationVariants , TokenBuilder tokenBuilder) throws NumberFormatException, PhramerException
	{
		String attrEnglish = tag.attributes.get("english");
		String attrProb = tag.attributes.get("prob");
		
		if (attrEnglish == null)
			throw new PhramerException("No 'english' attribute");
		
		String[] e= getE(attrEnglish);
		double[] prob = getProb(attrProb, e.length);
		// now check if the same size
		if (e.length != prob.length)
			throw new PhramerException("'english' and prob attributes have different number of translations");
		
		// build translation variants
		ArrayList<PhraseTranslationVariant> variants = new ArrayList<PhraseTranslationVariant>();
		for (int i = 0; i < e.length; i++)
			variants.add(PhraseTranslationVariant.buildWithoutTranslationTable(tokenizeE(e[i] , tokenBuilder) , MathTools.numberToLog(prob[i])));
		preTranslationVariants.add(variants);
	}
	
	private static double[] getProb(String attrProb, int defaultLen) throws NumberFormatException
	{
		double[] prob;
		if (attrProb == null)
		{
			prob = new double[defaultLen];
			// initialize to 1
			for (int i = 0; i < prob.length; i++)
				prob[i] = 1f;
			
		}
		else
		{
			if (attrProb.indexOf('|') != -1)
			{
				StringTokenizer st = new StringTokenizer(attrProb, "|");
				prob = new double[st.countTokens()];
				for (int i = 0; i < prob.length; i++)
					prob[i] = Double.parseDouble(st.nextToken().trim());
			}
			else
			{
				prob = new double[1];
				prob[0] = Double.parseDouble(attrProb.trim());
			}
		}
		return prob;
	}
	
	private static String[] getE(String attrEnglish)
	{
		String[] e;
		if (attrEnglish.indexOf('|') != -1)
		{
			StringTokenizer st = new StringTokenizer(attrEnglish, "|");
			e = new String[st.countTokens()];
			for (int i = 0; i < e.length; i++)
				e[i] = st.nextToken().trim();
		}
		else
		{
			e = new String[1];
			e[0] = attrEnglish.trim();
		}
		return e;
	}
	
	
	/** Perform simple tokenization of the input. Uses .intern() */
	private static FToken[] tokenizeF(String input, TokenBuilder tokenBuilder)
	{
		return PhramerTools.tokenizeIntoFToken(input, tokenBuilder);
	}
	
	/** Perform simple tokenization of the input. Uses .intern() */
	private static EToken[] tokenizeE(String input, TokenBuilder tokenBuilder)
	{
		return PhramerTools.tokenizeIntoEToken(input, tokenBuilder);
	}
	
}
