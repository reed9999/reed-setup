/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.xml;
import java.io.*;
import java.util.*;
import org.phramer.v1.decoder.xml.*;

// TODO: change to SAX
public class XmlTools
{
	private static final char[] WHITESPACE = " \t\r\n".toCharArray();
	private static final char[] ATTRVAL = "\"'".toCharArray();
	
	private static int scanFor(String input , int idx , char[] variants)
	{
		for (int i = idx; i < input.length(); i++)
			for (int j = 0; j < variants.length; j++)
				if (input.charAt(i) == variants[j])
					return i;
		return -1;
	}
	private static int scanForNeg(String input , int idx , char[] variants)
	{
		k:for (int i = idx; i < input.length(); i++)
		{
			for (int j = 0; j < variants.length; j++)
				if (input.charAt(i) == variants[j])
					continue k;
			
			return i;
		}
		return -1;
	}
	
	public static DecodedTag decodeTag(String input, int idxStart)
	throws IOException
	{
		assert input.charAt(idxStart) == '<';
		DecodedTag tag = new DecodedTag();
		if (input.charAt(idxStart + 1) == '/')
		{
			// end tag
			int k = input.indexOf('>' , idxStart);
			if (k == -1) throw new IOException("Bad XML tag");
			tag.tagName = input.substring(idxStart + 2 , k).trim();
			tag.isStart = false;
			tag.isEnd = true;
			tag.tagLength = k + 1 - idxStart;
			
			return tag;
		}
		// start or start/end tag
		int k = scanFor(input , idxStart , WHITESPACE);
		tag.tagName = input.substring(idxStart + 1 , k);
		tag.attributes = new HashMap<String,String>();
		tag.isStart = true;
		tag.isEnd = false;
		// now scan for attributes
		do
		{
			int q = scanForNeg(input, k , WHITESPACE);
			if (q == -1) throw new IOException("Bad XML tag");
			
			// different endings
			if (input.charAt(q) == '/')
			{
				if (input.charAt(q + 1) != '>')
					throw new IOException("XML tag not closing right");
				
				tag.isEnd = true;
				tag.tagLength = q + 2 - idxStart;
				return tag;
			}
			if (input.charAt(q) == '>')
			{
				tag.tagLength = q + 1 - idxStart;
				return tag;
			}
			
			// attribute
			int posEqAttr = input.indexOf('=' , q + 1);
			if (posEqAttr == -1) throw new IOException("Bad XML tag");
			
			String attrName = input.substring(q , posEqAttr).trim();
			// now look for " or '
			int posStartAttrVal = scanFor(input , posEqAttr + 1 , ATTRVAL);
			if (posStartAttrVal == -1) throw new IOException("Bad XML tag");
			int posEndAttrVal = input.indexOf(input.charAt(posStartAttrVal) , posStartAttrVal + 1);
			if (posEndAttrVal == -1) throw new IOException("Bad XML tag");
			
			// now I have the value
			String attrValue = XmlTools.xmlUnescape(input.substring(posStartAttrVal + 1 , posEndAttrVal));
			
			// push into tag
			tag.addAttribute(attrName , attrValue);
			
			k = posEndAttrVal + 1;
		}
		while(true);
	}
	public static String xmlUnescape(String escaped)
	throws IOException
	{
		if (escaped.indexOf('&') >= 0)
		{
			int idx = 0;
			StringBuilder out = new StringBuilder();
			
			int p = escaped.indexOf('&', idx);
			while (p != -1)
			{
				// throw out what's between idx and p
				if (idx < p)
					out.append(escaped.substring(idx , p));
				// now identify ";"
				int semicolon = escaped.indexOf(';', p);
				if (semicolon == 0 || semicolon == p)
					throw new IOException("Invalid XML escaping");
				// extract escaped stuff
				String escCode = escaped.substring(p + 1 , semicolon);
				if (escCode.equals("gt"))
					out.append('>');
				else if (escCode.equals("lt"))
					out.append('<');
				else if (escCode.equals("amp"))
					out.append('&');
				else if (escCode.equals("quot"))
					out.append('"');
				else if (escCode.equals("apos"))
					out.append('\'');
				// else numeric entities
				
				idx = semicolon + 1;
				p = escaped.indexOf('&', idx);
			}
			
			// put rest
			if (idx < escaped.length())
				out.append(escaped.substring(idx));
			
			return out.toString();
		}
		else
			return escaped;
	}
	
	
	// taken from AXXEL project and modified
	public static String xmlEscape(String unescaped)
	{
		if (unescaped.indexOf('<') >= 0
			|| unescaped.indexOf('>') >= 0
			|| unescaped.indexOf('&') >= 0
			|| unescaped.indexOf('\'') >= 0
			|| unescaped.indexOf('"') >= 0
			)
		{
			
			char[] buffer = unescaped.toCharArray();
			StringBuilder outBuffer = new StringBuilder(buffer.length);
			for (int i = 0; i < buffer.length ; i++)
			{
				switch (buffer[i])
				{
					case '<':
						outBuffer.append("&lt;");
						break;
					case '>':
						outBuffer.append("&gt;");
						break;
					case '&':
						outBuffer.append("&amp;");
						break;
					case '\'':
						outBuffer.append("&apos;");
						break;
					case '"':
						outBuffer.append("&quot;");
						break;
					default:
						outBuffer.append(buffer[i]);
				}
			}
			return outBuffer.toString();
		}
		else
			return unescaped;
	}
}
