/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.rescore;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.context.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.phrase.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.token.*;

public class Rescore
{
	// derived from rescore()
	public static String rescoreNBestItem(PhramerInput input , List<HypothesisState> itemInNbest, PhramerConfig config)
	throws PhramerException
	{
		double[] scoreXnow = config.weightX != null ?
			new double[config.weightX.length ] : null;
		
		int logScoreConstant = 0;
		double tProbability = 0;
		// <keep>
		int logScoreD = 0;
		int logScoreW = 0;
		double logScoreLM[] = new double[ config.weightL().length ];
		double logScoreT[] = new double[ config.weightT().length ];
		double logScoreX[] = config.weightX != null ?
			new double[config.weightX.length ] : null;
		LMContext context = config.helper.getNullContext(config.lmContextLength);
		
		// put <s> if it's not chunk translation
		if (!config.chunk)
			context = context.append(config.tokenBuilder.buildEToken(LMConstants.START_OF_SENTENCE));
		// </keep>
		
		for (int i = itemInNbest.size() - 1 ; i >= 0 ; i--)
		{
			HypothesisState h = itemInNbest.get(i);
			tProbability += h.getLogProbabilityAdded();
			
			logScoreD -= Math.abs(h.getStartPosition() - (h.parent.getEndPosition() + 1));
			logScoreW -= h.phraseUsed.getTranslation().length;
			
			// LM probability
			for (EToken token : h.phraseUsed.getTranslation())
			{
				// add probability
				add(logScoreLM , config.lmProcessor.getLogProbabilityUnWeighted(context , token , config.instrument));
				context = context.append(token);
			}
			
			// translation probability
			TableLine line = h.phraseUsed.translationTableLine;
			if (line == null)
			// non-translation table
			// add cost to constant cost
				logScoreConstant += h.phraseUsed.getLogProbability();
			else
			{
				// from translation table
				assert logScoreT.length == line.getProbabilitiesCount();
				for (int j = 0; j < logScoreT.length; j++)
					logScoreT[j] += line.getLogProbability(j);
			}
			if (logScoreX != null)
			{
				config.customProbability.getProbability(scoreXnow ,
														0 ,
														input ,
														h.parent ,
														h.phraseUsed ,
														h.constraintData ,
														h.getStartPosition() ,
														h.getEndPosition() - h.getStartPosition() + 1);
				assert logScoreX.length == scoreXnow.length;
				for (int j = 0; j < logScoreX.length; j++)
					logScoreX[j] += scoreXnow[j];
			}
		}
		
		
		// <keep>
		// put </s> if it's not chunk translation
		if (!config.chunk)
			add(logScoreLM , config.lmProcessor.getLogProbabilityUnWeighted(context ,
																			config.tokenBuilder.buildEToken(LMConstants.END_OF_SENTENCE), config.instrument));
		
		// now print
		// example: pD: -8, pLM: -72.7319, pTM: -5.79425 -30.6259 -4.43581 -19.2983 11.9988, pWP: -18, reported score: e^-95.2720771503106
		// -146.88736
		return generateLine(config.simpleScoreFiles , config.scoreMask , logScoreD, logScoreLM, logScoreT, logScoreW, logScoreX , logScoreConstant , Double.toString(MathTools.logToNumber(tProbability)));
		// </keep>
	}
	
	public static String rescore(PhramerConfig config, List<RescoreChunk> chunks, String tProbability)
	throws PhramerException
	{
		int logScoreD = 0;
		int logScoreW = 0;
		double logScoreLM[] = new double[ config.weightL().length ];
		double logScoreT[] = new double[ config.weightT().length ];
		double logScoreX[] = config.weightX != null ?
			new double[config.weightX.length ] : null;
		LMContext context = config.helper.getNullContext(config.lmContextLength);
		
		// put <s> if it's not chunk translation
		if (!config.chunk)
			context = context.append(config.tokenBuilder.buildEToken(LMConstants.START_OF_SENTENCE));
		
		for (RescoreChunk chunk : chunks)
		{
			logScoreD -= Math.abs(chunk.dLogProbability);
			logScoreW -= chunk.e.length;
			
			// LM probability
			for (EToken token : chunk.e)
			{
				// add probability
				add(logScoreLM , config.lmProcessor.getLogProbabilityUnWeighted(context , token , config.instrument));
				context = context.append(token);
			}
			
			// translation probability
			Phrase p = PhraseTools.getPhrase(chunk.f , 0 , chunk.f.length - 1 , config.translationTable);
			TableLine translation = config.translationTable.getTranslation(p, chunk.e);
			// add to pre-existing list or create a new list
			if (translation != null)
			// now add the probabilities
				for (int i = 0; i < logScoreT.length; i++)
					logScoreT[i] += translation.getLogProbability(i);
			else
			{
				// default translation
				// probability 1, don't add anything to the log-probability
				// TODO: add to constant
			}
			
			// TODO: pX
			if (logScoreX != null)
				throw new Error("Not implemented (File rescoring doesn't output pX)");
		}
		// put </s> if it's not chunk translation
		if (!config.chunk)
			add(logScoreLM , config.lmProcessor.getLogProbabilityUnWeighted(context ,
																			config.tokenBuilder.buildEToken(LMConstants.END_OF_SENTENCE), config.instrument));
		
		// now print
		// example: pD: -8, pLM: -72.7319, pTM: -5.79425 -30.6259 -4.43581 -19.2983 11.9988, pWP: -18, reported score: e^-95.2720771503106
		// -146.88736
		return generateLine(config.simpleScoreFiles , config.scoreMask , logScoreD, logScoreLM, logScoreT, logScoreW, logScoreX , 0 , tProbability);
	}
	
	private static String generateLine(boolean simple , String[] simpleMask, int logScoreD, double[] logScoreLM, double[] logScoreT, int logScoreW, double[] logScoreX , double logScoreConstant , String tProbability) throws PhramerException
	{
		StringBuilder sb = new StringBuilder();
		if (simple)
			if (simpleMask == null)
			{
				sb.append(logScoreD);
				for (double prob : logScoreLM)
					sb.append(" ").append(adjustNumber(prob));
				for (double prob : logScoreT)
					sb.append(" ").append(adjustNumber(prob));
				sb.append(" ").append(logScoreW);
				if (logScoreX != null)
					for (double prob : logScoreX)
						sb.append(" ").append(adjustNumber(prob));
			}
			else
			{
				for (int i = 0; i < simpleMask.length; i++)
				{
					if (simpleMask[i].equals("d"))
						sb.append(' ').append(logScoreD);
					else if (simpleMask[i].equals("w"))
						sb.append(' ').append(logScoreW);
					else if (simpleMask[i].equals("l"))
						for (double prob : logScoreLM)
							sb.append(' ').append(adjustNumber(prob));
					else if (simpleMask[i].equals("t"))
						for (double prob : logScoreT)
							sb.append(' ').append(adjustNumber(prob));
					else if (simpleMask[i].equals("x"))
						for (double prob : logScoreX)
							sb.append(' ').append(adjustNumber(prob));
					else
						throw new PhramerException("Illegal type");
				}
				return sb.toString().substring(1);
			}
		else
		{
			sb.append("pD:");
			sb.append(" ").append(logScoreD);
			
			sb.append(", pLM:");
			for (double prob : logScoreLM)
				sb.append(" ").append(adjustNumber(prob));
			
			sb.append(", pTM:");
			for (double prob : logScoreT)
				sb.append(" ").append(adjustNumber(prob));
			
			sb.append(", pWP:");
			sb.append(" ").append(logScoreW);
			
			if (logScoreX != null)
			{
				sb.append(", pX:");
				for (double prob : logScoreX)
					sb.append(" ").append(adjustNumber(prob));
			}
			//, reported score: e^-95.2720771503106
			sb.append(", reported score: ");
			sb.append(tProbability);
		}
		return sb.toString();
	}
	
	private static String adjustNumber(double prob)
	{
		String k = Double.toString(prob);
		if (true) return k;
		
		if (k.indexOf('e') != -1 || k.indexOf('E') != -1)
			return k;
		
		if (k.length() < 8)
			return k;
		
		k = k.substring(0 , 8);
		if (k.indexOf('.') >= 0)
			return cutZeros(k);
		return k;
	}
	
	private static String cutZeros(String k)
	{
		if (k.length() < 2)
			return k;
		
		if (k.charAt(k.length() - 1) == '0')
			if (k.charAt(k.length() - 1) == '.')
				return k.substring(0 , k.length() - 2);
			else
				return cutZeros(k.substring(0 , k.length() - 1));
		
		return k;
	}
	
	
	private static void add(double[] a, double[] b)
	{
		assert a.length == b.length;
		for (int i = 0; i < a.length; i++)
			a[i] += b[i];
	}
	public static String parseInput(TokenBuilder tokenBuilder , StringTokenizer st, String lineFile , List<RescoreChunk> chunks) throws PhramerException, NumberFormatException
	{
		String tProbability;
		String token = st.nextToken();
		try
		{
			while (true)
			{
				if (token.equals("T"))
				{
					token = st.nextToken();
					tProbability = token;
					if (st.hasMoreTokens())
						throw new PhramerException("Invalid input for rescoring (data after T):\n" + lineFile);
					break;
				}
				// now expect E ... F ... D x P y
				if (!token.equals("E"))
					throw new PhramerException("Invalid input for rescoring (expected E):\n" + lineFile);
				
				// parse till F
				List<EToken> e = new ArrayList<EToken>();
				StringBuilder eRaw = new StringBuilder();
				token = st.nextToken();
				while (!token.equals("F"))
				{
					e.add(tokenBuilder.buildEToken(token));
					eRaw.append(token).append(' ');
					token = st.nextToken();
				}
				assert token.equals("F");
				
				// parse till D
				List<FToken> f = new ArrayList<FToken>();
				StringBuilder fRaw = new StringBuilder();
				token = st.nextToken();
				while (!token.equals("D"))
				{
					f.add(tokenBuilder.buildFToken(token));
					fRaw.append(token).append(' ');
					token = st.nextToken();
				}
				assert token.equals("D");
				
				// get distorsion
				token = st.nextToken();
				int dLogProbability = Integer.parseInt(token);
				
				// now P x
				token = st.nextToken();
				if (!token.equals("P"))
					throw new PhramerException("Invalid input for rescoring (expected P):\n" + lineFile);
				token = st.nextToken();
				double pProbability = Double.parseDouble(token);
				
				// build object, add to list
				chunks.add(new RescoreChunk(e.toArray(new EToken[e.size()]) , f.toArray(new FToken[f.size()]) , dLogProbability , pProbability , eRaw.toString().trim() , fRaw.toString().trim()));
				
				// go to next
				token = st.nextToken();
			}
		}
		catch ( NumberFormatException e )
		{
			throw new PhramerException("Invalid input for rescoring (invalid number):\n" + lineFile , e);
		}
		catch ( NoSuchElementException e )
		{
			throw new PhramerException("Invalid input for rescoring (premature ending):\n" + lineFile , e);
		}
		return tProbability;
	}
	
}
