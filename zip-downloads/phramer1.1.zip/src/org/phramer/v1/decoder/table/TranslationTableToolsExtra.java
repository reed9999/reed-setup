/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.table;

import info.olteanu.utils.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;
import org.phramer.lib.vocabulary.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.table.wordalignment.*;
import org.phramer.v1.decoder.token.*;
/** Support class for binary translation tables <br><br>
 * The binary TT format:
 * <pre>(A) tt.voce - vocabulary for E
 *   -- text file
 *   -- one line:
 * 		word count
 *   -- desc. sorted by count
 * (B) tt.vocf - vocabulary for F
 *   -- same as .voce
 * (C) tt.data - file that stores serialized entries for F
 *   -- binary file
 *   -- format:
 *      (1) F entry (q times - q determined by the file length)
 *      (1.a) n - number of E phrases paired with F
 *                type: byte8
 *      (1.b) logProbabilityTotal (1..n)
 *                type: float32
 *      (1.c) E phrase (1..n)
 *      (1.c.i)  m (eTokenized.length) - number of tokens in the E phrase
 *                type: byte8
 * 				 If m > 64 then eTokenized.length = m - 64 and the entry is followed by alignment
 *      (1.c.ii) eTokenized[i] (0..m-1) - variable-length value for the
 *             index of the word in the vocabulary file. Indexed from 0
 *                type: unsignedIntVar40 (1 to 5 bytes. Low values - one byte)
 *      (1.d) [optional] alignment entry - variable-length value for the
 *             index of the alignment entry (in the tt.align file). Indexed from 0
 * (D) tt.idx - file that indexes the F phrases
 *   -- binary file
 *   -- format:
 *      (1) F phrase (q times - q determined by the file length)
 *            (same q as for tt.data)
 *      (1.a) Pointer into the tt.data file (position in the file - index from 0)
 *                type: int32
 *      (1.b) n (fTokenized.length) - number of tokens in the F phrase
 *                type: byte8
 *      (1.c) fTokenized[i] (0..n-1) - variable-length value for the
 *             index of the word in the vocabulary file. Indexed from 0
 *                type: unsignedIntVar40 (1 to 5 bytes. Low values - one byte)
 * (E) tt.align - file that stores word alignment data
 *   -- binary file
 *   -- format:
 *      (1) alignment entry
 * 		(1.a) n - number of bytes (one byte)
 *             type: byte8
 *      (1.b) bytes in the alignment entry
 *      (1.b.i) alignmentObject[i] (0..n-1)
 *             type: byte8
 *  -- preferably, entries are sorted descending by frequency (so that (D)(1.d) is minimized in lenght)
 * </pre>
 * When loading a TT, (A), (B) will be read into Vocabulary objects,
 * (C) will be stored in memory directly
 * and (D) will be parsed and mapped into a HashMap.
 *<br><br>
 * The files are already pre-filtered, pre-sorted.
 *
 */
public class TranslationTableToolsExtra
{
	private final static Integer ZERO = new Integer(0);
	
	// reads into ByteArrayHasher
	public static HashMap<ByteArrayHasher, MutableIntPair> readNioIndexB(String fileName, int sizeFile) throws IOException
	{
		HashMap<ByteArrayHasher, MutableIntPair> hash = new HashMap<ByteArrayHasher, MutableIntPair>();
		FileChannel fcIdx = new FileInputStream(fileName).getChannel();
		
		MutableIntPair lastPos = null;
		MappedByteBuffer map = fcIdx.map(FileChannel.MapMode.READ_ONLY , 0 , new File(fileName).length());
		while (map.hasRemaining())
		{
			// read position in Data file
			
			int position = map.getInt();
			// get # of words in f[]
			int n = map.get();
			
			ByteBuffer bb = ByteBuffer.allocate(LanguageConstants.SIZEOF_INT * n);
			for (int i = 0; i < n; i++)
			{
				int idxInVocabulary = NioBuffers.decodeVariableLengthInteger(map);
				bb.putInt(idxInVocabulary);
			}
			if (lastPos != null)
				lastPos.second = position;
			lastPos = new MutableIntPair(position, -1);
			hash.put(new ByteArrayHasher(bb.array()) , lastPos);
		}
		fcIdx.close();
		if (lastPos != null)
			lastPos.second = sizeFile;
		System.err.println("Loaded " + hash.size() + " entries from " + fileName);
		return hash;
	}
	public static TableLine[] extract(byte[] bufB, EToken[] idToEToken , Object[] alignmentIdToAlignmentObject)
	throws IOException
	{
		if (bufB.length == 0)
			return null;
		return extract(ByteBuffer.wrap(bufB) , idToEToken , ZERO , alignmentIdToAlignmentObject);
	}
	
	public static TableLine[] extract(ByteBuffer buf,  EToken[] idToEToken , Integer pos , Object[] alignmentIdToAlignmentObject)
	throws IOException
	{
		if (pos == null)
			return null;
		
		// seek
		buf.position(pos);
		
		// now deserialize
		int n = buf.get();
		//System.err.println("N lines: " + n);
		float[] prob = new float[n];
		for (int i = 0; i < prob.length; i++)
			prob[i] = buf.getFloat();
		
		TableLine[] line = new TableLine[n];
		for (int i = 0; i < line.length; i++)
		{
			int m = buf.get();
			boolean hasAlignment = false;
			if (m > 64)
			{
				hasAlignment = true;
				m -= 64;
			}
			EToken[] e = new EToken[m];
			for (int j = 0; j < e.length; j++)
			{
				int id = NioBuffers.decodeVariableLengthInteger(buf);
				e[j] = idToEToken[id];
			}
			// now build TableLine
			Object alignmentObject = null;
			if (hasAlignment)
			{
				int alignmentID = NioBuffers.decodeVariableLengthInteger(buf);// decode anyway. Even if adding alignment object is not desired
				if (alignmentIdToAlignmentObject != null)
					alignmentObject = alignmentIdToAlignmentObject[alignmentID];
			}
			line[i] = new TableLine(e , null , prob[i] , alignmentObject);
		}
		return line;
	}
	// limitation: 2GB translation tables
	public static HashMap<Object, Integer> readNioIndex(String fileName, FToken[] idToFToken, EFProcessorIf processor , TranslationTable tt)
	throws IOException
	{
		HashMap<Object,Integer> hash = new HashMap<Object, Integer>();
		FileChannel fcIdx = new FileInputStream(fileName).getChannel();
		
		MappedByteBuffer map = fcIdx.map(FileChannel.MapMode.READ_ONLY , 0 , new File(fileName).length());
		while (map.hasRemaining())
		{
			// read position in Data file
			
			int position = map.getInt();
			// get # of words in f[]
			int n = map.get();
			
			FToken[] f = new FToken[n];
			for (int i = 0; i < f.length; i++)
			{
				int idxInVocabulary = NioBuffers.decodeVariableLengthInteger(map);
				f[i] = idToFToken[idxInVocabulary];
			}
			
			hash.put(processor.getKey(f , tt) , position);
		}
		fcIdx.close();
		System.err.println("Loaded " + hash.size() + " entries from " + fileName);
		return hash;
	}
	
	public static int writeNioFiles(String[] f,
									SpecialTableLine[] lines ,
									int posE ,
									FileChannel fcE ,
									FileChannel fcIdx ,
									Vocabulary vF ,
									Vocabulary vE ,
									Map<Object,Integer> alignmentMap)
	throws IOException
	{
		{
			// write F index
			ByteBuffer bbuff = ByteBuffer.allocate(256);
			bbuff.putInt(posE);
			bbuff.put((byte) f.length);
			for (int i = 0; i < f.length; i++)
			{
				int vocID = vF.get(f[i]);
				if (vocID == -1)
					throw new IOException("f word not found in vocabulary: " + f[i] + ". Maybe you need to re-generate the cached vocabulary files (by deleting them and re-running): .voce and .vocf. If the problem persists, please report bug.");
				NioBuffers.encodeVariableLengthInteger(bbuff , vocID);
			}
			bbuff.flip();
			fcIdx.write(bbuff);
		}
		
		{
			// write data container
			ByteBuffer bbuff = ByteBuffer.allocate(1024);
			bbuff.put((byte) lines.length);
			for (int i = 0; i < lines.length; i++)
				bbuff.putFloat((float)lines[i].logProbabilityTotal);
			
			for (int i = 0; i < lines.length; i++)
			{
				if (lines[i].alignment == null)
					bbuff.put((byte)lines[i].e.length);
				else
					bbuff.put((byte)(lines[i].e.length + 64));
				for (int j = 0; j < lines[i].e.length; j++)
				{
					int id = vE.get(lines[i].e[j]);
					
					NioBuffers.encodeVariableLengthInteger(bbuff , id);
				}
				if (lines[i].alignment != null)
				{
					Object alignObject = lines[i].alignment;
					if (!(alignObject instanceof byte[]))
						throw new IOException("writeNioFiles/writeAlignEntry cannot write non- byte[] alignment objects yet");
					NioBuffers.encodeVariableLengthInteger(bbuff , alignmentMap.get(new ByteArrayHasher((byte[])alignObject)));
				}
			}
			bbuff.flip();
			posE += fcE.write(bbuff);
		}
		
		return posE;
	}
	
	public static void writeAlignEntry(OutputStream osAlign, Object alignObject)
	throws IOException
	{
		if (!(alignObject instanceof byte[]))
			throw new IOException("writeNioFiles/writeAlignEntry cannot write non- byte[] alignment objects yet");
		
		byte[] align = (byte[]) alignObject;
		byte[] bbuff = new byte[align.length + 1];
		bbuff[0] = (byte) align.length;
		System.arraycopy(align , 0 , bbuff , 1 , align.length);
		osAlign.write(bbuff);
	}
	
	
	public static void readVocab(String vocabFile , Vocabulary v) throws IOException
	{
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(
														  new FileInputStream(vocabFile)
														  , "UTF-8")
													  );
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
			v.add(StringTools.substringBefore(lineFile , " "));
		inputFile.close();
	}
	
	
//	public static void readAlignEntry(FileChannel fcAlign, Object alignObject)
//	throws IOException
//	{
//		if (!(alignObject instanceof byte[]))
//			throw new IOException("writeAlignEntry cannot write non- byte[] alignment objects yet");
//
//		byte[] align = (byte[]) alignObject;
//		ByteBuffer bbuff = ByteBuffer.allocate(256);
//		bbuff.put((byte) align.length);
//		for (int i = 0; i < align.length; i++)
//			bbuff.put((byte) align[i]);
//		bbuff.flip();
//		fcAlign.write(bbuff);
//	}
	
	
	public static Object[] readAlign(String alignFile) throws IOException
	{
		FileInputStream inputFile = new FileInputStream(alignFile);
		List<Object> a = new ArrayList<Object>();
		while (true)
		{
			int len = inputFile.read();
			if (len == -1)
				break;
			
			byte[] alignObject = new byte[len];
			int readLen = inputFile.read(alignObject);
			if (readLen != len)
				throw new IOException("Alignment file too short");
			
			a.add(alignObject);
		}
		inputFile.close();
		return a.toArray();
	}
	
	
	public static interface LineCollector
	{
		// f: tokenized
		public void collect(String[] f , SpecialTableLine[] lines)
		throws IOException;
	}
	public static class SpecialTableLine
	{
		private SpecialTableLine(String[] e , double logProbabilityTotal , double[] probs , Object alignment)
		{
			this.e = e;
			this.logProbabilityTotal = logProbabilityTotal;
			this.probs = probs;
			this.alignment = alignment;
		}
		public final String[] e;
		public final double logProbabilityTotal;
		public final double[] probs;
		public final Object alignment;
	}
	
	
	public static void parseSortedTextTranslationTable(int wordAlignmentType ,
													   WordAlignmentBuilder wordAlignmentBuilder ,
													   LineCollector collector ,
													   BufferedReader inputFile ,
													   double logTableThreshold ,
													   double[] thresholdWeights ,
													   int tableLimit ,
													   int maxPhraseLength ,
													   boolean doSortAndPruning ,
													   MutableInt size ,
													   MutableInt sizeFinal) throws IOException, NumberFormatException
	{
		System.err.println("Load TT from sorted file...");
		// fast, optimized for sorted files
		String lastF = null , lineFile;
		String lastLine = null;
		ArrayList<TranslationTableTools.UnparsedTableLine> cummulated = new ArrayList<TranslationTableTools.UnparsedTableLine>();
		while ((lineFile = inputFile.readLine()) != null)
		{
			if (lastLine != null)
				if (lastLine.compareTo(lineFile) >= 0)
					throw new IOException("Translation table not sorted: " + lastLine);
			
			size.value++;
			String f = StringTools.substringBefore(lineFile , " ||| ");
			if (!f.equals(lastF))
				commitVectorX(
					wordAlignmentType ,
					wordAlignmentBuilder ,
					collector ,
					cummulated,
					lastF,
					logTableThreshold ,
					thresholdWeights ,
					tableLimit ,
					maxPhraseLength,
					sizeFinal ,
					doSortAndPruning);
			
			double[] logProb = TranslationTableTools.getProbVector(lineFile);
			double logProbabilityTotal = PhramerTools.getWeight(thresholdWeights , logProb);
			// postpone after sort to parse
			if (logProbabilityTotal >= logTableThreshold)
			// add the line to the current ArrayList
				cummulated.add(new TranslationTableTools.UnparsedTableLine(lineFile , logProb , logProbabilityTotal));
			
			lastF = f;
			lastLine = lineFile;
		}
		commitVectorX(
			wordAlignmentType ,
			wordAlignmentBuilder ,
			collector ,
			cummulated,
			lastF,
			logTableThreshold ,
			thresholdWeights ,
			tableLimit ,
			maxPhraseLength,
			sizeFinal ,
			doSortAndPruning);
		inputFile.close();
	}
	
	
	
	
	private static void commitVectorX(
		int wordAlignmentType,
		WordAlignmentBuilder wordAlignmentBuilder,
		LineCollector collector ,
		ArrayList<TranslationTableTools.UnparsedTableLine> cummulated,
		String f,
		double logTableThreshold,
		double[] thresholdWeights,
		int tableLimit,
		int maxPhraseLength ,
		MutableInt sizeFinal,
		boolean doSortAndPruning) throws IOException
	{
		// advantage: don't overparse F
		if (cummulated.size() > 0)
		{
			// get F
			int len = StringTools.countTokens(f);// the right way. Slightly faster: countTokensNormalized
			if (len <= maxPhraseLength)
			{
				String[] fTokenized = StringTools.tokenize(false, f);
				
				SpecialTableLine[] vv;
				if (doSortAndPruning)
				{
					// advantage: parse E only when required
					Collections.sort(cummulated , new TranslationTableTools.UnparsedTableLineComparator());
					// pick at most...
					vv = new SpecialTableLine[Math.min(cummulated.size(), tableLimit)];
					
					for (int i = 0; i < vv.length; i++)
						vv[i] = insertOneFromUnparsedX(wordAlignmentType, wordAlignmentBuilder, cummulated.get(i), sizeFinal);
				}
				else
				{
					vv = new SpecialTableLine[cummulated.size()];
					
					for (int i = 0; i < vv.length; i++)
						vv[i] = insertOneFromUnparsedX(wordAlignmentType, wordAlignmentBuilder, cummulated.get(i), sizeFinal);
				}
				collector.collect(fTokenized, vv);
			}
			cummulated.clear();
		}
	}
	
	private static SpecialTableLine insertOneFromUnparsedX(int wordAlignmentType ,
														   WordAlignmentBuilder wordAlignmentBuilder ,
														   TranslationTableTools.UnparsedTableLine l,
														   MutableInt sizeFinal) throws IOException
	{
		String lineFile = l.rawLineFile;
		lineFile = StringTools.substringAfter(lineFile , " ||| ");
		String e = StringTools.substringBefore(lineFile , " ||| ");
		lineFile = StringTools.substringAfter(lineFile , " ||| ");
		
		Object wordAlignment = null;
		if (lineFile.indexOf(" ||| ") != -1 && wordAlignmentType != WordAlignmentTypes.TYPE_NONE)
		{
			String wa = StringTools.lastSubstringBefore(lineFile , " ||| ");
			wordAlignment = wordAlignmentBuilder.encodeWordAlignment(-1 , -1 , wa , wordAlignmentType);
		}
		sizeFinal.value++;
		
		return new SpecialTableLine(StringTools.tokenize(false, e) ,
									l.logProbabilityTotal ,
									l.logProb ,
									wordAlignment);
	}
	
}
