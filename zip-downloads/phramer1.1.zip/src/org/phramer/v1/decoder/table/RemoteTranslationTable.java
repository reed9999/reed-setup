/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.table;
import info.olteanu.utils.*;
import info.olteanu.utils.remoteservices.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.phrase.*;
import org.phramer.v1.decoder.table.wordalignment.*;
import java.io.*;
import org.phramer.v1.decoder.token.*;

public class RemoteTranslationTable extends TranslationTable
{
	
	private int tableLimit;
	private double logTableThreshold;
	private double[] thresholdWeights;
	private final EFProcessorIf processor;
	private final int wordAlignmentType;
	private final WordAlignmentBuilder wordAlignmentBuilder;
	
	public RemoteTranslationTable(RemoteService service ,
								  int type ,
								  int wordAlignmentType ,
								  WordAlignmentBuilder wordAlignmentBuilder ,
								  EFProcessorIf processor ,
								  int tableLimit ,
								  double tableThreshold ,
								  double[] thresholdWeights)
	{
		server = service;
		
		this.wordAlignmentType = wordAlignmentType;
		this.wordAlignmentBuilder = wordAlignmentBuilder;
		this.tableLimit = tableLimit;
		this.logTableThreshold = MathTools.numberToLog(tableThreshold);
		this.thresholdWeights = thresholdWeights;
		this.processor = processor;
	}
	
	
	private RemoteService server;
	/**
	 * Retrieves all translations for a certain phrase into a list
	 */
	public TableLine[] getAllTranslations(Phrase phrase)
	throws PhramerException
	{
		// determine length of the foreign phrase
		int lenF = -1;
		FToken[] f = phrase.getContent();
		if (f != null)
			lenF = f.length;
		
		
		String key = phrase.getStringKey();
		
//		System.err.print("<[" + key + "]");
//		System.err.flush();
		
		String[] input = new String[1];
		// prepare input
		input[0] = key;
		
		String[] output;
		try
		{
			output = server.service(input);
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
		
//		System.err.print(">");
//		System.err.flush();
		
		
		// don't return empty vector ever
		if (output.length == 0)
			return null;
		
		// generate output
		try
		{
			Vector<TableLine> out = generateTableLines(lenF , output);
			
			// don't return empty vector ever
			if (out.size() == 0)
				return null;
			
			assert out.size() > 0;
			return out.toArray(new TableLine[out.size()]);
		}
		catch (IOException e)
		{
			throw new PhramerException(e);
		}
	}
	
	private Vector<TableLine> generateTableLines(int lenF , String[] output) throws NumberFormatException, IOException
	{
		Vector<TableLine> out = new Vector<TableLine>();
		for (int j = 0; j < output.length; j++)
		{
			String lineFile = output[j];
			
			StringTokenizer st = new StringTokenizer(StringTools.lastSubstringAfter(lineFile , " ||| "));
			double logProb[] = new double[st.countTokens()];
			for (int i = 0; i < logProb.length; i++)
				logProb[i] = MathTools.numberToLog(Double.parseDouble(st.nextToken()));
			
			double logProbabilityTotal = PhramerTools.getWeight(thresholdWeights , logProb);
			if (logProbabilityTotal >= logTableThreshold)
			{
				// code from TranslationTableImplMemory
				String e = StringTools.substringBefore(lineFile , " ||| ");
				EToken[] eTokenized = processor.tokenizeTranslation(e);
				lineFile = StringTools.substringAfter(lineFile , " ||| ");
				// TODO: test alignment object
				Object wordAlignment = null;
				if (lineFile.indexOf(" ||| ") != -1 && wordAlignmentType != WordAlignmentTypes.TYPE_NONE)
				{
					// alignment object
					String wa = StringTools.lastSubstringBefore(lineFile , " ||| ");
					wordAlignment = wordAlignmentBuilder.encodeWordAlignment(lenF , eTokenized.length , wa, wordAlignmentType);
				}
				
				// add to vector if over threshold
				out.add(new TableLine(eTokenized , logProb, logProbabilityTotal, wordAlignment));
			}
		}
		
		Collections.sort(out , new TableLineComparator());
		// prune by size
		if (out.size() > tableLimit)
			out.setSize(tableLimit);
		return out;
	}
	
	public boolean readjustWeights(int tableLimit, double tableThreshold, double[] thresholdWeights)
	{
		this.tableLimit = tableLimit;
		this.logTableThreshold = MathTools.numberToLog(tableThreshold);
		this.thresholdWeights = thresholdWeights;
		return true;
	}
}
