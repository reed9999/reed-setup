/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.table;
import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.util.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.phrase.*;
import org.phramer.v1.decoder.table.wordalignment.*;

public class MemoryTranslationTable extends TranslationTable
{
	private final HashMap<Object,TableLine[]> hash;
	
	public MemoryTranslationTable(InputStream input ,
								  String encodingTextFile ,
								  int type,
								  int wordAlignmentType ,
								  WordAlignmentBuilder wordAlignmentBuilder ,
								  EFProcessorIf processor ,
								  int tableLimit ,
								  int maxPhraseLength ,
								  double tableThreshold ,
								  double[] thresholdWeights ,
								  boolean storeDetailed) throws IOException
	{
		Chronometer c = new Chronometer(true);
		MutableInt size = new MutableInt(0);
		MutableInt sizePruning = new MutableInt(0);
		hash = TranslationTableTools.readTranslationTable(type,
														  wordAlignmentType ,
														  wordAlignmentBuilder ,
														  input,
														  encodingTextFile ,
														  MathTools.numberToLog(tableThreshold),
														  thresholdWeights ,
														  tableLimit ,
														  maxPhraseLength ,
														  processor,
														  this ,
														  storeDetailed ,
														  true ,
														  size ,
														  sizePruning);
		
		//TranslationTableTools.sortAndPrune(hash , tableLimit , false , 0 , sizePruning);
		
		System.err.println("Translation table loaded in " + StringTools.formatDouble(c.getValue() * 0.001 , "0.0#")
						   + " secs. Kept " + sizePruning.value + "/" + size.value + " = " +
						   StringTools.formatDouble(100.0 * sizePruning.value / size.value , "0.0") + "%");
	}
	
	
	public MemoryTranslationTable(HashMap<Object,TableLine[]> hash , int tableLimit , double tableThreshold , double[] thresholdWeights)
	{
		double logTableThreshold = MathTools.numberToLog(tableThreshold);
		
		MutableInt sizePruning = new MutableInt(0);
		this.hash = TranslationTableTools.reweight(hash , thresholdWeights);
		TranslationTableTools.sortAndPruneArray(this.hash , tableLimit , true , logTableThreshold , sizePruning);
	}
	
	
	/** Retrieves all translations for a certain phrase into a list <br>
	 * size() must be greater than 0
	 */
	public TableLine[] getAllTranslations(Phrase phrase)
	{
		return hash.get(phrase.getKey());
	}
	
	
	
	
	public boolean readjustWeights(int tableLimit, double tableThreshold, double[] thresholdWeights)
	{
		// cannot readjust. period.
		// TODO: store old parameters and compare. Return true if identical
		return false;
	}
	
	/** It is reentrant */
	public boolean allowConcurrency()
	{
		return true;
	}
	
}
