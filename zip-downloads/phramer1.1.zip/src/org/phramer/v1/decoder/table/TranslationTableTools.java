/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.table;
import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.util.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.table.wordalignment.*;
import org.phramer.v1.decoder.token.*;
import org.phramer.*;

public class TranslationTableTools
{
	
	public static TableLine search(List<TableLine> translation , EToken[] e)
	{
		if (translation == null)
			return null;
		for (TableLine line : translation)
			if (PhramerTools.eEquals(e , line.getTranslation()))
				return line;
		return null;
	}
	
	public static TableLine search(TableLine[] translation , EToken[] e)
	{
		if (translation == null)
			return null;
		for (TableLine line : translation)
			if (PhramerTools.eEquals(e , line.getTranslation()))
				return line;
		return null;
	}
	
	public static HashMap<Object, TableLine[]> reweight(HashMap<Object, TableLine[]> hash,
														double[] thresholdWeights)
	{
		HashMap<Object, TableLine[]> out = new HashMap<Object, TableLine[]>();
		for (Object key : hash.keySet())
		{
			TableLine[] o = hash.get(key).clone();
			
			for (int i = 0; i < o.length; i++)
				o[i] = o[i].clone(thresholdWeights);
			
			out.put(key , o);
		}
		return out;
	}
	
	static class UnparsedTableLine
	{
		final double[] logProb;
		final String rawLineFile;
		final double logProbabilityTotal;
		UnparsedTableLine(String rawLineFile , double[] logProb , double logProbabilityTotal)
		{
			this.rawLineFile = rawLineFile;
			this.logProb = logProb;
			this.logProbabilityTotal = logProbabilityTotal;
		}
	}
	
	static class UnparsedTableLineComparator implements Comparator<UnparsedTableLine>
	{
		public int compare(UnparsedTableLine t1, UnparsedTableLine t2)
		{
			// t1 - t2
			if (t1.logProbabilityTotal < t2.logProbabilityTotal)
				return 1;
			if (t1.logProbabilityTotal > t2.logProbabilityTotal)
				return -1;
			return 0;
		}
	}
	
	public static HashMap<Object,TableLine[]> readTranslationTable(int type ,
																   int wordAlignmentType,
																   WordAlignmentBuilder wordAlignmentBuilder ,
																   InputStream input ,
																   String encodingFileText,
																   double logTableThreshold ,
																   double[] thresholdWeights ,
																   int tableLimit ,
																   int maxPhraseLength ,
																   EFProcessorIf processor,
																   TranslationTable tt,
																   boolean storeDetailed ,
																   boolean doSortAndPruning ,
																   MutableInt size ,
																   MutableInt sizeFinal)
	throws NumberFormatException, Error, IOException
	{
		size.value = 0;
		boolean isSorted = (type & Constants.FEATURE_SORTED) != 0;
		boolean isBinary = (type & Constants.FEATURE_BINARY) != 0;
		if (!isBinary)
		{
			if (isSorted)
				return readSortedTextTranslationTable(
					wordAlignmentType,
					wordAlignmentBuilder ,
					input ,
					encodingFileText,
					logTableThreshold ,
					thresholdWeights ,
					tableLimit ,
					maxPhraseLength ,
					processor,
					tt,
					storeDetailed ,
					doSortAndPruning ,
					size ,
					sizeFinal
				);
			else
				return readUnsortedTextTranslationTable(
					wordAlignmentType,
					wordAlignmentBuilder ,
					input ,
					encodingFileText,
					logTableThreshold ,
					thresholdWeights ,
					tableLimit ,
					maxPhraseLength ,
					processor,
					tt,
					storeDetailed ,
					doSortAndPruning ,
					size ,
					sizeFinal
				);
		}
		else
		{
			// BINARY
			throw new Error("Not implemented");
		}
		
	}
	
	public static HashMap<Object,TableLine[]> readUnsortedTextTranslationTable(int wordAlignmentType,
																			   WordAlignmentBuilder wordAlignmentBuilder ,
																			   InputStream input ,
																			   String encodingFileText,
																			   double logTableThreshold ,
																			   double[] thresholdWeights ,
																			   int tableLimit ,
																			   int maxPhraseLength ,
																			   EFProcessorIf processor,
																			   TranslationTable tt,
																			   boolean storeDetailed ,
																			   boolean doSortAndPruning ,
																			   MutableInt size ,
																			   MutableInt sizeFinal) throws IOException
	{
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(input, encodingFileText));
		String lineFile;
		
		HashMap<Object,Vector<TableLine>> hash = new HashMap<Object,Vector<TableLine>>();
		// regular
		while ((lineFile = inputFile.readLine()) != null)
		{
			// TODO: prune by maxPhraseLen
			size.value++;
			// break: es ist ||| it is ||| 0.8
			double[] logProb = getProbVector(lineFile);
			double logProbabilityTotal = PhramerTools.getWeight(thresholdWeights , logProb);
			// postpone after sort to parse
			if (logProbabilityTotal >= logTableThreshold)
				insertOne(hash ,
						  lineFile ,
						  wordAlignmentType ,
						  wordAlignmentBuilder ,
						  processor ,
						  tt ,
						  storeDetailed ,
						  logProb ,
						  logProbabilityTotal);
		}
		
		
		inputFile.close();
		if (doSortAndPruning)// don't prune threshold because we just did that few lines of code above
			sortAndPrune(hash , tableLimit , false , 0 , sizeFinal);
		return convert(hash);
	}
	
	public static HashMap<Object,TableLine[]> readSortedTextTranslationTable(int wordAlignmentType,
																			 WordAlignmentBuilder wordAlignmentBuilder ,
																			 InputStream input ,
																			 String encodingFileText,
																			 double logTableThreshold ,
																			 double[] thresholdWeights ,
																			 int tableLimit ,
																			 int maxPhraseLength ,
																			 EFProcessorIf processor,
																			 TranslationTable tt,
																			 boolean storeDetailed ,
																			 boolean doSortAndPruning ,
																			 MutableInt size ,
																			 MutableInt sizeFinal) throws IOException
	{
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(input, encodingFileText));
		
		HashMap<Object,TableLine[]> hash = new HashMap<Object,TableLine[]>();
		System.err.println("Load TT from sorted file...");
		// fast, optimized for sorted files
		String lastF = null , lineFile;
		String lastLine = null;
		ArrayList<UnparsedTableLine> cummulated = new ArrayList<TranslationTableTools.UnparsedTableLine>();
		while ((lineFile = inputFile.readLine()) != null)
		{
			if(lastLine != null)
				if(lastLine.compareTo(lineFile) >= 0)
					throw new IOException("Translation table not sorted: " + lastLine);
			
			size.value++;
			String f = StringTools.substringBefore(lineFile , " ||| ");
			if (!f.equals(lastF))
				commitVector(cummulated,
							 lastF,
							 hash ,
							 logTableThreshold ,
							 thresholdWeights ,
							 tableLimit ,
							 maxPhraseLength,
							 wordAlignmentType ,
							 wordAlignmentBuilder ,
							 processor ,
							 tt ,
							 storeDetailed ,
							 sizeFinal ,
							 doSortAndPruning);
			
			double[] logProb = getProbVector(lineFile);
			double logProbabilityTotal = PhramerTools.getWeight(thresholdWeights , logProb);
			// postpone after sort to parse
			if (logProbabilityTotal >= logTableThreshold)
			// add the line to the current ArrayList
				cummulated.add(new UnparsedTableLine(lineFile , logProb , logProbabilityTotal));
			
			lastF = f;
		}
		commitVector(cummulated,
					 lastF,
					 hash ,
					 logTableThreshold ,
					 thresholdWeights ,
					 tableLimit ,
					 maxPhraseLength,
					 wordAlignmentType ,
					 wordAlignmentBuilder ,
					 processor ,
					 tt ,
					 storeDetailed ,
					 sizeFinal ,
					 doSortAndPruning);
		inputFile.close();
		// done. No further pruning
		return hash;
	}
	
	private static HashMap<Object, TableLine[]> convert(HashMap<Object, Vector<TableLine>> hash)
	{
		HashMap<Object, TableLine[]> out = new HashMap<Object, TableLine[]>();
		for (Object key : hash.keySet())
		{
			out.put(key , toArray(hash.get(key)));
		}
		return out;
	}
	private static TableLine[] toArray(Vector<TableLine> v)
	{
		return v.toArray(new TableLine[v.size()]);
	}
	private static Vector<TableLine> toVector(TableLine[] a)
	{
		Vector<TableLine> v = new Vector<TableLine>(a.length);
		for (int i = 0; i < a.length; i++)
			v.add(a[i]);
		return v;
	}
	
	protected static void sortAndPruneArray(HashMap<Object,TableLine[]> hash ,
											int tableLimit ,
											boolean pruneThreshold ,
											double tableThreshold ,
											MutableInt sizeFinal)
	{
		System.err.println("Sorting and prunning...");
		
		sizeFinal.value = 0;
		Set keys = hash.keySet();
		for (Object key : keys)
		{
			Vector<TableLine> v = toVector(hash.get(key));
			if (pruneThreshold)
				for (int i = v.size() - 1 ; i >= 0 ; i--)
					if (v.get(i).getTotalLogProbability() < tableThreshold)
						v.remove(i);
			
			Collections.sort(v , new TableLineComparator());
			// prune by size
			if (v.size() > tableLimit)
			{
				if (DEBUG)
				{
					System.out.println("TT: Prunning of " + key);
					for (int i = 0; i < v.size(); i++)
						System.err.println("TT:   " + (i >= tableLimit ?"* " : "  ")
										   + _dbg_t(v.get(i).getTranslation()) + " : " + v.get(i).getTotalLogProbability()
										   );
					
				}
				v.setSize(tableLimit);
			}
			// put back
			hash.put(key, toArray(v));
			sizeFinal.value += v.size();
		}
	}
	protected static void sortAndPrune(HashMap<Object,Vector<TableLine>> hash ,
									   int tableLimit ,
									   boolean pruneThreshold ,
									   double tableThreshold ,
									   MutableInt sizeFinal)
	{
		System.err.println("Sorting and prunning...");
		
		sizeFinal.value = 0;
		Set keys = hash.keySet();
		for (Object key : keys)
		{
			Vector<TableLine> v = hash.get(key);
			if (pruneThreshold)
				for (int i = v.size() - 1 ; i >= 0 ; i--)
					if (v.get(i).getTotalLogProbability() < tableThreshold)
						v.remove(i);
			
			Collections.sort(v , new TableLineComparator());
			// prune by size
			if (v.size() > tableLimit)
			{
				if (DEBUG)
				{
					System.out.println("TT: Prunning of " + key);
					for (int i = 0; i < v.size(); i++)
						System.err.println("TT:   " + (i >= tableLimit ?"* " : "  ")
										   + _dbg_t(v.get(i).getTranslation()) + " : " + v.get(i).getTotalLogProbability()
										   );
					
				}
				v.setSize(tableLimit);
			}
			sizeFinal.value += v.size();
		}
	}
	private static void commitVector(ArrayList<TranslationTableTools.UnparsedTableLine> cummulated,
									 String f,
									 HashMap<Object, TableLine[]> hash,
									 double logTableThreshold,
									 double[] thresholdWeights,
									 int tableLimit,
									 int maxPhraseLength ,
									 int wordAlignmentType ,
									 WordAlignmentBuilder wordAlignmentBuilder ,
									 EFProcessorIf processor,
									 TranslationTable tt,
									 boolean storeDetailed,
									 MutableInt sizeFinal,
									 boolean doSortAndPruning) throws IOException
	{
		// advantage: don't overparse F
		if (cummulated.size() > 0)
		{
			int len = StringTools.countTokensNormalized(f);
			if (len <= maxPhraseLength)
			{
				// get F
				Object fKey = processor.getKey(f, tt);
				if (hash.containsKey(fKey))
					throw new IOException("Translation table not sorted: ``" + f + "''; Do not use <sorted:> attribute.");
				
				TableLine[] vv;
				if (doSortAndPruning)
				{
					// advantage: parse E only when required
					Collections.sort(cummulated , new UnparsedTableLineComparator());
					// pick at most...
					vv = new TableLine[Math.min(cummulated.size(), tableLimit)];
					
					for (int i = 0; i < vv.length; i++)
						vv[i] = insertOneFromUnparsed(cummulated.get(i), wordAlignmentType , wordAlignmentBuilder , processor, storeDetailed, sizeFinal);
				}
				else
				{
					vv = new TableLine[cummulated.size()];
					
					for (int i = 0; i < vv.length; i++)
						vv[i] = insertOneFromUnparsed(cummulated.get(i), wordAlignmentType , wordAlignmentBuilder , processor, storeDetailed, sizeFinal);
				}
				hash.put(fKey , vv);
			}
			cummulated.clear();
		}
	}
	
	private static TableLine insertOneFromUnparsed(UnparsedTableLine l,
												   int wordAlignmentType ,
												   WordAlignmentBuilder wordAlignmentBuilder ,
												   EFProcessorIf processor,
												   boolean storeDetailed,
												   MutableInt sizeFinal
												   ) throws IOException
	{
		String lineFile = l.rawLineFile;
		lineFile = StringTools.substringAfter(lineFile , " ||| ");
		String e = StringTools.substringBefore(lineFile , " ||| ");
		lineFile = StringTools.substringAfter(lineFile , " ||| ");
		
		Object wordAlignment = null;
		if (lineFile.indexOf(" ||| ") != -1 && wordAlignmentType != WordAlignmentTypes.TYPE_NONE)
		{
			String wa = StringTools.lastSubstringBefore(lineFile , " ||| ");
			wordAlignment = wordAlignmentBuilder.encodeWordAlignment(-1 , -1 , wa , wordAlignmentType);// TODO: put non-dummy lenF, lenE
		}
		sizeFinal.value++;
		
		return new TableLine(processor.tokenizeTranslation(e) , storeDetailed ?l.logProb: null
							 , l.logProbabilityTotal , wordAlignment);
	}
	private static void insertOne(HashMap<Object,Vector<TableLine>> hash ,
								  String lineFile ,
								  int wordAlignmentType ,
								  WordAlignmentBuilder wordAlignmentBuilder ,
								  EFProcessorIf processor ,
								  TranslationTable tt,
								  boolean storeDetailed ,
								  double[] logProb ,
								  double logProbabilityTotal
								  ) throws IOException
	{
		String f = StringTools.substringBefore(lineFile , " ||| ");
		lineFile = StringTools.substringAfter(lineFile , " ||| ");
		String e = StringTools.substringBefore(lineFile , " ||| ");
		lineFile = StringTools.substringAfter(lineFile , " ||| ");
		Object wordAlignment = null;
		if (lineFile.indexOf(" ||| ") != -1 && wordAlignmentType != WordAlignmentTypes.TYPE_NONE)
		{
			String wa = StringTools.lastSubstringBefore(lineFile , " ||| ");
			wordAlignment = wordAlignmentBuilder.encodeWordAlignment(-1 , -1 , wa , wordAlignmentType);// TODO: put non-dummy lenF, lenE
		}
		
		// insert
		append(hash ,
			   processor.getKey(f, tt),
			   processor.tokenizeTranslation(e) ,
			   storeDetailed ?logProb: null ,// don't store details, if not needed
			   logProbabilityTotal ,
			   wordAlignment);
	}
	static double[] getProbVector(String lineFile) throws NumberFormatException
	{
		StringTokenizer st = new StringTokenizer(StringTools.lastSubstringAfter(lineFile , " ||| "));
		double logProb[] = new double[st.countTokens()];
		for (int i = 0; i < logProb.length; i++)
			logProb[i] = MathTools.numberToLog(Double.parseDouble(st.nextToken()));
		return logProb;
	}
	
	private static void append(HashMap<Object,Vector<TableLine>> hash ,
							   Object fKey,
							   EToken[] eTokenized,
							   double logProb[] ,
							   double totalLogProbability ,
							   Object wordAlignment)
	{
		
		Vector<TableLine> v = hash.get(fKey);
		if (v == null)
		{
			v = new Vector<TableLine>();
			hash.put(fKey, v);
		}
		v.add(new TableLine(eTokenized , logProb, totalLogProbability, wordAlignment));
	}
	
	
	
	
	private static final boolean DEBUG = false;
	private static String _dbg_t(EToken[] e)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < e.length; i++)
		{
			if (i > 0)
				sb.append(' ');
			
			sb.append(e[i].serialize());
		}
		return sb.toString();
	}
}
