/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.decoder.table;
import info.olteanu.utils.lang.*;
import info.olteanu.utils.remoteservices.*;
import info.olteanu.utils.remoteservices.client.*;
import java.io.*;
import java.nio.*;
import org.phramer.*;
import org.phramer.lib.vocabulary.*;
import org.phramer.v1.decoder.phrase.*;
import org.phramer.v1.decoder.token.*;

/** Works with TokenWordOnly */
public class BinaryRemoteTranslationTable extends TranslationTable
{
	private final EToken[] idToEToken;
	private final Vocabulary vF;
	private final BinaryRemoteService brs;
	private final Object[] alignmentIdToAlignmentObject;
	public BinaryRemoteTranslationTable(String fileMask ,
										String remoteURL ,
										String encodingTextFile ,
										TokenBuilder tokenBuilder ,
										boolean readAlignment
										) throws IOException
	{
		brs = new BinaryRemoteConnector(remoteURL , true , true , true);
		// get vocabularies, build EToken[] and FToken[]
		vF = new Vocabulary();
		Vocabulary vE = new Vocabulary();
		TranslationTableToolsExtra.readVocab(fileMask + ".vocf" , vF);
		TranslationTableToolsExtra.readVocab(fileMask + ".voce" , vE);
		vF.lock();
		vE.lock();
		if (readAlignment)
			alignmentIdToAlignmentObject = TranslationTableToolsExtra.readAlign(fileMask + ".align");
		else
			alignmentIdToAlignmentObject = null;
		
		// build the tokens
		idToEToken = new EToken[vE.size()];
		for (int i = 0; i < idToEToken.length; i++)
			idToEToken[i] = tokenBuilder.buildEToken(vE.get(i));
		
	}
	/**
	 * Retrieves all translations for a certain phrase into a list <br>
	 * size() must be greater than 0
	 */
	public TableLine[] getAllTranslations(Phrase phrase) throws PhramerException
	{
		try
		{
			FToken[] f = phrase.getContent();
			if (f == null)
				throw new PhramerException("BinaryRemoteTranslationTable requires a Phrase implementation that returns the content");
			
			if (!(f[0] instanceof TokenWordOnly))
				throw new PhramerException("BinaryRemoteTranslationTable works only with TokenWordOnly");

			// serialize it and send it to the stream
			ByteBuffer buf = ByteBuffer.allocate(LanguageConstants.SIZEOF_INT * f.length);
			for (int i = 0; i < f.length; i++)
				buf.putInt(vF.get(f[i].getWord()));

			return TranslationTableToolsExtra.extract(brs.service(buf.array()), idToEToken , alignmentIdToAlignmentObject);
		}
		catch (IOException e)
		{
			throw new PhramerException(e);
		}
		catch (RemoteException e)
		{
			throw new PhramerException(e);
		}
	}
	
	/**
	 * Readjust the parameters. Returs true if it is possible, false if it is not possible.
	 */
	public boolean readjustWeights(int tableLimit, double tableThreshold, double[] thresholdWeights)
	{
		// TODO: Implement this method
		return false;
	}
	
}
