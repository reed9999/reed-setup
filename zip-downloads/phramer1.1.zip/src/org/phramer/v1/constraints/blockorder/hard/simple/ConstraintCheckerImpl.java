/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.hard.simple;

import org.phramer.v1.constraints.blockorder.*;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.search.*;

// TODO: in-phrase analysis
public class ConstraintCheckerImpl implements ConstraintChecker
{
	protected final boolean useInPhraseAnalysis;
	public ConstraintCheckerImpl(boolean useInPhraseAnalysis)
	{
		this.useInPhraseAnalysis = useInPhraseAnalysis;
	}
	
	private static final int IDX_BLOCK = 0;
	private static final int IDX_ORDER = 1;
	
	
	public int[][] getDescriptorForStartHypothesisState(Object inputConstraintsDescriptor)
	{
		ConstraintObject c = (ConstraintObject) inputConstraintsDescriptor;
		int[][] allOpen = new int[2][];
		allOpen[IDX_BLOCK] = new int[c.bc.length];
		for (int i = 0; i < c.bc.length; i++)
			allOpen[IDX_BLOCK][i] = BlockConstraintsProcessor.States.OPEN;
		allOpen[IDX_ORDER] = new int[c.oc.length];
		for (int i = 0; i < c.oc.length; i++)
			allOpen[IDX_ORDER][i] = OrderConstraintsProcessor.States.OPEN;
		return allOpen;
	}
	
	public int getMinStartWord(Object inputConstraintsDescriptor,
							   Object hypConstraintsDescriptor,
							   HypothesisState hyp)
	{
		return Integer.MAX_VALUE;
	}
	public int getMaxStartWord(Object inputConstraintsDescriptor,
							   Object hypConstraintsDescriptor,
							   HypothesisState hyp)
	{
		if (hypConstraintsDescriptor == null)// in case of soft mode
			return 0;
		
		ConstraintObject c = (ConstraintObject) inputConstraintsDescriptor;
		int[][] constraints = (int[][]) hypConstraintsDescriptor;
		// order constraints
		int maxStartWord = 0;
		int minEmpty = __getMinEmptyWord(hyp.foreignCovered);
		for (int i = 0; i < c.oc.length; i++)
			maxStartWord = Math.max(maxStartWord , __getMaxStartWord(c.oc[i] , constraints[IDX_ORDER][i], hyp.foreignCovered , minEmpty));
		return maxStartWord;
	}
	
	public static int __getMinEmptyWord(boolean[] foreignCovered)
	{
		for (int i = 0; i < foreignCovered.length; i++)
			if (!foreignCovered[i])
				return i;
		return foreignCovered.length;
	}
	
	public static int __getMaxStartWord(OrderConstraint oc, int state, boolean[] foreignCovered , int minEmpty)
	{
		// XXXX.xxx.....
		//     i j  i  j
		//     2 2  1  1
		// Allow: j1
		if (oc.i1 > oc.i2)// inversion constraint
			if (minEmpty >= oc.i2)// no more space for maneuver
			{
				// open or working A
				if (state == OrderConstraintsProcessor.States.OPEN || state == OrderConstraintsProcessor.States.WORKING_A)
					return oc.j1;
			}
		return 0;
	}
	
	
	public int getSoftConstraintsTypesCount()
	{
		return 0;
	}
	
	
	
	public int[][] checkHardConstraints(Object inputConstraintsDescriptor,
										Object hypParentConstraintsDescriptor,
										HypothesisState parent,
										PhraseTranslationVariant line,
										int start,
										int end,
										boolean finished,
										boolean softMode)
	{
		if (hypParentConstraintsDescriptor == null)// in case of soft mode
			return null;
		
		return _checkHardConstraints((ConstraintObject)inputConstraintsDescriptor ,
													   (int[][])hypParentConstraintsDescriptor ,
													   parent.foreignCovered ,
													   line ,
													   useInPhraseAnalysis , // it also can be true (descriptor will be null)
													   start ,
													   end ,
													   finished ,
													   parent);
	}
	public int[][] _checkHardConstraints(final ConstraintObject c,
														   final int[][] hypParentConstraintsDescriptor,
														   final boolean[] foreignCoveredParent,
														   PhraseTranslationVariant line,
														   boolean inPhraseAnalysis ,
														   final int start ,
														   final int end ,
														   final boolean finished ,
														   final Object debugObject)
	{
		boolean inPhraseAnalysisBlock = inPhraseAnalysis && c.inPhraseAnalysisDescriptor != null && c.inPhraseAnalysisDescriptor.descriptorsBlock != null;
		boolean inPhraseAnalysisOrder = inPhraseAnalysis && c.inPhraseAnalysisDescriptor != null && c.inPhraseAnalysisDescriptor.descriptorsOrder != null;
		
		int[][] states = new int[2][];
		states[IDX_BLOCK] = hypParentConstraintsDescriptor[IDX_BLOCK].clone();
		states[IDX_ORDER] = hypParentConstraintsDescriptor[IDX_ORDER].clone();
		// block
		for (int i = 0; i < states[IDX_BLOCK].length; i++)
			if (states[IDX_BLOCK][i] != BlockConstraintsProcessor.States.CLOSED)
			{
				assert states[IDX_BLOCK][i] != BlockConstraintsProcessor.States.BUG;
				assert states[IDX_BLOCK][i] != BlockConstraintsProcessor.States.FAILED;
				
				// Sync with ExpressionCommon
				states[IDX_BLOCK][i] = inPhraseAnalysisBlock && c.inPhraseAnalysisDescriptor.descriptorsBlock[i] != null ?
					BlockConstraintsProcessor.getNextState(states[IDX_BLOCK][i] , c.bc[i] , foreignCoveredParent , line , c.inPhraseAnalysisDescriptor.descriptorsBlock[i] , start, end)
					:
					BlockConstraintsProcessor.getNextState(states[IDX_BLOCK][i] , c.bc[i] , foreignCoveredParent , start, end);
				
				
				DebugTools.debugPrint(states[IDX_BLOCK][i], states , debugObject, start, end, c.bc[i]);
				
				if (states[IDX_BLOCK][i] == BlockConstraintsProcessor.States.FAILED)
					return null;
			}
		// order
		for (int i = 0; i < states[IDX_ORDER].length; i++)
			if (states[IDX_ORDER][i] != OrderConstraintsProcessor.States.CLOSED)
			{
				assert states[IDX_ORDER][i] != OrderConstraintsProcessor.States.BUG;
				assert states[IDX_ORDER][i] != OrderConstraintsProcessor.States.FAILED;
				
				// Sync with ExpressionCommon
				states[IDX_ORDER][i] = inPhraseAnalysisOrder && c.inPhraseAnalysisDescriptor.descriptorsOrder[i] != null ?
					OrderConstraintsProcessor.getNextState(states[IDX_ORDER][i] , c.oc[i] , foreignCoveredParent , line , c.inPhraseAnalysisDescriptor.descriptorsOrder[i] , start, end)
					:
					OrderConstraintsProcessor.getNextState(states[IDX_ORDER][i] , c.oc[i] , foreignCoveredParent , start, end);
				
				DebugTools.debugPrint(states[IDX_ORDER][i], states , debugObject, start, end, c.oc[i]);
				
				if (states[IDX_ORDER][i] == OrderConstraintsProcessor.States.FAILED)
					return null;
			}
		return states;
	}
	
	
	
	
	
	
	
	
	public int getSoftConstraintsPenality(double[] bufferOut,
										  int offset,
										  Object inputConstraintsDescriptor,
										  Object hypParentConstraintsDescriptor,
										  HypothesisState parent ,
										  PhraseTranslationVariant line ,
										  Object currentHypConstraintsDescriptor ,
										  int pos ,
										  int len
										  )
	{
		return 0;
	}
	
	public void reportStack(Object inputConstraintsDescriptor, SearchStackIf stack, boolean start)
	{
	}
	public void reportDecoding(Object inputConstraintsDescriptor, boolean start)
	{
	}
	
	
	/**
	 * If the constraint checker uses only positional information (start and end position)
	 * about the current phrase, then the method should return false.
	 * If the constraint checker requires info from the PhraseTranslationVariant
	 * that is passed to checkHardConstraints and to getSoftConstraintsPenality, then this
	 * method should return true
	 */
	public boolean useInPhraseAnalysis()
	{
		return useInPhraseAnalysis;
	}
	
	
}
