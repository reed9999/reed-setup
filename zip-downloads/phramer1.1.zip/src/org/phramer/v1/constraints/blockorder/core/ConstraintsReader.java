/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.core;

// reads a constraint from a text serialized version
import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import org.phramer.v1.constraints.blockorder.core.*;

public class ConstraintsReader
{
	public static Constraint getConstraint(String serialization) throws IOException
	{
		Constraint c = _getConstraint(serialization);
//		assert c.toString().replace(" " , "").equals(serialization.replace(" " , "")) : serialization + " vs. " + c.toString();
		return c;
	}
	private static Constraint _getConstraint(String s) throws IOException
	{
		// block: (i,j)
		// closed block: [i,j) / (i,j] / [i,j]
		// order: {i1,j1} < {i2,j2}
		// pivot: (|i|)  j,k
		// semipivot: (i|)  j,k
		// reverse semipivot: <i|>  j,k
		// freeze: *i,j*
		
		if (s.startsWith("(") && s.endsWith(")"))
		{
			IntPair p = parsePairX(s);
			return BlockConstraint.get(p.first, p.second);
		}
		if (s.startsWith("*") && s.endsWith("*"))
		{
			IntPair p = parsePairX(s);
			return FreezeConstraint.get(p.first, p.second);
		}
		if (s.startsWith("{") && s.endsWith("}"))
		{
			if (s.indexOf("<") == -1)
				throw new IOException("Unrecognized constraint: " + s);
			IntPair p1 = parsePairX(StringTools.substringBefore(s , "<").trim());
			IntPair p2 = parsePairX(StringTools.substringAfter(s , "<").trim());
			return OrderConstraint.get(p1.first, p1.second , p2.first, p2.second);
		}
		if ((s.startsWith("(") || s.startsWith("[")) && (s.endsWith(")") || s.endsWith("]")))
		{
			IntPair p = parsePairX(s);
			boolean startClose = s.startsWith("[");
			boolean endClose = s.endsWith("]");;
			return ClosedBlockConstraint.get(p.first, p.second , startClose , endClose);
		}
		int posPipe = s.indexOf('|');
		if (posPipe != -1)
		{
			// pivots
			IntPair jk = parsePair(StringTools.lastSubstringAfter(s, " "));
			
			if (s.startsWith("("))
			{
				// pivot/semipivot
				if (s.charAt(1) == '|')
				{
					// pivot
					posPipe = s.indexOf('|', 2);
					int i = Integer.parseInt(s.substring(2, posPipe));
					return PivotConstraint.get(i, jk.first, jk.second);
				}
				else
				{
					// semipivot
					int i = Integer.parseInt(s.substring(1, posPipe));
					return SemiPivotConstraint.get(i, jk.first, jk.second);
				}
			}
			else if (s.startsWith("<"))
			{
				// pivot/semipivot
				if (s.charAt(1) == '|')
				{
					// reverse pivot
					posPipe = s.indexOf('|', 2);
					int i = Integer.parseInt(s.substring(2, posPipe));
					return ReversePivotConstraint.get(i, jk.first, jk.second);
				}
				else
				{
					// reverse semipivot
					int i = Integer.parseInt(s.substring(1, posPipe));
					return ReverseSemiPivotConstraint.get(i, jk.first, jk.second);
				}
			}
			else
				throw new IOException("Unknown constraint type: " + s);
		}
		
		throw new IOException("Unknown constraint type: " + s);
	}
	
	private static IntPair parsePairX(String str)
	{
		return parsePair(str.substring(1, str.length() - 1));
	}
	
	private static IntPair parsePair(String str)
	{
		int posComma = str.indexOf(',');
		if (posComma == -1)
		{
			int value = Integer.parseInt(str);
			return new IntPair(value, value);
		}
		return new IntPair(
			Integer.parseInt(str.substring(0, posComma)) ,
			Integer.parseInt(str.substring(posComma + 1)));
	}
}
