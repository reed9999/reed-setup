/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.expression.constraints;
import java.io.*;
import java.util.*;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.constraints.blockorder.expression.*;
import info.olteanu.utils.lang.*;

public class ConstraintsExpressionReader
{
	
	private static final String[] OR = { " or " , "(" , ")" };
	private static final String[] AND = { " and " , "(" , ")" };
	public static NodeX getExpression(String serialization , PrimitiveConstraintsContainer container , int n , boolean inPhraseAnalysis)
	throws IOException
	{
		serialization = serialization.trim();
		
		// check or
		{
			Vector<String> pieces = new Vector<String>();
			int k = 0;
			IntPair pos = null;
			do
			{
				pos = getNext(OR  , serialization , k);
				if (pos != null)
				{
					pieces.add(serialization.substring(k , pos.first));
					k = pos.second + 1;
				}
			}
			while(pos != null);
			if (pieces.size() > 0)
			{
				pieces.add(serialization.substring(k));
				NodeX[] children = new NodeX[pieces.size()];
				for (int i = 0; i < children.length; i++)
					children[i] = getExpression(pieces.get(i) , container , n , inPhraseAnalysis);
				return new OrNodeX(children);
			}
		}
		
		// check and
		{
			Vector<String> pieces = new Vector<String>();
			int k = 0;
			IntPair pos = null;
			do
			{
				pos = getNext(AND  , serialization , k);
				if (pos != null)
				{
					pieces.add(serialization.substring(k , pos.first));
					k = pos.second + 1;
				}
			}
			while(pos != null);
			if (pieces.size() > 0)
			{
				pieces.add(serialization.substring(k));
				NodeX[] children = new NodeX[pieces.size()];
				for (int i = 0; i < children.length; i++)
					children[i] = getExpression(pieces.get(i) , container , n , inPhraseAnalysis);
				return new AndNodeX(children);
			}
		}
		
		// check negation
		if (serialization.startsWith("~"))
			return new NotNodeX(
				getExpression(serialization.substring(1) , container , n , inPhraseAnalysis)
			);
		
		// if it is with paranthesis, do what's inside
		if (serialization.startsWith("(") && serialization.endsWith(")"))
			return getExpression(serialization.substring(1, serialization.length() - 1) , container , n , inPhraseAnalysis);
		
		if (serialization.startsWith("/") && serialization.endsWith("/"))
		{
			// terminal
			return new ConstraintNodeX(ConstraintsReader.getConstraint(serialization.substring(1, serialization.length() - 1))
									   , container
									   , n
									   , inPhraseAnalysis);
		}
		
		throw new IOException("I don't know how to parse " + serialization);
	}
	
	private static IntPair getNext(String[] what, String serialization, int k)
	{
		int nestingLevel = 0;
		do
		{
			IntPair q = identify(serialization, k, what);
			if (q == null)
				return null;
			
			if (q.second == 0 && nestingLevel == 0)
				return new IntPair(q.first , q.first + what[q.second].length() - 1);
			
			if (q.second == 1)
				nestingLevel++;
			
			if (q.second == 2)
				nestingLevel--;
			
			k = q.first + 1;
		}
		while(true);
	}
	private static IntPair identify(String serialization , int k , String[] what)
	{
		int pos = Integer.MAX_VALUE;
		int type = -1;
		for (int i = 0; i < what.length; i++)
		{
			int q = serialization.indexOf(what[i] , k);
			if (q != -1)
				if (q < pos)
				{
					pos = q;
					type = i;
				}
		}
		if (pos != Integer.MAX_VALUE)
			return new IntPair(pos , type);
		
		return null;
	}
}
