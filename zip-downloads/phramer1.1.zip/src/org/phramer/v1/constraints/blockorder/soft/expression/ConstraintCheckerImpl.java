/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.soft.expression;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.constraints.blockorder.expression.execution.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.search.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.constraints.blockorder.*;
import org.phramer.v1.constraints.blockorder.expression.*;

public class ConstraintCheckerImpl implements ConstraintChecker
{
	private final int nFeatures;
	protected final boolean useInPhraseAnalysis;
	public ConstraintCheckerImpl(boolean useInPhraseAnalysis , int nFeatures)
	{
		this.useInPhraseAnalysis = useInPhraseAnalysis;
		this.nFeatures = nFeatures;
	}
	
	public ConstraintObjectOnNode getDescriptorForStartHypothesisState(Object inputConstraintsDescriptor)
	{
		ConstraintObject c = (ConstraintObject) inputConstraintsDescriptor;
		ConstraintObjectOnNode ret = new ConstraintObjectOnNode();
		
		ret.bcState = new int[c.bc.length];
		for (int i = 0; i < c.bc.length; i++)
			ret.bcState[i] = BlockConstraintsProcessor.States.OPEN;
		ret.ocState = new int[c.oc.length];
		for (int i = 0; i < c.oc.length; i++)
			ret.ocState[i] = OrderConstraintsProcessor.States.OPEN;
		
		ret.variables = new int[c.varLength];
		for (int i = 0; i < ret.variables.length; i++)
			ret.variables[i] = Node.Values.UNKNOWN;
		
		ret.expressions = new int[c.expressions.length];
		for (int i = 0; i < ret.expressions.length; i++)
			ret.expressions[i] = Node.Values.UNKNOWN;
		
		
		return ret;
	}
	public int getMinStartWord(Object inputConstraintsDescriptor,
							   Object hypConstraintsDescriptor,
							   HypothesisState hyp)
	{
		return Integer.MAX_VALUE;
	}
	public int getMaxStartWord(Object inputConstraintsDescriptor,
							   Object hypConstraintsDescriptor,
							   HypothesisState hyp)
	{
		// soft constraints don't require it
		return 0;
	}
	public int getSoftConstraintsTypesCount()
	{
		return nFeatures;
	}
	
	public ConstraintObjectOnNode checkHardConstraints(Object inputConstraintsDescriptor,
													   Object hypParentConstraintsDescriptor,
													   HypothesisState parent,
													   PhraseTranslationVariant line,
													   int start ,
													   int end ,
													   boolean finished ,
													   boolean softMode)
	{
		return _checkHardConstraints((ConstraintObject)inputConstraintsDescriptor ,
									 (ConstraintObjectOnNode)hypParentConstraintsDescriptor ,
									 parent.foreignCovered ,
									 line ,
									 useInPhraseAnalysis , // it also can be true (descriptor will be null)
									 start ,
									 end ,
									 finished ,
									 parent);
	}
	private ConstraintObjectOnNode _checkHardConstraints(final ConstraintObject c,
														 final ConstraintObjectOnNode hypParentConstraintsDescriptor,
														 final boolean[] foreignCoveredParent,
														 final PhraseTranslationVariant line,
														 final boolean inPhraseAnalysis ,
														 final int start ,
														 final int end ,
														 final boolean finished ,
														 final Object debugObject)
	{
		ConstraintObjectOnNode out = hypParentConstraintsDescriptor.getSuccessor();
		boolean change = ExpressionCommon.processSuccessor(out, c, foreignCoveredParent, line , inPhraseAnalysis , start, end, debugObject);
		
		// check what happened
		if (change)
		// reevaluate the expressions
			for (int i = 0; i < out.expressions.length;i++)
				out.expressions[i] = c.expressions[i].getValue(out.variables);
		
		return out;
	}
	
	
	public int getSoftConstraintsPenality(double[] bufferOut,
										  int offset,
										  Object inputConstraintsDescriptor,
										  Object hypParentConstraintsDescriptor,
										  HypothesisState parent ,
										  PhraseTranslationVariant line ,
										  Object currentHypConstraintsDescriptor ,
										  int pos ,
										  int len
										  )
	{
		// cleanup
		int n = getSoftConstraintsTypesCount();
		for (int i = 0; i < n; i++)
			bufferOut[i + offset] = 0;
		
		if (hypParentConstraintsDescriptor == null)
		{
			System.err.println("Return no constraints");
			return n;
		}
		if (currentHypConstraintsDescriptor == null)
		{
			System.err.println("Rebuild constraint");
			currentHypConstraintsDescriptor = checkHardConstraints(inputConstraintsDescriptor , hypParentConstraintsDescriptor , parent , line , pos , pos + len - 1 , false , true);// TODO: add finished; check if softMode is correct
		}
		ConstraintObject c = (ConstraintObject)inputConstraintsDescriptor;
		ConstraintObjectOnNode prev = (ConstraintObjectOnNode)hypParentConstraintsDescriptor;
		ConstraintObjectOnNode now = (ConstraintObjectOnNode)currentHypConstraintsDescriptor;
//		System.err.println( prev + " " + now );
		for (int i = 0; i < prev.expressions.length; i++)
		{
			assert prev.expressions[i] == Node.Values.UNKNOWN || now.expressions[i] == prev.expressions[i];
			
			if (prev.expressions[i] == Node.Values.UNKNOWN && now.expressions[i] == Node.Values.FALSE)
			{
//				System.err.println("Constraint of type " + c.expression2feature[i] + " failed. Index: " + (offset + c.expression2feature[i]) + " cost: " + c.expressionCost[i]);
				bufferOut[offset + c.expression2feature[i]] += c.expressionCost[i];
			}
		}
		return n;
	}
	
	public void reportStack(Object inputConstraintsDescriptor, SearchStackIf stack, boolean start)
	{
	}
	public void reportDecoding(Object inputConstraintsDescriptor, boolean start)
	{
	}
	
	
	/**
	 * If the constraint checker uses only positional information (start and end position)
	 * about the current phrase, then the method should return false.
	 * If the constraint checker requires info from the PhraseTranslationVariant
	 * that is passed to checkHardConstraints and to getSoftConstraintsPenality, then this
	 * method should return true
	 */
	public boolean useInPhraseAnalysis()
	{
		return useInPhraseAnalysis;
	}
}
