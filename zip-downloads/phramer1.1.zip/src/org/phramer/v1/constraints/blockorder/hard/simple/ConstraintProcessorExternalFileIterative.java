/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.hard.simple;

import info.olteanu.utils.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.constraints.blockorder.hard.simple.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.extensionifs.*;
import org.phramer.v1.decoder.table.wordalignment.*;

// Loads constraints from an external file
// one line of constraints per one line of input
// ; - separated
// first item; length in tokens
// next items: serialized constraints
public class ConstraintProcessorExternalFileIterative
extends ConstraintCheckerImpl
implements ConstraintProcessor
{
	private final WordAlignmentBuilder wordAlignmentBuilder;
	private final BufferedReader inputFile[];
	public ConstraintProcessorExternalFileIterative(PhramerConfig config , String param[])
	throws PhramerException, FileNotFoundException
	{
		super(config.useWordAlignment);
		this.wordAlignmentBuilder = config.wordAlignmentBuilder;
		
		System.err.println("[org.phramer.v1.constraints.blockorder.hard.simple.ConstraintProcessorExternalFileIterative]");
		if (param == null || param.length < 1)
			throw new PhramerException("ConstraintProcessorExternalFileIterative requires at least one parameter: the names of the files that defines constraints. Got: "  + (param == null ? 0 : param.length));
		
		inputFile = new BufferedReader[param.length];
		for (int i = 0; i < inputFile.length; i++)
			inputFile[i] = new BufferedReader(new InputStreamReader(new FileInputStream(param[0])));
	}
	
	/**
	 * Creates a constraint to be attached to the PhramerInput object
	 */
	public Object createGlobalDescriptor(PhramerInput input , PhraseTranslationVariant[][][] translationVariants , int sentenceIdx) throws PhramerException
	{
		try
		{
			Vector<Constraint> c = new Vector<Constraint>();
			int globalN = -1;
			
			for (int q = 0; q < inputFile.length; q++)
			{
				String lineFile = inputFile[q].readLine();
				String[] line = StringTools.tokenize(lineFile, ";");
				int n = Integer.parseInt(line[0].trim());
				if (globalN == -1)
					globalN = n;
				else if (globalN != n)
					throw new PhramerException("Incompatible files - different size of the sentence");
				
				if (n != input.getFWords().length)
					throw new PhramerException("Constraint info doesn't match foreign input (are you running it multithreaded?): " + n + " vs. " + input.getFWords().length);
				
				for (int i = 1; i < line.length; i++)
					c.add(ConstraintsReader.getConstraint(line[i].trim()));
			}
			
			
			ConstraintObject bco = new ConstraintObject(globalN);
			bco.setConstraints(c.toArray(new Constraint[c.size()]), useInPhraseAnalysis);
			bco.setTranslationVariants(translationVariants , wordAlignmentBuilder , useInPhraseAnalysis);
			return bco;
		}
		catch (IOException e)
		{
			throw new PhramerException(e);
		}
	}
	
}
