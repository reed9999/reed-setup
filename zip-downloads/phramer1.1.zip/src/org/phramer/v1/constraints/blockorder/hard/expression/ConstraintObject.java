/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.hard.expression;
import org.phramer.v1.constraints.blockorder.expression.constraints.*;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.constraints.blockorder.core.inphrase.*;
import org.phramer.v1.constraints.blockorder.expression.execution.*;
import org.phramer.v1.constraints.blockorder.expression.*;
import org.phramer.v1.decoder.PhraseTranslationVariant;
import java.util.*;
import java.io.*;
import org.phramer.v1.decoder.table.wordalignment.*;

public class ConstraintObject
{
	// n: len of the sentence
	public ConstraintObject(int n)
	{
		this.n = n;
		this.bc = null;
		this.oc = null;
		this.inPhraseAnalysisDescriptor = null;
	}
	public final int n;
	public BlockConstraint[] bc;
	public OrderConstraint[] oc;
	public boolean[] forMaxStartWord;
	public InPhraseAnalysisDescriptor inPhraseAnalysisDescriptor;
	public int[] mappingBc;
	public int[] mappingOc;
	public Node[] expressions;
	public int varLength;
	public void setConstraints(NodeX[] expressions ,  PrimitiveConstraintsContainer container , boolean inPhraseAnalysis)
	{
		Set<BlockConstraint> bcs = container.getBlockConstraints().keySet();
		Set<OrderConstraint> ocs = container.getOrderConstraints().keySet();
		bc = bcs.toArray(new BlockConstraint[bcs.size()]);
		oc = ocs.toArray(new OrderConstraint[ocs.size()]);
		mappingBc = new int[bc.length];
		for (int i = 0; i < bc.length; i++)
			mappingBc[i] = container.getIndex(bc[i]);
		mappingOc = new int[oc.length];
		for (int i = 0; i < oc.length; i++)
			mappingOc[i] = container.getIndex(oc[i]);
		
		this.expressions = new Node[expressions.length];
		for (int i = 0; i < expressions.length; i++)
			this.expressions[i] = expressions[i].getNode();
		
		forMaxStartWord = new boolean[oc.length];
		HashSet<Integer> required = new HashSet<Integer>();
		for (int i = 0; i < expressions.length; i++)
			this.expressions[i].getRequiredConstraints(required);
		for (int i = 0; i < forMaxStartWord.length; i++)
			forMaxStartWord[i] = required.contains(mappingOc[i]);
		
		varLength = container.getSize();
	}
	public void setConstraints(String[] expressions , boolean inPhraseAnalysis) throws IOException
	{
		NodeX[] e = new NodeX[expressions.length];
		PrimitiveConstraintsContainer container = new PrimitiveConstraintsContainer();
		for (int i = 0; i < e.length; i++)
			e[i] = ConstraintsExpressionReader.getExpression(expressions[i] , container , n , inPhraseAnalysis);
		setConstraints(e , container , inPhraseAnalysis);
	}
	public void setTranslationVariants(PhraseTranslationVariant[][][] phraseTableVariants , WordAlignmentBuilder wordAlignmentBuilder , boolean inPhraseAnalysis)
	{
		if (inPhraseAnalysis)
			inPhraseAnalysisDescriptor = InPhraseAnalysisTools.getDescriptor(phraseTableVariants , wordAlignmentBuilder , bc , oc);
	}
}
