/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.core;

// {fi1..j1} < {fi2..j2}
import org.phramer.v1.constraints.blockorder.core.*;

public class OrderConstraint extends PrimitiveConstraint
{
	public static Constraint get(int i1 , int j1 , int i2 , int j2)
	{
		return new OrderConstraint(i1, j1, i2, j2);
	}
	public static OrderConstraint instantiate(int i1 , int j1 , int i2 , int j2)
	{
		return new OrderConstraint(i1, j1, i2, j2);
	}
	
	private OrderConstraint(int i1 , int j1 , int i2 , int j2)
	{
		assert i1 <= j1 : "Intervals should be non-negative: {" + i1 + "," + j1 + "}";
		assert i2 <= j2 : "Intervals should be non-negative: {" + i2 + "," + j2 + "}";
		assert j1 < i2 || j2 < i1 : "Intervals should be non-overlapping: {" + i1 + "," + j1 + "} < {" + i2 + "," + j2 + "}";// not overlapping
		this.i1 = i1;
		this.i2 = i2;
		this.j1 = j1;
		this.j2 = j2;
	}
	public final int i1,j1;
	public final int i2,j2;
	
	public String toString()
	{
		// {i1,j1} < {i2,j2}
		return "{" + ConstraintTools.serializePair(i1, j1) + "} < {" + ConstraintTools.serializePair(i2, j2) + "}";
	}
	
	
	public boolean isTrivial(int n , boolean inPhraseAnalysis)
	{
		// never trivial
		return false;
	}
	
	public int hashCode()
	{
		return i1 << 2 + j1 << 10 + i2 << 19 + j2 << 26 + 1;
	}
	
	public boolean equals(Object other)
	{
		if (other instanceof OrderConstraint)
		{
			OrderConstraint o = (OrderConstraint) other;
			return o.i1 == this.i1 && o.j1 == this.j1 &&
				o.i2 == this.i2 && o.j2 == this.j2;
		}
		return false;
	}
	
	
}
