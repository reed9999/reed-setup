/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.expression;
import org.phramer.v1.constraints.blockorder.*;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.constraints.blockorder.expression.execution.*;
import org.phramer.v1.constraints.blockorder.hard.expression.*;
import org.phramer.v1.decoder.*;

public class ExpressionCommon
{
	public static boolean processSuccessor(ConstraintObjectOnNode successor,
										   ConstraintObject c,
										   boolean[] foreignCoveredParent,
										   PhraseTranslationVariant line,
										   boolean inPhraseAnalysis ,
										   int start,
										   int end,
										   Object debugObject)
	{
		boolean change = false;
		boolean inPhraseAnalysisBlock = inPhraseAnalysis && c.inPhraseAnalysisDescriptor != null && c.inPhraseAnalysisDescriptor.descriptorsBlock != null;
		boolean inPhraseAnalysisOrder = inPhraseAnalysis && c.inPhraseAnalysisDescriptor != null && c.inPhraseAnalysisDescriptor.descriptorsOrder != null;
		// block
		for (int i = 0; i < successor.bcState.length; i++)
			if (successor.bcState[i] != BlockConstraintsProcessor.States.CLOSED
				&& successor.bcState[i] != BlockConstraintsProcessor.States.FAILED
				)
			{
				assert successor.bcState[i] != BlockConstraintsProcessor.States.BUG;
				// Sync with hard.simple.ConstraintCheckerImpl
				successor.bcState[i] = inPhraseAnalysisBlock && c.inPhraseAnalysisDescriptor.descriptorsBlock[i] != null ?
					BlockConstraintsProcessor.getNextState(successor.bcState[i] , c.bc[i] , foreignCoveredParent , line , c.inPhraseAnalysisDescriptor.descriptorsBlock[i] , start, end)
					:
					BlockConstraintsProcessor.getNextState(successor.bcState[i] , c.bc[i] , foreignCoveredParent , start, end);
				
				DebugTools.debugPrint(successor.bcState[i] , successor.bcState , successor.ocState , debugObject , start , end , c.bc[i]);
				
				if (successor.bcState[i] == BlockConstraintsProcessor.States.CLOSED)
				{
					change = true;
					successor.variables[c.mappingBc[i]] = Node.Values.TRUE;
				}
				if (successor.bcState[i] == BlockConstraintsProcessor.States.FAILED)
				{
					change = true;
					successor.variables[c.mappingBc[i]] = Node.Values.FALSE;
				}
			}
		// order
		for (int i = 0; i < successor.ocState.length; i++)
			if (successor.ocState[i] != OrderConstraintsProcessor.States.CLOSED
				&& successor.ocState[i] != OrderConstraintsProcessor.States.FAILED
				)
			{
				assert successor.ocState[i] != OrderConstraintsProcessor.States.BUG;
				// Sync with hard.simple.ConstraintCheckerImpl
				successor.ocState[i] = inPhraseAnalysisOrder && c.inPhraseAnalysisDescriptor.descriptorsOrder[i] != null ?
					OrderConstraintsProcessor.getNextState(successor.ocState[i] , c.oc[i] , foreignCoveredParent , line , c.inPhraseAnalysisDescriptor.descriptorsOrder[i] , start, end)
					:
					OrderConstraintsProcessor.getNextState(successor.ocState[i] , c.oc[i] , foreignCoveredParent , start, end);
				
				DebugTools.debugPrint(successor.ocState[i] , successor.bcState , successor.ocState , debugObject , start , end , c.oc[i]);
				
				if (successor.ocState[i] == OrderConstraintsProcessor.States.CLOSED)
				{
					change = true;
					successor.variables[c.mappingOc[i]] = Node.Values.TRUE;
				}
				if (successor.ocState[i] == OrderConstraintsProcessor.States.FAILED)
				{
					change = true;
					successor.variables[c.mappingOc[i]] = Node.Values.FALSE;
				}
			}
		
		// asserts for finish = true
		// TODO
		
		return change;
	}
}
