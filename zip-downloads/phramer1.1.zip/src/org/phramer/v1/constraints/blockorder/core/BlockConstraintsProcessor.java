/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.core;
import info.olteanu.utils.*;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.constraints.blockorder.core.inphrase.*;

public class BlockConstraintsProcessor
{
	// returns next state, based also on the internal alignment
	// back references:
	//      expression.ExpressionCommon.processSuccessor
	//      hard.simple.ConstraintCheckerImpl._checkHardConstraints
	public static int getNextState(int currentState,
								   BlockConstraint c,
								   boolean[] foreignCovered ,
								   PhraseTranslationVariant phrase ,
								   InPhraseAnalysisDescriptorBlockConstraint descriptor ,
								   int start,
								   int end)
	{
		int type = Types.getType(phrase , descriptor , start , end , c.i , c.j);
		return retValue(currentState , type , c , foreignCovered , start , end);
	}
	
	// returns next state, not based on the internal alignment
	// back references:
	//      expression.ExpressionCommon.processSuccessor
	//      hard.simple.ConstraintCheckerImpl._checkHardConstraints
	public static int getNextState(int currentState,
								   BlockConstraint c,
								   boolean[] foreignCovered ,
								   int start,
								   int end)
	{
		int type = Types.getType(start , end , c.i , c.j);
		return retValue(currentState , type , c , foreignCovered , start , end);
	}
	
	private static int retValue(int currentState, int type, BlockConstraint c, boolean[] foreignCovered, int start, int end)
	{
		if (currentState == States.OPEN)
			return Transition.OPEN[type];
		
		if (currentState == States.WORKING)
		{
			if (type == Types.E)
				if (allCovered(c.i , c.j , foreignCovered , start , end))
					return States.CLOSED;
				else
					return States.FAILED;
			
			if (type == Types.I)
				if (allCovered(c.i , c.j , foreignCovered , start , end))
					return States.CLOSED;
				else
					return States.WORKING;
			
			if (type == Types.AG_or_X) // in fact, also AB. But if B, then FAILED. So AB_or_B it is not added here
				return States.BUG;
			
			return States.FAILED;
		}
		throw new Error("Unreachable");
	}
	
	
	protected static boolean allCovered(int constraintStart , int constraintEnd , boolean[] foreignCovered, int start , int end)
	{
		assert constraintEnd < foreignCovered.length : BlockConstraint.get(constraintStart , constraintEnd) + "\n" + foreignCovered.length ;
		
		for (int i = constraintStart; i <= constraintEnd; i++)
			if (!foreignCovered[i])
				if (!(i >= start && i <= end))
					return false;
		return true;
	}
	
	public static class States
	{
		public static final byte OPEN = 0;
		public static final byte WORKING = 1;
		public static final byte CLOSED = 2;
		public static final byte FAILED = 3;
		public static final byte BUG = 4;
		
		public static char[] _CHAR = {'O','W','C','F','B'};
	}
	
	public static class Types
	{
		// All Good, eXact, cover all and everything good, or exactly cover all
		public static final byte AG_or_X = 0;
		// All Bad - cover all, bad alignment, or simply bad cover
		public static final byte AB_or_B = 1;
		// Inside - phrase is inside the constraint, not eXact
		public static final byte I = 2;
		// Outside - phrase doensn't overlap
		public static final byte O = 3;
		// Start - phrase can act as a start phrase
		public static final byte S = 4;
		// End - phrase can act as and end
		public static final byte E = 5;
		
		
		public static final int MAX = E + 1;
		
		public static byte getType(int a , int b , int i , int j)
		{
			if (a <= i && j <= b)
				return AG_or_X; // or B
			if (b < i || j < a)
				return O;
			if (i <= a && b <= j)
				return I;
			if (a < i && i <= b && b < j)
				return S; // or E or B
			if (i < a && a <= j && j < b)
				return E; // or S or B
			throw new Error("unreachable");
		}
		public static byte getType(PhraseTranslationVariant phrase , InPhraseAnalysisDescriptorBlockConstraint descriptor , int a , int b , int i , int j)
		{
			if (a <= i && j <= b)
			{
				// AG_or_X , or B
				
				AlignmentIdentifier identifier = InPhraseAnalysisTools.getIdentifier(descriptor.wordAlignmentBuilderWIthCache , phrase , a , b);
				if (identifier != null && descriptor.bad.contains(identifier))
					return AB_or_B;
				return AG_or_X;
			}
			if (b < i || j < a)
				return O;
			if (i <= a && b <= j)
				return I;
			if (a < i && i <= b && b < j)
			{
				// S or E or B
				AlignmentIdentifier identifier = InPhraseAnalysisTools.getIdentifier(descriptor.wordAlignmentBuilderWIthCache , phrase , a , b);
				if (identifier != null)
				{
					if (descriptor.bad.contains(identifier))
						return AB_or_B;
					if (descriptor.flipped.contains(identifier))
						return E;
				}
				
				return S; // or E or B
			}
			if (i < a && a <= j && j < b)
			{
				// E or S or B
				AlignmentIdentifier identifier = InPhraseAnalysisTools.getIdentifier(descriptor.wordAlignmentBuilderWIthCache , phrase , a , b);
				if (identifier != null)
				{
					if (descriptor.bad.contains(identifier))
						return AB_or_B;
					if (descriptor.flipped.contains(identifier))
						return S;
				}
				
				return E;
			}
			throw new Error("unreachable");
		}
	}
	
	private static class Transition
	{
		private static final byte[] OPEN = new byte[ Types.MAX ];
		static
		{
			ArrayTools.fillWith(OPEN , States.FAILED);
			OPEN[Types.O] = States.OPEN;
			OPEN[Types.AG_or_X] = States.CLOSED;
			OPEN[Types.S] = States.WORKING;
			OPEN[Types.I] = States.WORKING;
		}
	}
}
