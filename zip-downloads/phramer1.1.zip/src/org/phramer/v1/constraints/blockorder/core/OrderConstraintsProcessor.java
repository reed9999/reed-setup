/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.core;

import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.constraints.blockorder.core.inphrase.*;
import org.phramer.v1.decoder.*;

public class OrderConstraintsProcessor
{
	
	// returns next state, based also on the internal alignment
	public static int getNextState(int currentState,
								   OrderConstraint c,
								   boolean[] foreignCovered ,
								   PhraseTranslationVariant phrase ,
								   InPhraseAnalysisDescriptorOrderConstraint descriptor ,
								   int start,
								   int end)
	{
		int type = Types.getType(phrase , descriptor , start , end , c.i1 , c.j1 , c.i2 , c.j2);
		return retValue(currentState , type , c , foreignCovered , start , end);
	}
	
	// returns next state, not based on the internal alignment
	// back references:
	//      expression.ExpressionCommon.processSuccessorWithoutInPhraseAnalysis
	//      hard.simple.ConstraintCheckerImpl._checkHardConstraintsNoInPhraseAnalysis
	public static int getNextState(int currentState,
								   OrderConstraint c,
								   boolean[] foreignCovered ,
								   int start,
								   int end)
	{
		int type = Types.getType(start , end , c.i1 , c.j1 , c.i2 , c.j2);
		return retValue(currentState , type , c , foreignCovered , start , end);
	}
	
	private static int retValue(int currentState, int type, OrderConstraint c, boolean[] foreignCovered, int start, int end)
	{
		switch (currentState)
		{
			case States.OPEN:
				return Transition.OPEN[type];
			case States.WORKING_A:
				if (type == Types.IO || type == Types.II || type == Types.IA)
					if (BlockConstraintsProcessor.allCovered(c.i1 , c.j1, foreignCovered , start , end))
						return Transition.WA_NOMORE[type];
					else
						return Transition.WA_MORE[type];
				
				return Transition.WA[type];
			case States.FINISHED_A:
				return Transition.FA[type];
			case States.WORKING_B:
				
				if (type == Types.OI)
					if (BlockConstraintsProcessor.allCovered(c.i2 , c.j2, foreignCovered , start , end))
						return Transition.WB_NOMORE[type];
					else
						return Transition.WB_MORE[type];
				
				return Transition.WB[type];
		}
		throw new Error("Unreachable " + currentState + " " + States._CHAR[currentState]);
	}
	
	private static class Transition
	{
		private static final int[] OPEN;
		private static final int[] WA, WB , FA;
		private static final int[] WA_MORE , WA_NOMORE;
		private static final int[] WB_MORE , WB_NOMORE;
		static
		{
			OPEN = new int[Types.MAX];
			WA = new int[Types.MAX];
			WB = new int[Types.MAX];
			FA = new int[Types.MAX];
			WA_MORE = new int[Types.MAX];
			WA_NOMORE = new int[Types.MAX];
			WB_MORE = new int[Types.MAX];
			WB_NOMORE = new int[Types.MAX];
			
			for (int i = 0; i < OPEN.length; i++)
			{
				OPEN[i] = States.BUG;
				WA[i] = States.BUG;
				WB[i] = States.BUG;
				FA[i] = States.BUG;
				WA_MORE[i] = States.BUG;
				WA_NOMORE[i] = States.BUG;
				WB_MORE[i] = States.BUG;
				WB_NOMORE[i] = States.BUG;
			}
			OPEN[Types.OO] = States.OPEN;
			OPEN[Types.BAD] = States.FAILED;
			OPEN[Types.OA] = States.FAILED;
			OPEN[Types.OI] = States.FAILED;
			OPEN[Types.IA] = States.FAILED;
			OPEN[Types.II] = States.FAILED;
			OPEN[Types.IO] = States.WORKING_A;
			OPEN[Types.AO] = States.FINISHED_A;
			OPEN[Types.AI] = States.WORKING_B;
			OPEN[Types.AA] = States.CLOSED;
			
			WA[Types.BAD] = States.FAILED;
			WA[Types.OI] = States.FAILED;
			WA[Types.OA] = States.FAILED;
			WA[Types.OO] = States.WORKING_A;
			
			WA_MORE[Types.IO] = States.WORKING_A;
			WA_MORE[Types.II] = States.FAILED;
			WA_MORE[Types.IA] = States.FAILED;
			
			WA_NOMORE[Types.IO] = States.FINISHED_A;
			WA_NOMORE[Types.II] = States.WORKING_B;
			WA_NOMORE[Types.IA] = States.CLOSED;
			
			FA[Types.BAD] = States.FAILED;
			FA[Types.OO] = States.FINISHED_A;
			FA[Types.OI] = States.WORKING_B;
			FA[Types.OA] = States.CLOSED;
			
			WB[Types.BAD] = States.FAILED;
			WB[Types.OO] = States.WORKING_B;
			
			WB_MORE[Types.OI] = States.WORKING_B;
			
			WB_NOMORE[Types.OI] = States.CLOSED;
		}
	}
	
	public static class States
	{
		public static final byte OPEN = 0;
		public static final byte WORKING_A = 1;
		public static final byte FINISHED_A = 2;
		public static final byte WORKING_B = 3;
		public static final byte CLOSED = 4;
		public static final byte FAILED = 5;
		public static final byte BUG = 6;
		
		public static final char[] _CHAR = {'O','A','X','B','C','F','B'};
		
	}
	
	public static class Types
	{
		private static int BITS = 3;
		public static final byte _O = 1;
		public static final byte _I = 2;
		public static final byte _A = 3;
		
		public static final byte BAD = 0;
		public static final byte OO = (byte)((_O << BITS) | _O);
		public static final byte OI = (byte)((_O << BITS) | _I);
		public static final byte OA = (byte)((_O << BITS) | _A);
		public static final byte IO = (byte)((_I << BITS) | _O);
		public static final byte II = (byte)((_I << BITS) | _I);
		public static final byte IA = (byte)((_I << BITS) | _A);
		public static final byte AO = (byte)((_A << BITS) | _O);
		public static final byte AI = (byte)((_A << BITS) | _I);
		public static final byte AA = (byte)((_A << BITS) | _A);
		
		private static String[] STR;
		static
		{
			STR = new String[256];
			STR[BAD] = "BAD";
			STR[OO] = "OO";
			STR[OI] = "OI";
			STR[OA] = "OA";
			STR[IO] = "OO";
			STR[II] = "OI";
			STR[IA] = "OA";
			STR[AO] = "AO";
			STR[AI] = "AI";
			STR[AA] = "AA";
		}
		
		public static final int MAX = AA + 1;
		
		public static byte getType(int a , int b , int i1 , int j1 , int i2 , int j2)
		{
			return (byte)((getType(a, b, i1, j1) << BITS) | getType(a, b, i2, j2));
		}
		private static byte getType(int a , int b , int i , int j)
		{
			if (a <= i && j <= b)
				return _A;
			if (b < i || j < a)
				return _O;
			return _I;
		}
		// This one also returns BAD
		public static byte getType(PhraseTranslationVariant phrase , InPhraseAnalysisDescriptorOrderConstraint descriptor , int a , int b , int i1 , int j1 , int i2 , int j2)
		{
			AlignmentIdentifier identifier = InPhraseAnalysisTools.getIdentifier(descriptor.wordAlignmentBuilderWIthCache , phrase , a , b);
			if (identifier != null && descriptor.bad.contains(identifier))
				return BAD;
			
			// if it is not in the bad group, then return it directly...
			return getType(a , b , i1 , j1 , i2 , j2);
		}
		
		public static String toString(byte type)
		{
			return STR[type];
		}
	}
}
