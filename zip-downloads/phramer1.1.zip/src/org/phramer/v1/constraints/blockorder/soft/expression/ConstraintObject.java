/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.soft.expression;
import info.olteanu.utils.*;
import java.io.*;
import java.util.*;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.constraints.blockorder.expression.*;
import org.phramer.v1.constraints.blockorder.expression.constraints.*;
import org.phramer.v1.constraints.blockorder.expression.execution.*;

public class ConstraintObject extends org.phramer.v1.constraints.blockorder.hard.expression.ConstraintObject
{
	// n: len of the sentence
	public ConstraintObject(int n)
	{
		super(n);
	}
	public double[] expressionCost;
	public int[] expression2feature;
	public void setConstraints(NodeX[] expressions ,
							   double[] expressionCost ,
							   int[] expression2feature ,
							   PrimitiveConstraintsContainer container ,
							   boolean inPhraseAnalysis)
	{
		super.setConstraints(expressions,container ,inPhraseAnalysis);
		this.expressionCost = expressionCost;
		this.expression2feature = expression2feature;
	}
	public void setConstraints(String[] expressions , boolean inPhraseAnalysis) throws IOException
	{
		NodeX[] e = new NodeX[expressions.length];
		double cost[] = new double[expressions.length];
		int[] e2f = new int[expressions.length];
		PrimitiveConstraintsContainer container = new PrimitiveConstraintsContainer();
		for (int i = 0; i < e.length; i++)
		{
			String k = expressions[i];
			e2f[i] = Integer.parseInt(StringTools.substringBefore(k , ",").trim());
			k = StringTools.substringAfter(k , ",");
			cost[i] = Double.parseDouble(StringTools.substringBefore(k , ",").trim());
			k = StringTools.substringAfter(k , ",");
			e[i] = ConstraintsExpressionReader.getExpression(k , container , n , inPhraseAnalysis);
		}
		setConstraints(e , cost , e2f , container , inPhraseAnalysis);
	}
}
