/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.v1.constraints.blockorder.core.inphrase;
import org.phramer.v1.constraints.blockorder.core.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.table.wordalignment.*;
import info.olteanu.utils.lang.*;
import java.util.*;


// TODO: fix limitation: supports only byte[] encoding
// another idea: allocate an identifier, attached to the PhraseTranslationVariant
public class InPhraseAnalysisTools
{
	private static final boolean DEBUG = true;
	public static InPhraseAnalysisDescriptor getDescriptor(PhraseTranslationVariant[][][] phraseTableVariants , WordAlignmentBuilder wordAlignmentBuilder ,  BlockConstraint[] bc , OrderConstraint[] oc)
	{
		int maxPhraseLength = getMaxPhraseLength(phraseTableVariants);
		
		
		InPhraseAnalysisDescriptorBlockConstraint[] bcD = new InPhraseAnalysisDescriptorBlockConstraint[bc.length];
		for (int i = 0; i < bcD.length; i++)
			bcD[i] = InPhraseAnalysisTools.getDescriptorForBlockConstraint(phraseTableVariants , wordAlignmentBuilder , maxPhraseLength , bc[i]);
		
		InPhraseAnalysisDescriptorOrderConstraint[] ocD = new InPhraseAnalysisDescriptorOrderConstraint[oc.length];
		for (int i = 0; i < ocD.length; i++)
			ocD[i] = InPhraseAnalysisTools.getDescriptorForOrderConstraint(phraseTableVariants , wordAlignmentBuilder , maxPhraseLength , oc[i]);
		
		return new InPhraseAnalysisDescriptor(bcD , ocD);
	}
	
	private static int getMaxPhraseLength(PhraseTranslationVariant[][][] phraseTableVariants)
	{
		int max = -1;
		for (int i = 0; i < phraseTableVariants.length; i++)
			if (phraseTableVariants[i] != null)
				max = Math.max(max, phraseTableVariants[i].length);
		return max;
	}
	private static InPhraseAnalysisDescriptorBlockConstraint getDescriptorForBlockConstraint(PhraseTranslationVariant[][][] phraseTableVariants , WordAlignmentBuilder wordAlignmentBuilder , int maxPhraseLength , BlockConstraint bc)
	{
		int bi = bc.i , bj = bc.j;
		if (bi == bj)
			return null;// cannot be bad
		
		InPhraseAnalysisDescriptorBlockConstraint d = new InPhraseAnalysisDescriptorBlockConstraint(wordAlignmentBuilder.generatesTheSameObjectForTheSameAlignment());
		
		// scan for bad overlapping phrases
		// for example
		//   (   )
		// [      ]
		// in which the alignment within is bad
		// or    (     )
		//   [       ]
		
		// scan for flipped start/end phrases
		
		
		MutableBool bad = new MutableBool();
		MutableBool flip = new MutableBool();
		
		
		// avoid repetitive processing of the same alignment matrix
		Set<ByteArrayHasher> processedAlignments = new HashSet<ByteArrayHasher>();
		for (int start = Math.max(0 , bi - maxPhraseLength + 1) ; start <= bj ; start++)// TODO: good limits?
			if (phraseTableVariants[start] != null)
			{
				int minLenX = start < bi ? bi - start : 0;
				assert start >= bi || !blockOverlapPartial(start, start + minLenX - 1, bi, bj);
				assert blockOverlap(start, start + minLenX , bi, bj) : start + " " + (start + minLenX) + "   (" + bi + "," + bj + ")";
				
				for (int i = minLenX ; i < phraseTableVariants[start].length; i++) // TODO: good start?
					if (phraseTableVariants[start][i] != null)
					{
						int end = start + i;
						if (blockOverlapPartial(start, end, bi, bj))
						{
							// no alignment yet processed
							processedAlignments.clear();
							
							for (PhraseTranslationVariant ptv : phraseTableVariants[start][i])
								if (ptv.translationTableLine != null && ptv.translationTableLine.getWordAlignment() != null)
								{
									byte[] encodedWordAlignment = (byte[])ptv.translationTableLine.getWordAlignment();
									ByteArrayHasher hashValue = new ByteArrayHasher(encodedWordAlignment);
									if (!processedAlignments.contains(hashValue))
									{
										// adds it to the list of alignments already processed, so that it doesn't
										processedAlignments.add(hashValue);// check if this can be optimized further (e.g.: use lists rather than hashes)...
										
										//[lenF][lenE]
										boolean[][] array = wordAlignmentBuilder.decodeWordAlignmentIntoMatrix(i + 1, ptv.translationTableLine.getTranslation().length, encodedWordAlignment);
										
										// scan for bad overlapping phrases
										if (bi >= start && bj <= end)
										{
											if (isBadBlock(start, end, bi, bj , array))
											{
												if (DEBUG)
													System.err.println("Bad nonoverlapping " + getDebugString(start, end, bc, wordAlignmentBuilder.decodeWordAlignment(-1 , -1 , encodedWordAlignment)));
												d.bad.add(AlignmentIdentifier.getAlignmentIdentifier(d.wordAlignmentBuilderWIthCache , start , end , encodedWordAlignment));
											}
										}
										else
										{
											checkFlippedOrBadInNonInclusion(start, end, bi, bj , array , bad, flip);
											assert !bad.value || !flip.value;
											// scan for flipping phrases
											if (bad.value)
											{
												if (DEBUG)
													System.err.println("Bad overlapping " + getDebugString(start, end, bc, wordAlignmentBuilder.decodeWordAlignment(-1 , -1 , encodedWordAlignment)));
												d.bad.add(AlignmentIdentifier.getAlignmentIdentifier(d.wordAlignmentBuilderWIthCache , start , end , encodedWordAlignment));
											}
											if (flip.value)
											{
												if (DEBUG)
													System.err.println("Flipped " + getDebugString(start, end, bc, wordAlignmentBuilder.decodeWordAlignment(-1 , -1 , encodedWordAlignment)));
												d.flipped.add(AlignmentIdentifier.getAlignmentIdentifier(d.wordAlignmentBuilderWIthCache , start , end , encodedWordAlignment));
											}
										}
									}
								}
						}
					}
			}
		
		if(DEBUG)
			System.err.println("Constraint " + bc + " : " + d.bad.size() + " bad and " + d.flipped.size() + " flipped");
		
		if (d.isEmpty())
			return null;
		return d;
	}
	
	private static void checkFlippedOrBadInNonInclusion(int a, int b, int i, int j, boolean[][] array , MutableBool isBad , MutableBool isFlip)
	{
		isBad.value = false;
		isFlip.value = false;
		assert array.length == (b - a + 1);
		
		// if the constraint is inside the phrase, then it's not considered for flipping
		assert !(a <= i && j <= b);
		
		// i should have either parts of (bi,bj) that are outside (start, end)
		int breakPoint; // areas: a..breakPoint and breakPoint+1..b
		if (i > a && i <= b) // +++(++   )   where + = phrase and (  ) = block constraint
			breakPoint = i - 1;
		else
		{
			assert (j >= a && j < b); // because it was checked through blockOverlap() before
			breakPoint = j;
		}
		// now breakpoint is within "array"
		breakPoint -= a;
		
		// check if it's
		// .....XXXX
		// .....XXXX
		// XXXXX....
		// XXXXX....
		// XXXXX....
		// XXXXX....
		// = is flipped
		//
		// instead of:
		//
		// XXXXX....
		// XXXXX....
		// XXXXX....
		// .....XXXX
		// .....XXXX
		// .....XXXX
		//
		// if it's none, then it's bad
		
		IntPair projectionStart = getProjection(array , 0 , breakPoint);
		IntPair projectionEnd = getProjection(array , breakPoint + 1  , array.length - 1);
		
		assert projectionStart != null || projectionEnd != null : "At least one half should have non-null projection...";
		// no projection? then neither bad or flip
		if (projectionStart == null || projectionEnd == null)
			return; // I believe that's the right answer, because one of them has no projection...
		
		if (projectionStart.second < projectionEnd.first)
			return; // standard (non-flip), not bad
		
		if (projectionStart.first > projectionEnd.second)
		{
			// flip
			isFlip.value = true;
			return;
		}
		
		// now it's bad...
		isBad.value = true;
		return;
	}
	
	
	
	// checks _only_ for when the block constraint is _totally_	included in the phrase
	protected static boolean isBadBlock(int start, int end, int bi, int bj , boolean[][] array)
	{
		assert array.length == (end - start + 1);
		assert bi >= start && bi <= end;
		assert bj >= start && bj <= end;
		
		bi -= start;
		bj -= start;
		assert bi >= 0 && bi < array.length;
		assert bj >= 0 && bj < array.length;
		// now bi and bj are relative to the coordinates in the virtual alignment matrix, and they don't out of the bounds
		
		// get min and max for the (i,j) projection
		IntPair blockProjection = getProjection(array , bi , bj);
		
		// no projection?
		if (blockProjection == null)
			return false; // I believe that's the right answer, because there's no violation
		
		return checkBlockBadOverlap(bi, bj, array , blockProjection.first , blockProjection.second);
	}
	private static boolean checkBlockBadOverlap(int bi , int bj , boolean[][] array , int low , int high)
	{
		// now i check that the projection of the rest of the phrase doesn't overlap with this projection
		for (int i = 0; i < bi; i++)
			for (int j = low; j <= high; j++)
				if (array[i][j])
					return true;
		
		for (int i = bj + 1; i < array.length; i++)
			for (int j = low; j <= high; j++)
				if (array[i][j])
					return true;
		
		return false;
	}
	
	// gets the projection of the F [start,end] interval in the array on the E dimension
	// return the <min,max> pair
	// or null for no projection
	private static IntPair getProjection(boolean[][] array , int start , int end)
	{
		int minIndexEforBlock = Integer.MAX_VALUE;
		int maxIndexEforBlock = -1;
		for (int i = start; i <= end; i++)
			for (int j = 0; j < array[i].length; j++)
				if (array[i][j])
				{
					if (minIndexEforBlock > j)
						minIndexEforBlock = j;
					if (maxIndexEforBlock < j)
						maxIndexEforBlock = j;
				}
		if (maxIndexEforBlock == -1)
			return null;// no projection
		return new IntPair(minIndexEforBlock, maxIndexEforBlock);
	}
	
	// checks if there's a partial overlap between a-b and i-j
	private static boolean blockOverlapPartial(int a, int b, int i, int j)
	{
		if (i > a && i <= b) // +++(++   )   where + = phrase and (  ) = block constraint
			return true;
		
		if (j >= a && j < b) // (   ++)++++  where + = phrase and (  ) = block constraint
			return true;
		
		return false;
	}
	
	// checks if there's a partial or total overlap between a-b and i-j
	// TODO: make it faster, if possible
	private static boolean blockOverlap(int a, int b, int i, int j)
	{
		if (i >= a && i <= b)
			return true;
		
		if (j >= a && j <= b)
			return true;
		
		if (a >= i && a <= j)
			return true;
		
		if (b >= i && b <= j)
			return true;
		
		return false;
	}
	
	
	
	
	private static InPhraseAnalysisDescriptorOrderConstraint getDescriptorForOrderConstraint(PhraseTranslationVariant[][][] phraseTableVariants , WordAlignmentBuilder wordAlignmentBuilder , int maxPhraseLength , OrderConstraint oc)
	{
		int i1 = oc.i1 , j1 = oc.j1;
		int i2 = oc.i2 , j2 = oc.j2;
		
		InPhraseAnalysisDescriptorOrderConstraint d = new InPhraseAnalysisDescriptorOrderConstraint(wordAlignmentBuilder.generatesTheSameObjectForTheSameAlignment());
		
		
		// avoid repetitive processing of the same alignment matrix
		Set<ByteArrayHasher> processedAlignments = new HashSet<ByteArrayHasher>();
		for (int start = 0 ; start < phraseTableVariants.length ; start++)// TODO: better limits
			if (phraseTableVariants[start] != null)
				for (int i = 0 ; i < phraseTableVariants[start].length; i++) // TODO: better limits
					if (phraseTableVariants[start][i] != null)
					{
						int end = start + i;
						// both overlap
						if (blockOverlap(start, end, i1, j1) && blockOverlap(start , end , i2 , j2))
						{
							// no alignment yet processed
							processedAlignments.clear();
							
							for (PhraseTranslationVariant ptv : phraseTableVariants[start][i])
								if (ptv.translationTableLine != null && ptv.translationTableLine.getWordAlignment() != null)
								{
									byte[] encodedWordAlignment = (byte[])ptv.translationTableLine.getWordAlignment();
									ByteArrayHasher hashValue = new ByteArrayHasher(encodedWordAlignment);
									if (!processedAlignments.contains(hashValue))
									{
										// adds it to the list of alignments already processed, so that it doesn't
										processedAlignments.add(hashValue);// check if this can be optimized further (e.g.: use lists rather than hashes)...
										
										//[lenF][lenE]
										boolean[][] array = wordAlignmentBuilder.decodeWordAlignmentIntoMatrix(i + 1, ptv.translationTableLine.getTranslation().length, encodedWordAlignment);
										
										// scan for bad overlapping phrases
										if (isBadOrder(start, end, i1, j1 , i2 , j2 , array))
										{
											if (DEBUG)
												System.err.println("Bad " + getDebugString(start, end, oc, wordAlignmentBuilder.decodeWordAlignment(-1 , -1 , encodedWordAlignment)));
											d.bad.add(AlignmentIdentifier.getAlignmentIdentifier(d.wordAlignmentBuilderWIthCache , start , end , encodedWordAlignment));
										}
									}
								}
						}
					}
		
		if(DEBUG)
			System.err.println("Constraint " + oc + " : " + d.bad.size() + " bad");
		
		if (d.isEmpty())
			return null;
		return d;
	}
	
	protected static boolean isBadOrder(int start, int end, int i1, int j1, int i2, int j2, boolean[][] array)
	{
		assert array.length == (end - start + 1);
		i1 = Math.max(i1 - start , 0);
		j1 = Math.min(j1 - start , array.length - 1);
		i2 = Math.max(i2 - start , 0);
		j2 = Math.min(j2 - start , array.length - 1);
		assert i1 >= 0 && i1 < array.length;
		assert j1 >= 0 && j1 < array.length;
		assert i2 >= 0 && i2 < array.length;
		assert j2 >= 0 && j2 < array.length;
		// now i1,j1,i2,j2 are relative to the coordinates in the virtual alignment matrix, and they don't out of the bounds
		
		IntPair projection1 = getProjection(array , i1 , j1);
		IntPair projection2 = getProjection(array , i2 , j2);
		
		// no projection?
		if (projection1 == null || projection2 == null)
			return false; // I believe that's the right answer, because one of them has no projection...
		
		// check if the constraint assertion validates
		if (!(projection1.second < projection2.first))
			return true;
		
		return false;
	}
	
	
	
	private static String getDebugString(int start, int end, PrimitiveConstraint bc, BytePair[] wa)
	{
		return "[" + start + "," + end + "] << " + WordAlignmentTools.serializeWordAlignment(-1 , -1 , wa , -1) + " >> for " + bc;
	}
	
	
	// accessed by BlockConstraintsProcessor and OrderConstraintProcessor
	public static AlignmentIdentifier getIdentifier(boolean cache , PhraseTranslationVariant phrase, int a, int b)
	{
		if (phrase.translationTableLine != null && phrase.translationTableLine.getWordAlignment() != null)
			return AlignmentIdentifier.getAlignmentIdentifier(cache , a , b , phrase.translationTableLine.getWordAlignment());
		return null;
	}
	
}
