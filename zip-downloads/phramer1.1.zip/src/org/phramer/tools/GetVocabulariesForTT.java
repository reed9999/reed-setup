/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools;

import info.olteanu.utils.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.util.*;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.table.wordalignment.*;

public class GetVocabulariesForTT
{
	public static void main(String[] args)
	throws Exception
	{
		if (args.length < 4 || args.length > 6)
		{
			System.err.println("Extracts the vocabulary (with counts) of both f and e side of a translation table.");
			System.err.println("Parameters: fileTableIn ttableEncoding fileVF fileVE [maxPhraseLenF [maxPhraseLenE]]");
			System.err.println("Sorts it descending");
			System.exit(1);
		}
		String fileTableIn = args[0];
		String encodingTT = args[1];
		String fileVF = args[2];
		String fileVE = args[3];
		int maxPhraseLenF = 10;
		if (args.length >= 5)
			maxPhraseLenF = Integer.parseInt(args[4]);
		int maxPhraseLenE = 10;
		if (args.length >= 6)
			maxPhraseLenE = Integer.parseInt(args[5]);
		
		extractVocabulary(fileTableIn , fileVF , fileVE , null , encodingTT , maxPhraseLenF , maxPhraseLenE , null , 0);// TODO: do align also
		
	}
	
	public static void extractVocabulary(String fileTableIn ,
										 String fileVF ,
										 String fileVE ,
										 String fileAlign ,
										 String encodingTT ,
										 int maxPhraseLenF ,
										 int maxPhraseLenE ,
										 WordAlignmentBuilder wordAlignmentBuilder ,
										 int wordAlignmentType) throws IOException
	{
		HashMap<String,MutableInt> vocF = fileVF != null ? new HashMap<String,MutableInt>() : null;
		HashMap<String,MutableInt> vocE = fileVE != null ?  new HashMap<String,MutableInt>() : null;
		HashMap<String,MutableInt> vocAlign = fileAlign != null ? new HashMap<String,MutableInt>() : null;
		
		// automatically detect .gz files
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(
														  IOTools.getInputStream(fileTableIn),
														  encodingTT
													  ));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
		{
			String f = StringTools.substringBefore(lineFile , " ||| ");
			if (StringTools.countTokens(f) <= maxPhraseLenF)
			{
				lineFile = StringTools.substringAfter(lineFile , " ||| ");
				String e = StringTools.substringBefore(lineFile , " ||| ");
				if (StringTools.countTokens(e) <= maxPhraseLenE)
				{
					if (vocF != null)
						addToVocabularyTok(vocF , f);
					if (vocE != null)
						addToVocabularyTok(vocE , e);
					// alignment stuff
					lineFile = StringTools.substringAfter(lineFile , " ||| ");
					if (lineFile.indexOf(" ||| ") != -1 && wordAlignmentType != WordAlignmentTypes.TYPE_NONE)
					{
						String wa = StringTools.lastSubstringBefore(lineFile , " ||| ");
						addToVocabulary(vocAlign , wa);
					}
				}
			}
		}
		inputFile.close();
		
		// dump
		if (vocF != null)
			writeVocabulary(vocF , fileVF);
		if (vocE != null)
			writeVocabulary(vocE , fileVE);
		if (wordAlignmentType != WordAlignmentTypes.TYPE_NONE)
			writeAlign(vocAlign , fileAlign , wordAlignmentBuilder , wordAlignmentType);
	}
	
	private static void writeAlign(HashMap<String, MutableInt> vocAlign, String fileAlign,  WordAlignmentBuilder wordAlignmentBuilder, int wordAlignmentType) throws IOException
	{
		Pair<String,MutableInt>[] all = sortCounts(vocAlign);
		// dump .align file; see
		FileOutputStream osAlign = new FileOutputStream(fileAlign);
		for (Pair<String,MutableInt> pair : all)
			TranslationTableToolsExtra.writeAlignEntry(osAlign , wordAlignmentBuilder.encodeWordAlignment(-1, -1, pair.first, wordAlignmentType));// TODO: lenF, lenE; requires build during parsing...
		osAlign.close();
	}
	
	private static void writeVocabulary(HashMap<String, MutableInt> voc, String file) throws FileNotFoundException
	{
		Pair<String,MutableInt>[] all = sortCounts(voc);
		
		// dump
		try
		{
			PrintStream outFile = new PrintStream(new FileOutputStream(file), true , "UTF-8");
			for (Pair<String,MutableInt> pair : all)
				outFile.println(pair.first + " " + pair.second.value);
			outFile.close();
		}
		catch (UnsupportedEncodingException e)
		{
			throw new Error("Is UTF-8 unsupported?" , e);
		}
	}
	
	public static Pair<String,MutableInt>[] sortCounts(HashMap<String, MutableInt> voc)
	{
		// sort by count, descending
		Pair<String,MutableInt>[] all = new Pair[voc.size()];
		int i=0;
		for (String key : voc.keySet())
			all[i++] = new Pair<String,MutableInt>(key , voc.get(key));
		
		// sort
		Arrays.sort(all , new Comparator<Pair<String,MutableInt>>()
			{
				public int compare(Pair<String, MutableInt> o1, Pair<String, MutableInt> o2)
				{
					return o2.second.value - o1.second.value;
				}
			});
		return all;
	}
	
	private static void addToVocabularyTok(HashMap<String, MutableInt> voc, String stringToBeTokenized)
	{
		StringTokenizer st = new StringTokenizer(stringToBeTokenized);
		while (st.hasMoreTokens())
			addToVocabulary(voc, st.nextToken());
	}
	
	private static void addToVocabulary(HashMap<String, MutableInt> voc, String word)
	{
		MutableInt cnt = voc.get(word);
		if (cnt == null)
		{
			cnt = new MutableInt(1);
			voc.put(word, cnt);
		}
		else
			cnt.value++;
	}
}
