/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools;
import info.olteanu.utils.*;
import java.io.*;
import java.util.*;
import info.olteanu.utils.io.*;

/** Filters a translation table, to contain only phrases that are found in a F file */
public class FilterTranslationTable
{
	public static void main(String[] args) throws IOException
	{
		if (args.length < 3 || args.length > 5)
		{
			System.err.println("Filters (and flips) a translation table, to contain only phrases that are found in a F file");
			System.err.println("Parameters: <text file F> <input translation table> <output translation table> [<maxForeignPhraseLen>] [inverse]");
			System.err.println("Default max foreign phrase length : 10");
			System.err.println("It implements phrase table flipping");
			System.exit(1);
		}
		String fileF = args[0];
		String fileTableIn = args[1];
		String fileTableOut = args[2];
		int maxPhraseLen = 10;
		if (args.length >= 4)
			maxPhraseLen = Integer.parseInt(args[3]);
		boolean inverse = false;
		if (args.length >= 5)
			inverse = args[4].toLowerCase().startsWith("inv");
		
		filterTranslationTable(fileF, fileTableOut, fileTableIn , maxPhraseLen , inverse);
	}
	
	public static void filterTranslationTable(String fileF, String fileTableOut, String fileTableIn , int maxPhraseLen , boolean inverse) throws IOException
	{
		// automatically detect .gz files
		
		
		HashSet<String> allPhrases = getAllPhrasesFromF(fileF, maxPhraseLen);
		BufferedPrintStream outFile = new BufferedPrintStream(
			IOTools.getOutputStream(fileTableOut)
		);
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(
														  IOTools.getInputStream(fileTableIn)
													  ));
		String lineFile;
		if (inverse)
			while ((lineFile = inputFile.readLine()) != null)
			{
				String f = StringTools.substringBefore(lineFile , " ||| ");
				lineFile = StringTools.substringAfter(lineFile , " ||| ");
				String e = StringTools.substringBefore(lineFile , " ||| ");
				String p = StringTools.substringAfter(lineFile , " ||| ");
				
				if (allPhrases.contains(e))
					outFile.println(e + " ||| " + f + " ||| " + p);
			}
		else
			while ((lineFile = inputFile.readLine()) != null)
			{
				String f = StringTools.substringBefore(lineFile , " ||| ");
				if (allPhrases.contains(f))
					outFile.println(lineFile);
			}
		inputFile.close();
		outFile.close();
	}
	
	public static HashSet<String> getAllPhrasesFromF(String fileF, int maxPhraseLen) throws IOException
	{
		HashSet<String> set = new HashSet<String>();
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(IOTools.getInputStream(fileF)));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
		{
			String[] l = StringTools.tokenize(false , lineFile);
			for (int i = 0; i < l.length; i++)
			{
				StringBuffer sb = new StringBuffer();
				for (int x = i ; x < l.length ; x++)
				{
					if (x - i >= maxPhraseLen)
						break;
					
					if (x > i)
						sb.append(' ');
					sb.append(l[x]);
					set.add(sb.toString());
				}
			}
		}
		inputFile.close();
		return set;
	}
}
