/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools;
import info.olteanu.utils.*;
import info.olteanu.utils.io.*;
import java.io.*;
import java.util.*;

public class FilterTranslationTableByMinProbability
{
	public static void main(String[] args) throws IOException
	{
		if (args.length != 4)
		{
			System.err.println("Filters the translation table ...");
			System.err.println("Parameters: <input translation table> <output translation table> <minCnt> <minProb>");
			System.exit(1);
		}
		String fileTableIn = args[0];
		String fileTableOut = args[1];
		int minCnt = Integer.parseInt(args[2]);
		double minProb = Double.parseDouble(args[3]);
		
		filterTranslationTable(fileTableIn, fileTableOut, minCnt , minProb);
	}
	
	public static void filterTranslationTable(String fileTableIn , String fileTableOut,
											  int minCnt , double minProb) throws IOException
	{
		int print = 0 , all = 0;
		// automatically detect .gz files
		
		BufferedPrintStream outFile = new BufferedPrintStream(
			IOTools.getOutputStream(fileTableOut)
		);
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(
														  IOTools.getInputStream(fileTableIn)
													  ));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
		{
			all++;
			if (all % 1000000 == 0)
				System.err.print("*");
			else if (all % 10000 == 0)
				System.err.print(".");
			
			
			String pp = StringTools.lastSubstringAfter(lineFile , " ||| ");
			StringTokenizer st = new StringTokenizer(pp);
			int cntHere = 0;
			while (st.hasMoreTokens())
			{
				double px = Double.parseDouble(st.nextToken());
				if (px >= minProb)
					cntHere++;
				
			}

			if (cntHere >= minCnt)
			{
				outFile.println(lineFile);
				print++;
			}
			else
				System.out.println(lineFile);
		}
		System.err.println();
		inputFile.close();
		outFile.close();
		System.err.println("Kept " + print + "/" + all);
	}
}
