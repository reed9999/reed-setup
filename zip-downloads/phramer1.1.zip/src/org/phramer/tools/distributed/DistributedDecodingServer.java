/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools.distributed;
import info.olteanu.utils.*;
import info.olteanu.utils.remoteservices.*;
import info.olteanu.utils.remoteservices.server.*;
import java.io.*;
import java.util.*;

public class DistributedDecodingServer implements RemoteService
{
	private boolean allowKill = false;
	private Vector<Process> processes;
	private String decoderCommand;
	private int port;
	public DistributedDecodingServer(String[] args)
	{
		processes = new Vector<Process>();
		port = Integer.parseInt(args[0]);
		decoderCommand = args[1];
	}
	
	
	public String[] service(String[] input) throws RemoteException
	{
		try
		{
			if (input[0].equals("direct"))
				return executeDecoder(input[3] , input[4] , input[5] , input , 6);
			
			if (input[0].equals("split"))
				return doSplit(input);
			if (allowKill)
			{
				if (input[0].equals("kill"))
					return killAll();
				
				if (input[0].equals("killtop"))
					return killTop(input[1]);
			}
			throw new RemoteException("Not implemented: " + input[0]);
			
		}
		catch (InterruptedException e)
		{
			throw new RemoteException(e);
		}
		catch ( IOException e )
		{
			throw new RemoteException(e);
		}
	}
	
	private static final String[] KILLEDALL = {"done"};
	private String[] killAll()
	{
		synchronized (processes)
		{
			for (Process p : processes)
				p.destroy();
			processes.clear();
		}
		
		return KILLEDALL;
	}
	
	private String[] killTop(String user) throws IOException
	{
		Process p = Runtime.getRuntime().exec("top -u " + user + " -b -n 1");
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String lineFile;
		boolean now = false;
		String line = null;
		while ((lineFile = inputFile.readLine()) != null)
		{
			if (lineFile.trim().startsWith("PID USER"))
				now = true;
			else
			if (now)
			{
				line = lineFile;
				break;
			}
		}
		inputFile.close();
		if (line != null)
		{
			String[] t = StringTools.tokenize(line);
			if (t.length == 12)
			{
				// check cpu usage
				try
				{
					double cpu = Double.parseDouble(t[8]);
					if (cpu >= 20)//20%
					{
						// PID
						int pid = Integer.parseInt(t[0]);
						// kill
						System.err.println("Kill " + pid);
						p = Runtime.getRuntime().exec("kill -9 " + pid);
					}
				}
				catch (NumberFormatException e)
				{}
			}
		}
		return KILLEDALL;
	}
	
	private String[] doSplit(String[] input) throws IOException, InterruptedException
	{
	 	// decode, but output lattice in a temp directory and then move
		int startLine = Integer.parseInt(input[1]);
		int len = Integer.parseInt(input[2]);
		String tempDir = input[3];
		String configFile = input[4];
		String otherArgs = input[5];
		
		String tempFolderMultiFiles = tempDir + "port" + port + ".start" + startLine + "." + (int)(Math.random() * 1000000000) + "/";
		int maxCnt = 5;
		while (!new File(tempFolderMultiFiles).mkdirs())
		{
			maxCnt--;
			if (maxCnt == 0)
				throw new IOException("Cannot create dir");
			Thread.sleep((long)(1000 * Math.random()));
		}
		
		String latticeSrc = null , latticeDest = null;
		boolean doMove = false;
		String otherArgsSplit[] = StringTools.tokenize(otherArgs);
		for (int i = 0; i < otherArgsSplit.length - 1; i++)
		{
			if (otherArgsSplit[i].equals("-l") || otherArgsSplit[i].equals("-lattice"))
			{
				doMove = true;
				latticeDest = otherArgsSplit[i + 1];
				latticeSrc = tempFolderMultiFiles + "lattice";
				otherArgsSplit[i + 1] = latticeSrc;
			}
			// TODO: other stuff than lattice that involves moving
		}
		
		String output[] = executeDecoder(tempDir , configFile , StringTools.untokenize(otherArgsSplit) , input , 6);
		
		// move
		if (doMove)
		{
			for (int i = 0; i < len; i++)
			{
				String fileNameLattice = latticeSrc + "." + StringTools.adjustLengthForNumber(i , 4);
				String fileNameLatticeDest = latticeDest + "." + StringTools.adjustLengthForNumber(i + startLine , 4);
				if (!new File(fileNameLattice).renameTo(new File(fileNameLatticeDest)))
					throw new IOException("Move of " + fileNameLattice + " failed");
				fileNameLattice += ".state";
				fileNameLatticeDest += ".state";
				if (!new File(fileNameLattice).renameTo(new File(fileNameLatticeDest)))
					throw new IOException("Move of " + fileNameLattice + " failed");
				
				
				// TODO: other stuff than lattice that involves moving
			}
		}
		new File(tempFolderMultiFiles).delete();
		//Thread.sleep(300);// there might be issues with the file system
		return output;
	}
	
	private String[] executeDecoder(String tempDir, String configFile , String otherArgs, String[] fileContent, int deltaFile) throws FileNotFoundException, IOException, InterruptedException
	{
		String tempFileName = writeTemp(tempDir, deltaFile, fileContent);
		String commandLine = decoderCommand + " " + tempDir + " " + configFile + " " + tempFileName + " " + otherArgs;
		
		String[] lines = exec(commandLine);
		
		// delete temp file
		new File(tempFileName).delete();
		
		return lines;
	}
	
	private String[] exec(String commandLine) throws IOException, InterruptedException
	{
		System.err.println("Command: " + commandLine);
		Process p = Runtime.getRuntime().exec(commandLine);
		processes.add(p);
		new StreamToStreamByLineThread(p.getErrorStream() , System.err , "").start();
		
		Vector<String> lines = new Vector<String>();
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
			lines.add(lineFile);
		inputFile.close();
		p.waitFor();
		processes.remove(p);
		//Thread.sleep(300);// there might be issues with the file system
		return lines.toArray(new String[ lines.size() ]);
	}
	
	private String writeTemp(String tempDir, int deltaFile, String[] fileContent) throws FileNotFoundException
	{
		String tempFileName = tempDir + "port" + port + ".start" + fileContent[1] + "." + (int)(Math.random() * 1000000000) + ".input.txt";
		// create temp file for text
		PrintStream outFile = new PrintStream(new FileOutputStream(tempFileName));
		for (int i = deltaFile; i < fileContent.length; i++)
			outFile.println(fileContent[i]);
		outFile.close();
		return tempFileName;
	}
	
	public static void main(String[] args)
	throws Exception
	{
		Server server = new Server(new DistributedDecodingServer(args) , args[0]);
		server.debugLevel = 2;
		System.out.println("Providing service...");
		server.start();
		
	}
}
