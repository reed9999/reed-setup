/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools.distributed;

import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.remoteservices.*;
import info.olteanu.utils.remoteservices.client.*;
import java.io.*;

class DecoderCommander extends Thread
{
	
	private OutputCollector collector;
	private String tempDir;
	private String configFile;
	private String otherParams;
	private RemoteConnector rc;
	private int start;
	private int len;
	private String[] fileIn;
	private int idx;
	
	private String serverUrl;
	
	private boolean split;
	public DecoderCommander(OutputCollector collector ,
							String tempDir , String configFile , String otherParams ,
							String serverUrl,
							int start , int len , String fileIn[] , int idx ,
							boolean split
							) throws IOException
	{
		this.split = split;
		this.serverUrl = serverUrl;
		this.collector = collector;
		this.tempDir = tempDir;
		this.configFile = configFile;
		this.otherParams = otherParams;
		this.rc = new RemoteConnector(serverUrl , true , true , false);
		this.start = start;
		this.len = len;
		this.fileIn = fileIn;
		this.idx = idx;
	}
	public void run()
	{
		// prepare command
		
		String command[] = new String[len + 6];
		if (split)
		{
			command[0] = "split";
			command[1] = Integer.toString(start);
			command[2] = Integer.toString(len);
		}
		else
		{
			command[0] = "direct";
			command[1] = "default";
			command[2] = "default";
		}
		command[3] = tempDir;
		command[4] = configFile;
		command[5] = otherParams;
		System.arraycopy(fileIn , start , command , 6 , len);
		try
		{
			System.err.println("> " + StringTools.substringAfter(serverUrl , "remote:"));
			Chronometer c = new Chronometer(true);
			String[] response = rc.service(command);
			System.err.println("< " + StringTools.substringAfter(serverUrl , "remote:")
							   + " " + StringTools.formatDouble(0.001 * c.getValue() , "0.00") + " seconds");
			collector.report(idx , response);
			rc.stop();
			
		}
		catch (IOException e)
		{
			throw new Error(e);
		}
		catch (RemoteException e)
		{
			throw new Error(e);
		}
	}
}
