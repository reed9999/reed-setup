/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools.distributed;
import info.olteanu.utils.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.remoteservices.client.*;
import java.io.*;
import java.util.*;

public class DistributedDecodingClient
{
	public static void main(String[] args)
	throws Exception
	{
		// args[0]: use delta instead of split-move
		//    split-move (0): Pharaoh, Phramer with lattice
		//    delta (1): Phramer 1.0.2+
		// args[1]: server list
		// args[2]: temp dir
		// args[3]: config file
		// args[4]: input file
		
		String[] serverList = StringTools.tokenize(args[1], "_");
		String tempDir = args[2];
		if (tempDir.endsWith("/") || tempDir.endsWith("\\"))
		{}
		else
			tempDir += "/";
		String configFile = args[3];
		String inputFile = args[4];
		String[] otherArgs = StringTools.cutFirst(args, 5);
		boolean useDelta = args[0].equals("1");
		
		String[] fileIn = Tools.readFile(inputFile);
		
		// first: decode separately?
		if (doSplitDecoding(otherArgs))
		{
			// many machines, split
			OutputCollector collector = new OutputCollector(serverList.length , System.out);
			// command each server individually
			int pieceLen = (fileIn.length + serverList.length - 1) / serverList.length;
			int pos = 0;
			for (int i = 0; i < serverList.length; i++)
			{
				new DecoderCommander(collector ,
									 tempDir ,
									 configFile ,
									 StringTools.untokenize(otherArgs)
									 + (useDelta ? " -start-id " + pos : ""),
									 serverList[i] ,
									 pos ,
									 Math.min(pieceLen , fileIn.length - pos) ,
									 fileIn ,
									 i ,
									 !useDelta).start();
				pos += pieceLen;
			}
			
		}
		else
		{
			// one machine: pass output to the first machine in the list, wait for the output
			RemoteConnector rc = new RemoteConnector(serverList[0] , false , false , false);
			String command[] = new String[fileIn.length + 6];
			command[0] = "direct";
			command[1] = "default";
			command[2] = "default";
			command[3] = tempDir;
			command[4] = configFile;
			command[5] = StringTools.untokenize(otherArgs);
			System.arraycopy(fileIn , 0 , command , 6 , fileIn.length);
			String[] response = rc.service(command);
			rc.stop();
			
			// output
			for (int i = 0; i < response.length; i++)
				System.out.println(response[i]);
		}
		
	}
	
	
	private static boolean doSplitDecoding(String[] otherArgs)
	{
		// look for rescoring - rescoring takes place only on one machine
		for (int i = 0; i < otherArgs.length; i++)
			if ("-rd".equals(otherArgs[i]) || "-rescoredir".equals(otherArgs[i]) ||
				"-r".equals(otherArgs[i]) || "-rescore".equals(otherArgs[i]))
				return false;
		return true;
	}
}
