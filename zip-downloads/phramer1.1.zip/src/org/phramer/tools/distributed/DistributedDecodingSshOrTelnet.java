/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools.distributed;

import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import java.io.*;

public class DistributedDecodingSshOrTelnet
{
	static class StreamToStringArray
	extends Thread
	{
		private String[] destination;
		private int pos;
		private int len;
		private BufferedReader br;
		private MutableInt count;
		
		public StreamToStringArray(String[] destination , int pos , int len , BufferedReader br , MutableInt count)
		{
			this.destination = destination;
			this.pos = pos;
			this.len = len;
			this.br = br;
			this.count = count;
		}
		
		public void run()
		{
			try
			{
				int cursor = pos;
				int maxCursor = pos + len;
				String lineFile;
				while ((lineFile = br.readLine()) != null)
				{
					if (cursor >= maxCursor)
						throw new IOException("Too many lines (delta=" + pos + ")");
					destination[cursor] = lineFile;
					cursor++;
				}
				br.close();
				if (cursor != maxCursor)
					throw new IOException("Too few lines (delta=" + pos + ")");
				synchronized (count)
				{
					count.value++;
					count.notifyAll();
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args)
	throws Exception
	{
		// args[0]: connection command (ssh/telnet)
		// args[1]: server list ( svr01_svr02_svr03 )
		// args[2]: command ( /.../run-phramer-x.perl )
		// args[3]: temp dir
		// args[4]: config file
		// args[5]: input file
		// args[6+] additional args. for the command
		String sshCmd = args[0];
		String[] serverList = StringTools.tokenize(args[1] , "_");
		String command = args[2];
		String tmpDir = args[3];
		String configFile = args[4];
		String inputFile = args[5];
		String otherParams = StringTools.untokenize(StringTools.cutFirst(args , 6));
		long sessionId = System.nanoTime();
		
		distributedDecoding(
			sshCmd,
			serverList,
			command,
			tmpDir,
			configFile,
			inputFile,
			otherParams,
			sessionId
		);
	}
	
	public static void distributedDecoding(
		String sshCmd,
		String[] serverList,
		String command,
		String tmpDir,
		String configFile,
		String inputFile,
		String otherParams,
		long sessionId
	)
	throws IOException, InterruptedException
	{
		String[] fileIn = Tools.readFile(inputFile);
		String[] fileOut = new String[ fileIn.length ];
		if (!tmpDir.endsWith("/") || tmpDir.endsWith("\\"))
			tmpDir += "/";
		
		Process[] processes = new Process[serverList.length];
		MutableInt countFinished = new MutableInt(0);
		String[] thisFileName = new String[serverList.length];
		
		// split file in pieces
		int pieceLen = (fileIn.length + serverList.length - 1) / serverList.length;
		int pos = 0;
		for (int i = 0; i < serverList.length; i++)
		{
			thisFileName[i] = tmpDir + "tmp-in." + sessionId + "." + (i + 1);
			int len = Math.min(pieceLen , fileIn.length - pos);
			Tools.writeFile(thisFileName[i] , fileIn , pos , len);
			
			String thisCommandLine =
				sshCmd
				+ " "
				+ serverList[i]
				+ " "
				+ command
				+ " "
				+ tmpDir
				+ " "
				+ configFile
				+ " "
				+ thisFileName
				+ " "
				+ otherParams
				+ " "
				+ "-start-id "
				+ pos
				;
			// execute
			processes[i] = Runtime.getRuntime().exec(thisCommandLine);
			new StreamToStreamByLineThread(processes[i].getErrorStream() , System.err , "(" + (i+1) + ") ").start();
			new StreamToStringArray(fileOut , pos , len , new BufferedReader(new InputStreamReader(processes[i].getInputStream())) , countFinished)
				.start();

			pos += pieceLen;
		}
		
		
		// wait for all
		for (int i = 0; i < processes.length; i++)
			processes[i].waitFor();
		
		// make sure I captured all output
		while (true)
			synchronized (countFinished)
			{
				if (countFinished.value == processes.length)
					break;
//				System.err.println( countFinished.value );
				countFinished.wait();
			}

		// delete temp files
		for (int i = 0; i < thisFileName.length; i++)
			new File( thisFileName[i] ).delete();
		
		// dump to output
		for (int i = 0; i < fileOut.length; i++)
			System.out.println(fileOut[i]);
		
	}
}
