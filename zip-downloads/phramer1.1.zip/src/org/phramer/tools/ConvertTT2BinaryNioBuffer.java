/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.tools;
import info.olteanu.interfaces.*;
import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import org.phramer.*;
import org.phramer.lib.vocabulary.*;
import org.phramer.v1.decoder.*;
import org.phramer.v1.decoder.lm.*;
import org.phramer.v1.decoder.lm.ngram.*;
import org.phramer.v1.decoder.lm.preprocessor.*;
import org.phramer.v1.decoder.loader.*;
import org.phramer.v1.decoder.loader.custom.*;
import org.phramer.v1.decoder.math.*;
import org.phramer.v1.decoder.table.*;
import org.phramer.v1.decoder.token.*;
import org.phramer.v1.decoder.table.wordalignment.*;
import java.util.*;

public class ConvertTT2BinaryNioBuffer
implements LMLoader , TTLoader , TranslationTableToolsExtra.LineCollector
{
	public LMLoader getCloneForConcurrencyLML() throws PhramerException
	{
		throw new PhramerException("Not implemented. Should be?");
	}
	public TTLoader getCloneForConcurrencyTTL() throws PhramerException
	{
		throw new PhramerException("Not implemented. Should be?");
	}
	
	private final Vocabulary vE,vF;
	private final String fileVocF, fileVocE;
	private boolean vLoaded;
	
	private final String fileAlignment;
	private final Map<Object,Integer> alignmentMap;
	private boolean alignLoaded;
	
	private FileOutputStream outE , outIdx;
	private FileChannel fcE , fcIdx;
	private final PrintStream fileMeta;
	
	private int posE = 0;
	private int cntEntries=0;
	
	public void collect(String[] f, TranslationTableToolsExtra.SpecialTableLine[] lines)
	throws IOException
	{
		cntEntries++;
		posE = TranslationTableToolsExtra.writeNioFiles(f ,
														lines ,
														posE ,
														fcE ,
														fcIdx ,
														vF ,
														vE ,
														alignmentMap);
	}
	
	
	
	public LMPreprocessor loadPreprocessor(String lmFileName, int index) throws IOException, PhramerException
	{
		return new LMPreprocessorWord(StringFilter.VOID);
	}
	
	public LanguageModelIf loadLanguageModel(String lmURL, String encodingTextFile, int index) throws IOException, PhramerException
	{
		return new SimpleBackOffLM();
	}
	
	public TranslationTable loadTranslationTable(TokenBuilder tokenBuilder, String ttURL, String encodingTextFile, WordAlignmentBuilder wordAlignmentBuilder , int ttLimit, int maxPhraseLength, double ttThreshold, double[] ttTresholdWeights, boolean loadWordAlignment, boolean storeDetails) throws IOException, PhramerException
	{
		fileMeta.println("URL: " + ttURL);
		fileMeta.println("ttLimit: " + ttLimit);
		fileMeta.println("maxPhraseLength: " + maxPhraseLength);
		fileMeta.println("ttThreshold: " + ttThreshold);
		fileMeta.print("ttTresholdWeights:");
		for (double ttTresholdWeight : ttTresholdWeights)
			fileMeta.print(" " + ttTresholdWeight);
		fileMeta.println();
		
		MutableInt type = new MutableInt(0);
		MutableInt alignmentConfig = new MutableInt(WordAlignmentTypes.TYPE_NONE);
		MutableBool nio = new MutableBool();
		ttURL = LoaderSimpleImpl.parseMemoryTT(ttURL, loadWordAlignment , type , alignmentConfig , nio);
		
		if (nio.value)
			throw new PhramerException("Cannot use java.nio.Buffer translation tables here!!!");
		
		if ((type.value & Constants.FEATURE_SORTED) == 0)
			System.err.println("Note: Binary conversion currently requires sorted translation tables");
		
		boolean hasAlign = alignmentConfig.value != WordAlignmentTypes.TYPE_NONE && alignmentConfig.value != WordAlignmentTypes.TYPE_ILLEGAL;
		fileMeta.println("hasAlign: " + hasAlign);
		// check if the vocabularies are there. If not, build
		if (!vLoaded || (!alignLoaded && hasAlign))
		{
			System.err.println("Extracting vocabularies...");
			fileMeta.println("Extracting vocabularies/alignment start: " + new Date());
			GetVocabulariesForTT.extractVocabulary(
				ttURL , !vLoaded ? fileVocF : null , !vLoaded ? fileVocE : null , hasAlign ? fileAlignment : null , encodingTextFile , maxPhraseLength , Integer.MAX_VALUE , wordAlignmentBuilder , alignmentConfig.value);
			
			if (!vLoaded)
			{
				TranslationTableToolsExtra.readVocab(fileVocF , vF);
				TranslationTableToolsExtra.readVocab(fileVocE , vE);
			}
			fileMeta.println("Extracting vocabularies/alignment end: " + new Date());
			
			if (hasAlign)
				populateAlignmentMap(alignmentMap , TranslationTableToolsExtra.readAlign(fileAlignment));
			
			vLoaded = true;
			if (hasAlign)
				alignLoaded = true;
		}
		
		MutableInt size = new MutableInt(0);
		MutableInt sizeFinal = new MutableInt(0);
		Chronometer c = new Chronometer(true);
		fileMeta.println("Conversion start: " + new Date());
		TranslationTableToolsExtra.parseSortedTextTranslationTable(
			alignmentConfig.value ,
			wordAlignmentBuilder ,
			this ,
			new BufferedReader(new InputStreamReader(IOTools.getInputStream(ttURL) , encodingTextFile)) ,
			MathTools.numberToLog(ttThreshold),
			ttTresholdWeights ,
			ttLimit ,
			maxPhraseLength ,
			true ,
			size ,
			sizeFinal);
		fileMeta.println("Conversion end: " + new Date());
		System.err.println("Translation table loaded in " + StringTools.formatDouble(c.getValue() * 0.001 , "0.0#")
						   + " secs. Kept " + sizeFinal.value + "/" + size.value + " = " +
						   StringTools.formatDouble(100.0 * sizeFinal.value / size.value , "0.0") + "%");
		System.err.println("F entries: " + cntEntries);

		fileMeta.println("Kept " + sizeFinal.value + "/" + size.value + " = " +
						 StringTools.formatDouble(100.0 * sizeFinal.value / size.value , "0.0") + "%");
		fileMeta.println("F entries: " + cntEntries);
		fileMeta.println("Generation end: " + new Date());
		fileMeta.close();
		return null;
	}
	
	public ConvertTT2BinaryNioBuffer(String outFile , String cmdLine[]) throws IOException
	{
		fileMeta = new PrintStream(new FileOutputStream(outFile + ".meta") , true , "UTF-8");
		fileMeta.println("Destination file (base): " + outFile);
		fileMeta.println("Command line: " + StringTools.untokenize(cmdLine));
		fileMeta.println("Vocabulary files preload: " + vLoaded);
		fileMeta.println("Generation start: " + new Date());
		
		fileVocF = outFile + ".vocf";
		fileVocE = outFile + ".voce";
		vE = new Vocabulary();
		vF = new Vocabulary();
		
		vLoaded = new File(fileVocF).exists()
			&& new File(fileVocE).exists();
		if (vLoaded)
		{
			TranslationTableToolsExtra.readVocab(fileVocE , vE);
			TranslationTableToolsExtra.readVocab(fileVocF , vF);
		}
		
		fileAlignment = outFile + ".align";
		alignmentMap = new HashMap<Object, Integer>();
		alignLoaded = new File(fileAlignment).exists();
		if (alignLoaded)
			populateAlignmentMap(alignmentMap , TranslationTableToolsExtra.readAlign(fileAlignment));
		
		
		outE = new FileOutputStream(outFile + ".data");
		fcE = outE.getChannel();
		
		outIdx = new FileOutputStream(outFile + ".idx");
		fcIdx = outIdx.getChannel();
		
	}
	
	private void populateAlignmentMap(Map<Object, Integer> alignmentMap, Object[] alignmentIdToAlignmentObject)
	{
		for (int i = 0; i < alignmentIdToAlignmentObject.length; i++)
			alignmentMap.put(new ByteArrayHasher((byte[])alignmentIdToAlignmentObject[i]), i);
	}
	
	
	
	
	public static void main(String[] args)
	throws Exception
	{
		//testEncoding();
		
		String fileOut = args[0];
		args = StringTools.cutFirst(args, 1);
		LoaderSimpleImpl loader = new LoaderSimpleImpl();
		ConvertTT2BinaryNioBuffer my = new ConvertTT2BinaryNioBuffer(fileOut , args);
		new PhramerConfig(
			args,
			new PhramerHelperCustom(loader ,
									new TokenBuilderWordOnly(null) ,
									my ,
									my ,
									loader) ,
			null
		);
		my.close();
		System.out.println("End");
	}
	
	private static void testEncoding() throws IOException
	{
		ByteBuffer b = ByteBuffer.allocate(1000);
		for (int i = 0; i < 1000000; i++)
		{
			NioBuffers.encodeVariableLengthInteger(b, i);
			b.flip();
			int v = NioBuffers.decodeVariableLengthInteger(b);
			if (v != i)
				throw new Error("Bad encoding for " + i);
			b.clear();
			if (i % 100000 == 0)
			{
				System.err.print(".");
				System.err.flush();
			}
		}
		for (int i = 0; i <= Integer.MAX_VALUE && i >= 0; i += 15)
		{
			NioBuffers.encodeVariableLengthInteger(b, i);
			b.flip();
			int v = NioBuffers.decodeVariableLengthInteger(b);
			if (v != i)
				throw new Error("Bad encoding for " + i + " (" + v  + ")");
			b.clear();
			if (i % 10000000 == 0)
			{
				System.err.print(".");
				System.err.flush();
			}
		}
		System.err.println();
	}
	private void close()
	{
		try
		{
			fcE.close();
		}
		catch (IOException e)
		{}
		try
		{
			outE.close();
		}
		catch (IOException e)
		{}
		try
		{
			fcIdx.close();
		}
		catch (IOException e)
		{}
		try
		{
			outIdx.close();
		}
		catch (IOException e)
		{}
	}
}
