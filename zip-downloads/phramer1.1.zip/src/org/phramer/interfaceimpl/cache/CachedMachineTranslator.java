/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.interfaceimpl.cache;
import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import info.olteanu.utils.objectcache.*;
import java.io.*;
import java.util.*;
import org.phramer.*;
import org.phramer.etc.*;

// it creates 16 object caches:
// Split by:
//  - xml
//  - chunk
//  - nbest vs. simple
//  - w/ metadata vs. w/o metadata
public class CachedMachineTranslator
extends MachineTranslatorBasicImpl
implements MachineTranslator
{
	private class CacheCallerTranslate implements ObjectCacheCaller<String,String>
	{
		private boolean chunk,xml;
		public CacheCallerTranslate(boolean xml , boolean chunk)
		{
			this.xml = xml;
			this.chunk = chunk;
		}
		public String callWhenMiss(String arg) throws Exception
		{
			return cached.translate(arg , 0 , xml , chunk);
		}
	}
	private class CacheCallerTranslateMeta implements ObjectCacheCaller<Pair<String,Map<String,String[]>>,String>
	{
		private boolean chunk,xml;
		public CacheCallerTranslateMeta(boolean xml , boolean chunk)
		{
			this.xml = xml;
			this.chunk = chunk;
		}
		public String callWhenMiss(Pair<String,Map<String,String[]>> arg) throws Exception
		{
			return cached.translate(arg.first , 0 , xml , chunk , arg.second);
		}
	}
	private class CacheCallerNbest implements ObjectCacheCaller<Pair<String,Integer>, String[]>
	{
		private boolean chunk,xml;
		public CacheCallerNbest(boolean xml , boolean chunk)
		{
			this.xml = xml;
			this.chunk = chunk;
		}
		public String[] callWhenMiss(Pair<String, Integer> arg) throws Exception
		{
			return cached.translateNBest(arg.first , xml , chunk , arg.second);
		}
	}
	private class CacheCallerNbestMeta implements ObjectCacheCaller<Triplet<String,Map<String,String[]>,Integer>, String[]>
	{
		private boolean chunk,xml;
		public CacheCallerNbestMeta(boolean xml , boolean chunk)
		{
			this.xml = xml;
			this.chunk = chunk;
		}
		public String[] callWhenMiss(Triplet<String,Map<String,String[]>,Integer> arg) throws Exception
		{
			return cached.translateNBest(arg.first , xml , chunk , arg.second , arg.third);
		}
	}
	
	private final MachineTranslator cached;
	private final ObjectCache<String, String> cacheT[][];
	private final ObjectCache<Pair<String,Map<String,String[]>>, String> cacheTM[][];
	private final ObjectCache<Pair<String,Integer>, String[]> cacheN[][];
	private final ObjectCache<Triplet<String,Map<String,String[]>,Integer>, String[]> cacheNM[][];
	
	public CachedMachineTranslator(MachineTranslator mt , int size)
	{
		this.cached = mt;
		cacheT = new ObjectCache[2][2];
		for (int i = 0; i < 2; i++)
			for (int j = 0; j < 2; j++)
				cacheT[i][j] = new ObjectCache
					<String,String>(new CacheCallerTranslate(i == 1, j == 1),
									size , size / 20 , false ,
									"CachedMachineTranslator.translate" + i + "." + j);
		
		cacheTM = new ObjectCache[2][2];
		for (int i = 0; i < 2; i++)
			for (int j = 0; j < 2; j++)
				cacheTM[i][j] = new ObjectCache
					<Pair<String,Map<String,String[]>>,String>(new CacheCallerTranslateMeta(i == 1, j == 1),
															   size , size / 20 , false ,
															   "CachedMachineTranslator.translate.meta" + i + "." + j);
		
		cacheN = new ObjectCache[2][2];
		for (int i = 0; i < 2; i++)
			for (int j = 0; j < 2; j++)
				cacheN[i][j] = new ObjectCache
					<Pair<String,Integer>, String[]>(new CacheCallerNbest(i == 1, j == 1),
													 size , size / 20 , false ,
													 "CachedMachineTranslator.nbest" + i + "." + j);
		
		cacheNM = new ObjectCache[2][2];
		for (int i = 0; i < 2; i++)
			for (int j = 0; j < 2; j++)
				cacheNM[i][j] = new ObjectCache
					<Triplet<String,Map<String,String[]>,Integer>, String[]>(new CacheCallerNbestMeta(i == 1, j == 1),
																			 size , size / 20 , false ,
																			 "CachedMachineTranslator.nbest.meta" + i + "." + j);
	}
	
	public boolean allowConcurrency()
	{
		return false;
	}
	
	public String getVersion()
	{
		return cached.getVersion();
	}
	
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		try
		{
			if (metaData == null)
				return cacheT[xml ?1: 0][chunk ?1: 0].getValue(fSentence , fSentence);
			else
			{
				Vector<String> v = new Vector<String>();
				v.add(fSentence);
				MetaDataTools.serialize(v, metaData);
				Object key = new StringArrayHasher(StringTools.array(v));
				
				return cacheTM[xml ?1: 0][chunk ?1: 0].getValue(key , new Pair<String, Map<String,String[]>>(fSentence, metaData));
			}
		}
		catch (PhramerException e)
		{
			throw e;
		}
		catch (IOException e)
		{
			throw e;
		}
		catch (RuntimeException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw new Error("unexpected", e);
		}
	}
	
	
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, Map<String,String[]> metaData, int nbestListSize) throws PhramerException, IOException
	{
		try
		{
			if (metaData == null)
				return cacheN[xml ?1: 0][chunk ?1: 0]
					.getValue(nbestListSize + "|" + fSentence , new Pair<String,Integer>(fSentence, nbestListSize));
			else
			{
				Vector<String> v = new Vector<String>();
				v.add(fSentence);
				v.add(String.valueOf(nbestListSize));
				MetaDataTools.serialize(v, metaData);
				Object key = new StringArrayHasher(StringTools.array(v));
				
				return cacheNM[xml ?1: 0][chunk ?1: 0]
					.getValue(key ,
							  new Triplet<String,Map<String,String[]>,Integer>(fSentence, metaData , nbestListSize));
			}
		}
		catch (PhramerException e)
		{
			throw e;
		}
		catch (IOException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw new Error("unexpected", e);
		}
	}
	
}
