/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.phramer.interfaceimpl.pooling;

import info.olteanu.utils.workpool.*;
import info.olteanu.utils.workpool.impl.*;
import info.olteanu.utils.workpool.service.*;
import java.io.*;
import org.phramer.*;
import org.phramer.interfaceimpl.pooling.*;
import java.util.*;

// code from MultiThreadedPhramerWrapper

public class WorkpoolMachineTranslator
implements MachineTranslator,
PooledService<MachineTranslator,AbstractTranslationTask,Exception,Exception>
{
	private final String version;
	private final Workpool<MachineTranslator,Exception> workpool;
	
	public WorkpoolMachineTranslator(Workpool<MachineTranslator,Exception> workpool , String version)
	{
		this.workpool = workpool;
		if (!workpool.isRunning())
			workpool.start();
		this.version = version;
	}
	
	public void enqueueTask(AbstractTranslationTask t)
	{
		workpool.add(t);
	}
	public void waitForCompletion() throws PhramerException,IOException
	{
		try
		{
			workpool.waitForCompletion();
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch (Exception e)
		{
			if (e instanceof RuntimeException)
				throw (RuntimeException)e;
			if (e instanceof PhramerException)
				throw (PhramerException)e;
			if (e instanceof IOException)
				throw (IOException)e;
			throw new Error("There should be no such exception here: " + e.getClass().getName() , e);
		}
		assert workpool.getOutputNE(true).size() == 0;
	}
	
	public boolean allowConcurrency()
	{
		return true;
	}
	
	public String getVersion()
	{
		return version;
	}
	
	private static class TranslateMtTask extends Task<MachineTranslator,Exception>
	{
		private final String fSentence;
		private final int sentenceIdx;
		private final boolean xml;
		private final boolean chunk;
		private final Map<String,String[]> metaData;
		public String output;
		TranslateMtTask(String fSentence, int sentenceIdx, boolean xml, boolean chunk, Map<String,String[]> metaData)
		{
			this.fSentence = fSentence;
			this.sentenceIdx = sentenceIdx;
			this.xml = xml;
			this.chunk = chunk;
			this.metaData = metaData;
		}
		public void execute(MachineTranslator resource) throws Exception
		{
			output = resource.translate(fSentence, sentenceIdx, xml, chunk, metaData);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk) throws PhramerException, IOException
	{
		return translate(fSentence, sentenceIdx, xml, chunk, null);
	}
	public String translate(String fSentence, int sentenceIdx, boolean xml, boolean chunk, Map<String,String[]> metaData) throws PhramerException, IOException
	{
		TranslateMtTask t = new TranslateMtTask(fSentence , sentenceIdx , xml , chunk, metaData);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch (Exception e)
		{
			if (e instanceof RuntimeException)
				throw (RuntimeException)e;
			if (e instanceof PhramerException)
				throw (PhramerException)e;
			if (e instanceof IOException)
				throw (IOException)e;
			throw new Error("There should be no such exception here: " + e.getClass().getName() , e);
		}
		
		return t.output;
	}
	
	
	private static class TranslateNbestMtTask extends Task<MachineTranslator,Exception>
	{
		private final String fSentence;
		private final boolean xml;
		private final boolean chunk;
		private final int nbestListSize;
		private final Map<String,String[]> metaData;
		public String[] output;
		
		TranslateNbestMtTask(String fSentence, boolean xml, boolean chunk, Map<String,String[]> metaData, int nbestListSize)
		{
			this.fSentence = fSentence;
			this.xml = xml;
			this.chunk = chunk;
			this.nbestListSize = nbestListSize;
			this.metaData = metaData;
		}
		public void execute(MachineTranslator resource) throws Exception
		{
			output = resource.translateNBest(fSentence, xml, chunk , metaData, nbestListSize);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, int nbestListSize) throws PhramerException, IOException
	{
		return translateNBest(fSentence, xml, chunk, null, nbestListSize);
	}
	public String[] translateNBest(String fSentence, boolean xml, boolean chunk, Map<String,String[]> metaData, int nbestListSize) throws PhramerException, IOException
	{
		TranslateNbestMtTask t = new TranslateNbestMtTask(fSentence , xml , chunk , metaData, nbestListSize);
		try
		{
			workpool.executeTask(t);
		}
		catch (InterruptedException e)
		{
			throw new PhramerException(e);
		}
		catch (Exception e)
		{
			if (e instanceof RuntimeException)
				throw (RuntimeException)e;
			if (e instanceof PhramerException)
				throw (PhramerException)e;
			if (e instanceof IOException)
				throw (IOException)e;
			throw new Error("There should be no such exception here: " + e.getClass().getName() , e);
		}
		
		return t.output;
	}
	
	
}
