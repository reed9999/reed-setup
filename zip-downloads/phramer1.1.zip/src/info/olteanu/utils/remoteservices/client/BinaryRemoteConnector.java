/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.client;

import info.olteanu.utils.io.*;
import info.olteanu.utils.lang.*;
import info.olteanu.utils.remoteservices.*;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;

public class BinaryRemoteConnector implements BinaryRemoteService
{
	public static final int PING_AFTER_X_MILLISECONDS = 10000;//10 secs
	public static final int RECONNECT_AFTER_X_MILLISECONDS = 1000; // 1 sec
	public static final boolean LOG = true;
	// prevents refactoring issues
	private static final String remoteExceptionName = new RemoteException().getClass().getName();
	
	private boolean keepAlive;
	private boolean autoReconnect;
	private long lastResponseTime = 0;
	private void setLastResponseTime()
	{
		lastResponseTime = System.currentTimeMillis();
	}
	private String serverName;
	private int port;
	
	private SocketChannel socket;
	private boolean stopped;
	public BinaryRemoteConnector(String url , boolean keepAlive , boolean connectNow)
	throws IOException
	{
		this(url, keepAlive, connectNow , true);
	}
	
	public BinaryRemoteConnector(String url , boolean keepAlive , boolean connectNow , boolean autoReconnect)
	throws IOException
	{
		stopped = false;
		
		if (!url.startsWith("remoteb:"))
			throw new MalformedURLException("Expected 'remoteb:...' Got: " + url);
		if (url.substring(8).indexOf(':') == -1)
			throw new MalformedURLException("Expected port number");
		
		decodeURL(url);
		
		this.keepAlive = keepAlive;
		this.autoReconnect = autoReconnect;
		
		socket = null;
		
		
		if (connectNow)
		{
			connect();
			if (!keepAlive)
				disconnect();
		}
	}
	
	private void decodeURL(String url)
	{
		// first, process URL
		assert url.startsWith("remoteb:");
		String x = url.substring(8);
		serverName = x.substring(0, x.indexOf(":"));
		x = x.substring(x.indexOf(":") + 1);
		if (x.indexOf('#') != -1)
			x = x.substring(0 , x.indexOf('#'));
		port = Integer.parseInt(x);
	}
	
	private void disconnect() throws IOException
	{
		socket.close();
		socket = null;
	}
	
	private void connect()
	throws IOException
	{
		if (stopped)
			throw new Error("Service stopped");
		if (socket == null)
		{
			socket = SocketChannel.open(new InetSocketAddress(serverName, port));
			//socket = new Socket(serverName , port);
			setLastResponseTime();
		}
		else
		if (autoReconnect)
		{
			if (System.currentTimeMillis() - lastResponseTime > PING_AFTER_X_MILLISECONDS)
			{
				try
				{
					ByteBuffer bb = ByteBuffer.allocate(LanguageConstants.SIZEOF_INT).putInt(-1);
					bb.flip();
					socket.write(bb);
					
					bb = NIOTools.readBytes(socket,LanguageConstants.SIZEOF_INT);
					
					setLastResponseTime();
				}
				catch ( IOException e )
				{
					socket = null;
					if (LOG)
						System.err.println("[RemoteConnector] Connection died (after long time). Reconnect");
					connect();
				}
			}
		}
	}
	
	
	
	public synchronized byte[] service(byte[] input) throws RemoteException
	{
		try
		{
			connect();
			
			byte[] response = doService(input);
			if (response == null && autoReconnect)
			{
				if (LOG)
					System.err.println("[RemoteConnector] Connection died (while servicing). Reconnect");
				disconnect();
				// reconnect, if fails, wait a little bit and reconnect
				try
				{
					connect();
				}
				catch (IOException e)
				{
					if (RECONNECT_AFTER_X_MILLISECONDS > 0)
					{
						try
						{
							Thread.sleep(RECONNECT_AFTER_X_MILLISECONDS);
						}
						catch (InterruptedException iExc)
						{}
						connect();
					}
					else
						throw e;
				}
				
				response = doService(input);
			}
			if (response == null)
				throw new IOException("No response (connection closed)");
			if (!keepAlive)
				disconnect();
			
			return response;
		}
		catch (IOException e)
		{
			socket = null;
			throw new RemoteException("RemoteConnector:IOException: " + e.getMessage() , e);
		}
	}
	private static final byte[] VOID = new byte[0];
	private byte[] doService(byte[] input) throws RemoteException, IOException
	{
		ByteBuffer bb = ByteBuffer.allocate(input.length + LanguageConstants.SIZEOF_INT);
		bb.putInt(input.length);
		bb.put(input);
		bb.flip();
		
		socket.write(bb);
		
		bb = NIOTools.readBytes(socket, LanguageConstants.SIZEOF_INT);
		int len = bb.getInt();
		
		if (len == -1 )
		{
			// exception
			bb = NIOTools.readBytes(socket, LanguageConstants.SIZEOF_INT);
			int lenX = bb.getInt();
			bb = NIOTools.readBytes(socket, lenX);
			byte[] b = new byte[lenX];
			bb.get(b);
			throw new RemoteException( new String( b , "UTF-8" ) );
		}
		if( len == -1 )
			return VOID;

		bb = NIOTools.readBytes(socket, len);
		byte[] b = new byte[len];
		bb.get(b);
		setLastResponseTime();
		return b;
	}
	public void finalize() throws Throwable
	{
		disconnect();
	}
	
	public synchronized void stop() throws IOException
	{
		stopped = true;
		if (keepAlive)
			disconnect();
	}
}
