/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.client;
import info.olteanu.utils.*;
import info.olteanu.utils.remoteservices.*;
import java.io.*;
import java.net.*;
import java.util.*;
import info.olteanu.utils.remoteservices.naming.*;

/** Connects to a remote service and execute service remote */
public class RemoteConnector implements RemoteService
{
	public static final int PING_AFTER_X_MILLISECONDS = 10000;//10 secs
	public static final int RECONNECT_AFTER_X_MILLISECONDS = 1000; // 1 sec
	public static final boolean LOG = true;
	// prevents refactoring issues
	private static final String remoteExceptionName = new RemoteException().getClass().getName();
	private String encoding = Constants.encoding;
	
	private boolean keepAlive;
	private boolean autoReconnect;
	private long lastResponseTime = 0;
	private void setLastResponseTime()
	{
		lastResponseTime = System.currentTimeMillis();
	}
	private String serverName;
	private int port;
	private Socket socket;
	private PrintStream outputStream;
	private BufferedReader inputStream;
	private boolean stopped;
	private boolean alwaysOneLine;
	
	public static RemoteConnector getRemoteConnector(String url)
	throws IOException
	{
		if ("1".equals(System.getProperty("remote-connector.mono")))
			return new RemoteConnector(url, false, false, false, false);
		else
			return new RemoteConnector(url, true, true, false, true);
	}
	
	public RemoteConnector(String url , boolean keepAlive , boolean connectNow , boolean alwaysOneLine)
	throws IOException
	{
		this(url, keepAlive, connectNow , alwaysOneLine , true);
	}
	
	public RemoteConnector(String url , boolean keepAlive , boolean connectNow , boolean alwaysOneLine , boolean autoReconnect)
	throws IOException
	{
		stopped = false;
		
		if (!url.startsWith("remote:"))
			throw new MalformedURLException("Expected 'remote:...' Got: " + url);
		if (url.substring(8).indexOf(':') == -1)
			throw new MalformedURLException("Expected port number");
		
		decodeURL(url);
		
		this.keepAlive = keepAlive;
		this.autoReconnect = autoReconnect;
		
		socket = null;
		outputStream = null;
		inputStream = null;
		
		this.alwaysOneLine = alwaysOneLine;
		
		if (connectNow)
		{
			connect();
			if (!keepAlive)
				disconnect();
		}
	}
	
	private void decodeURL(String url) throws IOException
	{
		if (url.indexOf('#') != -1)
			url = StringTools.substringBefore(url, "#");
		
		String[] parts = StringTools.tokenize(url, ":");
		assert parts[0].equals("remote");
		
		// if naming service required
		if (parts.length == 4)
			decodeURL(identifyService(url));
		
		serverName = parts[1];
		port = Integer.parseInt(parts[2]);
	}
	
	// cache access to naming service
	private static HashMap<String, String[]> nsMapping = new HashMap<String, String[]>();
	private static synchronized String identifyService(String url) throws IOException
	{
		if (nsMapping.containsKey(url))
			return selectRandomly(nsMapping.get(url));
		NamingService ns = new NamingRemoteService(new RemoteConnector(StringTools.lastSubstringBefore(url , ":"), false, false, false));
		String[] entries = ns.getEntries(StringTools.lastSubstringAfter(url, ":"));
		if (entries.length == 0)
			throw new IOException("No service registered in the NameService server: " + url);
		
		nsMapping.put(url, entries);
		return selectRandomly(entries);
	}
	
	// randomly picks one entry from the NS
	private static String selectRandomly(String[] a)
	{
		assert a.length > 0;
		if (a.length == 1)
			return a[0];
		
		int idx = ((int)(Math.random() * Integer.MAX_VALUE)) % a.length;
		
		return a[idx];
	}
	
	private void disconnect() throws IOException
	{
		outputStream.flush();
		socket.close();
		socket = null;
		inputStream = null;
		outputStream = null;
	}
	
	private void connect()
	throws IOException
	{
		if (stopped)
			throw new Error("Service stopped");
		if (socket == null)
		{
			socket = new Socket(serverName , port);
			setLastResponseTime();
			if (encoding != null)
			{
				outputStream = new PrintStream(socket.getOutputStream() , false , encoding);
				inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream(), encoding));
			}
			else
			{
				outputStream = new PrintStream(socket.getOutputStream() , false);
				inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			}
		}
		else
		if (autoReconnect)
		{
			if (System.currentTimeMillis() - lastResponseTime > PING_AFTER_X_MILLISECONDS)
			{
				try
				{
					outputStream.println("PING");
					inputStream.readLine();// read GNIP
					setLastResponseTime();
				}
				catch ( IOException e )
				{
					socket = null;
					if (LOG)
						System.err.println("[RemoteConnector] Connection died (after long time). Reconnect");
					connect();
				}
			}
		}
	}
	
	
	
	public synchronized String[] service(String[] input) throws RemoteException
	{
		try
		{
			connect();
			
			String[] response = doService(input);
			if (response == NO_RESPONSE_MARKER && autoReconnect)
			{
				if (LOG)
					System.err.println("[RemoteConnector] Connection died (while servicing). Reconnect");
				disconnect();
				// reconnect, if fails, wait a little bit and reconnect
				try
				{
					connect();
				}
				catch (IOException e)
				{
					if (RECONNECT_AFTER_X_MILLISECONDS > 0)
					{
						try
						{
							Thread.sleep(RECONNECT_AFTER_X_MILLISECONDS);
						}
						catch (InterruptedException iExc)
						{}
						connect();
					}
					else
						throw e;
				}
				
				response = doService(input);
			}
			if (response == NO_RESPONSE_MARKER)
				throw new IOException("No response (connection closed)");
			if (!keepAlive)
				disconnect();
			
			return response;
		}
		catch (IOException e)
		{
			socket = null;
			throw new RemoteException("RemoteConnector:IOException: " + e.getMessage() , e);
		}
	}
	
	
	private static final String[] NO_RESPONSE_MARKER = {"no response"}; // just a marker between doService() and service(); never returned to the RemoteConnector client
	private String[] doService(String[] input) throws RemoteException, IOException
	{
		// send request
		if (alwaysOneLine)
		{
			if (input.length != 1)
				throw new RemoteException("Mono-line communication expects one line only ");
			
			outputStream.print(input[0] + '\n');
		}
		else
			outputStream.print(ClientServerTools.sendData(input, -1));
		
		outputStream.flush();
		
		// now read response
		String line;
		String[] response;
		line = inputStream.readLine();
		if (line == null)
			return NO_RESPONSE_MARKER;//throw new IOException("No response");
		
		if (alwaysOneLine)
		{
			response = new String[1];
			response[0] = line;
		}
		else
		{
			if (line.equals("-1"))
			{
				// class
				String thisClass = inputStream.readLine();
				String thisMessage = inputStream.readLine();
				String causeClass = inputStream.readLine();
				String causeMessage = inputStream.readLine();
				// exception
				if (thisClass.equals(remoteExceptionName))
					throw new RemoteException(thisMessage);
				else
					throw new RemoteException("[" + thisClass + "] " + thisMessage + "\ncause=[" + causeClass + "] " + causeMessage);
			}
			
			response = ClientServerTools.recvData(inputStream , line, -2);
			
			setLastResponseTime();
		}
		return response;
	}
	public void finalize() throws Throwable
	{
		disconnect();
	}
	
	public synchronized void stop() throws IOException
	{
		stopped = true;
		if (keepAlive)
			disconnect();
	}
}
