/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices;
import java.io.*;

public class ClientServerTools
{
	private static final char escapeChar = '`';
	private static final String escapeStr = "" + escapeChar;
	private static final String escape2Str = escapeStr + escapeChar;
	private static final String escapeN = escapeStr + "n";
	private static final String escapeR = escapeStr + "r";
	
	public static String[] recvData(BufferedReader inReader, String line, int nullMarker)
	throws IOException
	{
		boolean inputWithNulls = line.charAt(0) == 'N';
		if (inputWithNulls)
			line = line.substring(1);
		
		boolean inputMultiline = line.charAt(0) == 'M';
		if (inputMultiline)
			line = line.substring(1);
		
		int nLines = Integer.parseInt(line);
		String[] lines;
		if (nLines == nullMarker)
			lines = null;
		else
		{
			lines = new String[nLines];
			for (int i = 0; i < lines.length; i++)
			{
				lines[i] = inReader.readLine();
				if (lines[i] == null)
					throw new IOException("my: Incomplete request");
				
				if (inputWithNulls)
					if (lines[i].length() == 0)
						lines[i] = null;
					else
						lines[i] = lines[i].substring(1);
				
				if (inputMultiline && lines[i] != null)
					lines[i] = unescape(lines[i]);
			}
		}
		
		return lines;
	}
	
	public static String sendData(String[] data, int nullMarker)
	{
		boolean dataWithNulls = false;// check if input/output has nulls
		boolean dataMultiline = false;// check if there are multilined elements in the input/output
		if (data != null)
		{
			for (int i = 0; i < data.length; i++)
				if (data[i] == null)
				{
					dataWithNulls = true;
					break;
				}
			for (int i = 0; i < data.length; i++)
				if (data[i] != null && (data[i].indexOf('\n') != -1 || data[i].indexOf('\r') != -1))
				{
					dataMultiline = true;
					break;
				}
		}
		
		StringBuilder sb = new StringBuilder();
		if (data == null)
			sb.append(nullMarker).append('\n');
		else if (dataWithNulls)
		{
			// output contains some nulls
			sb.append("N");
			if (dataMultiline)
				sb.append("M");
			sb.append(data.length).append('\n');
			for (int i = 0; i < data.length; i++)
			{
				if (data[i] != null)
					sb.append(":").append(dataMultiline ? escape(data[i]) : data[i]);
				sb.append('\n');
			}
		}
		else
		{
			if (dataMultiline)
				sb.append("M");
			sb.append(data.length).append('\n');
			for (int i = 0; i < data.length; i++)
				sb.append(dataMultiline ? escape(data[i]) : data[i]).append('\n');
		}
		
		return sb.toString();
	}
	
	
	private static String escape(String l)
	{
		if(l == null)
			return null;
		
		if (l.indexOf(escapeChar) != -1)
			l = l.replace(escapeStr, escape2Str);
		
		l = l.replace("\n", escapeN);
		l = l.replace("\r", escapeR);
		
		return l;
	}
	
	
	private static String unescape(String l)
	{
		if(l == null)
			return null;

		l = l.replace(escapeR , "\r");
		l = l.replace(escapeN , "\n");
		
		if (l.indexOf(escapeChar) != -1)
			l = l.replace(escape2Str, escapeStr);
		
		return l;
	}
	
}
