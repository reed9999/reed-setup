/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.naming.impl;
import info.olteanu.utils.*;
import info.olteanu.utils.remoteservices.naming.*;
import info.olteanu.utils.remoteservices.server.*;
import java.util.*;

public class SimpleNamingServiceImpl implements NamingService
{
	private final HashMap<String,String[]> hash;
	public SimpleNamingServiceImpl()
	{
		hash = new HashMap<String, String[]>();
	}
	
	public synchronized boolean setEntry(String name, String address)
	{
		String[] entries = getEntries(name);
		if (entries.length == 0)
		{
			hash.put(name, new String[]{address});
			return false;
		}
		if (StringTools.inArray(entries, address))
			return true;
		
		hash.put(name, StringTools.append(entries, address));
		return false;
	}
	
	
	public synchronized boolean removeEntry(String name, String address)
	{
		String[] entries = getEntries(name);
		if (StringTools.inArray(entries, address))
		{
			// remove
			hash.put(name, StringTools.removeFirst(entries , address));
			return true;
		}
		return false;
	}
	
	private final static String[] VOID = new String[0];
	public synchronized String[] getEntries(String name)
	{
		if (hash.containsKey(name))
			return hash.get(name);
		return VOID;
	}
	
	
	public static void main(String[] args)
	throws Exception
	{
		int port = Integer.parseInt(args[0]);
		
		NamingService ns = new SimpleNamingServiceImpl();
		
		Server server = new Server(new ServerWrapperNamingService(ns) , port);
		server.autoDisconnectTime = 20000;
		server.debugLevel = 2;
		System.out.println("Providing service on port " + port + " ...");
		server.start();
	}
}
