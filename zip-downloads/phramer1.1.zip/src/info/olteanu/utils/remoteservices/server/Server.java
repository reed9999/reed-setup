/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.server;
import info.olteanu.utils.*;
import info.olteanu.utils.remoteservices.*;
import java.io.*;
import java.net.*;
import info.olteanu.utils.remoteservices.naming.*;
import info.olteanu.utils.remoteservices.client.*;

public class Server
{
	/** The time for auto-disconnect, in ms */
	public int autoDisconnectTime = 0;
	public int debugLevel = 0;
	private RemoteService service;
	protected int port;
	protected boolean active = false;
	
	private int cntIn = 0;
	private int cntConn = 0;
	private long timeStamp = -1;
	private Object syncObj = new Object();
	
	/*  Monitor related stuff */
	public int monitorDelayMilliseconds = 5000;// 5 seconds
	private boolean activeMonitor;
	// global number of requests
	private long globalNR = 0;
	private Object lockGlobal = new Object();
	private Thread monitorThread = null;
	
	private class Monitor extends Thread
	{
		public Monitor()
		{
			super("Server Monitor");
		}
		private long lastNR = 0;
		public void run()
		{
			while (true)// I can also use !isInterrupted()
			{
				try
				{
					Thread.sleep(monitorDelayMilliseconds);
				}
				catch (InterruptedException e)
				{
					return;
				}
				
				synchronized (lockGlobal)
				{
					if (lastNR != globalNR)
						System.err.println("[" + new java.util.Date() + "] Total serviced requests: " + globalNR);
					
					lastNR = globalNR;
				}
			}
		}
	}
	
	/* ^ Monitor related stuff */
	
	public Server(RemoteService service , int port)
	{
		this.service = service;
		this.port = port;
		this.ns = null;
		this.serviceName = null;
		this.serviceAddress = null;
	}
	
	private NamingService ns;
	private String serviceName, serviceAddress;
	public Server(RemoteService service , String addr)
	throws IOException
	{
		this.service = service;
		try
		{
			this.port = Integer.parseInt(addr);
		}
		catch ( NumberFormatException e )
		{
			// Parse it
			//computer44:1000-remote:computer01:1999:mtAR
			String localAddr = StringTools.substringBefore(addr , "-");
			this.port = Integer.parseInt(StringTools.substringAfter(localAddr, ":"));
			String nsAddrAndName = StringTools.substringAfter(addr , "-");
			String nsAddr = StringTools.lastSubstringBefore(nsAddrAndName, ":");
			String serviceName = StringTools.lastSubstringAfter(nsAddrAndName, ":");
			
			this.ns = new NamingRemoteService(new RemoteConnector(nsAddr , false , false , false));
			this.serviceName = serviceName;
			this.serviceAddress = "remote:" + localAddr;
		}
	}
	
	class Accepter extends Thread
	{
		public void run()
		{
			try
			{
				ServerSocket server = new ServerSocket(port);
				server.setSoTimeout(5000);
				while (active)
					try
					{
						// accept a new client and continue
						new ServiceClient(server.accept(), service).start();
					}
					catch ( SocketTimeoutException e )
					{
						// ignore: designed to inspect active variable
					}
				server.close();
				if (debugLevel >= 1)
					System.out.println("[" + new java.util.Date() + "] Server stopped. Clients might be still active. New requests not accepted.");
			}
			catch (IOException e)
			{
				System.err.println("[" + new java.util.Date() + "] Failure in accepting: " + e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
	class ServiceClient extends Thread
	{
		private final Socket socket;
		private final RemoteService service;
		ServiceClient(Socket socket, RemoteService service)
		{
			this.socket = socket;
			this.service = service;
		}
		public void run()
		{
			long nR = 0;
			try
			{
				socket.setSoTimeout(autoDisconnectTime);
				if (debugLevel >= 2)
				{
					System.out.println("[" + new java.util.Date() + "] New connection from " + socket.getRemoteSocketAddress());
					System.out.println("[" + new java.util.Date() + "] Currently servicing " + cntConn + " other connections and " + cntIn + " requests"
									   + (timeStamp == -1 ? "" : " for " + StringTools.formatDouble(0.000000001 * (System.currentTimeMillis() - timeStamp), "0.000") + " s")
									   );
					synchronized (syncObj)
					{
						cntConn++;
					}
				}
				// service a client
				PrintStream outPrinter = new PrintStream(socket.getOutputStream() , false , Constants.encoding);// explicit flush
				InputStreamReader r = Constants.encoding != null ? new InputStreamReader(
					socket.getInputStream(),
					Constants.encoding) :
					new InputStreamReader(
					socket.getInputStream());
				//System.out.println( "Encoding: " + r.getEncoding() );
				BufferedReader inReader = new BufferedReader(r);
				String line = null;
				while (true)
				{
					line = inReader.readLine();
					// end of request
					if (line == null)
					{
						outPrinter.flush();
						if (debugLevel >= 2)
							System.out.println("[" + new java.util.Date() + "] Client closed the connection after " + nR + " requests");
						socket.close();
						return;
					}
					if (line.equals("PING"))
					{
						if (debugLevel >= 3)
							System.out.println("[" + new java.util.Date() + "] Ping received");
						
						outPrinter.println("GNIP");
						outPrinter.flush();
						continue;
					}
					
					String[] lines = ClientServerTools.recvData(inReader , line , -1);
					
					nR++;
					if (activeMonitor)
						synchronized (lockGlobal)
						{
							globalNR++;
						}
					
					_printDebug_input(lines);
					
					// process:
					try
					{
						long thisTimestamp = _debug_preProcess();
						String[] output = service.service(lines);
												
						_debug_postProcess(thisTimestamp);
						_printDebug_output(output);
						
						outPrinter.print(ClientServerTools.sendData(output, -2));
					}
					catch (RemoteException e)
					{
						// return error
						returnException(outPrinter, e);
					}
					catch (RuntimeException e)
					{
						e.printStackTrace();
						// return error
						returnException(outPrinter, e);
					}
					outPrinter.flush();
					if (debugLevel >= 3)
						System.out.println("[" + new java.util.Date() + "] Response sent");
					
					// useful??
					if (outPrinter.checkError())
					{
						socket.close();
						return;
					}
				}
			}
			catch ( IOException e )
			{
				System.err.println("[" + new java.util.Date() + "] Failure in servicing client (after " + nR + " requests): " + e.getMessage());
				try
				{
					socket.close();
				}
				catch (IOException e1)
				{}
			}
			// sometime it happens. and when it happens, it's bad enough to drop the server
			catch ( NoClassDefFoundError e )
			{
				e.printStackTrace();
				System.exit(1);
			}
			finally
			{
				try
				{
					socket.close();
				}
				catch (IOException e1)
				{}
				synchronized (syncObj)
				{
					cntConn--;
				}
			}
		}
		
		private void _debug_postProcess(long thisTimestamp)
		{
			if (debugLevel >= 2)
				synchronized (syncObj)
				{
					if (timeStamp == thisTimestamp)
						timeStamp = -1;
					cntIn--;
				}
		}
		
		private long _debug_preProcess()
		{
			long thisTimestamp = -1;
			
			if (debugLevel >= 2)
				synchronized (syncObj)
				{
					thisTimestamp = System.currentTimeMillis();
					if (cntIn == 0 || timeStamp == -1)
						timeStamp = thisTimestamp;
					cntIn++;
				}
			return thisTimestamp;
		}
		
		private void _printDebug_input(String[] lines)
		{
			if (debugLevel >= 3)
				System.out.println("[" + new java.util.Date() + "] Request received (" + (lines == null ? -1 : lines.length) + " lines)");
			
			if (debugLevel >= 4)
				if (lines == null)
					System.out.println("<request NULL/>");
				else
				{
					System.out.println("<request>");
					for (int i = 0; i < lines.length; i++)
					{
						System.out.print("\t");
						System.out.print(lines[i]);
						if (lines[i] == null)
							System.out.println("\t (no chars)");
						else
							System.out.println("\t (" + lines[i].length() + " chars)");
					}
					System.out.println("</request>");
				}
		}
		
		
		private void _printDebug_output(String[] output)
		{
			if (debugLevel == 4)
				System.out.println("<response length='" + (output == null ? -1 : output.length) + "'/>");
			else
			if (debugLevel >= 5)
			{
				System.out.println("<response length='" + (output == null ? -1 : output.length) + "'>");
				if (output != null)
					for (int i = 0; i < output.length; i++)
					{
						System.out.print("\t");
						System.out.println(output[i]);
					}
				System.out.println("</response>");
			}
		}
		
		
		private void returnException(PrintStream outPrinter, Throwable e)
		{
			if (e.getCause() == null)
				outPrinter.print("-1\n"
								 + e.getClass().getName() + "\n"
								 + e.getMessage()
								 + "\n\n\n");
			else
				outPrinter.print("-1\n"
								 + e.getClass().getName() + "\n"
								 + e.getMessage() + "\n"
								 + e.getCause().getClass().getName() + "\n"
								 + e.getCause().getMessage() +
								 "\n");
			if (debugLevel >= 4)
			{
				System.out.println("<response>");
				System.out.println("\t<exception>");
				System.out.println("\t\t" + e.getMessage());
				System.out.println("\t</exception>");
				System.out.println("</response>");
			}
		}
	}
	
	
	public void start()
	{
		if (debugLevel >= 1)
			System.out.println("[" + new java.util.Date() + "] Listening...");
		if (ns != null)
			ns.setEntry(serviceName, serviceAddress);
		synchronized (this)
		{
			active = true;
			
			if (debugLevel >= 2)
				synchronized (lockGlobal)
				{
					activeMonitor = true;
					// start monitor thread
					monitorThread = new Monitor();
					monitorThread.setDaemon(true);
					monitorThread.start();
				}
			
			// put a shutdown hook, to stop the server
			hook = new StopThread(this);
			Runtime.getRuntime().addShutdownHook(hook);
			
			new Accepter().start();
		}
	}
	private Thread hook = null;
	private static class StopThread extends Thread
	{
		
		private final Server s;
		private StopThread(Server s)
		{
			this.s = s;
		}
		public void run()
		{
			s.hook = null;
			s.stop();
		}
	}
	
	public void stop()
	{
		if (debugLevel >= 1)
			System.out.println("[" + new java.util.Date() + "] Request to stop...");
		if (ns != null)
			ns.removeEntry(serviceName, serviceAddress);
		
		synchronized (this)
		{
			if (hook != null)
			{
				Runtime.getRuntime().removeShutdownHook(hook);
				hook = null;
			}
			active = false;
			
			if (activeMonitor)
				synchronized (lockGlobal)
				{
					activeMonitor = false;
					// stop monitor thread
					monitorThread.interrupt();
					// let it be garbage collected
					monitorThread = null;
				}
			
		}
	}
}
