/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.server;
import info.olteanu.utils.io.*;
import info.olteanu.utils.lang.*;
import info.olteanu.utils.remoteservices.*;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;

public class BinaryServer
{
	public int debugLevel = 0;
	private BinaryRemoteService service;
	private int port;
	private boolean active = false;
	public BinaryServer(BinaryRemoteService service , int port)
	{
		this.service = service;
		this.port = port;
	}
	
	
	class Accepter extends Thread
	{
		public void run()
		{
			try
			{
				ServerSocketChannel server = ServerSocketChannel.open();
				InetSocketAddress isa
					= new InetSocketAddress(port);
				server.socket().bind(isa);
				
				while (active)
					try
					{
						// accept a new client and continue
						new ServiceClient(server.accept()).start();
					}
					catch ( SocketTimeoutException e )
					{
						// ignore: designed to inspect active variable
					}
				server.close();
				if (debugLevel >= 1)
					System.out.println("[" + new java.util.Date() + "] Server stopped. Clients might be still active. New requests not accepted.");
			}
			catch (IOException e)
			{
				System.err.println("[" + new java.util.Date() + "] Failure in accepting: " + e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
	class ServiceClient extends Thread
	{
		private final SocketChannel socket;
		ServiceClient(SocketChannel socket)
		{
			this.socket = socket;
		}
		public void run()
		{
			try
			{
				if (debugLevel >= 2)
					System.out.println("[" + new java.util.Date() + "] New connection");
				// service a client
				
				int nR = 0;
				while (true)
				{
					// read command
					ByteBuffer bb;
					try
					{
						bb = NIOTools.readBytes(socket, LanguageConstants.SIZEOF_INT);
					}
					catch (EOFException e )
					{
						if (debugLevel >= 2)
							System.out.println("[" + new java.util.Date() + "] Client closed the connection after " + nR + " requests");
						socket.close();
						return;
					}
					int len = bb.getInt();
					if (len == -1)// ping
					{
						if (debugLevel >= 3)
							System.out.println("[" + new java.util.Date() + "] Ping received");
						bb.rewind();
						socket.write(bb);
						continue;
					}
					
					ByteBuffer req = NIOTools.readBytes(socket, len);
					nR++;
					if (debugLevel >= 3)
						System.out.println("[" + new java.util.Date() + "] Request received (" + len + " bytes)");
					
					// process:
					try
					{
						byte[] output = service.service(req.array());
						bb = ByteBuffer.allocate(output.length + LanguageConstants.SIZEOF_INT);
						bb.putInt(output.length);
						bb.put(output);
						bb.flip();
						
						socket.write(bb);
					}
					catch (RemoteException e)
					{
						// return error
						returnException(socket, "[" + e.getClass().getName() + "] " + e.getMessage() );
					}
					catch (RuntimeException e)
					{
						e.printStackTrace();
						// return error
						returnException(socket, "[" + e.getClass().getName() + "] " + e.getMessage() );
					}
					
					if (debugLevel >= 3)
						System.out.println("[" + new java.util.Date() + "] Response sent");
					
				}
			}
			catch ( IOException e )
			{
				System.err.println("[" + new java.util.Date() + "] Failure in servicing client: " + e.getMessage());
				try
				{
					socket.close();
				}
				catch (IOException e1)
				{}
			}
			// sometime it happens. and when it happens, it's bad enough to drop the server
			catch ( NoClassDefFoundError e )
			{
				e.printStackTrace();
				System.exit(1);
			}
		}
		
		private void returnException(SocketChannel out, String e) throws IOException
		{
			try
			{
				byte[] x = e.getBytes("UTF-8");
				ByteBuffer bb = ByteBuffer.allocate(x.length + 8);
				bb.putInt(-1);
				bb.putInt(x.length);
				bb.put(x);
				bb.flip();
				
				socket.write(bb);
			}
			catch (UnsupportedEncodingException exc)
			{
				throw new Error(exc);
			}
			
			if (debugLevel >= 4)
			{
				System.out.println("<response>");
				System.out.println("\t<exception>");
				System.out.println("\t\t" + e);
				System.out.println("\t</exception>");
				System.out.println("</response>");
			}
		}
	}
	
	
	public void start()
	{
		if (debugLevel >= 1)
			System.out.println("[" + new java.util.Date() + "] Listening...");
		synchronized (this)
		{
			active = true;
			new Accepter().start();
		}
	}
	
	public void stop()
	{
		if (debugLevel >= 1)
			System.out.println("[" + new java.util.Date() + "] Request to stop...");
		synchronized (this)
		{
			active = false;
		}
	}
}
