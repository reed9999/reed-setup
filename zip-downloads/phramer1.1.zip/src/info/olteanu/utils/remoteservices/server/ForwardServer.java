/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.server;

import info.olteanu.utils.remoteservices.client.*;
import java.io.*;
import java.net.*;

public class ForwardServer extends Server
{
	/** The time for auto-disconnect, in ms */
	private String remoteAddress;
	public ForwardServer(String remoteAddress , int port)
	{
		super(null, port);
		this.remoteAddress = remoteAddress;
	}
	
	class AccepterFw extends Thread
	{
		public void run()
		{
			if (debugLevel >= 2)
				System.out.println("[" + new java.util.Date() + "] Forward service");
			try
			{
				ServerSocket server = new ServerSocket(port);
				server.setSoTimeout(5000);
				while (active)
					try
					{
						// accept a new client and continue
						new Server.ServiceClient(server.accept() , new RemoteConnector(remoteAddress, true , true , false , true)).start();
					}
					catch ( SocketTimeoutException e )
					{
						// ignore: designed to inspect active variable
					}
				server.close();
				if (debugLevel >= 1)
					System.out.println("[" + new java.util.Date() + "] Server stopped. Clients might be still active. New requests not accepted.");
			}
			catch (IOException e)
			{
				System.err.println("[" + new java.util.Date() + "] Failure in accepting: " + e.getMessage());
				e.printStackTrace();
			}
		}
	}
	public void start()
	{
		if (debugLevel >= 1)
			System.out.println("[" + new java.util.Date() + "] Listening...");
		synchronized (this)
		{
			active = true;
			new AccepterFw().start();
		}
	}
}
