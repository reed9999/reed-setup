/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.distributed.loadbalancing;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.remoteservices.*;
import java.util.*;

public class LoadBalancingServer implements RemoteService
{
	private static final String[] MULTIPLE = {"MULTIPLE"};
	private static final String[] NOW = {"NOW"};
	private static final String[] NO_STATS = {"NO_STATS"};
	private final RemoteService rs;
	private Vector<Chronometer> chrons = new Vector<Chronometer>();
	private int load = 0;
	private int totalQueries = 0;
	private long totalTime = 0;
	public LoadBalancingServer(RemoteService rs)
	{
		this.rs = rs;
	}
	public String[] service(String[] input) throws RemoteException
	{
		if (input.length == 0)
			throw new RemoteException("LoadBalancingServer doesn't take void input");
		
		if (input[0].equals("execute"))
		{
			Chronometer c = new Chronometer();
			synchronized (this)
			{
				load++;
				chrons.add(c);
			}
			String[] newInput = new String[input.length - 1];
			System.arraycopy(input , 1 , newInput, 0 , newInput.length);
			c.start();
			String output[] = rs.service(newInput);
			c.stop();
			synchronized (this)
			{
				load--;
				chrons.remove(c);
				totalQueries++;
				totalTime += c.getValue();
			}
			return output;
		}
		
		// commands
		if (input[0].equals("load"))
		{
			String[] output = {String.valueOf(load)};
			return output;
		}
		if (input[0].equals("eta-free"))
			synchronized (this)
			{
				if (load == 0)
					return NOW;
				
				if (load != 1)
					return MULTIPLE;
				
				if (totalQueries <= 5)
					return NO_STATS;
				
				// get average time
				long avgTime = totalTime / totalQueries;
				
				String[] out = new String[0];
				out[0] = Long.toString(avgTime - chrons.firstElement().getValue());
				
				return out;
			}
		
		throw new RemoteException("Unknown command");
	}
	
}
