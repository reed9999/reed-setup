/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.distributed;

import info.olteanu.utils.lang.*;
import info.olteanu.utils.remoteservices.*;
import java.util.*;
import info.olteanu.utils.workpool.*;
import info.olteanu.utils.workpool.impl.*;

// Splits a RemoteService request by size and distributes it on multiple RemoteService objects
// It assumes requests have prefixes and suffixes.
// It also assumes that a request is a block request of one-line function calls
// I.e.: (prefix request: 3, prefix response: 1, piece size: 3)
//    function1
//    43
//    abc
//    value 1
//    value 2
//    value 3
//    value 4
//    value 5
// will be split into:
//    function1
//    43
//    abc
//    value 1
//    value 2
//    value 3
// and
//    function1
//    43
//    abc
//    value 4
//    value 5
// and the response will be like:
//    response function 1
//    vv
//    vx
//    va
// and
//    response function 1
//    v1
//    v2
// so this class will reply:
//    response function 1
//    vv
//    vx
//    va
//    v1
//    v2
public class JobSplitLoadBalancing implements RemoteService
{
	public boolean DEBUG = false;
	private final HashMap<String, IntPair> prefixLength;
	private final IntPair defaultPrefixLength;
	private final int chunkSize;
	private final RemoteService[] rs;
	private final Workpool<RemoteService,RemoteException> wp;
	
	public JobSplitLoadBalancing(RemoteService[] rs ,
								 int chunkSize ,
								 HashMap<String,IntPair> prefixLength ,
								 int defaultPrefixLengthRequest ,
								 int defaultPrefixLengthResponse)
	{
		this.rs = rs;
		this.chunkSize = chunkSize;
		this.prefixLength = prefixLength;
		this.defaultPrefixLength = new IntPair(defaultPrefixLengthRequest, defaultPrefixLengthResponse);
		this.wp = new MultiThreadedWorkpoolImpl<RemoteService,RemoteException>(rs , true);
		wp.start();
	}
	
	
	private static class RemoteServiceTask extends Task<RemoteService,RemoteException>
	{
		private final String input[];
		public String[] output;
		public final int offset;
		
		RemoteServiceTask(int offset , String[] input)
		{
			this.offset = offset;
			this.input = input;
			this.output = null;
		}
		/**
		 * Returs true if it should be added to the output pool
		 */
		public void execute(RemoteService resource)
		throws RemoteException
		{
			output = resource.service(input);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	public String[] service(String[] input) throws RemoteException
	{
		if (input.length <= chunkSize)
			return rs[rand()].service(input);
		
		// classify
		IntPair prefixSize = getPrefixSize(input);
		assert prefixSize.first >= 0 && prefixSize.second >= 0;
		if (input.length - prefixSize.first <= chunkSize)
			return rs[rand()].service(input);
		
		
		// split and execute
		ArrayList<RemoteServiceTask> tasks = new ArrayList<RemoteServiceTask>();
		String[] output = new String[input.length - prefixSize.first + prefixSize.second];
		
		// create the tasks
		for (int i = prefixSize.first; i < input.length; i += chunkSize)
		{
			RemoteServiceTask t = new RemoteServiceTask(i - prefixSize.first , prepareInput(input, chunkSize, i, prefixSize.first));
			wp.add(t);
			tasks.add(t);
		}
		if (DEBUG)
			System.err.println("Wait for tasks...");
		
		try
		{
			boolean prefixCopied = false;
			for (RemoteServiceTask t : tasks)
			{
				wp.waitFor(t);
				// copy to output
				copyOutput(output, t.output , t.offset , prefixSize.second , prefixCopied);
				
				prefixCopied = true;
				if (DEBUG)
					System.err.print(".");
			}
		}
		catch (InterruptedException e)
		{
			throw new RemoteException("[InterruptedException]", e);
		}
		return output;
	}
	
	private void copyOutput(String[] bigOutput, String[] outputPiece, int offset, int prefixLength, boolean prefixCopied)
	{
		if (prefixLength > 0 && !prefixCopied)
			System.arraycopy(outputPiece , 0 , bigOutput , 0 , prefixLength);
		
		System.arraycopy(outputPiece , prefixLength , bigOutput , offset + prefixLength , outputPiece.length - prefixLength);
	}
	
	private static String[] prepareInput(String[] input , int chunkSize, int currentOffset , int prefixLength)
	{
		int lenX = Math.min(chunkSize , input.length - currentOffset);
		String[] x = new String[lenX + prefixLength];
		if (prefixLength > 0)
			System.arraycopy(input , 0 , x , 0 , prefixLength);
		System.arraycopy(input , currentOffset , x , prefixLength , lenX);
		return x;
	}
	private int rand()
	{
		return ((int)(Math.random() * Integer.MAX_VALUE)) % rs.length;
	}
	
	private IntPair getPrefixSize(String[] input)
	{
		if (prefixLength == null)
			return defaultPrefixLength;
		assert input.length > 0;
		IntPair k = prefixLength.get(input[0]);
		if (k != null)
			return k;
		return defaultPrefixLength;
	}
	
}
