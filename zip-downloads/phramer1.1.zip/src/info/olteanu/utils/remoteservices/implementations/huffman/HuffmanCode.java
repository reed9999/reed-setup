/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.remoteservices.implementations.huffman;
import info.olteanu.utils.remoteservices.implementations.huffman.*;
import java.util.*;

public class HuffmanCode
{
	private HuffmanNode root;
	private boolean[][] encoding;
	public HuffmanCode(CharStatistics cs)
	{
		TreeSet<HuffmanNode> set = new TreeSet<HuffmanNode>();
		encoding = new boolean[cs.count.length][];
		HashMap<Character,HuffmanNode> charMap = new HashMap<Character,HuffmanNode>();
		for (int i = 0; i < cs.count.length; i++)
			if (cs.count[i] > 0)
			{
				HuffmanNode node = new HuffmanNode();
				node.character = (char)i;
				node.count = cs.count[i];
				set.add(node);
				charMap.put((char)i , node);
			}
		
//		for (HuffmanNode node : set)
//			System.out.println(node.character + " " + node.count);
		
		while (set.size() != 1)
		{
			// get the first two
			HuffmanNode first = set.first();
			set.remove(first);
			HuffmanNode second = set.first();
			set.remove(second);
			
			// generate the mixed one
			HuffmanNode combined = new HuffmanNode();
			combined.count = first.count + second.count;
			combined.node0 = first;
			combined.node1 = second;
			first.parent = combined;
			second.parent = combined;
			set.add(combined);
		}
		
		assert set.size() == 1;
		root = set.first();
		
		// build codes out of it
		long sizeChars = 0;
		long sizeBits = 0;
		for (HuffmanNode c : charMap.values())
		{
			Vector<Boolean> v = new Vector<Boolean>();
			HuffmanNode node  = c;
			while (node.parent != null)
			{
				v.add(node.parent.node1 == node);
				node = node.parent;
			}
			boolean[] k = new boolean[v.size()];
			for (int i = 0; i < k.length; i++)
				k[i] = v.get(k.length - 1 - i).booleanValue();
			
			encoding[c.character] = k;
			
			sizeChars += c.count;
			sizeBits += c.count * k.length;
		}
		
		System.out.println("Reduced from " + sizeChars + " chars = " + (sizeChars * 8) + " bits (8b/c) to " + sizeBits);
		System.out.println("Reduction: " + (sizeChars * 8.0) / sizeBits + " times (8 bit/char)");
		System.out.println("Reduction: " + (sizeChars * 16.0) / sizeBits + " times (16 bit/char)");
	}
}
class HuffmanNode implements Comparable<HuffmanNode>
{
	private static int ID = 0;
	public HuffmanNode()
	{
		synchronized (getClass())
		{
			this.id = ID++;
		}
	}
	public int compareTo(HuffmanNode o)
	{
		if (o.count == this.count)
			return o.id - this.id;
		return this.count - o.count;
	}
	public HuffmanNode parent = null;
	public HuffmanNode node0 = null;
	public HuffmanNode node1 = null;
	public int count = 0;
	public char character = '\0';
	private int id;
	
}
