/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.io;
import java.io.*;

public class LookAheadLineReader
{
    private BufferedReader br;
    private String[] lookAheadBuffer;
    private int cursor1 , cursor2 , cursorLookAhead;
    private boolean inLookAhead;
    public LookAheadLineReader(BufferedReader br, int maxLookahead)
    {
        this.br = br;
        this.lookAheadBuffer = new String[maxLookahead];
        this.cursor1 = 0;
        this.cursor2 = 0;
        this.cursorLookAhead = 0;
        this.inLookAhead = false;
    }
	
    public String readLine() throws IOException
    {
        if (inLookAhead)
        {
            /* optional */
            if (cursor1 == cursor2)
            {
                cursor1 = 0;
                cursor2 = 0;
                cursorLookAhead = 0;
            }
			
            if (cursor2 == cursorLookAhead)
            {
                // read new
                int oldCursor2 = cursor2;
                cursor2 = (cursor2 + 1) % lookAheadBuffer.length;
                cursorLookAhead = cursor2;
                if (cursor1 == cursor2)
                    throw new IOException("Buffer too small for look ahead");
				
                lookAheadBuffer[oldCursor2] = br.readLine();
                return lookAheadBuffer[oldCursor2];
            }
            else
            {
                // return from buffer
                int oldCursorLookAhead = cursorLookAhead;
                cursorLookAhead = (cursorLookAhead + 1) % lookAheadBuffer.length;
                return lookAheadBuffer[oldCursorLookAhead];
            }
        }
        else
        {
            if (cursor1 == cursor2)
                return br.readLine();
            else
            {
                String out = lookAheadBuffer[cursor1];
                cursor1 = (cursor1 + 1) % lookAheadBuffer.length;
                return out;
            }
        }
    }
//    public void commitRead() throws IOException
//    {
//        if (inLookAhead)
//        {
//            // TODO: test
//            cursor1 = cursorLookAhead;
//            inLookAhead = false;
//        }
//        else
//            throw new IOException("Not in lookahead");
//    }
	
    public void startLookAhead() throws IOException
    {
        if (inLookAhead)
            throw new IOException("Already in lookahead");
        inLookAhead = true;
        cursorLookAhead = cursor1;
    }
    public void stopLookAhead() throws IOException
    {
        if (!inLookAhead)
            throw new IOException("Not in lookahead");
        inLookAhead = false;
        cursorLookAhead = -1;
    }
	
    public void close()
    throws IOException
    {
        br.close();
    }
}

