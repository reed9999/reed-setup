/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.io;
import java.util.*;
import java.io.*;


/** Reads a file as an iterator of strings - one per each line. <br>
 * It allows easy syntax for reading files - iterator syntax. <br>
 * Note: not synchronized.
 */
public class LineReaderIterator implements Iterator<String>
{
	private BufferedReader br;
	public LineReaderIterator(BufferedReader br)
	{
		this.br = br;
	}
	public LineReaderIterator(Reader r)
	{
		this.br = new BufferedReader(r);
	}
	public LineReaderIterator(InputStream is)
	{
		this.br = new BufferedReader(new InputStreamReader(is));
	}
	public LineReaderIterator(InputStream is , String charsetName) throws UnsupportedEncodingException
	{
		this.br = new BufferedReader(new InputStreamReader(is , charsetName));
	}
	public LineReaderIterator(String fileName) throws IOException
	{
		this.br = new BufferedReader(new InputStreamReader(IOTools.getInputStream(fileName)));
	}
	public LineReaderIterator(String fileName , String charsetName) throws IOException
	{
		this.br = new BufferedReader(new InputStreamReader(IOTools.getInputStream(fileName) , charsetName));
	}
	public LineReaderIterator(File file) throws IOException
	{
		this.br = new BufferedReader(new InputStreamReader(IOTools.getInputStream(file)));
	}
	public LineReaderIterator(File file , String charsetName) throws IOException
	{
		this.br = new BufferedReader(new InputStreamReader(IOTools.getInputStream(file) , charsetName));
	}
	
	
	
	private String fetched = null;
	private boolean eof = false; // prevents re-read when EOF was reached. Also, when EOF, br gets closed and the ref is lost
	private void fetch()
	{
		assert br != null && !eof || br == null && eof;
		
		if (fetched == null && !eof)
			try
			{
				fetched = br.readLine();
				
				if (fetched == null)
				{
					eof = true;
					br.close(); // close, release resource
					br = null;
				}
			}
			catch (IOException e)
			{
				throw new RuntimeException("[IOException] " + e.getMessage() , e);
			}
		
	}
	
	/**
	 * Returns <tt>true</tt> if the iteration has more elements. (In other
	 * words, returns <tt>true</tt> if <tt>next</tt> would return an element
	 * rather than throwing an exception.)
	 * @return <tt>true</tt> if the iterator has more elements.
	 */
	public boolean hasNext()
	{
		fetch();
		return fetched != null;
	}
	
	
	/**
	 * Returns the next element in the iteration.
	 * @return the next element in the iteration.
	 * @exception NoSuchElementException iteration has no more elements.
	 */
	public String next()
	{
		fetch();
		if (fetched == null)
			throw new NoSuchElementException();
		String out = fetched;
		fetched = null;
		return out;
	}
	
	/**
	 * Removes from the underlying collection the last element returned by the
	 * iterator (optional operation).  This method can be called only once per
	 * call to <tt>next</tt>.  The behavior of an iterator is unspecified if
	 * the underlying collection is modified while the iteration is in
	 * progress in any way other than by calling this method.
	 * @exception UnsupportedOperationException if the <tt>remove</tt>
	 *		  operation is not supported by this Iterator.
	 * @exception IllegalStateException if the <tt>next</tt> method has not
	 *		  yet been called, or the <tt>remove</tt> method has already
	 *		  been called after the last call to the <tt>next</tt>
	 *		  method.
	 */
	public void remove()
	{
		throw new UnsupportedOperationException();
	}
	
}
