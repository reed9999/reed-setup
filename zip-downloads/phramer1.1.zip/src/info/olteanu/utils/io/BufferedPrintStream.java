/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.io;
import java.io.*;
//public class BufferedPrintStream extends PrintStream
//{
//	public BufferedPrintStream(OutputStream o)
//	{
//		super(o);
//	}
//
//	public BufferedPrintStream(OutputStream o, boolean autoFlush)
//	{
//		super(o, autoFlush);
//	}
//
//}

public class BufferedPrintStream implements SimplePrintStream
{
	private static final int SIZE_BUFFER = 300 * 1024;
	private static final int SIZE_FOR_FLUSH = 256 * 1024;
	private int sizeBuffer , sizeForFlush;
	public final String lineSeparator = (String) java.security.AccessController.doPrivileged(
		new sun.security.action.GetPropertyAction("line.separator"));
	private final PrintStream o;
	private final StringBuilder sb;
	
	public BufferedPrintStream(PrintStream o)
	{
		//super((OutputStream)null);
		this.o = o;
		this.sb = new StringBuilder(SIZE_BUFFER);
		this.sizeBuffer = SIZE_BUFFER;
		this.sizeForFlush = SIZE_FOR_FLUSH;
	}
	
	public BufferedPrintStream(OutputStream o)
	{
		//super((OutputStream)null);
		this.o = new PrintStream(o);
		this.sb = new StringBuilder(SIZE_BUFFER);
		this.sizeBuffer = SIZE_BUFFER;
		this.sizeForFlush = SIZE_FOR_FLUSH;
	}
	
	public BufferedPrintStream(OutputStream o, boolean autoFlush)
	{
		//super((OutputStream)null);
		this.o = new PrintStream(o, autoFlush);
		this.sb = new StringBuilder(SIZE_BUFFER);
		this.sizeBuffer = SIZE_BUFFER;
		this.sizeForFlush = SIZE_FOR_FLUSH;
	}
	
	
	public BufferedPrintStream(int sizeKb , PrintStream o)
	{
		//super((OutputStream)null);
		this.o = o;
		this.sizeBuffer = 1024 * (sizeKb + 2);
		this.sizeForFlush = 1024 * sizeKb;
		this.sb = new StringBuilder(sizeBuffer);
	}
	
	public BufferedPrintStream(int sizeKb , OutputStream o)
	{
		//super((OutputStream)null);
		this.o = new PrintStream(o);
		this.sizeBuffer = 1024 * (sizeKb + 2);
		this.sizeForFlush = 1024 * sizeKb;
		this.sb = new StringBuilder(sizeBuffer);
	}
	
	public BufferedPrintStream(int sizeKb , OutputStream o, boolean autoFlush)
	{
		//super((OutputStream)null);
		this.o = new PrintStream(o, autoFlush);
		this.sizeBuffer = 1024 * (sizeKb + 2);
		this.sizeForFlush = 1024 * sizeKb;
		this.sb = new StringBuilder(sizeBuffer);
	}
	
	
	public void print(char s[])
	{
		sb.append(s);
		flushIfRequired();
	}
	public void print(boolean x)
	{
		sb.append(x);
		flushIfRequired();
	}
	public void print(char x)
	{
		sb.append(x);
		flushIfRequired();
	}
	public void print(int x)
	{
		sb.append(x);
		flushIfRequired();
	}
	public void print(long x)
	{
		sb.append(x);
		flushIfRequired();
	}
	public void print(double x)
	{
		sb.append(x);
		flushIfRequired();
	}
	public void print(float x)
	{
		sb.append(x);
		flushIfRequired();
	}
	public void print(String x)
	{
		sb.append(x);
		flushIfRequired();
	}
	public void print(Object x)
	{
		sb.append(x);
		flushIfRequired();
	}
	
	
	public void println(char s[])
	{
		sb.append(s);
		newLine();
	}
	public void println(boolean x)
	{
		sb.append(x);
		newLine();
	}
	public void println(char x)
	{
		sb.append(x);
		newLine();
	}
	public void println(int x)
	{
		sb.append(x);
		newLine();
	}
	public void println(long x)
	{
		sb.append(x);
		newLine();
	}
	public void println(double x)
	{
		sb.append(x);
		newLine();
	}
	public void println(float x)
	{
		sb.append(x);
		newLine();
	}
	public void println(String x)
	{
		sb.append(x);
		newLine();
	}
	public void println(Object x)
	{
		sb.append(x);
		newLine();
	}
	
	
	public void println()
	{
		newLine();
	}
	
	private void newLine()
	{
		sb.append(lineSeparator);
		flushIfRequired();
	}
	
	private void flushIfRequired()
	{
		if (sb.length() >= SIZE_FOR_FLUSH)
			flush();
	}
	public void flush()
	{
		o.print(sb);
		o.flush();
		sb.setLength(0);
	}
	
	public void close()
	{
		flush();
		o.close();
	}
	
	protected void finalize()
	{
		close();
	}
	
	
	
	
	
	
	
	
//
//    public boolean checkError()
//	{
//		flush();
//		return o.checkError();
//    }
//
//    public void write(int b)
//	{
//		// TODO
//    }
//
//
//    public void write(byte buf[], int off, int len)
//	{
//		// TODO
//    }
//	public PrintStream printf(String format, Object ... args)
//	{
//		// TODO
//    }
//
//    public PrintStream printf(Locale l, String format, Object ... args)
//	{
//		// TODO
//    }
//
//    public PrintStream format(String format, Object ... args)
//	{
//		// TODO
//		`
//
//    public PrintStream format(Locale l, String format, Object ... args)
//	{
//		// TODO
//    }
//
//    public PrintStream append(CharSequence csq)
//	{
//		// TODO
//    }
//
//    public PrintStream append(CharSequence csq, int start, int end)
//	{
//		// TODO
//    }
//
//    public PrintStream append(char c)
//	{
//		// TODO
//    }
	
	
}


