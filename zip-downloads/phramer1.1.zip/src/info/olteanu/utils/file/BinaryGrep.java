/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.file;
import info.olteanu.utils.*;
import java.io.*;
import info.olteanu.utils.io.*;

// parameters
//   option
//   stringToSearch
//   [file or files]

// not very efficient implementation: n*m
public class BinaryGrep
{
	public static class BinaryGrepConfig
	{
		public boolean outHexa = false;
		
	}
	private static int BUFFER_SIZE = 64 * 1024;
	public static void main(String[] args)
	throws Exception
	{
//		boolean showContext = false;
		boolean hexa = false;
		BinaryGrepConfig config = new BinaryGrep.BinaryGrepConfig();
		while (args.length > 0)
		{
			String command = args[0];
			if (command.startsWith("--"))
			{
				args = StringTools.cutFirst(args , 1);
				command = command.substring(2);
				
				// -- is a marker
				if (command.length() == 0)
					break;
				// show context
//				if (command.equals("c") || command.equals("context"))
//					showContext = true;
				// hexa
				if (command.equals("h") || command.equals("hexa"))
					hexa = true;
				if (command.equals("oh") || command.equals("out-hexa"))
					config.outHexa = true;
			}
			else
				break;
		}
		if (args.length == 0)
		{
			System.err.println("Expecting: string to search");
			System.exit(1);
		}
		byte[] toSearch = hexa ? parseHexa(args[0]) : args[0].getBytes();
		
		if (args.length == 1)
			binaryGrep(config , System.in , toSearch , null);
		else if (args.length == 2)
		{
			InputStream in = new FileInputStream(args[1]);
			binaryGrep(config , in , toSearch , null);
			in.close();
		}
		else
			for (int i = 1; i < args.length; i++)
			{
				InputStream in = new FileInputStream(args[i]);
				binaryGrep(config , in , toSearch , args[1] + ": ");
				in.close();
			}
	}
	private static byte[] parseHexa(String str)
	{
		throw new Error("TODO");
	}
	
	private static void binaryGrep(BinaryGrepConfig config, InputStream in, byte[] toSearch, String prefix) throws IOException
	{
		byte[][] buffer = new byte[2][BUFFER_SIZE];
		int cnt = 0;
		int currentBuffer = 0;
		long totalLen = 0;
		
		while (true)
		{
			cnt++;
			int len = IOTools.read(in , buffer[currentBuffer]);
			if (len == -1)
				break;// EOF
			
			if (cnt > 1)
				search(config, totalLen, toSearch, buffer[currentBuffer], len , buffer[1 - currentBuffer], prefix);
			else
				search(config, totalLen, toSearch, buffer[currentBuffer], len , null, prefix);
			
			totalLen += len;
		}
		
	}
	
	
	
	private static void search(BinaryGrepConfig config, long delta, byte[] toSearch, byte[] buffer, int len, byte[] prevBuffer, String prefix)
	{
		if (prevBuffer != null)
		{
			// search crossed
			for (int i = -toSearch.length + 1; i < 0; i++)
				if (isAt(prevBuffer , buffer , toSearch , i))
					print(config, delta , i , prefix);
		}
		
		for (int i = 0; i <= buffer.length - toSearch.length; i++)
			if (isAt(buffer , toSearch , i))
				print(config, delta , i , prefix);
	}
	
	private static void print(BinaryGrepConfig config, long delta, int deltaInBuffer, String prefix)
	{
		StringBuilder sb = new StringBuilder();
		if (prefix != null)
			sb.append(prefix);
		
		if(config.outHexa)
			sb.append(StringTools.adjustLengthForNumber(Long.toHexString(delta + deltaInBuffer).toUpperCase() , 16));
		else
		sb.append(delta + deltaInBuffer);
		
		System.out.println(sb);
	}
	
	private static boolean isAt(byte[] a, byte[] b, int pos)
	{
		for (int i = 0; i < b.length; i++)
			if (a[pos + i] != b[i])
				return false;
		return true;
	}
	private static boolean isAt(byte[] prevA, byte[] a, byte[] b, int pos)
	{
		for (int i = 0; i < b.length; i++)
		{
			int x = pos + i;
			if (x < 0)
			{
				if(prevA[prevA.length + x] != b[i])
					return false;
			}
			else
			{
				if (a[x] != b[i])
					return false;
			}
		}
		return true;
	}
}
