/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.file;
import java.io.*;
import info.olteanu.utils.*;

public class BinaryDiff
{
	public static void main(String[] args)
	throws Exception
	{
		FileInputStream f1 = new FileInputStream(args[0]);
		FileInputStream f2 = new FileInputStream(args[1]);
		long diffCount = binaryDiff(System.out , f1 , f2);
		if (diffCount == 0)
			System.out.println("No differences");
		else
			System.out.println("Differences: " + diffCount);
		f1.close();
		f2.close();
	}
	
	public static long binaryDiff(PrintStream out , InputStream is1 , InputStream is2) throws IOException
	{
		BufferedInputStream r1 = new BufferedInputStream(is1);
		BufferedInputStream r2 = new BufferedInputStream(is2);
		long diffCount = 0;
		long index = 0;
		
		while (true)
		{
			int byte1 = r1.read();
			int byte2 = r2.read();
			if (byte1 == -1 || byte2 == -1)
			{
				// EOF
				if (byte1 != -1)
					out.println("First file longer");
				if (byte2 != -1)
					out.println("Second file longer");
				
				return diffCount;
			}
			
			if (byte1 != byte2)
			{
				diffCount++;
				out.println(StringTools.adjustLengthForNumber(Long.toHexString(index), 8) + ": "
							+ StringTools.adjustLengthForNumber(Integer.toHexString(byte1), 2)
							+ " "
							+ StringTools.adjustLengthForNumber(Integer.toHexString(byte2), 2));
				
			}
			index++;
		}
	}
}
