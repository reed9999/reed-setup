/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.file;
import info.olteanu.utils.*;
import info.olteanu.utils.io.*;
import java.io.*;

public class Xfgrep
{
	public static void main(String[] args)
	throws Exception
	{
		int ctx = 2;
		
		// read params
		while (true)
		{
			int lastLen = args.length;
			if (args[0].startsWith("--ctx"))
			{
				ctx = Integer.parseInt(args[1]);
				args = StringTools.cutFirst(args, 2);
			}
			
			if (lastLen == args.length)
				break;
		}
		
		
		// first: string to search
		String searchFor = args[0];
		
		
		if (args.length == 1)
			xfgrep(ctx , searchFor , System.in , null);
		else if (args.length == 2)
			xfgrep(ctx , searchFor , IOTools.getInputStream(args[1]) , null);
		else
		{
			for (int i = 1; i < args.length; i++)
				xfgrep(ctx , searchFor , IOTools.getInputStream(args[i]) , args[i]);
		}
	}
	
	private static void xfgrep(int ctx , String searchFor , InputStream in, String fileName)
	throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		LookAheadLineReader lalr = new LookAheadLineReader(br , ctx + 1);
		
		String[] history = new String[ctx + 1];
		int historyCursor = 0;
		
		String lineFile;
		while ((lineFile = lalr.readLine()) != null)
		{
			history[historyCursor] = lineFile;
			historyCursor = increment(historyCursor , ctx + 1);
			
			if (lineFile.contains(searchFor))
			{
				// write pre-history
				int position = historyCursor;
				for (int i = 0; i <= ctx; i++)
				{
					print(history[position] , -(ctx - i) , fileName);
					position = increment(position , ctx + 1);
				}
				// write future
				lalr.startLookAhead();
				for (int i = 1; i <= ctx; i++)
				{
					String thisLine = lalr.readLine();
					if(thisLine==null)
						break;

					print(thisLine , i , fileName);
				}
				lalr.stopLookAhead();
				System.out.println();
			}
		}
		lalr.close();
	}
	
	private static void print(String line, int delta, String fileName)
	{
		if(line == null)
			return;
		if (fileName == null)
			System.out.println((delta >= 0 ? "+" : "") + delta + ":" + line);
		else
			System.out.println(fileName + ":" + (delta >= 0 ? "+" : "") + delta + ":" + line);
	}
	
	private static int increment(int historyCursor, int ctx)
	{
		historyCursor++;
		if (historyCursor >= ctx)
			historyCursor = 0;
		return historyCursor;
	}
	
	private static int decrement(int historyCursor, int size)
	{
		historyCursor--;
		if (historyCursor < 0)
			historyCursor = size - 1;
		return historyCursor;
	}
}
