/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.sort;

import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import info.olteanu.utils.sort.*;
import java.io.*;
import java.util.*;
import info.olteanu.utils.io.*;

public class SplitSort
{
	public static final boolean LOG = true;
	public static void main(String[] args)
	throws IOException
	{
		if (args.length < 4)
		{
			System.err.println("Sort using temporary files");
			System.err.println("Usage: ");
			System.err.println(" <program> <temp file> <in file> <out file> <type> [<value>]");
			System.err.println("type:");
			System.err.println("  -c cuttoff_points");
			System.err.println("  -n number_of_parts");
			System.err.println("  -l number_of_lines_per_part");
			System.exit(1);
		}
		String tempFileName = args[0] + "." + (int)(Math.random() * 1000000);
		String sufix;
		if( args[0].endsWith( ".gz" ))
			sufix = ".gz";
		else
			sufix = "";
		String inputFile = args[1];
		String outputFile = args[2];
		String type = args[3];
		
		String threshold = null;
		int nPieces = -1;
		long nLinesPerPiece = -1;
		
		if (type.equals("-c"))
			threshold = args[4];
		else if (type.equals("-n"))
			nPieces = Integer.parseInt(args[4]);
		else if (type.equals("-l"))
			nLinesPerPiece = Long.parseLong(args[4]);
		else
		{
			System.err.println("Invalid <type>");
			System.exit(1);
		}
		
		sort(tempFileName, sufix , inputFile , outputFile , threshold, nPieces, nLinesPerPiece);
		
	}
	
	public static void sort(String tempFileName, String sufix , String inputFile, String outputFile, String threshold,   int nPieces, long nLinesPerPiece) throws IOException
	{
		Chronometer c = new Chronometer();
		c.start();
		
		if (threshold == null)
		{
			if (LOG)
				System.err.println("Getting optimal threshold");
			threshold = ThresholdDetector.getOptimalThreshold(inputFile , nPieces , nLinesPerPiece);
			if (LOG)
				System.err.println("Using optimal threshold: " + threshold);
		}
		
		Splitter splitter = new ThresholdSplitter2(threshold);
		
		int nParts = splitter.getNumberOfParts();
		
		BufferedPrintStream[] temp = new BufferedPrintStream[nParts];
		for (int i = 0; i < temp.length; i++)
			temp[i] = new BufferedPrintStream(IOTools.getOutputStream(tempFileName + "." + i + sufix ) , false);
		
		processFile(inputFile, splitter, temp);
		for (int i = 0; i < temp.length; i++)
			temp[i].close();
		
		if (LOG)
			System.err.println("Output") ;
		BufferedPrintStream outFile = new BufferedPrintStream(IOTools.getOutputStream(outputFile), false);
		for (int i = 0; i < nParts; i++)
		{
			BufferedReader fileTmp = new BufferedReader(new InputStreamReader(IOTools.getInputStream(tempFileName + "." + i + sufix )));
			String lineFile;
			Vector<String> v = new Vector<String>();
			if (LOG)
				System.err.println("> Read " + i);
			while ((lineFile = fileTmp.readLine()) != null)
				v.add(lineFile);
			fileTmp.close();
			new File(tempFileName + "." + i + sufix).delete();
			if (LOG)
				System.err.println("> Sort " + i);
			Collections.sort(v);
			if (LOG)
				System.err.println("> Write " + i);
			for (String s : v)
				outFile.println(s);
		}
		outFile.close();
		if (LOG)
		{
			System.err.println("End!");
			System.err.println("Total time: " + (c.getValue() / 1000.0) + " seconds");
		}
	}
	public static void processFile(String inputFileName , Splitter splitter, BufferedPrintStream[] temp)
	throws IOException
	{
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(IOTools.getInputStream(inputFileName)));
		String lineFile;
		int cnt = 0;
		
		Chronometer c = new Chronometer();
		c.start();
		
		while ((lineFile = inputFile.readLine()) != null)
		{
			int partNo = splitter.getPart(lineFile);
			temp[partNo].println(lineFile);
			cnt++;
			if (cnt % 100000 == 0)
			{
				if (LOG)
					System.err.println("... Done " + cnt + " lines " + (c.getValue() / 1000.0) + " seconds  (" + StringTools.formatDouble(cnt * 1000.0 / c.getValue(), "0.#") + " lines/sec)");
				for (int i = 0; i < temp.length; i++)
					temp[i].flush();
			}
		}
		
		// commit
		inputFile.close();
		
	}
}
