/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.sort;

import java.io.*;
import info.olteanu.utils.io.*;

public class ThresholdDetector
{
	public static int MIN_CHAR = 32;
	public static int MAX_CHAR = 255;
	
	
	public static String getOptimalThreshold(String file , int nPieces , long nLinesPerPiece) throws IOException
	{
		if (nPieces == 1)
			return "";
		
		long nLines = 0;
		long cntTotal = 0;
		long[][] cnt = new long[MAX_CHAR + 1][MAX_CHAR + 1];
		
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(IOTools.getInputStream(file)));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
		{
			nLines++;
			cntTotal += index(cnt, lineFile);
		}
		inputFile.close();
//		System.err.println("* " + cntTotal);
		if (nPieces > 0)
			return thresholdFor(cnt , cntTotal , nPieces);
		else
			return thresholdFor(cnt , cntTotal , nLines / nLinesPerPiece);
	}
	
	private static String thresholdFor(long[][] cnt, long cntTotal, long nPieces)
	{
		long leftPieces = nPieces;
		long leftLines = cntTotal;
		
		long accumulated = 0;
		long lastAccumulated = 0;
		StringBuffer sb = new StringBuffer();
		
		for (int i = MIN_CHAR ; i <= MAX_CHAR ; i++)
			for (int j = MIN_CHAR ; j <= MAX_CHAR ; j++)
			{
				if (cnt[i][j] > 0)
					if (leftPieces > 1)
						if ((accumulated - lastAccumulated + cnt[i][j] / 2) > (leftLines / leftPieces))
						{
							// make a new piece
							sb.append((char)i);
							sb.append((char)j);
							//System.err.println( (nPieces-leftPieces) + " " + (char)i + (char)j + " " + (accumulated - lastAccumulated) + " " + accumulated + "/" + cntTotal);
							lastAccumulated = accumulated;

							leftLines = cntTotal-accumulated;
							leftPieces--;
						}
				accumulated += cnt[i][j];
			}
//		System.err.println(sb.length());
		return sb.toString();
	}
	
	private static int index(long[][] cnt, String lineFile)
	{
		if (lineFile.length() < 2)
			return 0;
		int x = lineFile.charAt(0);
		int y = lineFile.charAt(1);
		if (x < MIN_CHAR)
			x = MIN_CHAR;
		if (x > MAX_CHAR)
			x = MAX_CHAR;
		if (y < MIN_CHAR)
			y = MIN_CHAR;
		if (y > MAX_CHAR)
			y = MAX_CHAR;
		cnt[x][y]++;
		return 1;
	}
	
}
