/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.sort;

import info.olteanu.utils.chron.*;
import info.olteanu.utils.io.*;
import java.io.*;
import java.util.*;

public class MergeSort
{
	public static void main(String[] args)
	throws Exception
	{
		if (args.length != 3)
		{
			System.err.println("Merge Sort using temporary files");
			System.err.println("Usage: ");
			System.err.println(" <program> <no. pieces> <in file> <out file>");
			System.exit(1);
		}
		Chronometer c = new Chronometer(true);
		sort(args[1] , Integer.parseInt(args[0]) , args[2]);
		System.err.println("Total time: " + (c.getValue() / 1000.0) + " seconds");
	}
	
	public static String getPartName(int partNo , String fileName)
	{
		return fileName + ".part" + partNo;
	}
	public static void sort(String fileName , int partCnt , String fileNameOut) throws IOException
	{
		// shred
		splitFile(fileName , fileNameOut , partCnt);
		// sort and merge
		sortAndMergePieces(fileNameOut , partCnt);
	}
	public static void splitFile(String fileNameIn, String fileNameMaskOut , int partCnt) throws IOException
	{
		BufferedPrintStream[] out = new BufferedPrintStream[partCnt];
		for (int i = 0; i < out.length; i++)
			out[i] = new BufferedPrintStream(new PrintStream(IOTools.getOutputStream(
																 getPartName(i , fileNameMaskOut)
															 ))) ;
		
		BufferedReader file = new BufferedReader(new InputStreamReader(IOTools.getInputStream(fileNameIn)));
		int cnt = 0;
		String lineFile;
		while ((lineFile = file.readLine()) != null)
		{
			out[cnt].println(lineFile);
			cnt = (cnt+1)% partCnt;
		}
		file.close();
		
		for (int i = 0; i < out.length; i++)
			out[i].close();
	}
	public static void sortAndMergePieces(String fileName , int partCnt ) throws IOException
	{
		for (int i = 0; i < partCnt; i++)
			sortFileInMemory(getPartName(i , fileName));
		mergeFiles(fileName , partCnt );
	}
	public static void sortFileInMemory(String fileName) throws IOException
	{
		// read file
		BufferedReader fileTmp = new BufferedReader(new InputStreamReader(IOTools.getInputStream(fileName)));
		String lineFile;
		ArrayList<String> v = new ArrayList<String>();
		while ((lineFile = fileTmp.readLine()) != null)
			v.add(lineFile);
		fileTmp.close();
		new File(fileName).delete();
		
		// sort file
		Collections.sort(v);
		
		// dump file
		PrintStream outFile = new PrintStream(IOTools.getOutputStream(fileName));
		for (String s : v)
			outFile.println(s);
		outFile.close();
	}
	public static void mergeFiles(String fileName , int partCnt) throws IOException
	{
		BufferedReader fileTmp[] = new BufferedReader[partCnt];
		String[] lineFile = new String[partCnt];
		for (int i = 0; i < fileTmp.length; i++)
		{
			fileTmp[i] = new BufferedReader(new InputStreamReader(IOTools.getInputStream(
																	  getPartName(i, fileName)
																  )));
			lineFile[i] = fileTmp[i].readLine();
		}
		BufferedPrintStream outFile = new BufferedPrintStream(IOTools.getOutputStream(fileName));
		String x;
		while ((x = getMin(fileTmp , lineFile)) != null)
			outFile.println(x);
		outFile.close();
		
		for (int i = 0; i < fileTmp.length; i++)
		{
			fileTmp[i].close();
			new File(getPartName(i, fileName)).delete();
		}
	}
	
	private static String getMin(BufferedReader[] fileTmp, String[] lineFile) throws IOException
	{
		String min = null;
		int minPos = -1;
		for (int i = 0; i < fileTmp.length; i++)
			if (lineFile[i] != null)
				if (min == null || min.compareTo(lineFile[i]) > 0)
				{
					min = lineFile[i];
					minPos = i;
				}
		
		if (min == null)
			return null;
		
		lineFile[minPos] = fileTmp[minPos].readLine();
		return min;
	}
}
