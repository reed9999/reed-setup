/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.net;
import info.olteanu.utils.*;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;

// mapped links, with routing options
public class StreamToStreamRouter
{
	public static interface Selector
	{
		public Socket getDestination(Socket incoming)
		throws IOException;
	}
	
	public static class SelectorImpl
	implements Selector
	{
		private final String propFileName;
		private Properties p;
		private final Object pLock;
		private final int verboseLevel;
		public SelectorImpl(String propFileName) throws PropertiesTools.PropertyExpansionException, IOException
		{
			this.propFileName = propFileName;
			p = PropertiesTools.getProperties(propFileName);
			pLock = new Object();
			boolean runReloader = PropertiesTools.getBooleanProperty(p , "router.reloader" , false);
			verboseLevel = PropertiesTools.getIntProperty(p , "router.verbose" , 0);
			if (runReloader)
			{
				Thread reloader = new Reloader(
					PropertiesTools.getIntProperty(p , "router.reloader.interval" , 5000)
				);
				reloader.setDaemon(true);
				reloader.start();
			}
			
		}
		
		
		
		public Socket getDestination(Socket incoming)
		throws IOException
		{
			synchronized (pLock)
			{
				// try to match it in the prop file
				String address = StringTools.substringAfter(incoming.getInetAddress().toString() , "/");
				if (verboseLevel >= 1)
					System.err.println("Solving " + address);
				
				while (address.indexOf(".") != -1)
				{
					String solveIdx = PropertiesTools.getStringProperty(p, "router.route." + address);
					if (solveIdx != null)
					{
						if (verboseLevel >= 1)
							System.err.println("Sub-address " + address + " solved to route " + solveIdx);
						return getAddress(p, solveIdx);
					}
					address = StringTools.lastSubstringBefore(address , ".");
				}
				if (verboseLevel >= 1)
					System.err.println("Cannot solve. Going to default route...");
				// default
				String defaultAddrIdx = PropertiesTools.getStringProperty(p, "router.default", "1");
				return getAddress(p , defaultAddrIdx);
			}
		}
		private static Socket getAddress(Properties p , String addrIdx) throws IOException
		{
			String address = PropertiesTools.getStringProperty(p , "router.address." + addrIdx);
			return getAddress(address);
		}
		
		private static Socket getAddress(String addr) throws IOException
		{
			String[] tok = StringTools.tokenize(false , addr);
			return new Socket(tok[0] , Integer.parseInt(tok[1]));
		}
		
		
		// reloads the properties file
		private class Reloader
		extends Thread
		{
			private final int wait;
			public Reloader(int wait)
			{
				this.wait = wait;
			}
			public void run()
			{
				while (true)
				{
					try
					{
						sleep(wait);
					}
					catch (InterruptedException e)
					{
						return;
					}
					if (verboseLevel >= 2)
						System.err.println("Reloading properties file...");
					synchronized (pLock)
					{
						try
						{
							p = PropertiesTools.getProperties(propFileName);
						}
						catch (PropertiesTools.PropertyExpansionException e)
						{
							System.err.println("Cannot reload properties file");
							e.printStackTrace();
						}
						catch (IOException e)
						{
							System.err.println("Cannot reload properties file");
							e.printStackTrace();
						}
					}
					if (verboseLevel >= 2)
						System.err.println("Properties file reloaded");
				}
			}
		}	}
	
	private static class Accepter extends Thread
	{
		public Accepter(Selector selector)
		{
			this.selector = selector;
		}
		public int port;
		public boolean active = true;
		private final Selector selector;
		public int debugLevel = 0;
		public void run()
		{
			if (debugLevel >= 1)
				System.out.println("[" + new java.util.Date() + "] Listening...");
			
			try
			{
				ServerSocket server = new ServerSocket(port);
				server.setSoTimeout(5000);
				while (active)
					try
					{
						// accept a new client and continue
						process(server.accept());
					}
					catch ( SocketTimeoutException e )
					{
						// ignore: designed to inspect active variable
					}
				server.close();
				if (debugLevel >= 1)
					System.out.println("[" + new java.util.Date() + "] Server stopped. Clients might be still active. New requests not accepted.");
			}
			catch (IOException e)
			{
				System.err.println("[" + new java.util.Date() + "] Failure in accepting: " + e.getMessage());
				e.printStackTrace();
			}
		}
		
		private void process(Socket incomingSocket)
		{
			if (debugLevel >= 2)
				System.out.println("[" + new java.util.Date() + "] New connection from " + incomingSocket.getRemoteSocketAddress());
			
			Socket destSocket = null;
			
			try
			{
				destSocket = selector.getDestination(incomingSocket);
				//Pair<Socket,Socket> x = new Pair<Socket, Socket>(incomingSocket, destSocket);
				
				new StreamToStreamThread(incomingSocket.getInputStream(), destSocket.getOutputStream(), 1024).start();
				new StreamToStreamThread(destSocket.getInputStream(), incomingSocket.getOutputStream(), 1024).start();
			}
			catch (IOException e)
			{
				if (debugLevel >= 1)
				{
					System.out.println("[" + new java.util.Date() + "] Exception");
					e.printStackTrace(System.out);
				}
				closeSockets(incomingSocket, destSocket);
			}
		}
		
		private void closeSockets(Socket incomingSocket, Socket destSocket)
		{
			try
			{
				incomingSocket.close();
			}
			catch (Exception ex)
			{}
			try
			{
				destSocket.close();
			}
			catch (Exception ex)
			{}
		}
	}
	
	public static void main(String[] args)
	throws Exception
	{
		if (args.length != 2)
		{
			System.out.println("Routing (through mapped link) utility");
			System.out.println("Parameters: <listen port> <config file>");
			System.exit(1);
		}
		//StreamToStreamThread.printDebug = true;
		
		// mapped link with routing
		Accepter a = new Accepter(new SelectorImpl(args[1]));
		a.debugLevel = 5;
		a.port = Integer.parseInt(args[0]);
		a.start();
	}
}
