/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils;
import java.lang.reflect.*;

public class ClassInstantiationTools
{
	public static boolean printWarnings = false;
	
	
	/** Instantiates the default constructor (zero arguments).
	 */
	public static Object instantiate(String className)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		Constructor[] constructors = Class.forName(className).getConstructors();
		
		boolean myPrintWarnings = printWarnings;
		String constructorName = null;
		if (constructors.length == 1)
			myPrintWarnings = false;
		if (myPrintWarnings)
		{
			constructorName = _getConstructorName(className);
			System.err.println("Warning: class " + className + " has more than one constructor. Searching for " + constructorName);
		}
		
		for (Constructor c : constructors)
		// does it have a standard constructor?
			if (c.getParameterTypes().length == 0)
			{
				if (myPrintWarnings)
					System.err.println("Constructor " + constructorName + " found");
				
				return c.newInstance();
			}
		
		if (myPrintWarnings)
			System.err.println("Constructor " + constructorName + " not found");
		
		throw new IllegalArgumentException("Cannot find appropriate constructor for class " + className + ". Looking for " + _getConstructorName(className));
	}
	
	/**
	 * Instantiates the constructor with one argument, of type <code>arg.getClass()</code>.
	 * The parameter <code>arg</code> may not be null (because it is used to determine type).
	 */
	public static Object instantiateOneArg(String className , Object arg)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return instantiate(className , new Object[]{arg});
		//return instantiateOneArg(className , arg , arg.getClass());
	}
	
	/**
	 * Instantiates the constructor with one argument, of any type.
	 * If there are more than one constructor with the same ariety, then an IllegalArgumentException is thrown.
	 * The parameter <code>arg</code> may be null.
	 */
	public static Object instantiateOneArgUntyped(String className , Object arg)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return instantiateUntyped(className , new Object[]{arg});
		//return _instantiateOneArg(className , arg , null , true);
	}
	/**
	 * Instantiates the constructor with one argument, of type <code>argClass</code>.
	 * The parameter <code>arg</code> may be null.
	 */
	public static Object instantiateOneArg(String className , Object arg , Class argClass)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return instantiate(className , new Object[]{arg} , new Class[]{argClass});
		//return _instantiateOneArg(className , arg , argClass , false);
	}
	
//	private static Object _instantiateOneArg(String className , Object arg , Class argClass , boolean untyped)
//	throws InstantiationException,
//	IllegalAccessException,
//	IllegalArgumentException,
//	InvocationTargetException,
//	SecurityException,
//	ClassNotFoundException
//	{
//		Constructor[] constructors = Class.forName(className).getConstructors();
//
//		boolean myPrintWarnings = printWarnings;
//		String constructorName = null;
//		if (constructors.length == 1)
//			myPrintWarnings = false;
//		if (myPrintWarnings)
//		{
//			constructorName = _getConstructorName(className , argClass);
//			System.err.println("Warning: class " + className + " has more than one constructor. Searching for " + constructorName);
//		}
//
//		for (Constructor c : constructors)
//		{
//			Class[] params = c.getParameterTypes();
//			// does it have a standard constructor?
//			if (params.length == 1 && (untyped || params[0].equals(argClass)))
//			{
//				if (myPrintWarnings)
//					System.err.println("Constructor " + constructorName + " found");
//
//				return c.newInstance(new Object[]{arg});
//			}
//		}
//
//		if (myPrintWarnings)
//			System.err.println("Constructor " + constructorName + " not found");
//
//		throw new IllegalArgumentException("Cannot find appropriate constructor for class " + className + ". Looking for " + _getConstructorName(className , argClass));
//	}
	
	
	/**
	 * Instantiates the constructor with two arguments, of type <code>arg1.getClass()</code> and <code>arg2.getClass()</code>.
	 * The parameters <code>arg1</code> and <code>arg2</code> may not be null (because it is used to determine type).
	 */
	public static Object instantiateTwoArgs(String className , Object arg1 , Object arg2)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return instantiate(className , new Object[]{arg1 , arg2});
	}
	
	/**
	 * Instantiates the constructor with two arguments, of any type.
	 * If there are more than one constructor with the same ariety, then an IllegalArgumentException is thrown.
	 * The parameters <code>arg1</code> and <code>arg2</code> may be null.
	 */
	public static Object instantiateTwoArgsUntyped(String className , Object arg1 , Object arg2)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return instantiateUntyped(className , new Object[]{arg1 , arg2});
	}
	
	/**
	 * Instantiates the constructor with two arguments, of type <code>arg1Class</code> and <code>arg2Class</code>.
	 * The parameters <code>arg1</code> and <code>arg2</code> may be null.
	 */
	public static Object instantiateTwoArgs(String className , Object arg1 , Class arg1Class , Object arg2 , Class arg2Class)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return instantiate(className , new Object[]{arg1 , arg2} , new Class[]{arg1Class , arg2Class});
	}
	
	
	/**
	 * Instantiates the constructor with any number of arguments, of type <code>args[i].getClass()</code>.
	 * The parameters <code>args[i]</code> may not be null (because it is used to determine type).
	 *
	 * <br><br>
	 * Assumptions:<br>
	 * &nbsp;zero arguments constructor == (args.length == 0)<br>
	 * &nbsp;(args == null) == (args.length ==0)<br>
	 */
	public static Object instantiate(String className, Object[] args)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		if (args == null || args.length == 0)
			return instantiate(className);
		
//		if (args.length == 1)
//			return instantiateOneArg(className , args[0]);
		
		Class[] argClass = new Class[args.length];
		for (int i = 0; i < argClass.length; i++)
			argClass[i] = args[i].getClass();
		
		return instantiate(className , args , argClass);
	}
	
	/**
	 * Instantiates the constructor with any number of arguments, of any type.
	 * If there are more than one constructor with the same ariety, then an IllegalArgumentException is thrown.
	 * The parameters <code>arg[i]</code> may be null.
	 *
	 * <br><br>
	 * Assumptions:<br>
	 * &nbsp;zero arguments constructor == (args.length == 0)<br>
	 * &nbsp;(args == null) == (args.length ==0)<br>
	 */
	public static Object instantiateUntyped(String className, Object[] args)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return _instantiateMultipleArguments(className , args , null , true);
	}
	
	/**
	 * Instantiates the constructor with any number of arguments, of type <code>argsClass[i]</code>.
	 * The parameters <code>arg[i]</code> may be null.
	 */
	public static Object instantiate(String className, Object[] args , Class[] argsClass)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return _instantiateMultipleArguments(className , args , argsClass , false);
	}
	
	/**
	 * Instantiates the constructor with any number of arguments, of type <code>argsOptions[s][i].getClass()</code>.
	 * The caller provides a list of options (identified by index s), that are used to match the appropriate constructors.
	 * First matched (s = 0..n) is the one that is instantiated.
	 * The parameters <code>args[s][i]</code> may not be null (because it is used to determine type).
	 */
	public static Object instantiateMultiOptions(String className, Object[][] argsOptions)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		assert argsOptions.length >= 1;
		
		// only one option
		if (argsOptions.length == 1)
			return instantiate(className , argsOptions[0]);
		
		Class[][] argsOptionsClass = new Class[argsOptions.length][];
		for (int i = 0; i < argsOptionsClass.length; i++)
		{
			argsOptionsClass[i] = new Class[argsOptions[i].length];
			for (int j = 0; j < argsOptionsClass[i].length; j++)
				argsOptionsClass[i][j] = argsOptions[i][j].getClass();
		}
		
		return instantiateMultiOptions(className , argsOptions , argsOptionsClass);
	}
	
	/**
	 * Instantiates the constructor with any number of arguments, of type <code>argsOptions[s][i].getClass()</code>.
	 * The caller provides a list of options (identified by index s), that are used to match the appropriate constructors.
	 * First matched (s = 0..n) is the one that is instantiated.
	 * If there are more than one constructor with the same ariety, then an IllegalArgumentException is thrown.
	 * The parameters <code>args[s][i]</code> may be null.
	 */
	public static Object instantiateMultiOptionsUntyped(String className, Object[][] argsOptions)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return _instantiateMultiOptions(className , argsOptions , null , true);
	}
	
	/**
	 * Instantiates the constructor with any number of arguments, of type <code>argsOptionsClass[s][i]</code>.
	 * The caller provides a list of options (identified by index s), that are used to match the appropriate constructors.
	 * First matched (s = 0..n) is the one that is instantiated.
	 * The parameters <code>args[s][i]</code> may be null.
	 */
	public static Object instantiateMultiOptions(String className, Object[][] argsOptions , Class[][] argsOptionsClass)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		return _instantiateMultiOptions(className , argsOptions , argsOptionsClass , false);
	}
	
	
	private static Object _instantiateMultipleArguments(String className, Object[] args , Class[] argsClass , boolean untyped)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
		assert args == null || args.length == argsClass.length;
		if (args == null || args.length == 0)
			return instantiate(className);
		
//		if (args.length == 1)
//			return instantiateOneArg(className , args[0] , argsClass[0]);
		
		Constructor[] constructors = Class.forName(className).getConstructors();
		
		boolean myPrintWarnings = printWarnings;
		String constructorName = null;
		if (constructors.length == 1)
			myPrintWarnings = false;
		if (myPrintWarnings)
		{
			constructorName = _getConstructorName(className, argsClass , args);
			System.err.println("Warning: class " + className + " has more than one constructor. Searching for " + constructorName);
		}
		
		Constructor selectedC = null;
		Object[] selectedA = null;
		for (Constructor c : constructors)
		{
			Class[] params = c.getParameterTypes();
			// does it have a standard constructor?
			if (params.length == args.length && (untyped || equals(params , argsClass)))
			{
				if (myPrintWarnings)
					if (untyped)
						System.err.println("Constructor " + _getConstructorName(className , params , args) + " matching " + constructorName + " found");
					else
						System.err.println("Constructor " + constructorName + " found");
				
				if (!untyped)// if it is typed, return imediatelly. Assume that the class is not corrupt
					return c.newInstance(args);
				
				// if there is more than one...
				if (selectedC != null)
					throw new IllegalArgumentException("Found more than one constructor of ariety " + params.length + " for untyped match of class " + className);
				
				selectedC = c;
				selectedA = args;
			}
		}
		if (selectedC != null)
			return selectedC.newInstance(selectedA);
		
		
		if (myPrintWarnings)
			System.err.println("Constructor " + constructorName + " not found");
		
		throw new IllegalArgumentException("Cannot find appropriate constructor for class " + className + ". Looking for " + _getConstructorName(className, argsClass , args));
	}
	private static Object _instantiateMultiOptions(String className, Object[][] argsOptions , Class[][] argsOptionsClass , boolean untyped)
	throws InstantiationException,
	IllegalAccessException,
	IllegalArgumentException,
	InvocationTargetException,
	SecurityException,
	ClassNotFoundException
	{
//		assert args == null || args.length == argsClass.length;
		assert argsOptions.length >= 1;
		assert argsOptions.length == argsOptionsClass.length;
		
		// only one option
		if (argsOptions.length == 1)
			return instantiate(className , argsOptions[0] , argsOptionsClass[0]);
		
		Constructor[] constructors = Class.forName(className).getConstructors();
		
		boolean myPrintWarnings = printWarnings;
		String constructorName = null;
		if (constructors.length == 1)
			myPrintWarnings = false;
		if (myPrintWarnings)
		{
			constructorName = _getConstructorName(className, argsOptionsClass , argsOptions);
			System.err.println("Warning: class " + className + " has more than one constructor. Searching for " + constructorName);
		}
		
		for (int i = 0; i < argsOptions.length; i++)
		{
			Constructor selectedC = null;
			Object[] selectedA = null;
			for (Constructor c : constructors)
			{
				Class[] params = c.getParameterTypes();
				// does it have a standard constructor?
				if (params.length == argsOptions[i].length && (untyped || equals(params , argsOptionsClass[i])))
				{
					if (myPrintWarnings)
						if (untyped)
							System.err.println("Constructor " + _getConstructorName(className , params , argsOptions[i]) + " matching " + _getConstructorName(className , null , argsOptions[i]) + " found");
						else
							System.err.println("Constructor " + _getConstructorName(className , argsOptionsClass == null ? params : argsOptionsClass[i] , argsOptions[i]) + " found");
					
					if (!untyped)// if it is typed, return imediatelly. Assume that the class is not corrupt
						return c.newInstance(argsOptions[i]);
					
					// if there is more than one...
					if (selectedC != null)
						throw new IllegalArgumentException("Found more than one constructor of ariety " + params.length + " for untyped match of class " + className);
					
					selectedC = c;
					selectedA = argsOptions[i];
				}
			}
			if (selectedC != null)
				return selectedC.newInstance(selectedA);
		}
		
		if (myPrintWarnings)
			System.err.println("Constructors " + constructorName + " not found");
		
		throw new IllegalArgumentException("Cannot find appropriate constructor for class " + className + ". Looking for " + _getConstructorName(className, argsOptionsClass , argsOptions));
	}
	
	
	private static boolean equals(Class[] params, Class[] argsClass)
	{
//		for (int i = 0; i < params.length; i++)
//			System.err.println(i + ": " + params[i]);
		
		for (int i = 0; i < params.length; i++)
			if (!params[i].equals(argsClass[i]))
				return false;
		return true;
	}
	
	
	private static String _getConstructorName(String className)
	{
		return className + "()";
	}
	
	private static String _getConstructorName(String className, Class argClass)
	{
		return className + "(" + (argClass == null ? "?" : argClass.getName()) + ")";
	}
	
	private static String _getConstructorName(String className, Class[] argsClass , Object[] arg)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(className).append("(");
		
		if (argsClass == null)
			if (arg == null)
				sb.append("???");
			else
				for (int i = 0; i < arg.length; i++)
				{
					if (i > 0)
						sb.append(" , ");
					sb.append("?");
				}
		else
			for (int i = 0; i < argsClass.length; i++)
			{
				if (i > 0)
					sb.append(" , ");
				if (argsClass[i] == null)
					sb.append("?");
				else
					sb.append(argsClass[i].getName());
			}
		sb.append(")");
		return sb.toString();
	}
	
	
	private static String _getConstructorName(String className, Class[][] argsOptionClass , Object[][] args)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("< ");
		if (argsOptionClass == null)
			if (args == null)
				sb.append(className + "(???) ... " + className + "(???)");
			else
				for (int i = 0; i < args.length; i++)
				{
					if (i > 0)
						sb.append(" ; ");
					sb.append(_getConstructorName(className , null , args[i]));
				}
		else
			for (int i = 0; i < argsOptionClass.length; i++)
			{
				if (i > 0)
					sb.append(" ; ");
				sb.append(_getConstructorName(className , argsOptionClass[i] , args == null ? null : args[i]));
			}
		sb.append(" >");
		return sb.toString();
	}
}
