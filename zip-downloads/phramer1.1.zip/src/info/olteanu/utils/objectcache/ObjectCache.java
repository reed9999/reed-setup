/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.objectcache;
import info.olteanu.utils.*;
import info.olteanu.utils.chron.*;
import java.util.*;

/** A generic object cache */
public class ObjectCache<Arg,Value>
{
	private HashMap<Object,Value> cache;
	private ObjectCacheCaller<Arg,Value> cached;
	private Object[] historyKey;
	private Value[] historyValue;
	
	private int nextInHistory;
	private int maxSize;
	
	
	private Chronometer cX;
	private int hitCount, missCount;
	private boolean printDebug;
	
	private String myName;
	
	
	
	public ObjectCache(ObjectCacheCaller<Arg,Value> cached , int maxSize , int historyLengthWhenFlush , boolean printDebug , String myName)
	{
		hitCount = 0;
		missCount = 0;
		
		this.cached = cached;
		cache = new HashMap<Object,Value>();
		this.maxSize = maxSize;
		historyKey = new Object[historyLengthWhenFlush];
		historyValue = (Value[]) new Object[historyLengthWhenFlush];
		nextInHistory = 0;
		cX = new Chronometer(true);
		this.printDebug = printDebug;
		this.myName = myName;
	}
	
	public Value getValue(Object key , Arg argument)
	throws Exception
	{
		// if in cache...
		if (cache.containsKey(key))
		{
			hitCount++;
			return cache.get(key);
		}
		missCount++;
		
		// if cache too big, flush it
		if (cache.size() == maxSize)
			flushAndReconstruct();
		
		Value response = cached.callWhenMiss(argument);
		synchronized (cache)
		{
			cache.put(key , response);
			// keep history
			if (historyKey.length > 0)
			{
				historyKey[nextInHistory] = key;
				historyValue[nextInHistory] = response;
				nextInHistory = (nextInHistory + 1) % historyKey.length;
			}
		}
		// interogate, add to cache, exit
		return response;
	}
	private void flushAndReconstruct()
	{
		synchronized (cache)
		{
			cX.stop();
			if (printDebug)
				System.err.println("(" + myName + ") Flushing after " + StringTools.formatDouble(cX.getValue() / 1000.0 ,  "0.00") + " seconds..."
								   + " Hit: " + StringTools.formatDouble(hitCount * 100.0 / (hitCount + missCount), "0.00") + "% = " + hitCount + "/" + (hitCount + missCount));
			cX.start();
			Chronometer c = new Chronometer();
			cache.clear();
			c.start();
			// put back very near history
			for (int i = 0; i < historyKey.length; i++)
				if (historyKey[i] != null)
					cache.put(historyKey[i] , historyValue[i]);
			c.stop();
			if (printDebug)
				System.err.println("(" + myName + ") Flushed in " + c.getValue() + " milliseconds");
		}
	}
	
	public void flush()
	{
		synchronized (cache)
		{
			cache.clear();
		}
	}
}
