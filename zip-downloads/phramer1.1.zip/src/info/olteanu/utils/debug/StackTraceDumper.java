/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.debug;
import java.io.*;
import java.util.*;

// show delta: shows the difference between previous stack trace and the current one (in terms of string comparison)
public class StackTraceDumper
{
	private static class DumpThread extends Thread
	{
		private final String fileNameLog;
		private final int sleepTime;
		private final Set<String> selectedThreads;
		private final boolean showDelta;
		private Map<Thread, StackTraceElement[]> lastDump;
		public DumpThread(String fileNameLog , int sleepIntervalMilliSeconds , Set<String> selectedThreads)
		{
			this(fileNameLog , sleepIntervalMilliSeconds , selectedThreads , true);
		}
		public DumpThread(String fileNameLog , int sleepIntervalMilliSeconds , Set<String> selectedThreads , boolean showDelta)
		{
			this.fileNameLog = fileNameLog;
			this.sleepTime = sleepIntervalMilliSeconds;
			this.selectedThreads = selectedThreads;
			this.showDelta = showDelta;
			this.lastDump = null;
		}
		public void run()
		{
			try
			{
				PrintStream out = new PrintStream(new FileOutputStream(fileNameLog));
				while (true)
				{
					Map<Thread, StackTraceElement[]> threads = Thread.getAllStackTraces();
					
					out.println("Timestamp: " + new Date());
					out.println("Thread count: " + threads.size() + " (active " +
								Thread.activeCount() + ")");
					
					TreeMap<String,Thread> k = new TreeMap<String,Thread>();
					for (Thread t : threads.keySet())
						if (t != this) // don't add the current thread
							if (selectedThreads == null || selectedThreads.contains(t.getName()))
								k.put(t.getName(), t);
					
					
					for (String tn : k.keySet())
					{
						Thread t = k.get(tn);
						
						out.println("   " + t.getName());
						StackTraceElement[] elems = threads.get(t);
						StackTraceElement[] elemsLastTime = showDelta && lastDump != null ? lastDump.get(t) : null;
						if (elemsLastTime == null)
							for (StackTraceElement e : elems)
								out.println("        " +
											e.toString());
						else
						{
							boolean[] same = getSameMarker(elems , elemsLastTime);
							assert same.length == elems.length;
							for (int i = 0; i < elems.length; i++)
								out.println("        " + (same[i] ? "= " : "* ") +
											elems[i].toString());
						}
						out.println();
					}
					out.println();
					out.println();
					out.println();
					out.println();
					out.println();
					out.println();
					out.println();
					out.println();
					out.println();
					out.println();
					out.flush();
					
					if (showDelta)
						lastDump = threads;
					
					Thread.currentThread().sleep(sleepTime);
				}
			}
			catch (InterruptedException e)
			{}
			catch (IOException e)
			{}
		}
		
		private static boolean[] getSameMarker(StackTraceElement[] elems, StackTraceElement[] elemsLastTime)
		{
			boolean[] out = new boolean[elems.length];
			for (int i = 0; i < out.length; i++)
				out[i] = false;
			
			for (int deltaFromEnd= 1; deltaFromEnd <= out.length; deltaFromEnd++)
				if (elemsLastTime.length >= deltaFromEnd)
				{
					boolean equal = elems[elems.length - deltaFromEnd].toString().equals(elemsLastTime[elemsLastTime.length - deltaFromEnd].toString());
					//boolean equal = elems[elems.length - deltaFromEnd] == elemsLastTime[elemsLastTime.length - deltaFromEnd]; -- it doesn't work
					out[out.length - deltaFromEnd] = equal;
					if(!equal)
						break;
				}
				else
					break;
			return out;
		}
	}
	public static void startTraceDumper(String fileNameLog , int sleepIntervalMilliSeconds , Set<String> selectedThreads , boolean showDelta)
	{
		DumpThread dt = new DumpThread(fileNameLog , sleepIntervalMilliSeconds , selectedThreads , showDelta);
		dt.setDaemon(true);
		dt.start();
	}
	public static void startTraceDumper(String fileNameLog , int sleepIntervalMilliSeconds , Set<String> selectedThreads)
	{
		startTraceDumper(fileNameLog , sleepIntervalMilliSeconds , selectedThreads , true);
	}
	public static void startTraceDumper(String fileNameLog , int sleepIntervalMilliSeconds , boolean showDelta)
	{
		startTraceDumper(fileNameLog , sleepIntervalMilliSeconds , null , showDelta);
	}
	public static void startTraceDumper(String fileNameLog , int sleepIntervalMilliSeconds)
	{
		startTraceDumper(fileNameLog , sleepIntervalMilliSeconds , null);
	}
	public static void startTraceDumper(String fileNameLog , boolean showDelta)
	{
		startTraceDumper(fileNameLog , 10000 , showDelta); // 10 seconds
	}
	public static void startTraceDumper(String fileNameLog)
	{
		startTraceDumper(fileNameLog , 10000); // 10 seconds
	}
	
	public static void dumpNow(PrintStream out)
	{
		Map<Thread, StackTraceElement[]> threads = Thread.getAllStackTraces();
		
		out.println("Thread count: " + threads.size() + " (active " +
					Thread.activeCount() + ")");
		
		TreeMap<String,Thread> k = new TreeMap<String,Thread>();
		for (Thread t : threads.keySet())
			k.put(t.getName(), t);
		
		
		for (String tn : k.keySet())
		{
			Thread t = k.get(tn);
			
			out.println("   " + t.getName());
			StackTraceElement[] elems = threads.get(t);
			for (StackTraceElement e : elems)
				out.println("        " +
							e.toString());
			out.println();
		}
	}
	
}
