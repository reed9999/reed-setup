/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils;
import java.io.*;
import info.olteanu.interfaces.*;

public class StreamBlackHole extends Thread
{
	private final InputStream in;
	private final Object notificationParam;
	private final NotificationRecipient nr;
	private final int size;
	public static boolean printDebug = false;
	
	private long totalSize;
	/** Returns how much data in bytes went through the black hole.*/
	public long getTotalSize()
	{
		return totalSize;
	}
	
	public static StreamBlackHole createBlackHole(InputStream in)
	{
		StreamBlackHole thr = new StreamBlackHole(in);
		thr.setDaemon(true);
		thr.start();
		return thr;
	}
	
	public static StreamBlackHole createBlackHole(InputStream in , int sizeBuffer , NotificationRecipient nr , Object notificationParam)
	{
		StreamBlackHole thr = new StreamBlackHole(in, sizeBuffer, nr, notificationParam);
		thr.setDaemon(true);
		thr.start();
		return thr;
	}
	
	public StreamBlackHole(InputStream in)
	{
		this(in, 16 * 1024 , null , null);
	}
	public StreamBlackHole(InputStream in , int sizeBuffer , NotificationRecipient nr , Object notificationParam)
	{
		this.in = in;
		this.size = sizeBuffer;
		this.nr = nr;
		this.totalSize = 0;
		this.notificationParam = notificationParam;
	}
	public void run()
	{
		try
		{
			byte[] buffer = new byte[size];
			
			if (printDebug)
				System.err.println("In " + this);
			
			while (true)
			{
				int cnt = in.read(buffer);
				if (cnt == -1) // eof
					break;
				//out.write(buffer, 0, cnt);
				totalSize += cnt;
			}
			
			if (printDebug)
				System.err.println("Out " + this);
		}
		catch (IOException e)
		{
			if (printDebug)
			{
				System.err.println("IOException " + this);
				e.printStackTrace();
			}
		}
		finally
		{
			try
			{
				in.close();
			}
			catch (IOException e)
			{}
			if (nr != null)
				nr.notify(notificationParam);
		}
		if (printDebug)
			System.err.println("Exit " + this);
	}
	
}
