/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.math;

import info.olteanu.utils.math.*;
import java.util.*;



public class Statistics
{
	/** Sum */
	public static double sum(Vector<Double> v)
	{
		double sum = 0;
		for (double elem : v)
			sum += elem;
		return sum;
	}
	
	
	/** Average */
	public static double avg(Vector<Double> v)
	throws MathException
	{
		if (v.isEmpty())
			throw new MathException("Empty vector");
		double sum = 0;
		for (double elem : v)
			sum += elem;
		return sum / v.size();
	}
	
	/** Arithmetic mean (Average) */
	public static double aritheticMean(Vector <Double> v) throws MathException
	{
		return avg(v);
	}
	
	/** Geometric mean */
	public static double geometricMean(Vector <Double> v)
	throws MathException
	{
		if (v.isEmpty())
			throw new MathException("Empty vector");
		double product = 1;
		for (double elem : v)
			product *= elem;
		return Math.pow(product , 1.0 / v.size());
	}
	
	/** Interquartile mean - cut |_ n/4 _| elements from the beginning and from the end */
	public static double interquartileMean1(Vector <Double> v)
	throws MathException
	{
		if (v.isEmpty())
			throw new MathException("Empty vector");
		
		// avoid altering
		v = (Vector<Double>) v.clone();
		java.util.Collections.sort(v);
		
		// discard first 1/4 and last 1/4
		int cut = v.size() / 4;
		// cut last
		v.setSize(v.size() - cut);
		double sum = 0;
		int cnt = 0;
		// compute avg, ignoring first cnt elements
		for (int i = cut ; i < v.size() ; i++,cnt++)
			sum += v.get(i);
		return sum / cnt;
	}
	
	/** Median */
	public static double median(Vector<Double> v) throws MathException
	{
		if (v.isEmpty())
			throw new MathException("Empty vector");
		
		// avoid altering
		v = (Vector<Double>) v.clone();
		java.util.Collections.sort(v);
		// take middle
		return v.get(v.size() / 2);
	}
	
	
	/** Variance (sample) */
	public static double var(Vector<Double> v)
	throws MathException
	{
		if (v.size() < 2)
			throw new MathException("Variance requires at least 2 elements");
		double avg = avg(v);
		
		double sum = 0;
		for (double elem : v)
		{
			double e = elem - avg;
			sum += e * e;
		}
		return sum / (v.size() - 1);
	}
	
	/** Standard deviation (Sample) */
	public static double stddev(Vector<Double> v)
	throws MathException
	{
		return Math.sqrt(var(v));
	}
	
	
	/** Variance (population) */
	public static double varPop(Vector<Double> v)
	throws MathException
	{
		double avg = avg(v);
		
		double sum = 0;
		for (double elem : v)
		{
			double e = elem - avg;
			sum += e * e;
		}
		return sum / v.size();
	}
	
	/** Standard deviation (Population) */
	public static double stddevPop(Vector<Double> v)
	throws MathException
	{
		return Math.sqrt(varPop(v));
	}
}

