/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.expressionparser;
import info.olteanu.utils.lang.*;
import java.io.*;
import java.util.*;
import info.olteanu.utils.expressionparser.nodes.*;

// this is not a perfect parser
// it is designed to parse properly good expressions
// but it is not designed to reject all bad expressions
public class ExpressionReader<Output>
{
	private final ExpressionParsingConstants constants;
	public ExpressionReader(ExpressionParsingConstants constants)
	{
		this.constants = constants;
	}
	
	
	public NodeX<Output> getExpression(String serialization)
	throws IOException
	{
		serialization = serialization.trim();
		
		List<String> pieces;
		MutableInt k = new MutableInt(0);
		
		// check or
		pieces = scanFor(serialization , k , constants.OR);
		if (pieces.size() > 0)
		{
			pieces.add(serialization.substring(k.value));
			NodeX<Output>[] children = getChildren(pieces);
			return new OrNodeX<Output>(constants , children);
		}
		
		// check and
		pieces = scanFor(serialization , k , constants.AND);
		if (pieces.size() > 0)
		{
			pieces.add(serialization.substring(k.value));
			NodeX<Output>[] children = getChildren(pieces);
			return new AndNodeX<Output>(constants , children);
		}
		
		// check eq (equivalent)
		pieces = scanFor(serialization , k , constants.EQUIVALENT);
		if (pieces.size() > 0)
		{
			pieces.add(serialization.substring(k.value));
			NodeX<Output>[] children = getChildren(pieces);
			return new EquivalentNodeX<Output>(constants , children);
		}
		
		// check imply
		pieces = scanFor(serialization , k , constants.EQUIVALENT);
		if (pieces.size() > 0)
		{
			pieces.add(serialization.substring(k.value));
			NodeX<Output>[] children = getChildren(pieces);
			if (children.length == 2)
				return new ImplyNodeX<Output>(constants , children[0] , children[1]);
			else
			{
				// a imply b imply c == (a imply b) imply c
				ImplyNodeX<Output> node = new ImplyNodeX<Output>(constants , children[0] , children[1]);
				for (int i = 2; i < children.length; i++)
					node = new ImplyNodeX<Output>(constants , node , children[i]);
				return node;
			}
		}
		
		// check negation
		if (serialization.startsWith(constants.NOT))
			return new NotNodeX<Output>(constants , getExpression(serialization.substring(1)));
		
		// if it is with paranthesis, do what's inside
		if (serialization.startsWith(constants.BRACKET_START) && serialization.endsWith(constants.BRACKET_END))
			return getExpression(serialization.substring(1, serialization.length() - 1));
		
		if (serialization.startsWith(constants.VARIABLE_START) && serialization.endsWith(constants.VARIABLE_END))
		// terminal, variable
			return new VariableNodeX<Output>(constants , unescape(serialization.substring(1, serialization.length() - 1)));
		
		// terminal, constant
		if (serialization.equals(constants.TRUE))
			return new ConstantNodeX<Output>(constants, true);
		if (serialization.equals(constants.FALSE))
			return new ConstantNodeX<Output>(constants , true);
		
		throw new IOException("I don't know how to parse " + serialization);
	}
	
	private NodeX<Output>[] getChildren(List<String> pieces) throws IOException
	{
		NodeX<Output>[] children = new NodeX[pieces.size()];
		for (int i = 0; i < children.length; i++)
			children[i] = getExpression(pieces.get(i));
		return children;
	}
	
	private String unescape(String string)
	{
		// unescape end: \/ -> /
		string = string.replace(constants.ESCAPE_END , constants.VARIABLE_END);
		// TODO: replace \x with x, where x != \
		// unescape double escape char: \\ -> /
		string = string.replace(constants.ESCAPE_DOUBLE , constants.ESCAPE);
		return string;
	}
	
	
	private List<String> scanFor(String serialization , MutableInt k , String[] scan)
	{
		Vector<String> pieces = new Vector<String>();
		k.value = 0;
		IntPair pos = null;
		do
		{
			pos = getNext(scan , serialization , k.value);
			if (pos != null)
			{
				pieces.add(serialization.substring(k.value , pos.first));
				k.value = pos.second + 1;
			}
		}
		while(pos != null);
		return pieces;
	}
	
	private IntPair getNext(String[] what, String serialization, int k)
	{
		boolean varEqual = what[3].equals(what[4]);
		int nestingLevel = 0;
		boolean inVar = false;
		do
		{
			IntPair q = identify(serialization, k, what);
			if (q == null)
				return null;
			if (!inVar)
			{
				if (q.second == 0 && nestingLevel == 0)
					return new IntPair(q.first , q.first + what[q.second].length() - 1);
				
				if (q.second == 1)
					nestingLevel++;
				
				if (q.second == 2)
					nestingLevel--;
			}
			boolean x = false;
			// check for escape - skip if escaped
			if (inVar)
				if (q.first > 0)
					if (q.second == 4 || q.second == 3 && varEqual)
						if (serialization.charAt(q.first - 1) == constants.ESCAPE_CHAR)
							x = true;
			
			if (!x && !inVar)
				if (q.second == 3 || q.second == 4 && varEqual)
				{
					inVar = true;
					x = true;
				}
			
			if (!x && inVar)
				if (q.second == 4 || q.second == 3 && varEqual)
				{
					inVar = false;
					x = true;
				}
			
			
			k = q.first + 1;
		}
		while(true);
	}
	private static IntPair identify(String serialization , int k , String[] what)
	{
		int pos = Integer.MAX_VALUE;
		int type = -1;
		for (int i = 0; i < what.length; i++)
		{
			int q = serialization.indexOf(what[i] , k);
			if (q != -1)
				if (q < pos)
				{
					pos = q;
					type = i;
				}
		}
		if (pos != Integer.MAX_VALUE)
			return new IntPair(pos , type);
		
		return null;
	}
	
}
