/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils;
import java.io.*;
import java.text.*;
import java.util.*;
import info.olteanu.interfaces.*;
import info.olteanu.utils.lang.*;



public class StringTools
{
	// if it is set on true, then tokenization will apply .intern() on each element
	// putting it on true is dangerous: intern uses special memory to store the values, which is limited. Also it is not garbage collected
	public static boolean DEFAULT_DO_INTERN = false;
	
	private static final String[] PERCENT = {"0" , "0.0" , "0.00" , "0.000" , "0.0000" , "0.00000" , "0.000000" , "0.0000000" , "0.00000000"};
	
	// prints a/b as a percent
	public static String percent(long a, long b, int digitsAfterPeriod)
	{
		return formatDouble(100d * a / b , PERCENT[digitsAfterPeriod]) + "%";
	}
	public static String percent(int a, int b, int digitsAfterPeriod)
	{
		return formatDouble(100d * a / b , PERCENT[digitsAfterPeriod]) + "%";
	}
	public static String percent(double a, double b, int digitsAfterPeriod)
	{
		return formatDouble(100d * a / b , PERCENT[digitsAfterPeriod]) + "%";
	}
	
	public static boolean between(String input , String min , String max)
	{
		if (input.compareTo(min) < 0)
			return false;
		if (input.compareTo(max) > 0)
			return false;
		
		return true;
	}
	
	
	public static String replace(String input , String oldSequence , String newSequence)
	{
		// default
		return input.replace(oldSequence, newSequence);
	}
	
	public static String replace(String input , char oldChar , char newChar)
	{
		// default
		return input.replace(oldChar, newChar);
	}
	
	public static String replace(String input , char oldChar , String newSequence)
	{
		// default
		return input.replace(Character.toString(oldChar), newSequence);
	}
	
	public static String replace(String input , String oldSequence , char newChar)
	{
		// default
		return input.replace(oldSequence, Character.toString(newChar));
	}
	
	/** Replaces in the string <i>input</i> the first character in <i>oldChars</i> with the first character in <i>newChars</i>,
	 * then the second character in <i>oldChars</i> with the second character in <i>newChars</i>, etc.
	 */
	public static String replaceChars(String input, String oldChars , String newChars)
	{
		return replaceChars(input, oldChars.toCharArray(), newChars.toCharArray());
	}
	
	/** Replaces in the string <i>input</i> the first character in <i>oldChars</i> with the first character in <i>newChars</i>,
	 * then the second character in <i>oldChars</i> with the second character in <i>newChars</i>, etc.
	 */
	public static String replaceChars(String input, char[] oldChars , char[] newChars)
	{
		if (oldChars.length != newChars.length)
			throw new IndexOutOfBoundsException("Length of oldChars and newChars must be the same. Now: " + oldChars.length + " vs. " + newChars.length);
		
		int n = oldChars.length;
		if (n == 0)
			return input;
		if (n == 1)
			return replace(input, oldChars[0], newChars[0]);
		
		char[] str = input.toCharArray();
		for (int i = 0; i < n; i++)
		{
			char oldChar = oldChars[i];
			char newChar = newChars[i];
			
			if (oldChar != newChar)
				for (int j = 0; j < str.length; j++)
					if (str[j] == oldChar)
						str[j] = newChar;
			
		}
		return new String(str);
	}
	/** Replaces in the string <i>input</i> the first string in <i>oldSequences</i> with the first string in <i>newSequences</i>,
	 * then the second string in <i>oldSequences</i> with the second string in <i>newSequences</i>, etc.
	 */
	public static String replaceStrings(String input, String[] oldSequences , String[] newSequences)
	{
		if (oldSequences.length != newSequences.length)
			throw new IndexOutOfBoundsException("Length of oldSequences and newSequences must be the same. Now: " + oldSequences.length + " vs. " + newSequences.length);
		
		int n = oldSequences.length;
		if (n == 0)
			return input;
		if (n == 1)
			return replace(input, oldSequences[0], newSequences[0]);
		
		for (int i = 0; i < n; i++)
			input = replace(input, oldSequences[i], newSequences[i]);
		
		return input;
	}
	
	public static String remove(String input , String sequence)
	{
		// default
		return replace(input, sequence , "");
	}
	
	public static String remove(String input , char character)
	{
		// default
		return replace(input, Character.toString(character) , "");
	}
	
	
	/** Converts a collection of strings into a sorted array
	 */
	public static String[] arraySorted(Collection<String> collection)
	{
		List<String> list = new ArrayList<String>();
		list.addAll(collection);
		Collections.sort(list);
		return array(list);
	}
	/** Converts a list of strings into an array
	 */
	public static String[] array(List<String> list)
	{
		return list.toArray(new String[list.size()]);
	}
	/** Returns the first element in the array
	 */
	public static String first(String[] array)
	{
		return array[0];
	}
	/** Returns the last element in the array
	 */
	public static String last(String[] array)
	{
		return array[array.length - 1];
	}
	/** Removes the first entry in 'array' that equals 'str'
	 */
	public static String[] removeFirst(String[] array , String str)
	{
		int idx = -1;
		for (int i = 0; i < array.length; i++)
			if (str.equals(array[i]))
			{
				idx = i;
				break;
			}
		if (idx == -1)
			return array;
		
		String[] out = new String[array.length - 1];
		if (idx > 0)
			System.arraycopy(array, 0, out, 0, idx);
		if (idx < out.length)
			System.arraycopy(array, idx + 1, out, idx, out.length - idx);
		
		return out;
	}
	/** Returns true if 'str' is equal to at least one element in 'array'
	 */
	public static boolean inArray(String[] array , String str)
	{
		if (array == null)
			return false;
		for (int i = 0; i < array.length; i++)
			if (str.equals(array[i]))
				return true;
		return false;
	}
	/** Tokenizes a string using variable length delimiters */
	public static String[] tokenizeStr(String input, String delimiterStr)
	{
		ArrayList<String> q = new ArrayList<String>();
		while (input.indexOf(delimiterStr) != -1)
		{
			q.add(substringBefore(input, delimiterStr));
			input = substringAfter(input, delimiterStr);
		}
		q.add(input);
		return q.toArray(new String[q.size()]);
	}
	private static String[] VOID = new String[0];
	/** Generates a new array that contains array[posStart..posEnd]
	 */
	public static String[] select(String[] array , int posStart, int posEnd)
	{
		if (posEnd - posStart + 1 == 0)
			return VOID;
		String[] newArray = new String[posEnd - posStart + 1];
		System.arraycopy(array , posStart , newArray , 0 , newArray.length);
		return newArray;
	}
	/** Generates a new array that contains array[posStart..array.length-1]
	 */
	public static String[] select(String[] array , int posStart)
	{
		return select(array, posStart, array.length - 1);
	}
	/** Removes the first <i>countStart</i> and the last <i>countEnd</i> values from an array.
	 *  Generates a new array.
	 */
	public static String[] cutBothEnds(String[] array , int countStart , int countEnd)
	{
		if (countStart + countEnd > array.length)
			throw new ArrayIndexOutOfBoundsException("Trying to cut more elements (" + (countStart + countEnd) + ") than the array length (" + array.length + ")");
		String[] newArray = new String[array.length - countStart - countEnd];
		System.arraycopy(array , countStart , newArray , 0 , newArray.length);
		return newArray;
	}
	/** Removes the first <i>count</i> values from an array.
	 *  Generates a new array.
	 */
	public static String[] cutFirst(String[] array, int count)
	{
		if (count > array.length)
			throw new ArrayIndexOutOfBoundsException("Trying to cut more elements(" + count + ") than the array length(" + array.length + ")");
		String[] newArray = new String[array.length - count];
		System.arraycopy(array , count , newArray , 0 , newArray.length);
		return newArray;
	}
	/** Removes the last <i>count</i> values from an array.
	 *  Generates a new array.
	 */
	public static String[] cutLast(String[] array, int count)
	{
		if (count > array.length)
			throw new ArrayIndexOutOfBoundsException("Trying to cut more elements (" + count + ") than the array length (" + array.length + ")");
		String[] newArray = new String[array.length - count];
		System.arraycopy(array , 0 , newArray , 0 , newArray.length);
		return newArray;
	}
	/** Appends the value to the end to the array. Generates a new array.
	 */
	public static String[] insertLast(String[] array , String value)
	{
		if (array == null)
			return new String[]{value};
		String[] newArray = new String[array.length + 1];
		System.arraycopy(array , 0 , newArray , 0 , array.length);
		newArray[array.length] = value;
		return newArray;
	}
	/** Appends the value to the end to the array. Generates a new array.
	 */
	public static String[] append(String[] array , String string)
	{
		return insertLast(array, string);
	}
	/**
	 */
	public static String[] insertFirst(String[] array , String value)
	{
		String[] newArray = new String[array.length + 1];
		System.arraycopy(array , 0 , newArray , 1 , array.length);
		newArray[0] = value;
		return newArray;
	}
	/** Appends the values in the second array to the end to the first array. Generates a new array.
	 */
	public static String[] insertLast(String[] array1 , String[] array2)
	{
		String[] newArray = new String[array1.length + array2.length];
		System.arraycopy(array1 , 0 , newArray , 0 , array1.length);
		System.arraycopy(array2 , 0 , newArray , array1.length , array2.length);
		return newArray;
	}
	/** Appends the values in the second array to the end to the first array. Generates a new array.
	 */
	public static String[] append(String[] array1 , String[] array2)
	{
		return insertLast(array1 , array2);
	}
	/**
	 */
	public static String[] insertFirst(String[] array1 , String[] array2)
	{
		return insertLast(array2 , array1);
	}
	/**
	 */
	public static String[] insertLast(String[] array , int count)
	{
		String[] newArray = new String[array.length + count];
		System.arraycopy(array , 0 , newArray , 0 , array.length);
		return newArray;
	}
	/**
	 */
	public static String[] insertFirst(String[] array , int count)
	{
		String[] newArray = new String[array.length + count];
		System.arraycopy(array , 0 , newArray , count , array.length);
		return newArray;
	}
	
	/** Removes the first n characters from the string.
	 */
	public static String removeFirst(String str, int n)
	{
		return str.substring(n);
	}
	/** Removes the last n characters from the string.
	 */
	public static String removeLast(String str, int n)
	{
		return str.substring(0, str.length() - n);
	}
	/** Removes the first token (space-separated) from the string.
	 */
	public static String removeFirstToken(String input)
	{
		boolean found = false;
		for (int i = 0; i < input.length(); i++)
			if (input.charAt(i) <= ' ')
				found = true;
			else
			if (found)
				return input.substring(i);
		
		return "";
	}
	/** Removes the last token (space-separated) from the string.
	 */
	public static String removeLastToken(String input)
	{
		boolean found = false;
		for (int i = input.length() - 1; i >= 0 ; i--)
			if (input.charAt(i) <= ' ')
				found = true;
			else
			if (found)
				return input.substring(0, i + 1);
		
		return "";
	}
	/** Simulates ISNULL(a,b) in SQL. If a is null, return b. Else return a.
	 */
	public static String isNull(String a , String b)
	{
		if (a != null)
			return a;
		return b;
	}
	
	/** Counts how many tokens are in a string, using ' ' (character 32) as a separator
	 *  Assumes that the string is normalized (see normalizeString)
	 */
	public static int countTokensNormalized(String str)
	{
		return countChar(str , ' ') + 1;
	}
	
	/** Counts how many tokens are in a string.
	 */
	public static int countTokens(String str)
	{
		int len = str.length();
		boolean in = false;
		int tokCount = 0;
		for (int i = 0 ; i < len ; i++)
			if (separatorTokenization(str.charAt(i)))
				in = false;
			else
			{
				if (!in)
					tokCount++;
				in = true;
			}
		return tokCount;
	}
	private static boolean separatorTokenization(char c)
	{
		return c == ' ' || c == '\t' || c == '\n' || c == '\r';
	}
	
	/** Counts how many characters of type c are in a string.
	 */
	public static int countChar(String str , char c)
	{
		int cnt = 0;
		for (int i = 0; i < str.length(); i++)
			if (str.charAt(i) == c)
				cnt++;
		return cnt;
	}
	
	
	public static String removeAccents(String text)
	{
		return decomposeWithNormalizer(text)
			.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
	}
	
	private static StringFilter normalizer;
	static
	{
		try
		{
			normalizer = TextNormalizer.getNormalizationStringFilter();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			normalizer = null;
		}
	}
	public static String decomposeWithNormalizer(String text)
	{
		return normalizer.filter(text);
	}
	
	public static String tabulate(String value, int len)
	{
		if (value.length() >= len)
			return value;
		return " " + tabulate(value , len - 1);
	}
	
	public static final String keepOnlyText(String input)
	{
		StringBuilder ret = new StringBuilder(input.length());
		for (int i = 0; i < input.length(); i++)
		{
			char c = input.charAt(i);
			if (c >= '0' && c <= '9' ||
				c >= 'A' && c <= 'Z' ||
				c >= 'a' && c <= 'z')
				ret.append(c);
		}
		return ret.toString();
	}
	
	public static final String normalizeSpace2(String input)
	{
		String str = normalizeSpace(input);
		if (input.length() == 0)
			if (input.length() > 0 && isWhitespace(input.charAt(0)))
				return " ";
			else
				return "";
		
		boolean firstSpace = input.length() > 0 && isWhitespace(input.charAt(0));
		boolean lastSpace = input.length() > 0 && isWhitespace(input.charAt(input.length() - 1));
		return (firstSpace ? " " : "") + str + (lastSpace ? " " : "");
	}
	
	private static boolean isWhitespace(char c)
	{
		return c == ' ' || c == '\r' || c == '\n' || c == '\t';
	}
	
	public static final String normalizeSpace(String input)
	{
		java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(input);
		// assure that it does not grow
		StringBuilder ret = new StringBuilder(input.length());
		if (tokenizer.hasMoreTokens())
		{
			ret.append(tokenizer.nextToken());
			while (tokenizer.hasMoreTokens())
			{
				ret.append(' ');
				ret.append(tokenizer.nextToken());
			}
		}
		return ret.toString();
	}
	
	public static boolean containsDigit(String s)
	{
		for (int i = 0; i < s.length(); i++)
			if (s.charAt(i) >= '0' && s.charAt(i) <= '9')
				return true;
		return false;
	}
	public static String adjustLengthForNumber(int k, int len)
	{
		return adjustLengthForNumber(Integer.toString(k) , len);
	}
	
	public static String adjustLengthForNumber(String k, int len)
	{
		if (k.length() < len)
			return "0" + adjustLengthForNumber(k , len - 1);
		return k;
	}
	
	
	public static String formatDouble(double myDouble , String format)
	{
		DecimalFormat dfFormat = new DecimalFormat(format);
		FieldPosition f = new FieldPosition(0);
		StringBuffer s = new StringBuffer();
		dfFormat.format(myDouble, s, f);
		return s.toString();
	}
	
	public static String substringBefore(String a , String b)
	{
		int idx = a.indexOf(b);
		if (idx == -1)
			return null;
		return a.substring(0 , idx);
	}
	public static String lastSubstringBefore(String a , String b)
	{
		int idx = a.lastIndexOf(b);
		if (idx == -1)
			return null;
		return a.substring(0 , idx);
	}
	
	public static String substringAfter(String a , String b)
	{
		int idx = a.indexOf(b);
		if (idx == -1)
			return null;
		return a.substring(idx + b.length());
	}
	public static String lastSubstringAfter(String a , String b)
	{
		int idx = a.lastIndexOf(b);
		if (idx == -1)
			return null;
		return a.substring(idx + b.length());
	}
	
	
	public static String[] tokenize(String input)
	{
		return tokenize(DEFAULT_DO_INTERN , input);
	}
	
	public static String[] tokenize(String input , String delimiterCharacters)
	{
		return tokenize(DEFAULT_DO_INTERN , input, delimiterCharacters, false);
	}
	public static String[] tokenize(boolean doIntern , String input , String delimiterCharacters)
	{
		return tokenize(doIntern , input, delimiterCharacters, false);
	}
	
	public static String[] tokenize(String input , String delimiterCharacters, boolean keepDelimiters)
	{
		return tokenize(DEFAULT_DO_INTERN, input, delimiterCharacters, keepDelimiters);
	}
	
	public static String[] tokenize(boolean doIntern , String input)
	{
		StringTokenizer st = new StringTokenizer(input);
		String[] k = new String[st.countTokens()];
		if (doIntern)
			for (int i = 0; i < k.length; i++)
				k[i] = st.nextToken().intern();
		else
			for (int i = 0; i < k.length; i++)
				k[i] = st.nextToken();
		return k;
	}
	
	public static String[] tokenize(boolean doIntern , String input , String delimiterCharacters, boolean keepDelimiters)
	{
		StringTokenizer st = new StringTokenizer(input, delimiterCharacters , keepDelimiters);
		String[] k = new String[st.countTokens()];
		if (doIntern)
			for (int i = 0; i < k.length; i++)
				k[i] = st.nextToken().intern();
		else
			for (int i = 0; i < k.length; i++)
				k[i] = st.nextToken();
		return k;
	}
	public static String untokenize(String[] tokens)
	{
		if (tokens.length == 0)
			return "";
		StringBuilder sb = new StringBuilder();
		sb.append(tokens[0]);
		for (int i = 1; i < tokens.length; i++)
		{
			sb.append(' ');
			sb.append(tokens[i]);
		}
		return sb.toString();
	}
	public static String untokenize(String[] tokens , String separator)
	{
		if (tokens.length == 0)
			return "";
		StringBuilder sb = new StringBuilder();
		sb.append(tokens[0]);
		for (int i = 1; i < tokens.length; i++)
		{
			sb.append(separator);
			sb.append(tokens[i]);
		}
		return sb.toString();
	}
	public static void replace(String[] tok, String source, String destination)
	{
		for (int i = 0; i < tok.length; i++)
			if (tok[i].equals(source))
				tok[i] = destination;
	}
	
	public static String fixEncoding(String line , String expectedEncoding , String realEncoding) throws UnsupportedEncodingException
	{
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(bout , false , expectedEncoding);
		ps.print(line);
		ps.close();
		ByteArrayInputStream bin = new ByteArrayInputStream(bout.toByteArray());
		BufferedReader x = new BufferedReader(new InputStreamReader(bin , realEncoding));
		
		try
		{
			return x.readLine();
		}
		catch (IOException e)
		{
			throw new Error(e);
		}
	}
	
	
	
	
	
	// tokenize with some syntax
	// example: tokenize by , while not escaped with \ while not between ( )
	// would be: (input , "," , "\\" , "(" , ")"
	public static String[] tokenizeInBlocks(String input , String delimiter , String escapeSymbol , String enter , String exit , boolean keepDelimiters)
	{
		int depth = 0;
		boolean sameEnterExit = enter.equals(exit);
		String[] search = sameEnterExit ?  new String[]{delimiter , enter} : new String[]{delimiter , enter , exit};
		List<Integer> breakPoints = new ArrayList<Integer>();
		int pos = 0;
		while (true)
		{
			IntPair next = findNext(input , pos , search);
			if (next == null)
				break;
			
			// check if is escaped
			if (!input.substring(pos , next.second).endsWith(escapeSymbol))
			{
				switch (next.first)
				{
					case 0:
						if (depth == 0)
							breakPoints.add(next.second);
						break;
					case 1:
						if (sameEnterExit)
							depth = 1 - depth;// flip between 0 and 1
						else
							depth++;
						break;
					case 2:
						if (depth > 0)
							depth--;
						break;
				}
			}
			
			// move
			pos = next.second + search[next.first].length();
		}
		
		// now break by break points
		List<String> out = new ArrayList<String>();
		
		pos = 0;
		for (int breakPoint : breakPoints)
		{
			if (pos < breakPoint)
				out.add(input.substring(pos , breakPoint));
			
			if (keepDelimiters)
				out.add(delimiter);
			
			pos = breakPoint + delimiter.length();
		}
		
		if (pos < input.length())
			out.add(input.substring(pos));
		
		return array(out);
	}
	
	// find the fist occurence of several choices
	public static IntPair findNext(String input, int fromIndex, String[] strs)
	{
		int foundWhich = -1;
		int foundPos = Integer.MAX_VALUE;
		
		for (int i = 0; i < strs.length; i++)
		{
			int pos = input.indexOf(strs[i] , fromIndex);
			if (pos != -1)
				if (pos < foundPos)
				{
					foundWhich = i;
					foundPos = pos;
				}
		}
		
		
		if (foundWhich == -1)
			return null;
		else
			return new IntPair(foundWhich , foundPos);
	}
}
