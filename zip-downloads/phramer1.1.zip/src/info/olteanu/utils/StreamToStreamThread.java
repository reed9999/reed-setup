/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils;
import info.olteanu.interfaces.*;
import java.net.*;
import java.io.*;
import info.olteanu.utils.lang.*;

// notification recipient: gets notified when the thread ends, due to end of stream/EOF
// data collector: receives all the data transferred
public class StreamToStreamThread extends Thread
{
	public static interface DataCollector
	{
		public void reportData(byte[] data, int start, int length, Object notificationParam);
		public void endOfStream(Object notificationParam);
	}
	
	private final InputStream in;
	private final OutputStream out;
	private final Object notificationParam;
	private final NotificationRecipient nr;
	private final DataCollector dc;
	private final int size;
	public static boolean printDebug = false;
	
	private long totalSize;
	/** Returns how much data in bytes went through the black hole.*/
	public long getTotalSize()
	{
		return totalSize;
	}
	
	public StreamToStreamThread(InputStream in , OutputStream out)
	{
		this(in, out, 16 * 1024 , null , null , null);
	}
	public StreamToStreamThread(InputStream in , OutputStream out , int sizeBuffer)
	{
		this(in, out, sizeBuffer , null , null , null);
	}
	public StreamToStreamThread(InputStream in , OutputStream out , int sizeBuffer , DataCollector dc, NotificationRecipient nr , Object notificationParam)
	{
		this.in = in;
		this.out = out;
		this.size = sizeBuffer;
		this.nr = nr;
		this.dc = dc == null ? new DataCollector(){
			public void reportData(byte[] data, int start, int length, Object notificationParam)
			{
				// nothing to do
			}
			public void endOfStream(Object notificationParam)
			{
				// nothing to do
			}
		} : dc;
		this.notificationParam = notificationParam;
		this.totalSize = 0;
	}
	public void run()
	{
		try
		{
			byte[] buffer = new byte[size];
			
			if (printDebug)
				System.err.println("In " + this);
			
			while (true)
			{
				int cnt = in.read(buffer);
				if (cnt == -1) // eof
					break;
				dc.reportData(buffer , 0 , cnt , notificationParam);
				out.write(buffer, 0, cnt);
				totalSize += cnt;
			}
			
			if (printDebug)
				System.err.println("Out " + this);
		}
		catch (IOException e)
		{
			if (printDebug)
			{
				System.err.println("IOException " + this);
				e.printStackTrace();
			}
		}
		finally
		{
			dc.endOfStream(notificationParam);
			
			closeInAndOut();
			if (nr != null)
				nr.notify(notificationParam);
		}
		if (printDebug)
			System.err.println("Exit " + this);
	}
	
	private void closeInAndOut()
	{
		try
		{
			in.close();
		}
		catch (IOException e)
		{}

		try
		{
			out.flush();
		}
		catch (IOException e)
		{}
		
		if (out != System.out && out != System.err)
			try
			{
				out.close();
			}
			catch (IOException e)
			{}
	}
	
	
	private static class Accepter extends Thread
	{
		public int port, destPort;
		public String destAddr;
		public boolean active = true;
		public int debugLevel = 0;
		public void run()
		{
			if (debugLevel >= 1)
				System.out.println("[" + new java.util.Date() + "] Listening...");
			
			try
			{
				ServerSocket server = new ServerSocket(port);
				server.setSoTimeout(5000);
				while (active)
					try
					{
						// accept a new client and continue
						process(server.accept());
					}
					catch ( SocketTimeoutException e )
					{
						// ignore: designed to inspect active variable
					}
				server.close();
				if (debugLevel >= 1)
					System.out.println("[" + new java.util.Date() + "] Server stopped. Clients might be still active. New requests not accepted.");
			}
			catch (IOException e)
			{
				System.err.println("[" + new java.util.Date() + "] Failure in accepting: " + e.getMessage());
				e.printStackTrace();
			}
		}
		
		private void process(Socket incomingSocket)
		{
			if (debugLevel >= 2)
				System.out.println("[" + new java.util.Date() + "] New connection from " + incomingSocket.getRemoteSocketAddress());
			
			Socket destSocket = null;
			
			try
			{
				destSocket = new Socket(destAddr , destPort);
				//Pair<Socket,Socket> x = new Pair<Socket, Socket>(incomingSocket, destSocket);
				
				new StreamToStreamThread(incomingSocket.getInputStream(), destSocket.getOutputStream(), 1024).start();
				new StreamToStreamThread(destSocket.getInputStream(), incomingSocket.getOutputStream(), 1024).start();
			}
			catch (IOException e)
			{
				if (debugLevel >= 1)
				{
					System.out.println("[" + new java.util.Date() + "] Exception");
					e.printStackTrace(System.out);
				}
				try
				{
					incomingSocket.close();
				}
				catch (Exception ex)
				{}
				try
				{
					destSocket.close();
				}
				catch (Exception ex)
				{}
			}
		}
	}
	
	public static void main(String[] args)
	throws Exception
	{
		if (args.length != 3)
		{
			System.out.println("Mapped link utility");
			System.out.println("Parameters: <listen port> <addr dest> <port dest>");
			System.exit(1);
		}
		//StreamToStreamThread.printDebug = true;
		
		// mapped link
		Accepter a = new Accepter();
		a.debugLevel = 5;
		a.port = Integer.parseInt(args[0]);
		a.destAddr = args[1];
		a.destPort = Integer.parseInt(args[2]);
		a.start();
	}
}
