/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.copyright;
import info.olteanu.utils.*;
import java.io.*;

public class RemoveCopyrightNotice
{
	public static void main(String[] args)
	throws Exception
	{
		String folder = args[0];
		processFolder(new File(folder));
		
	}
	
	private static void processFolder(File folder) throws IOException
	{
		System.out.println("Process: " + folder);
		File[] files = folder.listFiles();
		for (int i = 0; i < files.length; i++)
		{
			if (files[i].getName().endsWith(".java"))
				processFile(files[i]);
			if (files[i].isDirectory())
				processFolder(files[i]);
		}
	}
	
	private static void processFile(File file) throws IOException
	{
		File orig = new File(file.getPath() + ".orig");
		System.out.println("Process file: " + file);
		// rename first
		if (file.renameTo(orig))
		{
			PrintStream outFile = new PrintStream(new FileOutputStream(file));
			// read original file
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(orig)));
			String lineFile;
			boolean inside = false;
			while ((lineFile = inputFile.readLine()) != null)
			{
				int startIdx = 0;
				if (lineFile.startsWith("/* Copyright (c)"))
					inside = true;
				else if (lineFile.indexOf("/* Copyright (c)") > 0 && lineFile.indexOf("\"/* Copyright (c)") == -1)
				{
					startIdx = lineFile.indexOf("/* Copyright (c)") + 1;
					inside = true;

					String part = StringTools.substringBefore(lineFile , "/* Copyright (c)");
					if (lineFile.indexOf("*/" , startIdx) != -1 && !lineFile.trim().endsWith("*/"))
						outFile.print(part);
					else
						outFile.println(part);
				}
				
				if (!inside)
					outFile.println(lineFile);
				
				if (inside)
					if (lineFile.indexOf("*/" , startIdx) != -1)
					{
						inside = false;
						
						if (!lineFile.trim().endsWith("*/"))
							outFile.println(lineFile.substring(lineFile.indexOf("*/" , startIdx) + 2));
					}
				
			}
			inputFile.close();
			outFile.close();
			
			orig.delete();
		}
		else
			throw new IOException("Rename failed");
	}
}
