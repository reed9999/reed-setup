/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.copyright;
import java.io.*;
import java.util.*;

public class PutCopyrightNotice
{
	public static void main(String[] args)
	throws Exception
	{
		String folder = args[0];
		String fileCopyright = args[1];
		
		Vector<String> copyrightNotice = readCopyrightNotice(fileCopyright);
		
		processFolder(new File(folder) , copyrightNotice);
		
	}
	
	private static void processFolder(File folder, Vector<String> copyrightNotice) throws IOException
	{
		System.out.println("Process: " + folder);
		File[] files = folder.listFiles();
		for (int i = 0; i < files.length; i++)
		{
			if (files[i].getName().endsWith(".java"))
				processFile(files[i] , copyrightNotice);
			if (files[i].isDirectory())
				processFolder(files[i] , copyrightNotice);
		}
	}
	
	private static void processFile(File file, Vector<String> copyrightNotice) throws IOException
	{
		File orig = new File(file.getPath() + ".orig");
		System.out.println("Process file: " + file);
		// rename first
		if (file.renameTo(orig))
		{
			PrintStream outFile = new PrintStream(new FileOutputStream(file));
			// read original file
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(orig)));
			String lineFile;
			boolean first = true;
			while ((lineFile = inputFile.readLine()) != null)
			{
				if (first)
				{
					first = false;
					if (!lineFile.startsWith("/* Copyright (c)"))
					{
						System.out.println("  Add notice");
						for (String line: copyrightNotice)
							outFile.println(line);
					}
					else
						System.out.println("  Keep notice: " + lineFile);
				}
				
				outFile.println(lineFile);
			}
			inputFile.close();
			outFile.close();
			
			orig.delete();
		}
		else
			throw new IOException("Rename failed");
	}
	
	private static Vector<String> readCopyrightNotice(String fileCopyRight) throws IOException
	{
		Vector<String> copyrightNotice = new Vector<String>();
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(fileCopyRight)));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
			copyrightNotice.add(lineFile);
		inputFile.close();
		return copyrightNotice;
	}
}
