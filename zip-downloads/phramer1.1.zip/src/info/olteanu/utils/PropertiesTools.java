/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils;

import info.olteanu.utils.lang.Pair;
import java.io.*;
import java.util.*;
import info.olteanu.utils.io.*;

// TODO: detect circular include/import
public class PropertiesTools
{
	
	// no defaults
	/** Retrieves a boolean property from the properties object.
	 */
	public static boolean getBooleanProperty(Properties p , String key)
	{
		return getBooleanProperty(p, key, false);
	}
	/** Retrieves a string property from the properties object.
	 */
	public static String getStringProperty(Properties p , String key)
	{
		return p.getProperty(key);
	}
	/** Retrieves a integer property from the properties object.
	 */
	public static int getIntProperty(Properties p , String key)
	{
		return Integer.parseInt(p.getProperty(key));
	}
	/** Retrieves a long property from the properties object.
	 */
	public static long getLongProperty(Properties p , String key)
	{
		return Long.parseLong(p.getProperty(key));
	}
	/** Retrieves a floating number property from the properties object.
	 */
	public static float getFloatProperty(Properties p , String key)
	{
		return Float.parseFloat(p.getProperty(key));
	}
	/** Retrieves a double (floating number) property from the properties object.
	 */
	public static double getDoubleProperty(Properties p , String key)
	{
		return Double.parseDouble(p.getProperty(key));
	}
	/** Retrieves a string array property from the properties object.
	 */
	public static String[] getStringArrayProperty(Properties p , String key)
	{
		if (!p.containsKey(key + ".count"))
			return null;
		int count = getIntProperty(p , key + ".count");
		String[] values = new String[count];
		for (int i = 0; i < values.length; i++)
			values[i] = getStringProperty(p , key + "." + (i + 1));
		return values;
	}
	
	
	// with defaults
	/** Retrieves a boolean property from the properties object.
	 *  It uses the default value if the property cannot be found in the properties object.
	 */
	public static boolean getBooleanProperty(Properties p , String key , boolean defaultValue)
	{
		String v = p.getProperty(key);
		if (v == null)
			return defaultValue;
		v = v.toLowerCase();
		return v.equals("true") || v.equals("1") || v.equals("yes") || v.equals("y");
	}
	/** Retrieves a string property from the properties object.
	 *  It uses the default value if the property cannot be found in the properties object.
	 */
	public static String getStringProperty(Properties p , String key , String defaultValue)
	{
		String value = p.getProperty(key);
		if (value != null)
			return value;
		return defaultValue;
	}
	/** Retrieves a integer property from the properties object.
	 *  It uses the default value if the property cannot be found in the properties object.
	 */
	public static int getIntProperty(Properties p , String key , int defaultValue)
	{
		String v = p.getProperty(key);
		if (v == null)
			return defaultValue;
		return Integer.parseInt(v);
	}
	/** Retrieves a long property from the properties object.
	 *  It uses the default value if the property cannot be found in the properties object.
	 */
	public static long getLongProperty(Properties p , String key , long defaultValue)
	{
		String v = p.getProperty(key);
		if (v == null)
			return defaultValue;
		return Long.parseLong(v);
	}
	/** Retrieves a floating number property from the properties object.
	 *  It uses the default value if the property cannot be found in the properties object.
	 */
	public static float getFloatProperty(Properties p , String key , float defaultValue)
	{
		String v = p.getProperty(key);
		if (v == null)
			return defaultValue;
		return Float.parseFloat(v);
	}
	/** Retrieves a double (floating number) property from the properties object.
	 *  It uses the default value if the property cannot be found in the properties object.
	 */
	public static double getDoubleProperty(Properties p , String key , double defaultValue)
	{
		String v = p.getProperty(key);
		if (v == null)
			return defaultValue;
		return Double.parseDouble(v);
	}
	
	
	/** Adds the properties from the command line to the properties object.
	 *  The properties are identified by the prefix (e.g.: "--" or "/").
	 */
	public static void addPropertiesFromCommandLine(Properties p , String[] cmdLine , String prefix)
	{
		HashMap<String, Object> overwritting = CommandLineTools.getParameters(cmdLine , prefix);
		for (String param : overwritting.keySet())
		{
			Object value = overwritting.get(param);
			param = param.substring(prefix.length());// get rid of the prefix
			String strValue;
			// convert value
			if (value == null)
				strValue = "";// TODO: check if it is the right thing
			else if (value instanceof String)
				strValue = (String)value;
			else if (value instanceof String[])
				strValue = StringTools.untokenize((String[])value);
			else
				throw new Error("Unexpected object type: " + value);
			
			p.setProperty(param , strValue);
		}
	}
	
	/** Generates a map (properties-like object) from a comma separated list
	 * Input example: "key1 = value1 , key2 = value2".
	 */
	public static HashMap<String,String> getPropertiesFromCSV(String line)
	{
		HashMap<String,String> h = new HashMap<String,String>();
		StringTokenizer st = new StringTokenizer(line, ",");
		while (st.hasMoreTokens())
		{
			String prop = st.nextToken();
			h.put(StringTools.substringBefore(prop , "=").trim() ,
				  StringTools.substringAfter(prop , "=").trim());
		}
		return h;
	}
	
	
	/** Concatenates the properties from <b>initial</b> with the properties
	 * from <b>addOn</b> into the <b>initial</b> object
	 */
	public static void overwritePropertiesWith(Map<String, String> initial ,
											   Map<String, String> addOn)
	{
		initial.putAll(addOn);
	}
	
	
	
	/** Reads a property list file (key = value). <br>
	 * Solves imports:<br>
	 * <i>&#x40;&#x40;import [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;import [filename] (filename reference -- relative to the current properties file)</i><br>
	 * <i>&#x40;&#x40;import-name [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;import-name [filename] (filename reference -- relative to the current properties file)</i><br>
	 * Solves includes:<br>
	 * <i>&#x40;&#x40;include [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;include [filename] (filename reference -- relative to the current properties file)</i><br>
	 * <i>&#x40;&#x40;include-name [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;include-name [filename] (filename reference -- relative to the current properties file)</i><br>
	 * Warning: multiple include/import references require multiple names
	 * (e.g.: <i>&#x40;&#x40;import-basic</i> and <i>&#x40;&#x40;import-extra)</i>. <br>
	 * Difference between include and import:
	 * <ul>
	 * <li> Imported property files - expansion takes place prior to addition to the big set of properties <br>
	 * <li> Included property files - expansion doesn't take prior to addition to the big set of properties.
	 * After all includes and imports are processed, property expansion takes place. The base for property expansion
	 * (which involves relative paths) is considered the main file that includes additional files.
	 * </ul>
	 * <br>
	 *
	 *
	 * Properties expansion implements the following features:
	 * <ol>
	 *
	 * <li>Solves references to other properties: <br>
	 * <i>key1 = a b c ${key2} d e f </i><br>
	 *
	 * <li>Reads files and put the content into the value of the property: <br>
	 * <i>key = a b c ${&#x40;file} d e f </i><br>
	 * <i>key = a b c ${&#x40;&#x40;file} d e f </i><br>
	 * where &#x40;file points to an absolute referred file and &#x40;&#x40; points to a relative referred file <br>
	 *
	 * <li>Provides the name of the folder in which the current property file resides: <br>
	 * <i>dataFile = ${&#x40;&#x40;}/../data/dataFile.txt</i>
	 *
	 * <li>Provides the name of current properties file: <br>
	 * <i>thisPropFile = ${&#x40;&#x40;&#x40;}</i>
	 *
	 * <li>Executes commands and put the stdout content into the value of the property: <br>
	 * <i>key = a b c ${`command`} d e f </i><br>
	 * This is enabled only when the parameter <b>allowExecProperties</b> is set on true.
	 * Warning: enabling it may pose security risks. <br>
	 *
	 * <li>Solves references to environment variables: <br>
	 * <i>key1 = a b c ${$USER} d e f </i>
	 *
	 * <li>Solves references to system properties: <br>
	 * <i>key1 = a b c ${#file.encoding} d e f </i>
	 *
	 * </ol>
	 */
	public static Properties getProperties(String fileName, boolean allowExecProperties)
	throws IOException, PropertiesTools.PropertyExpansionException
	{
		Properties p = new Properties();
		p.load(new BufferedInputStream(new FileInputStream(fileName)));
		// during the include solving, accumulate import data in this list
		List<Pair<Boolean,String>> imports = new ArrayList<Pair<Boolean, String>>();
		solveIncludes(fileName, p, imports);
		// use the import data accumulated during includes
		solveImports(imports , fileName , p , allowExecProperties);
		expand(fileName, p , allowExecProperties);
		return p;
	}
	
	/** Implements <b>getProperties(String fileName, boolean allowExecProperties)</b>,
	 * setting <b>allowExecProperties</b> to <b>false</b>.
	 * <br><br><br>
	 * Reads a property list file (key = value). <br>
	 * Solves imports:<br>
	 * <i>&#x40;&#x40;import [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;import [filename] (filename reference -- relative to the current properties file)</i><br>
	 * <i>&#x40;&#x40;import-name [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;import-name [filename] (filename reference -- relative to the current properties file)</i><br>
	 * Solves includes:<br>
	 * <i>&#x40;&#x40;include [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;include [filename] (filename reference -- relative to the current properties file)</i><br>
	 * <i>&#x40;&#x40;include-name [filename] (filename reference -- absolute)</i><br>
	 * <i>&#x40;&#x40;&#x40;include-name [filename] (filename reference -- relative to the current properties file)</i><br>
	 * Warning: multiple include/import references require multiple names
	 * (e.g.: <i>&#x40;&#x40;import-basic</i> and <i>&#x40;&#x40;import-extra)</i>. <br>
	 * Difference between include and import:
	 * <ul>
	 * <li> Imported property files - expansion takes place prior to addition to the big set of properties <br>
	 * <li> Included property files - expansion doesn't take prior to addition to the big set of properties.
	 * After all includes and imports are processed, property expansion takes place. The base for property expansion
	 * (which involves relative paths) is considered the main file that includes additional files.
	 * </ul>
	 * <br>
	 *
	 *
	 * Properties expansion implements the following features:
	 * <ol>
	 *
	 * <li>Solves references to other properties: <br>
	 * <i>key1 = a b c ${key2} d e f </i><br>
	 *
	 * <li>Reads files and put the content into the value of the property: <br>
	 * <i>key = a b c ${&#x40;file} d e f </i><br>
	 * <i>key = a b c ${&#x40;&#x40;file} d e f </i><br>
	 * where &#x40;file points to an absolute referred file and &#x40;&#x40; points to a relative referred file <br>
	 *
	 * <li>Provides the name of the folder in which the current property file resides: <br>
	 * <i>dataFile = ${&#x40;&#x40;}/../data/dataFile.txt</i>
	 *
	 * <li>Provides the name of current properties file: <br>
	 * <i>thisPropFile = ${&#x40;&#x40;&#x40;}</i>
	 *
	 * <li>Solves references to environment variables: <br>
	 * <i>key1 = a b c ${$USER} d e f </i>
	 *
	 * <li>Solves references to system properties: <br>
	 * <i>key1 = a b c ${#file.encoding} d e f </i>
	 *
	 * </ol>
	 */
	public static Properties getProperties(String fileName)
	throws IOException, PropertiesTools.PropertyExpansionException
	{
		return getProperties(fileName, false);
	}
	
	private static Properties getPropertiesOnlyInclude(String fileName , List<Pair<Boolean,String>> imports) throws IOException
	{
		Properties p = new Properties();
		p.load(new BufferedInputStream(new FileInputStream(fileName)));
		solveIncludes(fileName, p, imports);
		return p;
	}
	
	private static void solveIncludes(String fileName , Properties p , List<Pair<Boolean,String>> imports)
	throws IOException
	{
		// old way: scan them in the properties file
		// issue: conflict (double @@include or double @@import) - only one gets loaded
		// new way: scan file
		boolean contLine = false;
		for (String lineFile : new LineReaderCollection(fileName , "ISO-8859-1"))// see java.lang.Properties, load method: assumes encoding ISO 8859-1
		{
			// avoid:
			//   +--------------
			//   |key = xxx \
			//   |@@@import x
			//   +--------------
			// which is not a valid import clause
			// and it is equivalent with:
			//   +--------------
			//   |key = xxx @@@import x
			//   +--------------
			boolean prevContLine = contLine;
			contLine = lineFile.endsWith("\\");
			if (prevContLine)
				continue;
			
			boolean absoluteIncl = lineFile.startsWith("@@include");
			boolean relativeIncl = lineFile.startsWith("@@@include");
			boolean absoluteImp = lineFile.startsWith("@@import");
			boolean relativeImp = lineFile.startsWith("@@@import");
			
			boolean incl = absoluteIncl || relativeIncl;
			boolean imp = absoluteImp || relativeImp;
			
			if (incl || imp)
			{
				lineFile = lineFile.replace('\t' , ' ');// make sure no tabs
				
				p.remove(StringTools.substringBefore(lineFile , " ").trim());
				String fileNameI = StringTools.substringAfter(lineFile , " ").trim();
				if (incl)
					solveOneInclude(relativeIncl, fileNameI, fileName, p , imports);
				else
					imports.add(new Pair<Boolean,String>(relativeImp , fileNameI));
			}
		}
	}
	
	
	
	
	public static void solveImports(List<Pair<Boolean,String>> imports, String fileName , Properties p, boolean allowExecProperties)
	throws IOException, PropertiesTools.PropertyExpansionException
	{
		// old way: scan them in the properties file
		// issue: conflict (double @@include or double @@import) - only one gets loaded
		// new way: scan file in include, use values here
		for (Pair<Boolean,String> pair : imports)
		{
			boolean relative = pair.first;
			String fileNameI = pair.second;
			solveOneImport(relative, fileNameI, fileName, p, allowExecProperties);
		}
		
	}
	
	private static void solveOneInclude(boolean relativePath, String includeFileName, String fileName, Properties p , List<Pair<Boolean,String>> imports) throws IOException
	{
		if (relativePath)
			includeFileName = solveRelativePath(includeFileName , fileName);
		Properties incl = getPropertiesOnlyInclude(includeFileName , imports);
		// push them for include
		Enumeration<String> enum2 = (Enumeration<String>) incl.propertyNames();
		while (enum2.hasMoreElements())
		{
			String key2 = enum2.nextElement();
			if (!p.containsKey(key2))
				p.setProperty(key2 , incl.getProperty(key2));
		}
	}
	
	private static void solveOneImport(boolean relativePath, String importFileName, String fileName, Properties p, boolean allowExecProperties) throws PropertiesTools.PropertyExpansionException, IOException
	{
		if (relativePath)
			importFileName = solveRelativePath(importFileName , fileName);
		Properties imp = getProperties(importFileName, allowExecProperties);
		// push them for import
		Enumeration<String> enum2 = (Enumeration<String>) imp.propertyNames();
		while (enum2.hasMoreElements())
		{
			String key2 = enum2.nextElement();
			if (!p.containsKey(key2))
				p.setProperty(key2 , imp.getProperty(key2));
		}
	}
	
	private static String solveRelativePath(String relativePath, String base)
	{
		// linux/unix style
		if (relativePath.startsWith("/"))
			return relativePath;
		
		// windows style
		char c1 = relativePath.charAt(0),
			c2 = relativePath.charAt(1);
		if (c2 == ':')
			if (c1 >= 'A' && c1 <= 'Z' || c1 >= 'a' && c1 <= 'z')
				return relativePath;
		
		// continue
		base = new File(base).getAbsolutePath();
		if (base.indexOf(File.separator) == -1)
			return relativePath;
		return StringTools.lastSubstringBefore(base , File.separator) + File.separator + relativePath;
	}
	
	private static String getFolderName(String base)
	{
		base = new File(base).getAbsolutePath();
		if (base.indexOf(File.separator) == -1)
			return "";// or null?
		return StringTools.lastSubstringBefore(base , File.separator);
	}
	
	public static void expand(String basePath, Properties p, boolean allowExecProperties)
	throws PropertyExpansionException, IOException
	{
		Enumeration<String> enu = (Enumeration<String>) p.propertyNames();
		while (enu.hasMoreElements())
		{
			String key = enu.nextElement();
			String value = p.getProperty(key);
			if (value != null)
				if (needsExpansion(value))
					p.setProperty(key, getExpandedValue(basePath, key , p, new HashSet<String>(), allowExecProperties));
		}
	}
	
	private static String getExpandedValue(String basePath, String thisKey , Properties p, HashSet<String> keys, boolean allowExecProperties)
	throws PropertyExpansionException, IOException
	{
		String value = p.getProperty(thisKey);
		if (value == null)
			throw new PropertyExpansionException("Missing property: " + thisKey);
		
		if (!needsExpansion(value))
			return value;
		
		keys.add(thisKey);
		
		StringBuilder sb = new StringBuilder();
		int pos = 0 , newPos;
		while ((newPos = value.indexOf("${" , pos)) != -1)
		{
			if (newPos > pos)
				sb.append(value.substring(pos , newPos));
			// get name
			int posClose = value.indexOf("}" , newPos + 2);
			if (posClose == -1)
				throw new PropertyExpansionException("Invalid property value: [" + value + "]");
			
			String xpd = value.substring(newPos + 2 , posClose);
			
			if (xpd.startsWith("@"))
			{
				// reference to the prop file folder, or name of the file folder
				// or load a new file
				if (xpd.equals("@@"))
					sb.append(getFolderName(basePath));
				else if (xpd.equals("@@@"))
					sb.append(basePath);
				else
				{
					String filePath;
					// read a file
					
					if (xpd.startsWith("@@"))
						filePath = solveRelativePath(xpd.substring(2), basePath);
					else
						filePath = xpd.substring(1);
					
					sb.append(readPropertyFromFile(filePath));
				}
			}
			else if (xpd.startsWith("$"))
			{
				String v = System.getenv(xpd.substring(1));
				if (v == null)
					throw new IOException("Environment variable '" + xpd.substring(1) + "' not defined");
				sb.append(v);
			}
			else if (xpd.startsWith("#"))
			{
				String v = System.getProperty(xpd.substring(1));
				if (v == null)
					throw new IOException("System property '" + xpd.substring(1) + "' not defined");
				sb.append(v);
			}
			else if (allowExecProperties && xpd.startsWith("`") && xpd.endsWith("`"))
			{
				String command = xpd.substring(1, xpd.length() - 1);
				sb.append(readPropertyFromCommand(command));
			}
			else
			{
				
				if (keys.contains(xpd))
					throw new PropertyExpansionException("Circular reference for " + thisKey);
				
				
				sb.append(getExpandedValue(basePath , xpd , p , (HashSet<String>)keys.clone(), allowExecProperties));
			}
			
			pos = posClose + 1;
		}
		if (pos < value.length())
			sb.append(value.substring(pos));
		keys.clone();
		
		return sb.toString();
	}
	
	private static String readPropertyFromCommand(String command) throws IOException
	{
		try
		{
			return ProcessExecTools.exec(command).first;
		}
		catch (InterruptedException e)
		{
			throw new IOException("InterruptedException: " + e);
		}
	}
	
	private static String readPropertyFromFile(String filePath) throws IOException
	{
		StringBuilder sb = new StringBuilder();
		BufferedReader inputFile = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
		String lineFile;
		while ((lineFile = inputFile.readLine()) != null)
		{
			if (lineFile.length() > 0)
			{
				if (sb.length() > 0)
					sb.append('\n');
				sb.append(lineFile);
			}
		}
		inputFile.close();
		return sb.toString();
	}
	private static boolean needsExpansion(String value)
	{
		return value.indexOf("${") != -1;
	}
	public static class PropertyExpansionException extends Exception
	{
		public PropertyExpansionException()
		{
			super();
		}
		public PropertyExpansionException(String message)
		{
			super(message);
		}
	}
}
