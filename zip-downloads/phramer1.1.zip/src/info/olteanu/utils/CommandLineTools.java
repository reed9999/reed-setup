/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils;
import info.olteanu.utils.*;
import java.util.*;

public class CommandLineTools
{
	
	/** Read parameters from the command line. Build hash: String[] or String or null
	 */
	public static HashMap<String,Object> getParameters(String[] cmdLine, String prefix)
	{
		if (cmdLine.length == 0)
			return new HashMap<String,Object>();
		if (!cmdLine[0].startsWith(prefix)
			|| isNumber(cmdLine[0]))
			return null;// not valid
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		Vector<String> values = new Vector<String>();
		String activeParameter = null;
		for (int i = 0; i < cmdLine.length; i++)
			if (cmdLine[i].startsWith(prefix)
				&& !isNumber(cmdLine[i])
				)
			{
				// commit the last one
				if (activeParameter != null)
					commit(values, map, activeParameter);
				activeParameter = cmdLine[i];
			}
			else
				values.add(cmdLine[i]);
		assert activeParameter != null;
		commit(values, map, activeParameter);
		assert values.size() == 0;
		return map;
	}
	
	private static boolean isNumber(String param)
	{
		try
		{
			Double.parseDouble(param);
			return true;
		}
		catch ( NumberFormatException e )
		{
			return false;
		}
	}
	
	private static void commit(Vector<String> values, HashMap<String,Object> map, String activeParameter)
	{
		if (values.size() == 0)
			map.put(activeParameter , null);
		else if (values.size() == 1)
			map.put(activeParameter, values.firstElement());
		else
			map.put(activeParameter, values.toArray(new String[values.size()]));
		values.clear();
	}
	public static String[] tokenize(String commandLine)
	{
		return StringTools.tokenize(false, commandLine);
	}
	public static String getParameter(String name, String[] commandLine)
	{
		for (int i = 0; i < commandLine.length - 1; i++)
			if (commandLine[i].equals(name))
				return commandLine[i + 1];
		return null;
	}
	public static boolean isParameter(String name, String[] commandLine)
	{
		for (int i = 0; i < commandLine.length; i++)
			if (commandLine[i].equals(name))
				return true;
		return false;
	}
	public static String[] getParameter(String name, String[] commandLine , int paramLength)
	{
		for (int i = 0; i < commandLine.length - paramLength; i++)
			if (commandLine[i].equals(name))
			{
				String[] k = new String[paramLength];
				for (int j = 0; j < k.length; j++)
					k[j] = commandLine[i + 1 + j];
				return k;
			}
		return null;
	}
}
