/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils;
import info.olteanu.interfaces.*;
import java.io.*;

public class StreamToStreamByLineThread extends Thread
{
	
	private BufferedReader in;
	private PrintStream out;
	private String prefix = null;
	private Object notificationParam;
	private NotificationRecipient nr;
	private boolean timestamp;
	
	private long lineCount;
	/** Returns how much data in lines went through the black hole.*/
	public long getLineCount()
	{
		return lineCount;
	}
	private long charCount;
	/** Returns how much data in characters (not counting line breaks) went through the black hole.*/
	public long getCharCount()
	{
		return charCount;
	}
	public StreamToStreamByLineThread(BufferedReader in , PrintStream out , String prefix)
	{
		this(in, out, prefix, null, null);
	}
	public StreamToStreamByLineThread(BufferedReader in , PrintStream out , String prefix , NotificationRecipient nr , Object notificationParam)
	{
		this(in, out, prefix, nr, notificationParam, false);
	}
	
	public StreamToStreamByLineThread(BufferedReader in , PrintStream out , String prefix , NotificationRecipient nr , Object notificationParam , boolean timestamp)
	{
		this.in = in;
		this.out = out;
		this.prefix = prefix;
		this.nr = nr;
		this.notificationParam = notificationParam;
		this.timestamp = timestamp;
	}
	public StreamToStreamByLineThread(InputStream in , PrintStream out , NotificationRecipient nr , Object notificationParam)
	{
		this(in , out , null , nr , notificationParam);
	}
	public StreamToStreamByLineThread(InputStream in , PrintStream out)
	{
		this(in, out, null);
	}
	public StreamToStreamByLineThread(InputStream in , PrintStream out , String prefix , NotificationRecipient nr , Object notificationParam)
	{
		this(in, out, prefix, nr, notificationParam, false);
	}
	public StreamToStreamByLineThread(InputStream in , PrintStream out , String prefix , NotificationRecipient nr , Object notificationParam, boolean timestamp)
	{
		this.in = new BufferedReader(new InputStreamReader(in));
		this.out = out;
		this.prefix = prefix;
		this.nr = nr;
		this.notificationParam = notificationParam;
		this.timestamp = timestamp;
		this.lineCount = 0;
		this.charCount = 0;
	}
	public StreamToStreamByLineThread(InputStream in , PrintStream out , String prefix)
	{
		this(in, out, prefix , null, null);
	}
	public StreamToStreamByLineThread(InputStream in , PrintStream out , String prefix, boolean timestamp)
	{
		this(in, out, prefix , null, null , timestamp);
	}
	public void run()
	{
		try
		{
			String lineFile;
			if (timestamp)
			{
				if (prefix != null)
					while ((lineFile = in.readLine()) != null)
					{
						out.println(new java.util.Date() + prefix + lineFile);
						lineCount++;
						charCount += lineFile.length();
					}
				else
					while ((lineFile = in.readLine()) != null)
					{
						out.println(new java.util.Date() + lineFile);
						lineCount++;
						charCount += lineFile.length();
					}
			}
			else
			{
				if (prefix != null)
					while ((lineFile = in.readLine()) != null)
					{
						out.println(prefix + lineFile);
						lineCount++;
						charCount += lineFile.length();
					}
				else
					while ((lineFile = in.readLine()) != null)
					{
						out.println(lineFile);
						lineCount++;
						charCount += lineFile.length();
					}
			}
			
			in.close();
			
			if (nr != null)
				nr.notify(notificationParam);
			
			// NO: out.close();
			// if applied to System.err or System.out ...
		}
		catch (IOException e)
		{
			if (nr != null)
				nr.notify(notificationParam);
		}
	}
}
