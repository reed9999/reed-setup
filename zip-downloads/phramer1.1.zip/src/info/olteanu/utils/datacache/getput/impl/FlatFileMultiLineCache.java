/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.datacache.getput.impl;
import info.olteanu.utils.datacache.getput.*;
import info.olteanu.utils.remoteservices.*;
import info.olteanu.utils.remoteservices.server.*;
import info.olteanu.utils.datacache.getput.remote.*;
import java.io.*;
import info.olteanu.utils.io.*;
import info.olteanu.utils.*;

// not fully reliable if it's closed while it writes to the file
// ".gz" not very reliable. Zip is better
public class FlatFileMultiLineCache implements MultiLineCache
{
	private final MemoryMultiLineCache mmlc;
	private final PrintStream ps;
	public FlatFileMultiLineCache(String fileName) throws IOException
	{
		mmlc = new MemoryMultiLineCache();
		boolean fileExists = new File(fileName).exists();
		int cnt = 0;
		if (fileExists)
		{
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(
															  IOTools.getInputStream(fileName)
															  , "UTF-8"
														  ));
			
			String lineFile;
			while ((lineFile = inputFile.readLine()) != null)
			{
				if (lineFile.length() != 0)
					throw new IOException("Bad file format. Expected zero-length line");
				
				String[] key = readBlock(inputFile);
				String[] value = readBlock(inputFile);
				
				mmlc.put(key, value);
				cnt++;
			}
			inputFile.close();
		}
		if (IOTools.isArchived(fileName) && fileExists && cnt > 0)
		{
			// redo the file
			
			// move
			String newFileName = fileName + ".bak." + StringTools.lastSubstringAfter(fileName, ".");
			new File(fileName).renameTo(new File(newFileName));
			ps = new PrintStream(IOTools.getOutputStream(fileName), false , "UTF-8");
			
			// copy
			BufferedReader inputFile = new BufferedReader(new InputStreamReader(
															  IOTools.getInputStream(newFileName)
															  , "UTF-8"
														  ));
			
			String lineFile;
			while ((lineFile = inputFile.readLine()) != null)
				ps.println(lineFile);
			inputFile.close();
		}
		else if (fileExists && cnt > 0)
			ps = new PrintStream(new FileOutputStream(fileName, true), false , "UTF-8");
		else // file doesn't exist or has lenght 0. Maybe it's archived
			ps = new PrintStream(IOTools.getOutputStream(fileName), false , "UTF-8");
		
		Runtime.getRuntime().addShutdownHook(new Thread(){
				public void run()
				{
					System.err.println("Closing archive file...");
					synchronized (ps)
					{
						ps.close();
					}
				}
			});
	}
	
	
	
	public synchronized String[] get(String[] key)
	{
		return mmlc.get(key);
	}
	
	public synchronized boolean put(String[] key, String[] value)
	{
		synchronized (ps)
		{
			ps.println();
			writeBlock(key);
			writeBlock(value);
			ps.flush();
		}
		return mmlc.put(key, value);
	}
	
	
	private String[] readBlock(BufferedReader inputFile)
	throws IOException
	{
		String strCnt = inputFile.readLine();
		boolean withNulls = false;
		if (strCnt.charAt(0) == 'N')
		{
			strCnt = strCnt.substring(1);
			withNulls = true;
		}
		int cntLine = Integer.parseInt(strCnt);
		if (cntLine == -1)
			return null;
		String[] out = new String[cntLine];
		for (int i = 0; i < out.length; i++)
		{
			String fileLine = inputFile.readLine();
			if (withNulls)
				if (fileLine.length() == 0)
					out[i] = null;
				else
					out[i] = fileLine.substring(1);
			else
				out[i] = fileLine;
		}
		
		return out;
	}
	private void writeBlock(String[] block)
	{
		if (block == null)
			ps.println("-1");
		else
		{
			boolean withNulls = false;
			for (String line : block)
				if (line == null)
				{
					withNulls = true;
					break;
				}
			
			if (withNulls)
				ps.print('N');
			ps.println(block.length);
			if (withNulls)
				for (String line : block)
				{
					if (line == null)
						ps.println();
					else
					{
						ps.print(":");
						ps.println(line);
					}
				}
			else
				for (String line : block)
					ps.println(line);
		}
	}
	protected void finalize()
	{
		synchronized (ps)
		{
			ps.close();
		}
	}
	
	
	public static void main(String[] args)
	throws Exception
	{
		if (args.length != 2)
		{
			System.err.println("Usage: <port> <cache_file>");
			System.exit(1);
		}
		
		String port = args[0];
		MultiLineCache cache = new FlatFileMultiLineCache(args[1]);
		RemoteService rs = new ServerWrapperMultiLineCache(cache);
		Server server = new Server(rs, port);
		server.autoDisconnectTime = 20000;
		server.debugLevel = 2;
		server.start();
	}
}
