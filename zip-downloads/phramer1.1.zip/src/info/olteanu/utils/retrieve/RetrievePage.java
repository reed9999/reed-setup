/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.retrieve;
import java.io.*;
import java.net.*;
import java.util.zip.*;
import info.olteanu.utils.*;

public class RetrievePage
{
	// buffer length, binary
	private final int BUFFER_LEN = 65536;
	// buffer length, string
	private final int BUFFER_LEN_STRING = 16*1024;
	
	// default encoding for string retrieval
	public String defaultEncoding = "UTF-8";
	// should "defaultEncoding" be used always, ignoring Content-Type ?
	public boolean forceDefaultEncoding = false;
	// timeout for retrieving content (both connection timeout and read timeout). -1 = infinity
	public int timeOut = -1;
	public static RetrievePage makeWithCookie(String cookie , boolean autoRef)
	{
		String req[][] = new String[1][2];
		req[0][0] = "Cookie";
		req[0][1] = cookie;
		return new RetrievePage(req , autoRef);
	}
	private static final String[][] pIE =
	{
		{"Accept","image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, application/x-shockwave-flash, */*" },
		{"Accept-Language","en-us"},
		{"Accept-Encoding","gzip, deflate"},
		{"User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)"	},
	};
	
	public static RetrievePage makeAsIE(boolean autoRef)
	{
		return new RetrievePage(pIE , autoRef);
	}
	
	public static RetrievePage makeAsIE(String host , boolean autoRef)
	{
		String[][] pIE2 = new String[pIE.length + 1][2];
		System.arraycopy(pIE , 0 , pIE2 , 0 , pIE.length);
		pIE2[pIE.length][0] = "Host";
		pIE2[pIE.length][1] = host;
		return new RetrievePage(pIE2 , autoRef);
	}
	
	
	public RetrievePage()
	{
		props = null;
		autoRef = false;
		this.lastURLConnection = null;
	}
	public RetrievePage(String props[][])
	{
		this.props = props;
		autoRef = false;
		this.lastURLConnection = null;
	}
	public RetrievePage(boolean autoRef)
	{
		props = null;
		this.autoRef = autoRef;
		this.lastURLConnection = null;
	}
	public RetrievePage(String props[][], boolean autoRef)
	{
		this.props = props;
		this.autoRef = autoRef;
	}
	private final String props[][];
	private final boolean autoRef;
	private URLConnection lastURLConnection;
	
	public URLConnection getLastURLConnection()
	{
		return lastURLConnection;
	}
	
	private void prepareUC(URLConnection uc, String urlToRetrieve)
	{
		if (autoRef)
			uc.setRequestProperty("Referer" , urlToRetrieve);
		
		if (props != null)
			for (String[] prop : props)
				uc.setRequestProperty(prop[0] , prop[1]);
	}
	
	private InputStream prepareInputStream(String urlToRetrieve) throws IOException
	{
		URL url = new URL(urlToRetrieve);
		URLConnection uc = url.openConnection();
		if (timeOut > 0)
		{
			uc.setConnectTimeout(timeOut);
			uc.setReadTimeout(timeOut);
		}
		prepareUC(uc, urlToRetrieve);
		InputStream is = uc.getInputStream();
		// deflate, if necesarily
		if ("gzip".equals(uc.getContentEncoding()))
			is = new GZIPInputStream(is);
		
		this.lastURLConnection = uc;
		return is;
	}
	
	
	
	// retrieves into an output stream
	public void retrieveToStream(String urlToRetrieve , OutputStream stream)
	throws MalformedURLException , IOException
	{
		InputStream is = prepareInputStream(urlToRetrieve);
		byte[] buffer = new byte[BUFFER_LEN];
		while (true)
		{
			int nBytes = is.read(buffer);
			if (nBytes == -1)
				break;
			stream.write(buffer , 0 , nBytes);
		}
		is.close();
		stream.flush();
	}
	
	// retrieves into an String object
	public String retrieve(String urlToRetrieve)
	throws MalformedURLException , IOException
	{
		InputStream is = prepareInputStream(urlToRetrieve);
		String encoding = detectEncoding();
		BufferedReader in = new BufferedReader(new InputStreamReader(is , encoding));
		StringBuilder output = new StringBuilder(BUFFER_LEN_STRING);
		String str;
		boolean first = true;
		while ((str = in.readLine()) != null)
		{
			if (!first)
				output.append("\n");
			first = false;
			output.append(str);
		}
		in.close();
		return output.toString();
	}
	
	
	
	
	
	
	// retrieves into a file
	public void retrieveBinaryToFile(String urlToRetrieve, String fileDest)
	throws MalformedURLException , IOException
	{
		OutputStream os = new FileOutputStream(fileDest);
		retrieveToStream(urlToRetrieve , os);
		os.close();
	}
	
	
	
	
	
	
	
	public void forceRetrieveBinaryToFile(String urlToRetrieve, String fileDest)
	throws MalformedURLException , IOException
	{
		for (int i = 1 ; i <= 10 ; i++)
			try
			{
				retrieveBinaryToFile(urlToRetrieve , fileDest);
				return;
			}
			catch ( IOException e )
			{
				System.err.println("Exception " + e);
			}
		retrieveBinaryToFile(urlToRetrieve , fileDest);
	}
	public String forceRetrieve(String urlToRetrieve)
	throws MalformedURLException , IOException
	{
		for (int i = 1 ; i <= 10 ; i++)
			try
			{
				return retrieve(urlToRetrieve);
			}
			catch ( IOException e )
			{
				System.err.println("Exception " + e);
			}
		return retrieve(urlToRetrieve);
	}
	
	
	
	
	// detects encoding associated to the current URL connection, taking into account the default encoding
	public String detectEncoding()
	{
		if (forceDefaultEncoding)
			return defaultEncoding;
		String detectedEncoding = detectEncodingFromContentTypeHTTPHeader(lastURLConnection.getContentType());
		if (detectedEncoding == null)
			return defaultEncoding;
		
		return detectedEncoding;
	}
	
	
	public static String detectEncodingFromContentTypeHTTPHeader(String contentType)
	{
		if (contentType != null)
		{
			int chsIndex = contentType.indexOf("charset=");
			if (chsIndex != -1)
			{
				String enc = StringTools.substringAfter(contentType , "charset=");
				if(enc.indexOf(';') != -1)
					enc = StringTools.substringBefore(enc , ";");
				return enc.trim();
			}
		}
		return null;
	}
}

