/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.workpool.apps;
import info.olteanu.interfaces.*;
import info.olteanu.utils.workpool.*;
import info.olteanu.utils.*;
import info.olteanu.utils.workpool.impl.*;
import java.util.*;

public class LoadBalancingBlockStringFilter
implements BlockStringFilter
{
	private final Workpool<BlockStringFilter, RuntimeException> workpool;
	private final int chunkSize;
	public LoadBalancingBlockStringFilter(int chunkSize, BlockStringFilter[] filters)
	{
		this.chunkSize = chunkSize;
		this.workpool = new MultiThreadedWorkpoolImpl<BlockStringFilter, RuntimeException>("LoadBalancingBlockStringFilter wp", filters , true);
		this.workpool.start();
	}
	
	public String filter(String input)
	{
		try
		{
			SingleFilterTask task = new SingleFilterTask(input);
			workpool.executeTask(task);
			return task.output;
		}
		catch (InterruptedException e)
		{
			throw new RuntimeException("[InterruptedException]", e);
		}
	}
	
	public String[] filter(String[] input)
	{
		try
		{
			Vector<Task> tasks = new Vector<Task>();
			String[] output = new String[input.length];
			for (int i = 0; i < input.length; i += chunkSize)
			{
				BlockFilterTask t = new BlockFilterTask(input, output , i , Math.min(input.length - i , chunkSize));
				workpool.add(t);
				tasks.add(t);
			}
			workpool.waitForCompletion(tasks);
			return output;
		}
		catch (InterruptedException e)
		{
			throw new RuntimeException("[InterruptedException]", e);
		}
	}
	
	private static abstract class FilterTask extends Task<BlockStringFilter, RuntimeException>
	{
		// nothing to write here
	}
	
	private static class SingleFilterTask extends FilterTask
	{
		private final String input;
		public String output;
		
		SingleFilterTask(String input)
		{
			this.input = input;
		}
		public void execute(BlockStringFilter resource)
		{
			output = resource.filter(input);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	
	private static class BlockFilterTask extends FilterTask
	{
		private final String[] input;
		private final String[] output;
		private final int start, len;
		
		BlockFilterTask(String[] input, String[] output , int start , int len)
		{
			this.input = input;
			this.output = output;
			this.start = start;
			this.len = len;
		}
		public void execute(BlockStringFilter resource)
		{
			String[] myOutput = resource.filter(StringTools.select(input, start , start + len - 1));
			System.arraycopy(myOutput , 0 , output , start , len);
		}
		public boolean putInOutput()
		{
			return true;
		}
	}
	
	protected void finalize() throws Throwable
	{
		super.finalize();
		this.workpool.stop();
	}
}
