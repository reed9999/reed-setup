/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.workpool;
import java.util.*;
import info.olteanu.utils.lang.*;

// Output set behavior:
//   waitForCompletion, waitForCompletionNE - they doesn't clean the output set.
//      One should use either getOutput(true) after it, or should make tasks that
//      are not queued in the output queue
//   add - stalls if the input queue is full and it is not infinite
//   waitFor(task), waitForCompletion(taskSet),  waitForCompletionNE(taskSet) - they remove
//         the tasks that are waited for from the output queue. The tasks are required to allow enquewing
//   getOutput(false), getOutputNE(false) - they don't clear the output set
//   getOutput(true), getOutputNE(true) - they clear the output set. Even if getOutput(true) throws exception
//         the output set will be emptly
//   getOutputItem - removes the item from the output set, even if it throws exception
//   getOutputItemNE - removes the item from the output set
public interface Workpool<Resource , E extends Exception>
{
	// wait for execution to finish (typical implementation: add followed by waitFor)
	// returns the task
	// assert: x == wp.executeTask(x)
	// typical implementation: 	add(task);waitFor(task);return task;
	public Task<Resource,E> executeTask(Task<Resource,E> task)
	throws InterruptedException , E;
	
	// add it to the queue
	public void add(Task<Resource,E> task);
	
	// are there any more tasks in the execution queue?
	public boolean hasMore();
	
	// wait for all tasks to be executed
	public void waitForCompletion()
	throws InterruptedException , E, RuntimeException;
	
	// wait for all tasks to be executed, no exception thrown.
	// The user must check the error status for each task
	// returns true if all tasks were executed without an exception thrown
	public boolean waitForCompletionNE()
	throws InterruptedException;
	
	// wait for all tasks in the set to be executed
	public void waitForCompletion(Collection<Task> tasks)
	throws InterruptedException , E, RuntimeException;

	// wait for all tasks in the set to be executed, no exception thrown.
	// The user must check the error status for each task
	// returns true if all tasks were executed without an exception thrown
	public boolean waitForCompletionNE(Collection<Task> tasks)
	throws InterruptedException;
	
	// get the set of tasks already executed. Don't wait. Throw exceptions
	public List<Task<Resource,E>> getOutput(boolean clear)
	throws E , RuntimeException;
	
	// get the set of tasks already executed. Don't wait, don't throw exceptions
	public List<Task<Resource,E>> getOutputNE(boolean clear);
	
	// get one item from the set of tasks already executed. Or wait if none are in the queue
	public Task<Resource,E> getOutputItem()
	throws InterruptedException, E, RuntimeException;

	// get one item from the set of tasks already executed. Or wait if none are in the queue
	// No exception is thrown
	public Task<Resource,E> getOutputItemNE()
	throws InterruptedException;
	
	
	// wait for a specific task to be executed
	public void waitFor(Task<Resource,E> task)
	throws InterruptedException, E, RuntimeException;
	
	// get the last exception thrown during execution
	public Exception getLastException(boolean clear);
	
	public boolean isRunning();
	
	// start the workpool (new tasks can be added before)
	public void start();
	
	// stop the workpool (still, new tasks can be added)
	public void stop();
}
