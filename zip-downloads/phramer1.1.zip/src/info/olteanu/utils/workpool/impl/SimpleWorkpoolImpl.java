/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.workpool.impl;
import info.olteanu.utils.workpool.*;
import java.util.*;

// TODO: check exception behavior for waitForCompletion/waitForCompletionNE

// Ideally, use only executeTask method
// And don't expect multi-threading. Tasks are executed locally
// To be used in multi-client scenarios only, to share resources
public class SimpleWorkpoolImpl<Resource, E extends Exception> implements Workpool<Resource, E>
{
	public static boolean SHOW_EXCEPTION = true;
	
	private E lastTaskException;// used by waitForCompletion() only
	private RuntimeException lastTaskRuntimeException;// used by waitForCompletion() only
	private Exception lastExceptionAll; // used by getLastException(..) only
	private final ArrayList<Resource> resourceStack;
	private ArrayList<Task<Resource,E>> outputSet;
	private final Object mutex , notifyNonEmptyOutput , resourceLock , resourcesAvailable , notifyAllResourcesAvailable;
	private final int resourceCount;
	public SimpleWorkpoolImpl(Resource[] resources)
	{
		outputSet = new ArrayList<Task<Resource, E>>();
		resourceStack = new ArrayList<Resource>(resources.length);
		resourceCount = resources.length;
		for (Resource r: resources)
			resourceStack.add(r);
		
		this.lastExceptionAll = null;
		
		mutex = new Object();
		notifyNonEmptyOutput = new Object();
		resourceLock = new Object();
		resourcesAvailable = new Object();
		notifyAllResourcesAvailable = new Object();
	}
	
	
	public Task<Resource,E> executeTask(Task<Resource,E> task)
	throws InterruptedException, E
	{
		Resource r = getResource();
		try
		{
			task.execute(r);
			return task;
		}
		catch (Exception e)
		{
			setException(e);
			if (e instanceof RuntimeException)
			{
				task.__setRuntimeException((RuntimeException)e);
				throw (RuntimeException)e;
			}
			else
			{
				task.__setException((E)e);
				throw (E)e;
			}
		}
		finally
		{
			releaseResource(r);
		}
	}
	
	// add it to the queue
	public void add(Task<Resource,E> task)
	{
		Resource r;
		try
		{
			r = getResource();
		}
		catch (InterruptedException e)
		{
			throw new RuntimeException("Interrupted Workpool.add()" , e);
		}
		
		try
		{
			task.execute(r);
		}
		catch (Exception e)
		{
			setException(e);
			if (e instanceof RuntimeException)
			{
				task.__setRuntimeException((RuntimeException)e);
				lastTaskRuntimeException = (RuntimeException)e;
			}
			else
			{
				task.__setException((E)e);
				lastTaskException = (E)e;
			}
		}
		finally
		{
			releaseResource(r);
		}
		releaseResource(r);
		if (task.putInOutput())
			putInOutput(task);
	}
	
	
	
	// are there any more tasks in the execution queue?
	public boolean hasMore()
	{
		// executed directly
		return false;
	}
	
	// wait for all tasks to be executed
	public void waitForCompletion()
	throws InterruptedException , E, RuntimeException
	{
		while (true)
			synchronized (notifyAllResourcesAvailable)
			{
				synchronized (resourceLock)
				{
					//n exception throw add-on
					if (lastTaskRuntimeException != null)
					{
						RuntimeException re = lastTaskRuntimeException;
						lastTaskRuntimeException = null;
						lastTaskException = null;
						throw re;
					}
					if (lastTaskException != null)
					{
						E e = lastTaskException;
						lastTaskRuntimeException = null;
						lastTaskException = null;
						throw e;
					}
					//u exception throw add-on
					
					if (resourceStack.size() == resourceCount)
						return;
				}
				notifyAllResourcesAvailable.wait();
			}
	}
	
	// wait for all tasks to be executed, no exception thrown.
	// The user must check the error status for each task
	// returns true if all tasks were executed without an exception thrown
	public boolean waitForCompletionNE()
	throws InterruptedException
	{
		boolean allGood = true;
		while (true)
			synchronized (notifyAllResourcesAvailable)
			{
				synchronized (resourceLock)
				{
					if (resourceStack.size() == resourceCount)
					{
						//n exception throw add-on
						if (lastTaskRuntimeException != null || lastTaskException != null)
							allGood = false;
						//u exception throw add-on
						
						return allGood;
					}
				}
				notifyAllResourcesAvailable.wait();
			}
	}
	
	// wait for all tasks in the set to be executed
	public void waitForCompletion(Collection<Task> tasks)
	throws InterruptedException , E, RuntimeException
	{
		// from MultitThreadedWorkpoolImpl
		for (Task t : tasks)
			waitFor(t);
	}
	
	// wait for all tasks in the set to be executed, no exception thrown.
	// The user must check the error status for each task
	// returns true if all tasks were executed without an exception thrown
	public boolean waitForCompletionNE(Collection<Task> tasks)
	throws InterruptedException
	{
		// from MultitThreadedWorkpoolImpl
		boolean allGood = true;
		for (Task t : tasks)
			try
			{
				waitFor(t);
			}
			catch (RuntimeException e)
			{
				allGood = false;
			}
			catch (Exception e)
			{
				if (e instanceof InterruptedException)
					throw (InterruptedException)e;
				allGood = false;
			}
		return allGood;
	}
	
	// get the set of tasks already executed. Don't wait. Throw exceptions
	public List<Task<Resource,E>> getOutput(boolean clear)
	throws E , RuntimeException
	{
		if (clear)
			synchronized (mutex)
			{
				ArrayList<Task<Resource,E>> o = outputSet;
				outputSet = new ArrayList<Task<Resource,E>>();
				checkException(o);
				return o;
			}
		else
			synchronized (mutex)
			{
				checkException(outputSet);
				return (List<Task<Resource,E>>)outputSet.clone();
			}
	}
	
	
	// get the set of tasks already executed. Don't wait, don't throw exceptions
	public List<Task<Resource,E>> getOutputNE(boolean clear)
	{
		// from MultitThreadedWorkpoolImpl
		if (clear)
			synchronized (mutex)
			{
				ArrayList<Task<Resource,E>> o = outputSet;
				outputSet = new ArrayList<Task<Resource,E>>();
				return o;
			}
		else
			synchronized (mutex)
			{
				return (List<Task<Resource,E>>)outputSet.clone();
			}
	}
	
	// get one item from the set of tasks already executed. Or wait if none are in the queue
	public Task<Resource,E> getOutputItem()
	throws InterruptedException, E, RuntimeException
	{
		// from MultitThreadedWorkpoolImpl
		Task<Resource, E> o = getOutputItemNE();
		checkException(o);
		return o;
	}
	
	// get one item from the set of tasks already executed. Or wait if none are in the queue
	// No exception is thrown
	public Task<Resource,E> getOutputItemNE()
	throws InterruptedException
	{
		// from MultitThreadedWorkpoolImpl
		while (true)
			synchronized (notifyNonEmptyOutput)
			{
				synchronized (mutex)
				{
					if (outputSet.size() > 0)
					{
						Task<Resource,E> o = outputSet.get(0);
						outputSet.remove(0);
						return o;
					}
				}
				notifyNonEmptyOutput.wait();
			}
	}
	
	
	// wait for a specific task to be executed
	public void waitFor(Task<Resource,E> task)
	throws InterruptedException, E, RuntimeException
	{
		// from MultitThreadedWorkpoolImpl
		while (true)
			synchronized (notifyNonEmptyOutput)
			{
				synchronized (mutex)
				{
					if (outputSet.contains(task))
					{
						outputSet.remove(task);
						checkException(task);
						return;
					}
				}
				
				notifyNonEmptyOutput.wait();
			}
	}
	
	// get the last exception thrown during execution
	public Exception getLastException(boolean clear)
	{
		// from MultitThreadedWorkpoolImpl
		synchronized (mutex)
		{
			Exception e = lastExceptionAll;
			if (clear)
				lastExceptionAll = null;
			return e;
		}
	}
	
	public boolean isRunning()
	{
		return true;
	}
	
	// start the workpool (new tasks can be added before)
	public void start()
	{}
	
	// stop the workpool (still, new tasks can be added)
	public void stop()
	{}
	
	
	private Resource getResource() throws InterruptedException
	{
		while (true)
			synchronized (resourcesAvailable)
			{
				synchronized (resourceLock)
				{
					if (resourceStack.size() > 0)
					{
						int idx = resourceStack.size() - 1;
						Resource r = resourceStack.get(idx);
						resourceStack.remove(idx);
						return r;
					}
				}
				resourcesAvailable.wait();
			}
	}
	
	private void releaseResource(Resource r)
	{
		synchronized (resourcesAvailable)
		{
			synchronized (resourceLock)
			{
				resourceStack.add(r);
			}
			resourcesAvailable.notify();
		}
		
		// check if they are all available, and notify threads that wait for completion
		synchronized (notifyAllResourcesAvailable)
		{
			synchronized (resourceLock)
			{
				if (resourceStack.size() == resourceCount)
					notifyAllResourcesAvailable.notifyAll();
			}
		}
	}
	private void putInOutput(Task<Resource, E> task)
	{
		synchronized (notifyNonEmptyOutput)
		{
			synchronized (mutex)
			{
				outputSet.add(task);
			}
			notifyNonEmptyOutput.notifyAll();
		}
	}
	
	
	// from MultitThreadedWorkpoolImpl
	private void checkException(List<Task<Resource, E>> o)
	throws E,RuntimeException
	{
		for (Task<Resource, E> t : o)
			checkException(t);
	}
	// from MultitThreadedWorkpoolImpl
	private void checkException(Task<Resource, E> t)
	throws E,RuntimeException
	{
		if (t.getRuntimeException() != null)
			throw t.getRuntimeException();
		if (t.getException() != null)
			throw t.getException();
	}
	
	// from MultitThreadedWorkpoolImpl
	private void setException(Exception e)
	{
		if (SHOW_EXCEPTION)
			e.printStackTrace();
		
		synchronized (mutex)
		{
			lastExceptionAll = e;
		}
	}
}
