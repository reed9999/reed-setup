/* Copyright (c) 2006-2009, Marian Olteanu <marian_DOT_olteanu_AT_gmail_DOT_com>
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice, this list
 of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.
 - Neither the name of the University of Texas at Dallas nor the names of its
 contributors may be used to endorse or promote products derived from this
 software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package info.olteanu.utils.workpool.impl;
import info.olteanu.utils.workpool.*;
import java.io.*;
import java.util.*;
import info.olteanu.utils.lang.*;

// TODO: check exception behavior for waitForCompletion/waitForCompletionNE

// behaves as a thread pool
public class MultiThreadedWorkpoolImpl<Resource, E extends Exception> implements Workpool<Resource, E>
{
	public static boolean LOGGING = false;
	public static boolean SHOW_EXCEPTION = true;
	private static PrintStream LOG = null;
	static
	{
//		try
//		{
		if (LOGGING)
		//LOG = new PrintStream(new FileOutputStream("MultiThreadedWorkpoolImpl.log"));
			LOG = System.err;
//		}
//		catch ( IOException e)
//		{
//			e.printStackTrace();
//		}
	}
	
	protected void finalize()
    {
        stop();
    }
	private boolean stopActivity = false;
	
	private class WorkerThread extends Thread
	{
		private final Resource r;
		private final int id;
		private WorkerThread(Resource w , int id)
		{
			this.r = w;
			this.id = id;
		}
		public void run()
		{
			try
			{
				while (true)
				{
					//  get a new task
					Task<Resource,E> task = null;
					while (true)
						synchronized (notifyNotEmpty)
						{
							if (stopActivity)
                            {
                                if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": stop");
                                return;
                            }
							
							if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": notifyNotEmpty aquired");
							synchronized (mutex)
							{
								if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": MUTEX aquired");
								if (inputSet.size() > 0)
								{
									if (starvationSafe)
									{
										if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": Task exists. Break.  " + inputSet.firstElement());
										task = inputSet.firstElement();
										inputSet.remove(0);
									}
									else
									{
										if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": Task exists. Break.  " + inputSet.lastElement());
										task = inputSet.lastElement();
										inputSet.setSize(inputSet.size() - 1);
									}
									if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": MUTEX released BRK");
									if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": notifyNotEmpty released BRK");
									break;
								}
								if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": MUTEX released");
							}
							if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": no task. Wait...");
							// else wait to be notified
							if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": Wait on notifyNotEmpty...");
							notifyNotEmpty.wait();
						}
					
					if (maxQueueLength > 0)
						synchronized (notifyQueueAdd)
						{
							queueAddLength--;
							notifyQueueAdd.notifyAll();// what about notify?
						}
					
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": Do execution");
					// process task
					try
					{
						if (LOGGING) LOG.println("[>" + id + ">]  " + task);
						task.execute(r);
						if (LOGGING) LOG.println("[<" + id + "<]  " + task);
					}
					catch (Exception e)
					{
						if (e instanceof RuntimeException)
						{
							task.__setRuntimeException((RuntimeException)e);
							lastTaskRuntimeException = (RuntimeException)e;
						}
						else
						{
							task.__setException((E)e);
							lastTaskException = (E)e;
						}
						setException(e);
					}
					
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": Execution finished  " + task);
					
					// decrease counter and add to the output set
					synchronized (notifyNonEmptyOutput)
					{
						synchronized (notifyEmpty)
						{
							synchronized (mutex)
							{
								if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": MUTEX aquired  " + task);
								// null output is not added to the output
								if (task.putInOutput())
								{
									outputSet.add(task);
									notifyNonEmptyOutput.notifyAll();// required
								}
								
								cntElementsToProcess--;
								// notify, if required
								if (cntElementsToProcess == 0)
									notifyEmpty.notifyAll(); // required
								if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": MUTEX released " + task);
							}
						}
					}
				}
			}
			catch (InterruptedException e)
			{
				throw new Error();
			}
		}
		
		private void setException(Exception e)
		{
			if (SHOW_EXCEPTION)
				e.printStackTrace();
			
			if (LOGGING)
			{
				LOG.println("[" + new java.util.Date() + "] [" + name + "] Thread " + id + ": Task throwed exception");
				e.printStackTrace(LOG);
			}
			synchronized (mutex)
			{
				if (lastException != null)
					lastException[id] = e;
				lastExceptionAll = e;
			}
		}
	}
	
	
	private E lastTaskException;// used by waitForCompletion() only
	private RuntimeException lastTaskRuntimeException;// used by waitForCompletion() only
	private Exception lastExceptionAll; // used by getLastException(..) only
	private Exception[] lastException;// used by nobody
	private final String name;
	private final Thread[] threads;
	private final boolean starvationSafe;
	private final int maxQueueLength;
	private boolean running;
	// mutex: guards the inputSet, lastException, lastExceptionAll. Never wait on mutex
	// notifyEmpty
	// notifyNotEmpty: wakes up a worker
	// notifyQueueAdd: waits for full queue (Add)
	// lock order: first notifyNE or notifyE , notifyO, then mutex
	private final Object mutex , notifyEmpty , notifyNotEmpty , notifyNonEmptyOutput;
	private final Object notifyQueueAdd;
	private int queueAddLength;
	private int cntElementsToProcess;
	private Vector<Task<Resource,E>> inputSet;
	private Vector<Task<Resource,E>> outputSet;
	
	public MultiThreadedWorkpoolImpl(Resource[] workers)
	{
		this(null, workers);
	}
	public MultiThreadedWorkpoolImpl(Resource[] workers , int maxQueueLength)
	{
		this(null, workers , maxQueueLength);
	}
	public MultiThreadedWorkpoolImpl(Resource[] workers , boolean starvationSafe)
	{
		this(null , workers, starvationSafe);
	}
	public MultiThreadedWorkpoolImpl(Resource[] workers , int maxQueueLength , boolean starvationSafe)
	{
		this(null, workers, maxQueueLength , starvationSafe);
	}
	
	
	public MultiThreadedWorkpoolImpl(String name , Resource[] workers)
	{
		this(name, workers, 0);
	}
	public MultiThreadedWorkpoolImpl(String name , Resource[] workers , int maxQueueLength)
	{
		this(name, workers , maxQueueLength , false);
	}
	public MultiThreadedWorkpoolImpl(String name , Resource[] workers , boolean starvationSafe)
	{
		this(name, workers , 0 , starvationSafe);
	}
	public MultiThreadedWorkpoolImpl(String name , Resource[] workers , int maxQueueLength , boolean starvationSafe)
	{
		int threadCount = workers.length;
		this.starvationSafe = starvationSafe;
		this.maxQueueLength = maxQueueLength;
		this.mutex = new Object();
		this.notifyEmpty = new Object();
		this.notifyNotEmpty = new Object();
		this.notifyNonEmptyOutput = new Object();
		this.lastException = new Exception[workers.length];
		this.lastExceptionAll = null;
		this.cntElementsToProcess = 0;
		this.notifyQueueAdd = new Object();
		this.queueAddLength = 0;
		this.inputSet = new Vector<Task<Resource,E>>();
		this.outputSet = new Vector<Task<Resource,E>>();
		this.threads = new Thread[threadCount];
		this.name = name == null ? "<no name>" : name;
		for (int i = 0; i < threads.length; i++)
		{
			threads[i] = new WorkerThread(workers[i] , i);
			if (name == null)
				threads[i].setName("Workpool <no name> * Thread " + i);
			else
				threads[i].setName("Workpool " + name + " * Thread " + i);
			threads[i].setDaemon(true);
		}
		running = false;
	}
	
	public boolean isRunning()
	{
		return running;
	}
	
	public void start()
	{
		if (stopActivity || running)
			throw new IllegalStateException("start() cannot run after start() or after stop()");
		running = true;
		for (int i = 0; i < threads.length; i++)
			threads[i].start();
	}
	public void stop()
    {
        if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] stop");
		running = false;
        stopActivity = true;
        synchronized (notifyNotEmpty)
        {
            notifyNotEmpty.notifyAll();
        }
    }
	
	public void add(Task<Resource,E> task)
	{
		if (maxQueueLength > 0)
			try
			{
				synchronized (notifyQueueAdd)
				{
					if (queueAddLength >= maxQueueLength)
						notifyQueueAdd.wait();
					
					queueAddLength++;
				}
			}
			catch (InterruptedException e)
			{
				throw new RuntimeException("Interrupted Workpool.add()" , e);
			}
		_add(task);
	}
	
	public void _add(Task<Resource,E> task)
	{
		if (LOGGING) LOG.println("Adding a new task: " + task);
		synchronized (notifyNotEmpty)
		{
			synchronized (mutex)
			{
				if (LOGGING) LOG.println("Add: MUTEX aquired  " + task);
				cntElementsToProcess++;
				inputSet.add(task);
				if (LOGGING) LOG.println("There are " + cntElementsToProcess + " tasks to process");
				if (LOGGING) LOG.println("There are " + inputSet.size() + " tasks in the waiting queue");
				notifyNotEmpty.notify();// notify a waiting worker. notifyAll is not required
				if (LOGGING) LOG.println("Add: MUTEX released  " + task);
			}
		}
	}
	
	
	public boolean hasMore()
	{
		synchronized (mutex)
		{
			return cntElementsToProcess > 0;
		}
	}
	
	
	public void waitForCompletion()
	throws InterruptedException, E, RuntimeException
	{
		while (true)
			synchronized (notifyEmpty)
			{
				synchronized (mutex)
				{
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitForCompletion: MUTEX aquired");
					
					//n exception throw add-on
					if (lastTaskRuntimeException != null)
					{
						RuntimeException re = lastTaskRuntimeException;
						lastTaskRuntimeException = null;
						lastTaskException = null;
						throw re;
					}
					if (lastTaskException != null)
					{
						E e = lastTaskException;
						lastTaskRuntimeException = null;
						lastTaskException = null;
						throw e;
					}
					//u exception throw add-on
					
					if (cntElementsToProcess == 0)
						return;
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitForCompletion: MUTEX released");
				}
				if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitForCompletion: wait on notifyEmpty");
				notifyEmpty.wait();
			}
	}
	
	public boolean waitForCompletionNE()
	throws InterruptedException
	{
		boolean allGood = true;
		while (true)
			synchronized (notifyEmpty)
			{
				synchronized (mutex)
				{
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitForCompletionNE: MUTEX aquired");
					//n exception check add-on
					if (lastTaskRuntimeException != null || lastTaskException != null)
						allGood = false;
					//u exception check add-on
					
					if (cntElementsToProcess == 0)
						return allGood;
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitForCompletionNE: MUTEX released");
				}
				if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitForCompletionNE: wait on notifyEmpty");
				notifyEmpty.wait();
			}
	}
	
	
	public void waitForCompletion(Collection<Task> tasks)
	throws InterruptedException , E, RuntimeException
	{
		for (Task t : tasks)
			waitFor(t);
	}
	
	public boolean waitForCompletionNE(Collection<Task> tasks)
	throws InterruptedException
	{
		boolean allGood = true;
		for (Task t : tasks)
			try
			{
				waitFor(t);
			}
			catch (RuntimeException e)
			{
				allGood = false;
			}
			catch (Exception e)
			{
				if (e instanceof InterruptedException)
					throw (InterruptedException)e;
				allGood = false;
			}
		return allGood;
	}
	
	
	
	private void checkException(Vector<Task<Resource, E>> o)
	throws E,RuntimeException
	{
		for (Task<Resource, E> t : o)
			checkException(t);
	}
	
	private void checkException(Task<Resource, E> t)
	throws E,RuntimeException
	{
		if (t.getRuntimeException() != null)
			throw t.getRuntimeException();
		if (t.getException() != null)
			throw t.getException();
	}
	
	
	public Vector<Task<Resource,E>> getOutput(boolean clear)
	throws E,RuntimeException
	{
		if (clear)
			synchronized (mutex)
			{
				Vector<Task<Resource,E>> o = outputSet;
				outputSet = new Vector<Task<Resource,E>>();
				checkException(o);
				return o;
			}
		else
			synchronized (mutex)
			{
				checkException(outputSet);
				return (Vector<Task<Resource,E>>)outputSet.clone();
			}
	}
	
	public Vector<Task<Resource,E>> getOutputNE(boolean clear)
	{
		if (clear)
			synchronized (mutex)
			{
				Vector<Task<Resource,E>> o = outputSet;
				outputSet = new Vector<Task<Resource,E>>();
				return o;
			}
		else
			synchronized (mutex)
			{
				return (Vector<Task<Resource,E>>)outputSet.clone();
			}
	}
	
	
	public void waitFor(Task<Resource,E> task)
	throws InterruptedException, E, RuntimeException
	{
		while (true)
			synchronized (notifyNonEmptyOutput)
			{
				synchronized (mutex)
				{
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitFor: MUTEX aquired  " + task);
					if (outputSet.contains(task))
					{
						outputSet.remove(task);
						checkException(task);
						if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitFor: MUTEX released RET  " + task);
						return;
					}
					if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitFor: MUTEX released" + task);
				}
				
				if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitFor: notifyNonEmptyOutput.wait() " + task);
				notifyNonEmptyOutput.wait();
				if (LOGGING) LOG.println("[" + new java.util.Date() + "] [" + name + "] waitFor: notifyNonEmptyOutput.wait finished " + task);
			}
	}
	
	
	public Task<Resource,E> getOutputItem()
	throws InterruptedException, E, RuntimeException
	{
		Task<Resource, E> o = getOutputItemNE();
		checkException(o);
		return o;
	}
	public Task<Resource,E> getOutputItemNE()
	throws InterruptedException
	{
		while (true)
			synchronized (notifyNonEmptyOutput)
			{
				synchronized (mutex)
				{
					if (outputSet.size() > 0)
					{
						Task<Resource,E> o = outputSet.firstElement();
						outputSet.remove(0);
						return o;
					}
				}
				notifyNonEmptyOutput.wait();
			}
	}
	
	
	public Exception getLastException(boolean clear)
	{
		synchronized (mutex)
		{
			Exception e = lastExceptionAll;
			if (clear)
				lastExceptionAll = null;
			return e;
		}
	}
	
	public Task<Resource,E> executeTask(Task<Resource,E> task)
	throws InterruptedException, E, RuntimeException
	{
		add(task);
		waitFor(task);
		return task;
	}
}
