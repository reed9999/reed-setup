sh scripts/phramer.sh \
-f testfr/decoding-sorted-fast.ini \
-read testfr/realtest2000.fr.lowercased \
-write testfr/realtest2000.fr.lowercased.out \
-compatibility 1.0.5 \
-dl 4 -b 0.025 -ttable-limit 10 -s 50 -x-max-phrase-length 5 -x-level-good-probabilities 2 -threads 2 \
-d 0.44080195220967083 -lm 0.882097432837817 -tm 0.3728345470130269 0.49433049734528384 0.8605642715857179 0.320713515470119 -0.37358127039250716 -w -0.9998702463472661

sh scripts/run.sh org.phramer.tools.BleuScore testfr/realtest2000.en.lowercased testfr/realtest2000.fr.lowercased.out