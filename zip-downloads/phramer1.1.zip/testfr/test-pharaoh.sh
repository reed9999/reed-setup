../pharaoh-v1.2.3/pharaoh \
-f testfr/decoding-pharaoh.ini \
< testfr/realtest2000.fr.lowercased \
> testfr/realtest2000.fr.lowercased.out.pharaoh \
-dl 4 -b 0.025 -ttable-limit 10 -s 50 \
-d 0.44080195220967083 -lm 0.882097432837817 -tm 0.3728345470130269 0.49433049734528384 0.8605642715857179 0.320713515470119 -0.37358127039250716 -w -0.9998702463472661

sh scripts/run.sh org.phramer.tools.BleuScore testfr/realtest2000.en.lowercased testfr/realtest2000.fr.lowercased.out.pharaoh